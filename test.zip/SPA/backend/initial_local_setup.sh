#!/bin/bash

# Updating .env ip address to access postgres from local system
# Get the system's IP address
echo "[INFO] Updating Dockerfile with host ip address..."
HOST_IP=$(hostname -I | awk '{print $1}')

# Set the path to the env.txt file
ENV_FILE_PATH="app/.env"
# Check if pg_hba_conf exists
if [ ! -f "$ENV_FILE_PATH" ]; then
    echo "ERROR: ENV_FILE_PATH not found. Please enter the correct path:"
    read -r ENV_FILE_PATH
    if [ ! -f "$ENV_FILE_PATH" ]; then
        echo "ERROR: Invalid path. Exiting."
        exit 1
    fi
fi
# Specify the variable you want to update
TARGET_VARIABLE="DB_HOST"

# Update the value of the specified variable in the env.txt file
sed -i "s/^$TARGET_VARIABLE=.*/$TARGET_VARIABLE=$HOST_IP/" "$ENV_FILE_PATH"
echo "Host IP from Local Postgres is: $HOST_IP."

echo "[INFO] Updated Dockerfile."
echo ""

echo "[INFO] Updating the configurations of postgres..."
# Check if conf file exist or ask user to enter
pg_hba_conf="/etc/postgresql/16/main/pg_hba.conf"
# Check if pg_hba_conf exists
if [ ! -f "$pg_hba_conf" ]; then
    echo "ERROR: pg_hba_conf not found. Please enter the correct path:"
    read -r pg_hba_conf
    if [ ! -f "$pg_hba_conf" ]; then
        echo "ERROR: Invalid path. Exiting."
        exit 1
    fi
fi

# Lines to add
lines_to_add="# TYPE  DATABASE        USER            ADDRESS                 METHOD
host    all             all             172.16.0.0/12           md5
host    all             all             0.0.0.0           md5
"

# Check if the lines already exist
if grep -q "$lines_to_add" "$pg_hba_conf"; then
    echo "$pg_hba_conf is already updated. No changes made."
else
    # Add lines to the file
    echo "$lines_to_add" | sudo tee -a "$pg_hba_conf" > /dev/null
    echo "$pg_hba_conf file is updated now."
fi


postgresql_conf="/etc/postgresql/16/main/postgresql.conf"
# Check if pg_hba_conf exists
if [ ! -f "$postgresql_conf" ]; then
    echo "ERROR: postgresql_conf not found. Please enter the correct path:"
    read -r postgresql_conf
    if [ ! -f "$postgresql_conf" ]; then
        echo "ERROR: Invalid path. Exiting."
        exit 1
    fi
fi

# String to be added to postgresql.conf
listen_addresses="listen_addresses = '*'"

# Check if the lines already exist
if grep -q "^$listen_addresses" "$postgresql_conf"; then
    echo "$postgresql_conf is already updated. No changes made."
else
    # Add lines to the file
    echo "$listen_addresses" | sudo tee -a "$postgresql_conf" > /dev/null
    echo "$postgresql_ file is updated nowconf."
fi

echo "[INFO] Postgres local setup completed"
echo " "

echo "[INFO] Restarting postgresql server..."
# Restart PostgreSQL
sudo systemctl restart postgresql
echo "PostgreSQL restarted."


# Allow ports using ufw
sudo ufw allow 5432
sudo ufw allow 5433

