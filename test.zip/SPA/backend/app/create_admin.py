from sqlalchemy.orm import Session
from models.admin import Admin
from db.session import get_db

def create_initial_admin():
    print("Starting to create initial admin...")
    db = next(get_db())
    
    # Check if admin already exists
    admin_exists = db.query(Admin).filter(Admin.username == "admin").first()
    
    if not admin_exists:
        # Create admin user
        admin = Admin(
            username="admin",
            email="admin@example.com",
            hashed_password="admin123",  # In a real app, you should hash this password
            is_active=True
        )
        
        db.add(admin)
        db.commit()
        print("Initial admin user created! Username: admin, Password: admin123")
    else:
        print("Admin user already exists")
    
    db.close()

if __name__ == "__main__":
    create_initial_admin() 