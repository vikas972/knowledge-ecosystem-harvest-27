import sys
import os
from pathlib import Path

# Add the parent directory to the Python path
sys.path.append(str(Path(__file__).parent.parent.parent))

from app.db.session import SessionLocal
from app.models.admin import Admin
from app.core.security import get_password_hash

def create_admin(username: str, email: str, password: str):
    db = SessionLocal()
    try:
        # Check if admin already exists
        existing_admin = db.query(Admin).filter(Admin.username == username).first()
        if existing_admin:
            print(f"Admin with username {username} already exists")
            return

        # Create new admin
        hashed_password = get_password_hash(password)
        admin = Admin(
            username=username,
            email=email,
            hashed_password=hashed_password,
            is_active=True
        )
        db.add(admin)
        db.commit()
        print(f"Admin user {username} created successfully")
    except Exception as e:
        print(f"Error creating admin: {str(e)}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python create_admin.py <username> <email> <password>")
        sys.exit(1)
    
    username = sys.argv[1]
    email = sys.argv[2]
    password = sys.argv[3]
    
    create_admin(username, email, password) 