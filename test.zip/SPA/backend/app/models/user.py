from sqlalchemy import Column, ForeignKey, TIMESTAMP, JSON, String, Integer, Boolean, Text
from sqlalchemy.dialects.postgresql import UUID as pgUUID
from sqlalchemy.orm import relationship
from db.base import Base
from sqlalchemy.sql import func
import uuid
from uuid import UUID as pyUUID

class User(Base):
    __tablename__ = 'users'
    userId = Column(pgUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String(255), unique=True, nullable=False)
    is_deleted = Column(Boolean, default=False)
    createdAt = Column(TIMESTAMP, default=func.now())
    updatedAt = Column(TIMESTAMP, default=func.now(), onupdate=func.now())
    
    files = relationship("FileMetadata", back_populates="user")
    
 