from sqlalchemy import Column, ForeignKey, TIMESTAMP, JSON, String, Integer, Boolean, Text
from sqlalchemy.dialects.postgresql import UUID as pgUUID
from sqlalchemy.orm import relationship
from db.base import Base
from sqlalchemy.sql import func
import uuid
from uuid import UUID as pyUUID

class OCRInfo(Base):
    __tablename__ = "ocr_info"
    id = Column(Integer, primary_key=True, autoincrement=True)
    fileId = Column(pgUUID(as_uuid=True), ForeignKey('file_metadata.fileId'))
    totalPages = Column(Integer, nullable=False)
    completedPages = Column(Integer, nullable=False)
    errorPages = Column(Integer, nullable=False)
    is_deleted = Column(Boolean, default=False)
    createdAt = Column(TIMESTAMP, default=func.now())
    updatedAt = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    file = relationship("FileMetadata", back_populates="ocr_info")

class OCROutputs(Base):
    __tablename__ = "ocr_outputs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    fileId = Column(pgUUID(as_uuid=True), ForeignKey('file_metadata.fileId'))
    pageNumber = Column(Integer, nullable=False)
    pageText = Column(Text, nullable=False)
    errorMsg = Column(Text, nullable=True)
    isCompleted = Column(Boolean, default=False)    
    is_deleted = Column(Boolean, default=False)
    createdAt = Column(TIMESTAMP, default=func.now())
    updatedAt = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    file = relationship("FileMetadata", back_populates="ocr_outputs")

   