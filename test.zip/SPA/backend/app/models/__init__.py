# Import base models first
from .user import User
from .admin import Admin

# Then import other models
from .ocr.ocr_records import OCRInfo, OCROutputs
from .file_processing.file_record import FileMetadata, FileWorkflowTracker
from .generator.requirement import RequirementData
from .generator.scenario import ScenarioOutput
from .generator.test_case import TestCases
from .generator.test_data import TestData
from .generator.test_scripts import TestScripts
from .use_case.usecase_records import UsecaseMetadata