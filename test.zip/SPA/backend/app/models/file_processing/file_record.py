from sqlalchemy import Column, ForeignKey, TIMESTAMP, JSON, String, Integer, Boolean, Text
from sqlalchemy.dialects.postgresql import UUID as pgUUID
from sqlalchemy.orm import relationship
from db.base import Base
from sqlalchemy.sql import func
import uuid
from uuid import UUID as pyUUID

class FileMetadata(Base):
    __tablename__ = 'file_metadata'
    fileId = Column(pgUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    usecaseId = Column(Integer, ForeignKey('usecase_metadata.usecaseId'))
    fileName = Column(String(255), nullable=False)
    fileLink = Column(String(255), nullable=False)
    userId = Column(pgUUID(as_uuid=True), ForeignKey('users.userId'))
    documentType = Column(String(255), nullable=True)
    documentFormat = Column(String(255), nullable=True)
    businessDomain = Column(String(255), nullable=True)
    additionalContext = Column(Text, nullable=True)
    createdAt = Column(TIMESTAMP, default=func.now())
    updatedAt = Column(TIMESTAMP, default=func.now(), onupdate=func.now())
    is_deleted = Column(Boolean, default=False)

    user = relationship("User", back_populates="files")
    usecase = relationship("UsecaseMetadata", back_populates="files")
    workflow_trackers = relationship("FileWorkflowTracker", back_populates="file")
    ocr_info = relationship("OCRInfo", back_populates="file")
    ocr_outputs = relationship("OCROutputs", back_populates="file")
    requirements = relationship("RequirementData", back_populates="file")
    scenarios = relationship("ScenarioOutput", back_populates="file")
    test_cases = relationship("TestCases", back_populates="file")
    test_data = relationship("TestData", back_populates="file")
    test_scripts = relationship("TestScripts", back_populates="file")

 
class FileWorkflowTracker(Base):
    __tablename__ = "file_workflow_tracker"
    fileId = Column(pgUUID(as_uuid=True), ForeignKey('file_metadata.fileId'), primary_key=True)
    text_extraction = Column(String(50), default="Not Started")
    requirement_generation = Column(String(50), default="Not Started")
    scenario_generation = Column(String(50), default="Not Started")
    test_case_generation = Column(String(50), default="Not Started")
    test_data_generation = Column(String(50), default="Not Started")
    test_script_generation = Column(String(50), default="Not Started")
    error_msg = Column(Text, nullable=True)
    is_deleted = Column(Boolean, default=False)

    file = relationship("FileMetadata", back_populates="workflow_trackers")

