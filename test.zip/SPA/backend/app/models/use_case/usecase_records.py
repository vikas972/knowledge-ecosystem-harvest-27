from sqlalchemy import Column, ForeignKey, TIMESTAMP, JSON, String, Integer, Boolean, Text
from sqlalchemy.dialects.postgresql import UUID as pgUUID
from sqlalchemy.orm import relationship
from db.base import Base
from sqlalchemy.sql import func
import uuid
from uuid import UUID as pyUUID

class UsecaseMetadata(Base):
    __tablename__ = "usecase_metadata"
    usecaseId = Column(Integer, primary_key=True, index=True, autoincrement=True)
    usecaseName = Column(String, nullable=False)
    text_extraction = Column(String(50), default="Not Started")
    requirement_generation = Column(String(50), default="Not Started")
    scenario_generation = Column(String(50), default="Not Started")
    test_case_generation = Column(String(50), default="Not Started")
    test_data_generation = Column(String(50), default="Not Started")
    test_script_generation = Column(String(50), default="Not Started")
    is_deleted = Column(Boolean, default=False)
    createdAt = Column(TIMESTAMP, default=func.now())
    updatedAt = Column(TIMESTAMP, default=func.now(), onupdate=func.now())
    product=Column(String(50), nullable=False)
    sub_product=Column(String(50), nullable=False)
    domain=Column(String(50), nullable=False)

    files = relationship("FileMetadata", back_populates="usecase")

