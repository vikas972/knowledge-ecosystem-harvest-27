import uuid
from sqlalchemy import Column, ForeignKey, TIMESTAMP, Integer, Boolean, Text, String
from sqlalchemy.dialects.postgresql import UUID as pgUUID
from uuid import UUID as pyUUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from db.base import Base

class RequirementData(Base):
    __tablename__ = "requirement_data"
    fileId = Column(pgUUID(as_uuid=True), ForeignKey('file_metadata.fileId'))
    requirementId = Column(pgUUID(as_uuid=True), primary_key=True)
    displayId = Column(Integer, nullable=False)
    requirementName = Column(String, nullable=False)
    isCompleted = Column(Boolean, default=False)
    isScenarioGenerated = Column(Boolean, default=False)
    errorMessage = Column(Text, nullable=True)
    requirementJson = Column(Text, nullable=True)
    is_deleted = Column(Boolean, default=False)
    createdAt = Column(TIMESTAMP, default=func.now())
    updatedAt = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    file = relationship("FileMetadata", back_populates="requirements")
    scenarios = relationship("ScenarioOutput", back_populates="requirement")
    test_scripts = relationship("TestScripts", back_populates="requirement")

 