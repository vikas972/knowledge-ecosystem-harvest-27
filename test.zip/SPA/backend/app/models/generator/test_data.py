from sqlalchemy import Column, ForeignKey, TIMESTAMP, JSON, String, Integer, Boolean, Text
from sqlalchemy.dialects.postgresql import UUID as pgUUID
from sqlalchemy.orm import relationship
from db.base import Base
from sqlalchemy.sql import func
import uuid
from uuid import UUID as pyUUID

class TestData(Base):
    __tablename__ = 'test_data'
    fileId = Column(pgUUID(as_uuid=True), ForeignKey('file_metadata.fileId'))
    testCaseId = Column(pgUUID(as_uuid=True), ForeignKey('test_cases.testCaseId'))
    testDataId = Column(pgUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    isCompleted = Column(Boolean, default=False)
    errorMessage = Column(Text, nullable=True)
    testDataJson = Column(JSON, nullable=False)
    is_deleted = Column(Boolean, default=False)
    createdAt = Column(TIMESTAMP, default=func.now())
    updatedAt = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    file = relationship("FileMetadata", back_populates="test_data")
    test_case = relationship("TestCases", back_populates="test_data")

  