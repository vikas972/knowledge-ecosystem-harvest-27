from sqlalchemy import Column, ForeignKey, String, TIMESTAMP, JSON, Text, Integer, Boolean
from sqlalchemy.dialects.postgresql import UUID as pgUUID
from sqlalchemy.orm import relationship
from db.base import Base
from sqlalchemy.sql import func
import uuid
from uuid import UUID as pyUUID

class ScenarioOutput(Base):
    __tablename__ = 'scenario_output'
    fileId = Column(pgUUID(as_uuid=True), ForeignKey('file_metadata.fileId'))
    scenarioId = Column(pgUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    displayId = Column(Integer, nullable=False)
    requirementId = Column(pgUUID(as_uuid=True), ForeignKey('requirement_data.requirementId'))
    isCompleted = Column(Boolean, default=False)
    isTestcasesGenerated = Column(Boolean, default=False)
    errorMessage = Column(Text, nullable=True)
    outputJson = Column(JSON, nullable=False)
    is_deleted = Column(Boolean, default=False)
    createdAt = Column(TIMESTAMP, default=func.now())
    updatedAt = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    file = relationship("FileMetadata", back_populates="scenarios")
    requirement = relationship("RequirementData", back_populates="scenarios")
    test_cases = relationship("TestCases", back_populates="scenario")
    test_scripts = relationship("TestScripts", back_populates="scenario")

