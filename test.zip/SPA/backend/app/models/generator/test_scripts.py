from sqlalchemy import Column, ForeignKey, TIMESTAMP, JSON, String, Integer, Boolean, Text
from sqlalchemy.dialects.postgresql import UUID as pgUUID
from sqlalchemy.orm import relationship
from db.base import Base
from sqlalchemy.sql import func
import uuid
from uuid import UUID as pyUUID

class TestScripts(Base):
    __tablename__ = 'test_scripts'
    fileId = Column(pgUUID(as_uuid=True), ForeignKey('file_metadata.fileId'))
    requirementId = Column(pgUUID(as_uuid=True), ForeignKey('requirement_data.requirementId'))
    scenarioId = Column(pgUUID(as_uuid=True), ForeignKey('scenario_output.scenarioId'))
    testCaseId = Column(pgUUID(as_uuid=True), ForeignKey('test_cases.testCaseId'))
    testScriptId = Column(pgUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    displayId = Column(Integer, nullable=False)
    isCompleted = Column(Boolean, default=False)
    errorMessage = Column(Text, nullable=True)
    testScriptJson = Column(JSON, nullable=False)
    is_deleted = Column(Boolean, default=False)
    createdAt = Column(TIMESTAMP, default=func.now())
    updatedAt = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    file = relationship("FileMetadata", back_populates="test_scripts")
    requirement = relationship("RequirementData", back_populates="test_scripts")
    scenario = relationship("ScenarioOutput", back_populates="test_scripts")
    test_case = relationship("TestCases", back_populates="test_scripts") 