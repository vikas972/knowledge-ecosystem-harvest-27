from sqlalchemy import Column, ForeignKey, String, TIMESTAMP, JSON, Text, Integer, Boolean
from sqlalchemy.dialects.postgresql import UUID as pgUUID
from sqlalchemy.orm import relationship
from db.base import Base
from sqlalchemy.sql import func
import uuid
from uuid import UUID as pyUUID

class TestCases(Base):
    __tablename__ = 'test_cases'
    fileId = Column(pgUUID(as_uuid=True), ForeignKey('file_metadata.fileId'))
    scenarioId = Column(pgUUID(as_uuid=True), ForeignKey('scenario_output.scenarioId'))
    testCaseId = Column(pgUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    displayId = Column(Integer, nullable=False)
    isCompleted = Column(Boolean, default=False)
    isTestDataGenerated = Column(Boolean, default=False)    
    errorMessage = Column(Text, nullable=True)
    testJson = Column(JSON, nullable=False)
    is_deleted = Column(Boolean, default=False)
    createdAt = Column(TIMESTAMP, default=func.now())
    updatedAt = Column(TIMESTAMP, default=func.now(), onupdate=func.now())

    file = relationship("FileMetadata", back_populates="test_cases")
    scenario = relationship("ScenarioOutput", back_populates="test_cases")
    test_data = relationship("TestData", back_populates="test_case")
    test_scripts = relationship("TestScripts", back_populates="test_case")

