"""
Background Task Management Utilities

This module provides functions and classes to limit and manage background tasks 
in the FastAPI application, especially for API calls to external services.
"""

import asyncio
import logging
from fastapi import BackgroundTasks
from typing import Callable, Any, List, Dict
from functools import wraps
from concurrent.futures import ThreadPoolExecutor
from threading import BoundedSemaphore, Lock
import time

from app.core.config import PFAssetServiceConfigs

# Configure logger
logger = logging.getLogger(__name__)
if not logger.handlers:
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    logger.setLevel(logging.INFO)

# Load configuration
MAX_CONCURRENT_TASKS = PFAssetServiceConfigs.MAX_CONCURRENT_TASKS
TASK_QUEUE_TIMEOUT = PFAssetServiceConfigs.TASK_QUEUE_TIMEOUT

# Global thread pool for executing background tasks
executor = ThreadPoolExecutor(max_workers=MAX_CONCURRENT_TASKS)

# Semaphore to control concurrent access
task_semaphore = BoundedSemaphore(MAX_CONCURRENT_TASKS)

# Track active tasks
_task_count_lock = Lock()
_active_tasks = 0
_task_queue: List[Dict[str, Any]] = []

def get_active_task_count() -> int:
    """
    Get the current number of active background tasks.
    
    Returns:
        int: Number of active tasks
    """
    with _task_count_lock:
        return _active_tasks

def get_task_queue_length() -> int:
    """
    Get the current length of the task queue.
    
    Returns:
        int: Number of tasks waiting in the queue
    """
    with _task_count_lock:
        return len(_task_queue)

def add_limited_task(background_tasks: BackgroundTasks, func: Callable, *args, **kwargs) -> None:
    """
    Add a task to the background tasks with concurrency limiting.
    If the maximum number of concurrent tasks is reached, the task is queued.
    
    Args:
        background_tasks (BackgroundTasks): FastAPI BackgroundTasks object
        func (Callable): The function to execute
        *args, **kwargs: Arguments to pass to the function
    """
    # Add the wrapper function to background tasks
    background_tasks.add_task(_execute_limited_task, func, *args, **kwargs)
    
def _execute_limited_task(func: Callable, *args, **kwargs) -> Any:
    """
    Execute a task with concurrency limiting.
    
    Args:
        func (Callable): The function to execute
        *args, **kwargs: Arguments to pass to the function
        
    Returns:
        Any: The result of the function
    """
    # Make a single global declaration at the beginning of the function
    global _active_tasks
    
    task_name = func.__name__
    logger.info(f"Preparing to execute task: {task_name}")
    logger.info(f"Current active tasks: {get_active_task_count()}/{MAX_CONCURRENT_TASKS}")
    
    # Try to acquire the semaphore
    acquired = task_semaphore.acquire(blocking=True, timeout=TASK_QUEUE_TIMEOUT)
    if not acquired:
        logger.warning(f"Task semaphore acquisition timeout after {TASK_QUEUE_TIMEOUT}s for {task_name}. Forcing execution.")
    
    # Increment active task counter
    with _task_count_lock:
        _active_tasks += 1
        current_tasks = _active_tasks
    
    logger.info(f"Starting task: {task_name}. Active tasks: {current_tasks}/{MAX_CONCURRENT_TASKS}")
    
    try:
        # Execute the task
        result = func(*args, **kwargs)
        logger.info(f"Task completed: {task_name}")
        return result
    except Exception as e:
        logger.error(f"Error in task {task_name}: {str(e)}")
        raise
    finally:
        # Decrement counter and release semaphore
        with _task_count_lock:
            _active_tasks -= 1
        
        task_semaphore.release()
        logger.info(f"Released semaphore. Active tasks: {get_active_task_count()}/{MAX_CONCURRENT_TASKS}")

# Async version for coroutines
async def add_limited_async_task(background_tasks: BackgroundTasks, func: Callable, *args, **kwargs) -> None:
    """
    Add an async task to the background tasks with concurrency limiting.
    
    Args:
        background_tasks (BackgroundTasks): FastAPI BackgroundTasks object
        func (Callable): The async function to execute
        *args, **kwargs: Arguments to pass to the function
    """
    background_tasks.add_task(_execute_limited_async_task, func, *args, **kwargs)

async def _execute_limited_async_task(func: Callable, *args, **kwargs) -> Any:
    """
    Execute an async task with concurrency limiting.
    
    Args:
        func (Callable): The async function to execute
        *args, **kwargs: Arguments to pass to the function
        
    Returns:
        Any: The result of the function
    """
    task_name = func.__name__
    logger.info(f"Preparing to execute async task: {task_name}")
    
    # Create an async semaphore if it doesn't exist
    semaphore = asyncio.Semaphore(MAX_CONCURRENT_TASKS)
    
    logger.info(f"Waiting for semaphore for task: {task_name}")
    async with semaphore:
        logger.info(f"Starting async task: {task_name}")
        try:
            # Execute the async task
            result = await func(*args, **kwargs)
            logger.info(f"Async task completed: {task_name}")
            return result
        except Exception as e:
            logger.error(f"Error in async task {task_name}: {str(e)}")
            raise
