"""
Database Utilities for Generator Services

This module provides database utility functions for the generator services,
specifically for storing requirement parser results in the database.
"""

import logging
import uuid
from sqlalchemy.exc import SQLAlchemyError
from db.session import get_db
from models.generator.requirement import RequirementData
from models.file_processing.file_record import FileMetadata
from models.use_case.usecase_records import UsecaseMetadata
from models.user import User
from models.ocr.ocr_records import OCROutputs

logger = logging.getLogger(__name__)

def create_dummy_file_metadata():
    """
    Create a dummy file metadata record for testing purposes.
    
    Returns:
        UUID: The ID of the newly created file metadata record
        bool: Success status of the operation
    """
    file_id = uuid.uuid4()
    
    try:
        with get_db() as db:
            # Check if we can find any existing file metadata to use
            existing_file = db.query(FileMetadata).first()
            if existing_file:
                logger.info(f"Using existing file metadata with ID: {existing_file.fileId}")
                return existing_file.fileId, True
            
            # Try to find an existing usecase and user to reference
            existing_usecase = db.query(UsecaseMetadata).first()
            existing_user = db.query(User).first()
            
            # Create a new dummy file metadata record
            new_file = FileMetadata(
                fileId=file_id,
                fileName="dummy_file.txt",
                fileLink="/dummy/path/dummy_file.txt",
                usecaseId=existing_usecase.usecaseId if existing_usecase else None,
                userId=existing_user.userId if existing_user else None
            )
            
            db.add(new_file)
            logger.info(f"Successfully created dummy file metadata with ID: {file_id}")
            return file_id, True
            
    except SQLAlchemyError as e:
        logger.error(f"Database error while creating dummy file metadata: {str(e)}")
        return file_id, False
    except Exception as e:
        logger.error(f"Unexpected error while creating dummy file metadata: {str(e)}")
        return file_id, False

def insert_requirement_data(file_id, requirement_name, requirement_json, is_completed=True, error_message=None):
    """
    Insert requirement parser results into the requirement_data table.
    
    Args:
        file_id (UUID): The ID of the file associated with this requirement
        requirement_name (str): The name or title of the requirement
        requirement_json (str): The JSON string containing the parsed requirement data
        is_completed (bool, optional): Whether the requirement processing is completed. Defaults to True.
        error_message (str, optional): Error message if any. Defaults to None.
        
    Returns:
        UUID: The ID of the newly created requirement record
        bool: Success status of the operation
    """
    requirement_id = uuid.uuid4()
    
    try:
        db = next(get_db())
        try:
            # Verify that the file_id exists in the file_metadata table
            file = db.query(FileMetadata).filter(FileMetadata.fileId == file_id).first()
            
            if not file:
                logger.warning(f"File ID {file_id} does not exist in file_metadata table. Creating a dummy file.")
                # Create a dummy file metadata record
                dummy_file_id, success = create_dummy_file_metadata()
                if not success:
                    logger.error("Failed to create dummy file metadata")
                    return requirement_id, False
                file_id = dummy_file_id
                # Re-fetch the file to get its usecaseId
                file = db.query(FileMetadata).filter(FileMetadata.fileId == file_id).first()
            
            # Get the usecaseId from the file
            usecase_id = file.usecaseId
            
            # Find the maximum displayId for requirements under this usecase with proper locking
            max_display_id = 0
            if usecase_id:
                # Get all files for this usecase
                usecase_files = db.query(FileMetadata.fileId).filter(
                    FileMetadata.usecaseId == usecase_id
                ).all()
                
                # Extract file IDs into a list
                usecase_file_ids = [f.fileId for f in usecase_files]
                
                # Get the maximum displayId with row locking to prevent race conditions
                if usecase_file_ids:
                    # We can't use FOR UPDATE directly with aggregate functions in PostgreSQL,
                    # so we'll select the rows first with locking, then get the max value
                    requirements = db.query(
                        RequirementData.displayId
                    ).filter(
                        RequirementData.fileId.in_(usecase_file_ids),
                        RequirementData.is_deleted == False
                    ).order_by(
                        RequirementData.displayId.desc()
                    ).with_for_update().limit(1).all()
                    
                    # Get the maximum displayId from the locked rows
                    if requirements and len(requirements) > 0:
                        max_display_id = requirements[0][0]  # First row, first column
                    
                    logger.info(f"Locked and found maximum displayId for usecase {usecase_id}: {max_display_id}")
            
            # Set the new displayId as max + 1, or 1 if no existing requirements
            new_display_id = max_display_id + 1
            
            new_requirement = RequirementData(
                fileId=file_id,
                requirementId=requirement_id,
                displayId=new_display_id,
                requirementName=requirement_name,
                isCompleted=is_completed,
                errorMessage=error_message,
                requirementJson=requirement_json
            )
            
            db.add(new_requirement)
            db.commit()
            logger.info(f"Successfully inserted requirement data with ID: {requirement_id} and displayId: {new_display_id}")
            return requirement_id, True
        except Exception as e:
            db.rollback()
            logger.error(f"Error in insert_requirement_data: {str(e)}")
            raise e
        finally:
            db.close()
            
    except SQLAlchemyError as e:
        logger.error(f"Database error while inserting requirement data: {str(e)}")
        return requirement_id, False
    except Exception as e:
        logger.error(f"Unexpected error while inserting requirement data: {str(e)}")
        return requirement_id, False

def update_requirement_data(requirement_id, **kwargs):
    """
    Update an existing requirement record in the database.
    
    Args:
        requirement_id (UUID): The ID of the requirement to update
        **kwargs: Fields to update (can include requirementName, isCompleted, 
                 errorMessage, requirementJson)
                 
    Returns:
        bool: Success status of the operation
    """
    try:
        with get_db() as db:
            requirement = db.query(RequirementData).filter(
                RequirementData.requirementId == requirement_id
            ).first()
            
            if not requirement:
                logger.error(f"Requirement with ID {requirement_id} not found")
                return False
                
            # Update fields
            for key, value in kwargs.items():
                if hasattr(requirement, key):
                    setattr(requirement, key, value)
            
            logger.info(f"Successfully updated requirement data with ID: {requirement_id}")
            return True
            
    except SQLAlchemyError as e:
        logger.error(f"Database error while updating requirement data: {str(e)}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error while updating requirement data: {str(e)}")
        return False

def get_requirement_by_id(requirement_id):
    """
    Retrieve a requirement record by its ID.
    
    Args:
        requirement_id (UUID): The ID of the requirement to retrieve
        
    Returns:
        RequirementData: The requirement record if found, None otherwise
    """
    try:
        with get_db() as db:
            requirement = db.query(RequirementData).filter(
                RequirementData.requirementId == requirement_id
            ).first()
            
            return requirement
            
    except SQLAlchemyError as e:
        logger.error(f"Database error while retrieving requirement data: {str(e)}")
        return None
    except Exception as e:
        logger.error(f"Unexpected error while retrieving requirement data: {str(e)}")
        return None

def get_ocr_text_by_user_id(user_id):
    """
    Retrieve all OCR text for a specific user ID.
    
    Args:
        user_id (UUID): The ID of the user
        
    Returns:
        tuple: (combined_text, file_id, success)
            - combined_text (str): All OCR text combined
            - file_id (UUID): The ID of the file (first one found if multiple)
            - success (bool): Success status of the operation
    """
    try:
        with get_db() as db:
            # Find files belonging to the user
            files = db.query(FileMetadata).filter(
                FileMetadata.userId == user_id
            ).all()
            
            if not files:
                logger.error(f"No files found for user ID: {user_id}")
                return "", None, False
            
            # Get the first file ID (we'll use this for the requirement)
            file_id = files[0].fileId
            
            # Get all OCR outputs for the user's files
            all_text = []
            for file in files:
                ocr_outputs = db.query(OCROutputs).filter(
                    OCROutputs.fileId == file.fileId,
                    OCROutputs.isCompleted == True
                ).order_by(OCROutputs.pageNumber).all()
                
                for output in ocr_outputs:
                    if output.pageText:
                        all_text.append(output.pageText)
            
            if not all_text:
                logger.error(f"No OCR text found for user ID: {user_id}")
                return "", file_id, False
            
            # Combine all text
            combined_text = "\n\n".join(all_text)
            logger.info(f"Successfully retrieved OCR text for user ID: {user_id}")
            return combined_text, file_id, True
            
    except SQLAlchemyError as e:
        logger.error(f"Database error while retrieving OCR text: {str(e)}")
        return "", None, False
    except Exception as e:
        logger.error(f"Unexpected error while retrieving OCR text: {str(e)}")
        return "", None, False 