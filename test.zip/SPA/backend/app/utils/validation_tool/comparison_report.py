import pandas as pd
import os
import sys
from typing import List, Dict, Any, Optional
import json
from dotenv import load_dotenv
import concurrent.futures
from tqdm import tqdm

# Add the parent directory to the Python path to import PF Asset module
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../')))
from app.services.llm.pf_asset import invoke_asset

# Load environment variables
load_dotenv()

class ComparisonReportGenerator:
    """
    A class to generate comparison reports between human-generated and LLM-generated outputs
    using PF Asset.
    """
    
    def __init__(self, asset_id: Optional[str] = None, max_parallel_calls: int = 5):
        """
        Initialize the ComparisonReportGenerator.
        
        Args:
            asset_id: The PF Asset ID to use for comparison. If None, uses the default asset ID from settings.
            max_parallel_calls: Maximum number of parallel asset calls to make at once.
        """
        self.asset_id = asset_id
        self.max_parallel_calls = max_parallel_calls
        
    def _get_comparison_prompt(self) -> str:
        """
        Returns the prompt template for comparing human and LLM outputs.
        """
        return """
You are a professional evaluator tasked with comparing two sets of test cases generated using different approaches: Old Approach and New Approach. Your goal is to evaluate how the new approach improves upon the old one and identify any areas of regression. Perform a detailed, fact-based analysis without assuming superiority for either approach.

old_approach:  
{human_output}

new_approach:  
{llm_output}

Perform the comparison using the following criteria. Each score must be justified with a clear explanation:

### Evaluation Criteria

1. **Improvement in Test Coverage (1-10)**:
    - Evaluate whether the new approach covers more functional and edge cases compared to the old one.
2. **Reduction in Redundancy (1-10)**:
    - Assess if the new approach eliminates unnecessary or duplicate test cases.
3. **Accuracy of Test Cases (1-10)**:
    - Compare the correctness of the test cases in identifying expected behaviors, inputs, and outputs.
4. **Scenario Prioritization (1-10)**:
    - Determine how well the new approach prioritizes critical test cases based on risk, impact, and business importance.
5. **Maintainability and Readability (1-10)**:
    - Evaluate how easy it is to understand, update, and maintain the test cases under the new approach.
6. **Efficiency of Test Generation (1-10)**:
    - Assess whether the new approach reduces the time and effort required to generate and validate test cases.
7. **Alignment with Business Requirements (1-10)**:
    - Analyze how well the test cases map to actual business and functional requirements in both approaches.
8. **Edge Case Identification (1-10)**:
    - Evaluate the new approach’s effectiveness in identifying critical edge cases compared to the old one.
9. **Reduction in False Positives/Negatives (1-10)**:
    - Assess if the new approach reduces incorrect test results (false positives or negatives).
10. **Automation Readiness (1-10)**:
    - Evaluate the suitability of test cases for automation in the new approach compared to the old one.

---

### Strengths & Weaknesses
Provide specific strengths and weaknesses of both the old and new approaches using evidence from the test cases.

---

### Overall Assessment
Summarize the comparison, indicating how the new approach has improved and where it still requires enhancements. Provide a balanced view with an overall percentage score for each approach.

---

### Output Format
Your response should be a structured JSON object with no additional text:

{{
    "improvement_in_test_coverage": {{
        "assessment": "string",
        "score": number
    }},
    "reduction_in_redundancy": {{
        "assessment": "string",
        "score": number
    }},
    "accuracy_of_test_cases": {{
        "assessment": "string",
        "score": number
    }},
    "scenario_prioritization": {{
        "assessment": "string",
        "score": number
    }},
    "maintainability_and_readability": {{
        "assessment": "string",
        "score": number
    }},
    "efficiency_of_test_generation": {{
        "assessment": "string",
        "score": number
    }},
    "alignment_with_business_requirements": {{
        "assessment": "string",
        "score": number
    }},
    "edge_case_identification": {{
        "assessment": "string",
        "score": number
    }},
    "reduction_in_false_positives_negatives": {{
        "assessment": "string",
        "score": number
    }},
    "automation_readiness": {{
        "assessment": "string",
        "score": number
    }},
    "strengths": {{
        "old_approach": ["string", "string", ...],
        "new_approach": ["string", "string", ...]
    }},
    "weaknesses": {{
        "old_approach": ["string", "string", ...],
        "new_approach": ["string", "string", ...]
    }},
    "overall_assessment": "string",
    "overall_score": {{
        "old_approach": number,
        "new_approach": number
    }}
}}

Ensure that all evaluations are based on facts, providing examples wherever necessary. Avoid assuming that the new approach is inherently better without justification.
"""

#         return """You are a professional evaluator tasked with comparing two sets of test scenarios generated using different approaches: Old Approach and New Approach. Your evaluation should be based on objective, fact-based analysis, maintaining a neutral stance without assuming the superiority of either approach.
# old_approach:  
# {human_output}

# new_approach:  
# {llm_output}
# Perform a detailed comparison using the following metrics. Each score must be justified with a clear explanation:

# ### Evaluation Criteria
# 1. **Scenario Coverage (1-10)**:
#     - Evaluate how comprehensively the test scenarios cover various functional and edge cases.
# 2. **Scenario Relevance (1-10)**:
#     - Assess if the scenarios generated are contextually relevant and aligned with the actual business use cases.
# 3. **Accuracy of Scenario Generation (1-10)**:
#     - Compare the correctness of generated test scenarios in terms of identifying expected behaviors, inputs, and outputs.
# 4. **Redundancy Reduction (1-10)**:
#     - Analyze if the new approach reduces duplicate or unnecessary scenarios compared to the old approach.
# 5. **Scenario Prioritization (1-10)**:
#     - Determine how well the new approach prioritizes critical scenarios for testing based on risk and impact.
# 6. **Execution Readiness (1-10)**:
#     - Evaluate how easily the scenarios can be directly converted into test scripts and executed.
# 7. **Logical Consistency (1-10)**:
#     - Assess the flow and logical connection between test steps, ensuring clear, structured scenarios.
# 8. **Efficiency Gain (1-10)**:
#     - Evaluate any noticeable reduction in time, effort, or computational resources required for scenario generation.

# ### Strengths & Weaknesses
# Provide specific strengths and weaknesses for both the old and new approaches, supporting your observations with evidence from the scenarios.

# ### Overall Assessment
# Summarize the comparison, indicating which approach performs better for the given task and why. Provide an overall percentage rating for each approach. If the new approach shows significant improvement, specify the areas of enhancement.

# ### Output Format
# Your response should be a structured JSON object with no additional text:

# {{
#     "scenario_coverage": {{
#         "assessment": "string",
#         "score": number
#     }},
#     "scenario_relevance": {{
#         "assessment": "string",
#         "score": number
#     }},
#     "accuracy_of_scenario_generation": {{
#         "assessment": "string",
#         "score": number
#     }},
#     "redundancy_reduction": {{
#         "assessment": "string",
#         "score": number
#     }},
#     "scenario_prioritization": {{
#         "assessment": "string",
#         "score": number
#     }},
#     "execution_readiness": {{
#         "assessment": "string",
#         "score": number
#     }},
#     "logical_consistency": {{
#         "assessment": "string",
#         "score": number
#     }},
#     "efficiency_gain": {{
#         "assessment": "string",
#         "score": number
#     }},
#     "strengths": {{
#         "old_approach": ["string", "string", ...],
#         "new_approach": ["string", "string", ...]
#     }},
#     "weaknesses": {{
#         "old_approach": ["string", "string", ...],
#         "new_approach": ["string", "string", ...]
#     }},
#     "overall_assessment": "string",
#     "overall_score": {{
#         "old_approach": number,
#         "new_approach": number
#     }}
# }}

# Ensure all evaluations are backed by clear examples and reasoned analysis. Maintain a balanced view without assuming any inherent advantage for either approach."""
    

#         return """You are a professional evaluator tasked with comparing two outputs based on key qualitative and quantitative metrics while maintaining an unbiased assessment. 

# Your evaluation must be objective, fact-based, and balanced. Do NOT assume that either output is superior by default. 

# Output 1:  
# {human_output}

# Output 2:  
# {llm_output}

# Analyze and rate the outputs based on the following top 5 criteria. Each score must be justified with a clear explanation:

# 1. Accuracy (1-10): Give the accuracy of the output as Full, Partial or None. Provide an explanation for the rating.
# 2. Completeness (1-10): Does the output fully cover the required details, or is key information missing? Justify your rating.
# 3. Clarity (1-10): How well is the response structured? Is it easy to understand? Explain your score.
# 4. Conciseness (1-10): Does the output provide necessary details without excessive verbosity or unnecessary brevity? Justify your rating.
# 5. Logical Flow & Coherence (1-10): Does the response follow a logical structure, with ideas flowing naturally? Justify your rating.

# Strengths & Weaknesses:  
# List the strengths and weaknesses of each output based on the above criteria.

# Overall Assessment:  
# Summarize the comparison in a balanced manner, highlighting which output is better suited for the given task and why. Give percentage of each output.

# Your response should be a structured JSON object with no additional text:

# {{
#     "accuracy": {{
#         "assessment": "string",
#         "score": number
#     }},
#     "completeness": {{
#         "assessment": "string",
#         "score": number
#     }},
#     "clarity": {{
#         "assessment": "string",
#         "score": number
#     }},
#     "conciseness": {{
#         "assessment": "string",
#         "score": number
#     }},
#     "logical_flow_coherence": {{
#         "assessment": "string",
#         "score": number
#     }},
#     "strengths": {{
#         "output_1": ["string", "string", ...],
#         "output_2": ["string", "string", ...]
#     }},
#     "weaknesses": {{
#         "output_1": ["string", "string", ...],
#         "output_2": ["string", "string", ...]
#     }},
#     "overall_assessment": "string",
#     "overall_score": number
# }}

# Ensure that all evaluations are objective, fair, and based solely on the quality of the outputs. Do NOT assume any output is superior by default."""
    
    def generate_comparison(self, human_output: str, llm_output: str) -> Dict[str, Any]:
        """
        Generate a comparison report between human-generated and LLM-generated outputs.
        
        Args:
            human_output: The human-generated output text
            llm_output: The LLM-generated output text
            
        Returns:
            A dictionary containing the structured comparison report
        """
        prompt = self._get_comparison_prompt().format(
            human_output=human_output,
            llm_output=llm_output
        )
        
        try:
            # Use PF Asset to generate the comparison
            response, cost, tokens = invoke_asset(asset_id_param=self.asset_id, query=prompt)
            
            # Parse the JSON response
            result = json.loads(response)
            
            # Add metadata about the API call
            result["_metadata"] = {
                "cost": cost,
                "tokens": tokens
            }
            
            return result
        except Exception as e:
            print(f"Error generating comparison: {e}")
            return {
                "error": str(e),
                "status": "failed"
            }
    
    def _process_row(self, row_data):
        """
        Process a single row of data for parallel execution.
        
        Args:
            row_data: Tuple containing (idx, row, human_col, llm_col)
            
        Returns:
            Tuple containing (idx, report, cost, tokens)
        """
        idx, row, human_col, llm_col = row_data
        human_text = str(row[human_col])
        llm_text = str(row[llm_col])
        
        # Skip if either text is empty or NaN
        if pd.isna(human_text) or pd.isna(llm_text) or human_text.strip() == "" or llm_text.strip() == "":
            return idx, None, 0, 0
        
        report = self.generate_comparison(human_text, llm_text)
        
        # Extract cost and tokens if available
        cost = 0
        tokens = 0
        if "_metadata" in report:
            cost = report["_metadata"]["cost"]
            tokens = report["_metadata"]["tokens"]
        
        return idx, report, cost, tokens
    
    def process_excel_file(self, 
                          file_path: str, 
                          human_col: str, 
                          llm_col: str, 
                          output_col: str = "comparison_report",
                          save_path: Optional[str] = None,
                          max_parallel_calls: Optional[int] = None) -> pd.DataFrame:
        """
        Process an Excel file containing human and LLM outputs and generate comparison reports.
        
        Args:
            file_path: Path to the Excel file
            human_col: Column name containing human-generated outputs
            llm_col: Column name containing LLM-generated outputs
            output_col: Column name to store the comparison reports
            save_path: Optional path to save the resulting DataFrame as Excel
            max_parallel_calls: Maximum number of parallel asset calls to make at once.
                               If None, uses the value set during initialization.
            
        Returns:
            DataFrame with the original data and added comparison reports
        """
        try:
            # Use the instance max_parallel_calls if not specified
            if max_parallel_calls is None:
                max_parallel_calls = self.max_parallel_calls
                
            # Read the Excel file
            df = pd.read_excel(file_path)
            
            # Validate columns exist
            if human_col not in df.columns:
                raise ValueError(f"Column '{human_col}' not found in the Excel file")
            if llm_col not in df.columns:
                raise ValueError(f"Column '{llm_col}' not found in the Excel file")
            
            # Prepare data for parallel processing
            row_data = [(idx, row, human_col, llm_col) for idx, row in df.iterrows()]
            
            # Initialize results
            comparison_reports = [None] * len(df)
            total_cost = 0
            total_tokens = 0
            
            # Process rows in parallel using ThreadPoolExecutor
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_parallel_calls) as executor:
                # Submit all tasks
                future_to_row = {executor.submit(self._process_row, data): data[0] for data in row_data}
                
                # Process results as they complete with progress bar
                for future in tqdm(concurrent.futures.as_completed(future_to_row), 
                                  total=len(future_to_row), 
                                  desc="Processing rows"):
                    idx, report, cost, tokens = future.result()
                    if report is not None:
                        comparison_reports[idx] = json.dumps(report)
                        total_cost += cost
                        total_tokens += tokens
            
            # Add comparison reports to DataFrame
            df[output_col] = comparison_reports
            
            # Save to Excel if save_path is provided
            if save_path:
                df.to_excel(save_path, index=False)
                print(f"Results saved to {save_path}")
            
            # Print usage statistics
            print(f"Total cost: {total_cost}")
            print(f"Total tokens: {total_tokens}")
            
            return df
        
        except Exception as e:
            print(f"Error processing Excel file: {e}")
            raise

def main():
    """
    Example usage of the ComparisonReportGenerator.
    """
    # Initialize the generator with optional asset ID and max_parallel_calls
    # You can specify a specific asset ID or leave it as None to use the default
    generator = ComparisonReportGenerator(asset_id=None, max_parallel_calls=5)
    
    # Example file path and column names
    file_path = "/home/vikasmayura/Documents/SPA_Docs/PF_vs_local_EKG_Scenario.xlsx"
    human_col = "output_of_PF_EKG"
    llm_col = "output_of_local_EKG"
    output_col = "Comparison_Report"
    save_path = "/home/vikasmayura/Documents/results1.xlsx"
    
    # Process the Excel file with optional override of max_parallel_calls
    result_df = generator.process_excel_file(
        file_path=file_path,
        human_col=human_col,
        llm_col=llm_col,
        output_col=output_col,
        save_path=save_path,
        max_parallel_calls=5  # Override the default value if needed
    )
    
    print("Processing complete!")

if __name__ == "__main__":
    main() 