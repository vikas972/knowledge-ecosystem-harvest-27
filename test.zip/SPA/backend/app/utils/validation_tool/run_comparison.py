#!/usr/bin/env python3
import argparse
import os
import sys

# Add the current directory to the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from comparison_report import ComparisonReportGenerator

def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Generate comparison reports between human and LLM outputs from an Excel file."
    )
    
    parser.add_argument(
        "--input", "-i", 
        required=True,
        help="Path to the input Excel file containing human and LLM outputs."
    )
    
    parser.add_argument(
        "--human-col", 
        required=True,
        help="Column name containing human-generated outputs."
    )
    
    parser.add_argument(
        "--llm-col", 
        required=True,
        help="Column name containing LLM-generated outputs."
    )
    
    parser.add_argument(
        "--output-col", 
        default="Comparison_Report",
        help="Column name to store the comparison reports (default: Comparison_Report)."
    )
    
    parser.add_argument(
        "--output", "-o", 
        help="Path to save the resulting Excel file. If not provided, will use input filename with '_compared' suffix."
    )
    
    parser.add_argument(
        "--asset-id", 
        default=None,
        help="PF Asset ID to use for comparison. If not provided, will use the default asset ID from settings."
    )
    
    return parser.parse_args()

def main():
    """Main function to run the comparison report generator."""
    args = parse_arguments()
    
    # Set default output path if not provided
    if not args.output:
        input_base = os.path.splitext(args.input)[0]
        args.output = f"{input_base}_compared.xlsx"
    
    print(f"Initializing comparison report generator with PF Asset ID: {args.asset_id or 'default'}")
    generator = ComparisonReportGenerator(asset_id=args.asset_id)
    
    print(f"Processing file: {args.input}")
    print(f"Human column: {args.human_col}")
    print(f"LLM column: {args.llm_col}")
    print(f"Output column: {args.output_col}")
    print(f"Output file: {args.output}")
    
    # Process the Excel file
    result_df = generator.process_excel_file(
        file_path=args.input,
        human_col=args.human_col,
        llm_col=args.llm_col,
        output_col=args.output_col,
        save_path=args.output
    )
    
    print(f"Processing complete! Results saved to: {args.output}")
    print(f"Processed {len(result_df)} rows.")

if __name__ == "__main__":
    main() 