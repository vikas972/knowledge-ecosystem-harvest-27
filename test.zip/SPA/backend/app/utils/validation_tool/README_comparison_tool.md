# Excel Comparison Report Generator

This tool generates structured comparison reports between human-generated and LLM-generated outputs stored in an Excel file. It uses PF Asset to analyze and compare the outputs.

## Features

- Compares human-generated and LLM-generated text outputs
- Provides structured analysis on multiple dimensions:
  - Accuracy
  - Completeness
  - Clarity
  - Style
  - Strengths and weaknesses
  - Overall assessment
- Outputs results as JSON in a new Excel column
- Easy-to-use command-line interface
- Visualization tools for analyzing comparison results
- Tracks token usage and cost metrics

## Requirements

- Python 3.7+
- Access to PF Asset API
- Required Python packages:
  - pandas
  - openpyxl
  - requests
  - python-dotenv
  - matplotlib (for visualizations)
  - numpy (for visualizations)

## Setup

1. Make sure you have access to the PF Asset API and the necessary credentials are configured in your environment.
2. The tool uses the following environment variables from your application settings:
   - API_KEY
   - ASSET_ID (default asset ID, can be overridden)
   - PF_USERNAME
   - PF_PASSWORD
   - Various PF API endpoints

3. Install required packages:
   ```
   pip install pandas openpyxl requests python-dotenv matplotlib numpy
   ```

## Usage

### Command Line Interface for Generating Comparisons

The easiest way to use this tool is through the command-line interface:

```bash
python run_comparison.py --input your_excel_file.xlsx --human-col "Human_Column_Name" --llm-col "LLM_Column_Name"
```

#### Arguments:

- `--input`, `-i`: Path to the input Excel file (required)
- `--human-col`: Column name containing human-generated outputs (required)
- `--llm-col`: Column name containing LLM-generated outputs (required)
- `--output-col`: Column name to store the comparison reports (default: "Comparison_Report")
- `--output`, `-o`: Path to save the resulting Excel file (default: input filename with '_compared' suffix)
- `--asset-id`: PF Asset ID to use for comparison (default: uses the default asset ID from settings)

### Example:

```bash
python run_comparison.py --input data.xlsx --human-col "Human_Answers" --llm-col "AI_Answers" --output-col "Comparison" --output results.xlsx --asset-id "a7e2958c-76ef-492e-b55b-a2f4a95cc570"
```

### Visualizing Comparison Results

After generating comparison reports, you can visualize and analyze the results using the visualization tool:

```bash
python visualize_comparisons.py --input your_compared_file.xlsx --report-col "Comparison_Report"
```

#### Arguments:

- `--input`, `-i`: Path to the Excel file containing comparison reports (required)
- `--report-col`: Column name containing the comparison reports (default: "Comparison_Report")
- `--output`, `-o`: Base path to save the visualization results (default: input filename with '_analysis' suffix)
- `--format`: Output format for visualizations (choices: png, pdf, svg, jpg; default: png)

### Example:

```bash
python visualize_comparisons.py --input results.xlsx --report-col "Comparison" --output analysis --format pdf
```

This will generate:
- Bar charts of average scores
- Visualizations of top strengths and weaknesses
- A text summary report

### Python API

You can also use the tool programmatically in your Python code:

```python
from comparison_report import ComparisonReportGenerator

# Initialize the generator with optional asset ID
generator = ComparisonReportGenerator(asset_id="a7e2958c-76ef-492e-b55b-a2f4a95cc570")

# Process an Excel file
result_df = generator.process_excel_file(
    file_path="your_excel_file.xlsx",
    human_col="Human_Column_Name",
    llm_col="LLM_Column_Name",
    output_col="Comparison_Report",
    save_path="output_file.xlsx"
)

# Or generate a single comparison
human_text = "This is human-generated text."
llm_text = "This is LLM-generated text."
comparison = generator.generate_comparison(human_text, llm_text)
print(comparison)
```

## Output Format

The comparison report is stored as a JSON string in the specified output column. The JSON structure is:

```json
{
    "accuracy": {
        "assessment": "Detailed assessment of factual correctness",
        "score": 8
    },
    "completeness": {
        "assessment": "Assessment of information comprehensiveness",
        "score": 7
    },
    "clarity": {
        "assessment": "Assessment of clarity and structure",
        "score": 9
    },
    "style": {
        "assessment": "Assessment of writing style and readability",
        "score": 8
    },
    "strengths": {
        "human": ["Strength 1", "Strength 2", "..."],
        "llm": ["Strength 1", "Strength 2", "..."]
    },
    "weaknesses": {
        "human": ["Weakness 1", "Weakness 2", "..."],
        "llm": ["Weakness 1", "Weakness 2", "..."]
    },
    "overall_assessment": "Overall comparison summary",
    "overall_score": 8,
    "_metadata": {
        "cost": 0.0123,
        "tokens": 1234
    }
}
```

## Visualization Outputs

The visualization tool generates several outputs:

1. **Score Chart**: A bar chart showing average scores for accuracy, completeness, clarity, style, and overall assessment.
2. **Strengths Visualization**: A chart showing the top strengths of human and LLM outputs.
3. **Weaknesses Visualization**: A chart showing the top weaknesses of human and LLM outputs.
4. **Summary Report**: A text file containing a summary of all the analysis results.

## Notes

- The tool skips rows where either the human or LLM output is empty.
- Processing large files may take time due to API rate limits.
- Ensure your Excel file has the correct column names before processing.
- The visualization tool requires matplotlib and numpy packages.
- The tool tracks and reports total token usage and cost for all processed comparisons. 