#!/usr/bin/env python3
"""
Test script for the parallel comparison report generator.
This script demonstrates how to use the ComparisonReportGenerator with parallel processing.
"""

import os
import sys
import argparse
from typing import Optional

# Add the parent directory to the Python path to import the ComparisonReportGenerator
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../')))
from app.utils.validation_tool.comparison_report import ComparisonReportGenerator

def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='Generate comparison reports in parallel.')
    parser.add_argument('--file', '-f', required=True, help='Path to the Excel file')
    parser.add_argument('--human-col', required=True, help='Column name for human-generated outputs')
    parser.add_argument('--llm-col', required=True, help='Column name for LLM-generated outputs')
    parser.add_argument('--output-col', default='comparison_report', help='Column name for output reports')
    parser.add_argument('--save-path', '-o', help='Path to save the output Excel file')
    parser.add_argument('--asset-id', help='PF Asset ID to use (optional)')
    parser.add_argument('--parallel', '-p', type=int, default=5, 
                        help='Maximum number of parallel asset calls (default: 5)')
    return parser.parse_args()

def main():
    """Main function to run the parallel comparison report generator."""
    args = parse_args()
    
    # Print configuration
    print(f"Configuration:")
    print(f"  Input file: {args.file}")
    print(f"  Human column: {args.human_col}")
    print(f"  LLM column: {args.llm_col}")
    print(f"  Output column: {args.output_col}")
    print(f"  Save path: {args.save_path or 'Same as input'}")
    print(f"  Asset ID: {args.asset_id or 'Default'}")
    print(f"  Max parallel calls: {args.parallel}")
    print()
    
    # Initialize the generator
    generator = ComparisonReportGenerator(
        asset_id=args.asset_id,
        max_parallel_calls=args.parallel
    )
    
    # Process the Excel file
    result_df = generator.process_excel_file(
        file_path=args.file,
        human_col=args.human_col,
        llm_col=args.llm_col,
        output_col=args.output_col,
        save_path=args.save_path
    )
    
    print(f"\nProcessing complete! Generated {len(result_df)} comparison reports.")
    
    # If no save path was provided, print a sample of the results
    if not args.save_path:
        print("\nSample of results (first 3 rows):")
        for idx, row in result_df.head(3).iterrows():
            report = row[args.output_col]
            if report:
                print(f"Row {idx+1}: Report generated successfully")
            else:
                print(f"Row {idx+1}: No report generated (empty input)")

if __name__ == "__main__":
    main() 