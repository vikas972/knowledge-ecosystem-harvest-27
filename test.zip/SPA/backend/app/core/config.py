from pydantic_settings import BaseSettings
from dotenv import load_dotenv
import os
import json
import random
load_dotenv()

# OCR Service Configuration
class OCRServiceConfigs:
    NUM_FILES_PER_BACKGROUND_TASK = 2
    NUM_WORKERS = 20
    MAX_RETRIES = 3
    BATCH_SIZE = 1

# PF Asset Service Configuration - limits API calls
class PFAssetServiceConfigs:
    MAX_CONCURRENT_TASKS = int(os.getenv("PF_MAX_CONCURRENT_TASKS", "10"))
    TASK_QUEUE_TIMEOUT = int(os.getenv("PF_TASK_QUEUE_TIMEOUT", "60"))  # seconds

class Settings(BaseSettings):
    # Database settings
    DB_USER: str = os.getenv("DB_USER", "postgres")
    DB_PASSWORD: str = os.getenv("DB_PASSWORD", "postgres")
    DB_HOST: str = os.getenv("DB_HOST")
    DB_PORT: str = os.getenv("DB_PORT", "5432")
    DB_NAME: str = os.getenv("DB_NAME", "spa_automation_ea")
    print(f"DB_HOST: {DB_HOST}")
    
    # PF Authentication settings
    # Get profiles from env and select a random one
    PF_PROFILES_STR: str = os.getenv("PF_PROFILES", "{}")
    PF_PROFILES: dict = json.loads(PF_PROFILES_STR)
    
    # Select a random profile
    _random_profile_id = random.choice(list(PF_PROFILES.keys())) if PF_PROFILES else "1"
    _random_profile = PF_PROFILES.get(_random_profile_id, {"username": "", "password": ""})
    
    # Use the selected profile's credentials
    PF_USERNAME: str = _random_profile.get("username", "")
    PF_PASSWORD: str = _random_profile.get("password", "")
    
    ASSET_ID: str = os.getenv("ASSET_ID", "531cbf1b-5969-4651-8314-bff3fc2c39f1")
    API_KEY: str = os.getenv("API_KEY", "")
    
    # PF Base URL
    PF_BASE_URL: str = os.getenv("PF_BASE_URL", "https://api.intellectseecstag.com")
    
    # PF Asset IDs for requirement processing
    JOURNEY_EXTRACTION_ASSET_ID: str = os.getenv("JOURNEY_EXTRACTION_ASSET_ID")#, "326d7b93-97c5-4e3e-b139-47f2802c8080")
    REQUIREMENT_ANALYSIS_ASSET_ID: str = os.getenv("REQUIREMENT_ANALYSIS_ASSET_ID")#, "97265b63-191b-4e26-8281-8444ea620d81")#"352e5118-96f9-4894-ba5a-a99b2eae098c")
    REQUIREMENT_EXTRACTION_ASSET_ID: str = os.getenv("REQUIREMENT_EXTRACTION_ASSET_ID")#, "97265b63-191b-4e26-8281-8444ea620d81")#"71a5da27-c2ba-45cb-b7f4-4a8bd47a114f")

    # PF API Endpoints (with default values)
    PF_ACCESS_TOKEN_URL: str = os.getenv("PF_ACCESS_TOKEN_URL", "https://api.intellectseecstag.com/accesstoken/idxpigtb")
    PF_CREATE_CONVERSATION_URL: str = os.getenv("PF_CREATE_CONVERSATION_URL", "https://api.intellectseecstag.com/magicplatform/v1/genai/conversation/create")
    PF_ADD_MESSAGE_URL: str = os.getenv("PF_ADD_MESSAGE_URL", "https://api.intellectseecstag.com/magicplatform/v1/genai/conversation/addmessage")
    PF_GET_RESPONSE_BASE_URL: str = os.getenv("PF_GET_RESPONSE_BASE_URL", "https://api.intellectseecstag.com/magicplatform/v1/genai/conversation/response")
    
    # Additional PF Configuration
    PF_MAX_RETRIES: int = int(os.getenv("PF_MAX_RETRIES", "3"))
    PF_RETRY_DELAY: int = int(os.getenv("PF_RETRY_DELAY", "2"))
    
    # PF Knowledge Base settings
    PF_DOC_LIB: str = os.getenv("PF_DOC_LIB", "81af4d01-5657-4c0f-a6e1-899dce3f34ff")
    PF_KB_ID: str = os.getenv("PF_KB_ID", "6b877a98-44a7-4079-8378-57f04ea7a0d7")
    DEFAULT_FILE_PATH: str = os.getenv("DEFAULT_FILE_PATH", "/home/vikasmayura/Documents/SPA_Docs/ABIR.pdf")
    DEFAULT_FILE_NAME: str = os.getenv("DEFAULT_FILE_NAME", "ABIR.pdf")
    
    # Azure Storage configuration
    AZURE_SUBSCRIPTION_ID: str = os.getenv("AZURE_SUBSCRIPTION_ID", "2352fb14-1dd2-445e-ab8e-d66cfc221ff6")
    AZURE_CONTAINER_NAME: str = os.getenv("AZURE_CONTAINER_NAME", "spadocs")
    AZURE_CONTAINER_URL: str = os.getenv("AZURE_CONTAINER_URL", "https://igtbspa.blob.core.windows.net/spadocs")
    AZURE_CONNECTION_STRING: str = os.getenv("AZURE_CONNECTION_STRING", "DefaultEndpointsProtocol=https;AccountName=igtbspa;AccountKey=KCjXPb4F0ecsoMA8iV99LpGV272UW/4MoBkAGCqGBKl13/Gf9Xr1ST/W/Qaz2TQojEqWlg21e6oe+AStx5qE/g==;EndpointSuffix=core.windows.net")
    
    # Hosting Configuration
    HOST: str = os.getenv("HOST", "0.0.0.0")
    PORT: int = int(os.getenv("PORT", "8000"))
    
    class Config:
        env_file = ".env"

settings = Settings()

# Azure Storage configuration
class AzureBlobStorageConfigs:
    SUBSCRIPTION_ID = settings.AZURE_SUBSCRIPTION_ID
    CONTAINER_NAME = settings.AZURE_CONTAINER_NAME
    CONTAINER_URL = settings.AZURE_CONTAINER_URL
    CONNECTION_STRING = settings.AZURE_CONNECTION_STRING

class DatabaseConfigs:
    DATABASE_URL = f"postgresql://{settings.DB_USER}:{settings.DB_PASSWORD}@{settings.DB_HOST}:{settings.DB_PORT}/{settings.DB_NAME}"

# Knowledge Base Configuration
class KnowledgeBaseConfigs:
    # PF Knowledge Base API settings
    BASE_URL = settings.PF_BASE_URL
    API_KEY = settings.API_KEY
    USERNAME = settings.PF_USERNAME
    PASSWORD = settings.PF_PASSWORD
    DOC_LIB = settings.PF_DOC_LIB
    KB_ID = settings.PF_KB_ID
    DEFAULT_FILE_PATH = settings.DEFAULT_FILE_PATH
    DEFAULT_FILE_NAME = settings.DEFAULT_FILE_NAME

# Hosting Configuration
class HostingConfigs:
    HOST = settings.HOST
    PORT = settings.PORT
    URL = f"http://{HOST}:{PORT}"
