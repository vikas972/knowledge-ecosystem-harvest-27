
class PFImageToTextConfigs:
    api_key = "magicplatform.7881874f7df9423d94b6fFd8ebd6e279"
    username = "gtb.nikhildusane"
    password = "Nikhil@123"
    asset_id = "951f5446-c525-4f50-929b-9a959137208e" #"eac3cc4c-59a9-423e-a10c-cd8690485ec1"