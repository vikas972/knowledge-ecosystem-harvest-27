from pydantic import BaseModel, ConfigDict
from uuid import UUID
from datetime import datetime
from typing import Optional


class FileMetadataSchema(BaseModel):
    fileId: UUID
    usecaseId: int
    fileName: str
    userId: UUID
    createdAt: datetime
    updatedAt: datetime
    
    model_config = ConfigDict(from_attributes=True)

class FileWorkflowTrackerSchema(BaseModel):
    fileId: UUID
    text_extraction: str = "Not Started"
    requirement_generation: str = "Not Started"
    scenario_generation: str = "Not Started"
    test_case_generation: str = "Not Started"
    test_data_generation: str = "Not Started"
    error_msg: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)
