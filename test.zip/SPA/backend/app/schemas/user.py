from pydantic import BaseModel
from uuid import UUID
from datetime import datetime

class UserSchema(BaseModel):
    userId: UUID
    email: str
    createdAt: datetime
    updatedAt: datetime

    class Config:
        orm_mode = True 