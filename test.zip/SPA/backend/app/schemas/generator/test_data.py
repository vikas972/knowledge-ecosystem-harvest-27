from pydantic import BaseModel
from uuid import UUID
from datetime import datetime
from typing import Any

class TestDataSchema(BaseModel):
    testDataId: UUID
    testCaseId: UUID
    scenarioId: UUID
    requirementId: UUID
    documentId: UUID
    fileId: UUID
    userId: UUID
    testDataJson: Any
    createdAt: datetime
    updatedAt: datetime

    class Config:
        orm_mode = True
