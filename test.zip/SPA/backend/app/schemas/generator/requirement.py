from pydantic import BaseModel
from uuid import UUID
from datetime import datetime
from typing import Any

class RequirementDataSchema(BaseModel):
    documentId: UUID
    fileId: UUID
    userId: UUID
    jsonData: Any
    createdAt: datetime
    updatedAt: datetime

    class Config:
        orm_mode = True

class RequirementOutputSchema(BaseModel):
    requirementId: UUID
    documentId: UUID
    fileId: UUID
    userId: UUID
    outputJson: Any
    createdAt: datetime
    updatedAt: datetime

    class Config:
        orm_mode = True
