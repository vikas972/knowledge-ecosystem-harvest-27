from pydantic import BaseModel
from uuid import UUID
from datetime import datetime
from typing import Any

class ScenarioOutputSchema(BaseModel):
    scenarioId: UUID
    requirementId: UUID
    documentId: UUID
    fileId: UUID
    userId: UUID
    outputJson: Any
    createdAt: datetime
    updatedAt: datetime

    class Config:
        orm_mode = True
