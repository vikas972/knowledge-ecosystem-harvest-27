from typing import Optional, Dict, Any, List
from uuid import UUID
from pydantic import BaseModel
from datetime import datetime

class TestScriptsSchema(BaseModel):
    fileId: Optional[UUID] = None
    requirementId: Optional[UUID] = None
    scenarioId: Optional[UUID] = None
    testCaseId: Optional[UUID] = None
    testScriptId: Optional[UUID] = None
    displayId: Optional[int] = None
    isCompleted: Optional[bool] = False
    errorMessage: Optional[str] = None
    testScriptJson: Dict[str, Any]
    is_deleted: Optional[bool] = False
    createdAt: Optional[datetime] = None
    updatedAt: Optional[datetime] = None

    class Config:
        orm_mode = True

class TestScriptsCreate(BaseModel):
    fileId: UUID
    requirementId: UUID
    scenarioId: UUID
    testCaseId: UUID
    displayId: int
    testScriptJson: Dict[str, Any]

class TestScriptsUpdate(BaseModel):
    isCompleted: Optional[bool] = None
    errorMessage: Optional[str] = None
    testScriptJson: Optional[Dict[str, Any]] = None
    is_deleted: Optional[bool] = None 