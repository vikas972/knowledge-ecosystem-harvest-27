import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from db.base import Base
from db.session import engine
from sqladmin import Admin as SQLAdmin, ModelView
from sqladmin.authentication import AuthenticationBackend
from starlette.requests import Request
from starlette.responses import RedirectResponse
import os
from sqlalchemy.orm import Session

# Import models to ensure they're registered with Base metadata
import models
from models.admin import Admin as AdminModel
from models.user import User
from models.ocr.ocr_records import OCRInfo, OCROutputs
from models.file_processing.file_record import FileMetadata, FileWorkflowTracker
from models.generator.requirement import RequirementData
from models.generator.scenario import ScenarioOutput
from models.generator.test_case import TestCases
from models.generator.test_data import TestData
from models.generator.test_scripts import TestScripts
from models.use_case.usecase_records import UsecaseMetadata
from db.session import get_db

# Create database tables first
Base.metadata.create_all(bind=engine)

# Authentication backend for SQLAdmin
class AdminAuth(AuthenticationBackend):
    async def login(self, request: Request) -> bool:
        form = await request.form()
        username = form.get("username")
        password = form.get("password")
        
        # Get database session
        db = next(get_db())
        
        # Check if admin exists and password matches
        admin = db.query(AdminModel).filter(AdminModel.username == username).first()
        
        # Close the session
        db.close()
        
        if not admin or admin.hashed_password != password:
            return False
            
        # Set session data
        request.session.update({"token": "admin"})
        return True

    async def logout(self, request: Request) -> bool:
        request.session.clear()
        return True

    async def authenticate(self, request: Request) -> bool:
        token = request.session.get("token")
        if not token:
            return False
        return True

# Create authentication backend
authentication_backend = AdminAuth(secret_key="your-secret-key")

app = FastAPI(title="SPA")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Set up SQLAdmin with authentication
admin = SQLAdmin(app, engine, authentication_backend=authentication_backend)

# Define admin views for models
class UserAdmin(ModelView, model=User):
    column_list = [User.userId, User.email, User.is_deleted]
    name = "User"
    name_plural = "Users"
    icon = "fa-solid fa-user"

class AdminModelAdmin(ModelView, model=AdminModel):
    column_list = [AdminModel.id, AdminModel.username, AdminModel.email, AdminModel.is_active]
    name = "Admin"
    name_plural = "Admins"
    icon = "fa-solid fa-lock"

class RequirementDataAdmin(ModelView, model=RequirementData):
    column_list = [RequirementData.fileId, RequirementData.displayId, RequirementData.requirementName, 
                  RequirementData.isCompleted, RequirementData.isScenarioGenerated, 
                  RequirementData.errorMessage, 
                  RequirementData.is_deleted]
    name = "Requirement"
    name_plural = "Requirements"
    icon = "fa-solid fa-list-check"

class ScenarioOutputAdmin(ModelView, model=ScenarioOutput):
    column_list = [ScenarioOutput.fileId, ScenarioOutput.requirementId , ScenarioOutput.scenarioId ,ScenarioOutput.displayId,
                  ScenarioOutput.isCompleted, ScenarioOutput.isTestcasesGenerated, 
                  ScenarioOutput.errorMessage, 
                  ScenarioOutput.is_deleted]
    name = "Scenario"
    name_plural = "Scenarios"
    icon = "fa-solid fa-sitemap"

class TestCasesAdmin(ModelView, model=TestCases):
    column_list = [TestCases.fileId, TestCases.testCaseId, TestCases.displayId,
                  TestCases.isCompleted, TestCases.isTestDataGenerated, 
                  TestCases.errorMessage, 
                  TestCases.is_deleted]
    name = "Test Case"
    name_plural = "Test Cases"
    icon = "fa-solid fa-vial"

class TestDataAdmin(ModelView, model=TestData):
    name = "Test Data"
    name_plural = "Test Data"
    icon = "fa-solid fa-database"

class OCRInfoAdmin(ModelView, model=OCRInfo):
    name = "OCR Info"
    name_plural = "OCR Info"
    icon = "fa-solid fa-file-image"

class OCROutputsAdmin(ModelView, model=OCROutputs):
    name = "OCR Output"
    name_plural = "OCR Outputs"
    icon = "fa-solid fa-file-lines"

class FileMetadataAdmin(ModelView, model=FileMetadata):
    name = "File Metadata"
    name_plural = "File Metadata"
    icon = "fa-solid fa-file"

class FileWorkflowTrackerAdmin(ModelView, model=FileWorkflowTracker):
    name = "File Workflow"
    name_plural = "File Workflows"
    icon = "fa-solid fa-diagram-project"

class UsecaseMetadataAdmin(ModelView, model=UsecaseMetadata):
    column_list = [UsecaseMetadata.usecaseId, UsecaseMetadata.usecaseName, 
                  UsecaseMetadata.text_extraction, UsecaseMetadata.requirement_generation,
                  UsecaseMetadata.scenario_generation, UsecaseMetadata.test_case_generation,
                  UsecaseMetadata.test_data_generation, UsecaseMetadata.test_script_generation,
                  UsecaseMetadata.is_deleted]
    name = "Usecase"
    name_plural = "Usecases"
    icon = "fa-solid fa-briefcase"

class TestScriptsAdmin(ModelView, model=TestScripts):
    column_list = [TestScripts.fileId, TestScripts.requirementId, TestScripts.scenarioId, TestScripts.testCaseId,
                  TestScripts.testScriptId, TestScripts.displayId, TestScripts.isCompleted, TestScripts.errorMessage,
                  TestScripts.is_deleted]
    name = "Test Scripts"
    name_plural = "Test Scripts"
    icon = "fa-solid fa-file-code"

# Register admin views
admin.add_view(UserAdmin)
admin.add_view(AdminModelAdmin)
admin.add_view(RequirementDataAdmin)
admin.add_view(ScenarioOutputAdmin)
admin.add_view(TestCasesAdmin)
admin.add_view(TestScriptsAdmin)
admin.add_view(TestDataAdmin)
admin.add_view(OCRInfoAdmin)
admin.add_view(OCROutputsAdmin)
admin.add_view(FileMetadataAdmin)
admin.add_view(FileWorkflowTrackerAdmin)
admin.add_view(UsecaseMetadataAdmin)

# Import and include routers after database initialization
from api.v1.api_router import api_router
from api.v1.admin import router as admin_router
# from backend.app.api.v1.endpoints.generator_api.metrics_api import router as metrics_router

# Include routers
app.include_router(api_router)
app.include_router(admin_router, prefix="/admin-api", tags=["admin-api"])
# app.include_router(
#     metrics_router,
#     prefix="/metrics",
#     tags=["metrics"]
# )

@app.get("/")
async def root():
    return {"message": "FastAPI app is running!"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
