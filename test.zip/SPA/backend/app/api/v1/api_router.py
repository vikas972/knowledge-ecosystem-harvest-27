from fastapi import APIRouter
from api.v1.endpoints.file_processing.file_upload import router as file_processing_router
from api.v1.endpoints.user_management.manage_user import router as user_management_router
from api.v1.endpoints.usecase_management.manage_usecase import router as usecase_management_router
from api.v1.endpoints.generator_api.scenario_api import router as scenario_router
from api.v1.endpoints.generator_api.manage_testcases import router as testcase_management_router
from api.v1.endpoints.generator_api.requirement_api import router as requirement_router
from api.v1.endpoints.generator_api.test_scripts_api import router as test_scripts_router
from api.v1.endpoints.generator_api.metrics_api import router as metrics_router
# Create a main API router
api_router = APIRouter()

# Include file processing routes
api_router.include_router(file_processing_router, prefix="/file-processing", tags=["File Processing"])
api_router.include_router(user_management_router, prefix="/user-management", tags=["User Management"])  
api_router.include_router(usecase_management_router, prefix="/usecase-management", tags=["Usecase Management"])
api_router.include_router(user_management_router, prefix="/user-management", tags=["User Management"])
api_router.include_router(scenario_router, prefix="/scenario-management", tags=["Test Scenarios"])  
api_router.include_router(testcase_management_router, prefix="/testcase-management", tags=["Testcase Management"])
api_router.include_router(requirement_router, prefix="/requirements", tags=["Requirements"])
api_router.include_router(test_scripts_router, prefix="/test-scripts", tags=["Test Scripts"])
api_router.include_router(metrics_router, prefix="/metrics", tags=["Metrics"])
