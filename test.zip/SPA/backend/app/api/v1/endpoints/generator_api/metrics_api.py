"""
Metrics API Module

This module provides API endpoints for retrieving metrics data.
"""

import logging
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import Dict, Any

from deps import get_db
from models.generator.requirement import RequirementData
from models.generator.scenario import ScenarioOutput
from models.generator.test_case import TestCases
from models.file_processing.file_record import FileMetadata
from models.use_case.usecase_records import UsecaseMetadata

router = APIRouter()
logger = logging.getLogger(__name__)

@router.get(
    "/get-metrics-by-usecaseid/{usecase_id}",
    response_model=Dict[str, Any],
    status_code=status.HTTP_200_OK,
    summary="Get metrics for a usecase",
    description="Retrieves the count of requirements, scenarios, and test cases for a specific usecase ID."
)
async def get_metrics_by_usecase(
    usecase_id: int,
    db: Session = Depends(get_db)
):
    """
    Endpoint to retrieve metrics for a specific usecase.
    
    Args:
        usecase_id: The ID of the usecase
        db: Database session
        
    Returns:
        A dictionary containing metrics data (requirements, scenarios, test cases counts)
    """
    try:
        # Check if usecase exists
        usecase = db.query(UsecaseMetadata).filter(
            UsecaseMetadata.usecaseId == usecase_id
        ).first()
        
        if not usecase:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Usecase not found with ID: {usecase_id}"
            )
        
        # Get all files associated with this usecase
        files = db.query(FileMetadata).filter(
            FileMetadata.usecaseId == usecase_id,
            FileMetadata.is_deleted == False
        ).all()
        
        if not files:
            return {
                "usecase_id": usecase_id,
                "usecase_name": usecase.usecaseName,
                "metrics": {
                    "total_requirements": 0,
                    "total_scenarios": 0,
                    "total_test_cases": 0
                }
            }
        
        file_ids = [file.fileId for file in files]
        
        # Count requirements
        total_requirements = db.query(RequirementData).filter(
            RequirementData.fileId.in_(file_ids),
            RequirementData.is_deleted == False
        ).count()
        
        # Count scenarios
        total_scenarios = db.query(ScenarioOutput).filter(
            ScenarioOutput.fileId.in_(file_ids),
            ScenarioOutput.is_deleted == False,
            ScenarioOutput.isCompleted == True
        ).count()
        
        # Count test cases
        # First get all scenario IDs for this usecase
        scenarios = db.query(ScenarioOutput).filter(
            ScenarioOutput.fileId.in_(file_ids),
            ScenarioOutput.is_deleted == False
        ).all()
        
        scenario_ids = [scenario.scenarioId for scenario in scenarios]
        
        total_test_cases = 0
        if scenario_ids:
            total_test_cases = db.query(TestCases).filter(
                TestCases.scenarioId.in_(scenario_ids),
                TestCases.is_deleted == False,
                TestCases.isCompleted == True
            ).count()
        
        return {
            "usecase_id": usecase_id,
            "usecase_name": usecase.usecaseName,
            "metrics": {
                "total_requirements": total_requirements,
                "total_scenarios": total_scenarios,
                "total_test_cases": total_test_cases
            }
        }
        
    except HTTPException as he:
        raise he
    except Exception as e:
        logger.error(f"Error fetching metrics for usecase {usecase_id}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error fetching metrics: {str(e)}"
        ) 