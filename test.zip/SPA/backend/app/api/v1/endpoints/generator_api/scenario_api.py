"""
Scenario API Module

This module provides API endpoints for generating test scenarios from requirements.
"""

import sys
from pathlib import Path
# Add the parent directory to sys.path to allow importing from sibling packages
sys.path.append(str(Path(__file__).parent.parent.parent))


import logging
from typing import List, Optional, Dict, Any
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, status, Query
from sqlalchemy.orm import Session
from pydantic import BaseModel

from deps import get_db
from models.generator.scenario import ScenarioOutput
from services.generator.scenario_generator import ScenarioGenerator
from models.generator.requirement import RequirementData
from models.use_case.usecase_records import UsecaseMetadata
from models.file_processing.file_record import FileMetadata
from models.generator.test_case import TestCases
from models.generator.test_data import TestData
from db.session import SessionLocal
from models.file_processing.file_record import FileWorkflowTracker

router = APIRouter()
logger = logging.getLogger(__name__)

class DeleteScenarioResponse(BaseModel):
    scenario_id: UUID
    is_deleted: bool
    message: str

# Inline schema definitions
class ScenarioGenerationRequest(BaseModel):
    requirement_ids: List[UUID]

class ScenarioGenerationResponse(BaseModel):
    message: str
    requirement_ids: List[UUID]

class UsecaseScenarioRequest(BaseModel):
    usecase_id: int
@router.post(
    "/generate-by-usecase",
    response_model=ScenarioGenerationResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Generate test scenarios from usecase",
    description="Triggers the generation of test scenarios based on the provided usecase ID."
)
async def generate_scenarios_by_usecase(
    request: UsecaseScenarioRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Endpoint to generate test scenarios from usecase.
    
    Args:
        request: Contains the usecase ID
        background_tasks: FastAPI background tasks handler
        db: Database session
        
    Returns:
        A response indicating the task has been accepted for processing
    """
    try:
        # Get all files associated with the usecase
        files = db.query(FileMetadata).filter(
            FileMetadata.usecaseId == request.usecase_id,
            FileMetadata.is_deleted == False
        ).all()
        
        if not files:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No files found for usecase ID: {request.usecase_id}"
            )
        
        # Get all requirements from these files
        requirement_ids = []
        requirements_list = []
        for file in files:
            requirements = db.query(RequirementData).filter(
                RequirementData.fileId == file.fileId,
                RequirementData.is_deleted == False
            ).all()
            requirement_ids.extend([req.requirementId for req in requirements])
            requirements_list.extend(requirements)
        
        if not requirement_ids:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No requirements found for usecase ID: {request.usecase_id}"
            )

        # Print requirements
        logger.info(f"Requirements for usecase {request.usecase_id}:")
        for req in requirements_list:
            logger.info(f"Requirement ID: {req.requirementId}, Name: {req.requirementName}")
        
        # Add the scenario generation task to background tasks
        background_tasks.add_task(
            _generate_scenarios_background,
            requirement_ids=requirement_ids,
            usecase_id=request.usecase_id
        )
        
        # Update usecase status
        usecase = db.query(UsecaseMetadata).filter(
            UsecaseMetadata.usecaseId == request.usecase_id
        ).first()
        if usecase:
            usecase.scenario_generation = "In Progress"
            db.commit()
        
        return ScenarioGenerationResponse(
            message="Scenario generation started",
            requirement_ids=requirement_ids
        )
        
    except HTTPException as he:
        raise he
    except Exception as e:
        logger.error(f"Error initiating scenario generation for usecase {request.usecase_id}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error initiating scenario generation: {str(e)}"
        )


@router.post(
    "/generate",
    response_model=ScenarioGenerationResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Generate test scenarios from requirements",
    description="Triggers the generation of test scenarios based on the provided requirement IDs. "
                "The generation process runs as a background task."
)
async def generate_scenarios(
    request: ScenarioGenerationRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Endpoint to generate test scenarios from requirements.
    
    Args:
        request: Contains the list of requirement IDs to process
        background_tasks: FastAPI background tasks handler
        db: Database session
        
    Returns:
        A response indicating the task has been accepted for processing
    """
    if not request.requirement_ids:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No requirement IDs provided"
        )
    
    # get usecase id from requirement id
    # Get the usecase ID from the first requirement ID
    requirement = db.query(RequirementData).filter(
        RequirementData.requirementId == request.requirement_ids[0]
    ).first()
    
    if not requirement:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Requirement not found with ID: {request.requirement_ids[0]}"
        )
    
    # Get the file associated with the requirement
    file = db.query(FileMetadata).filter(
        FileMetadata.fileId == requirement.fileId
    ).first()
    
    if not file:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"File not found for requirement ID: {request.requirement_ids[0]}"
        )
    
    usecase_id = file.usecaseId
    
    # Add the scenario generation task to background tasks
    background_tasks.add_task(
        _generate_scenarios_background,
        requirement_ids=request.requirement_ids,
        usecase_id=usecase_id
    )
    
    return ScenarioGenerationResponse(
        message="Scenario generation started",
        requirement_ids=request.requirement_ids
    )

@router.get(
    "/requirement/{requirement_id}",
    response_model=List[Dict[str, Any]],
    status_code=status.HTTP_200_OK,
    summary="Get scenarios for a requirement",
    description="Retrieves all generated scenarios for a specific requirement ID."
)
async def get_scenarios_by_requirement(
    requirement_id: UUID,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to retrieve scenarios for a specific requirement.
    
    Args:
        requirement_id: The UUID of the requirement
        db: Database session
        
    Returns:
        A list of scenario outputs for the specified requirement
    """
    # Create a new database session using the context manager
    with db_session as db:
        scenarios = db.query(ScenarioOutput).filter(
            ScenarioOutput.requirementId == requirement_id
        ).all()
        
        if not scenarios:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No scenarios found for requirement ID: {requirement_id}"
            )
        
        # Convert SQLAlchemy models to dictionaries
        return [
            {
                "scenarioId": scenario.scenarioId,
                "fileId": scenario.fileId,
                "requirementId": scenario.requirementId,
                "isCompleted": scenario.isCompleted,
                "errorMessage": scenario.errorMessage,
                "outputJson": scenario.outputJson,
                "createdAt": scenario.createdAt,
                "updatedAt": scenario.updatedAt,
                "is_deleted": scenario.is_deleted,
                "displayId": scenario.displayId
            }
            for scenario in scenarios
        ]

@router.get(
    "/{scenario_id}",
    status_code=status.HTTP_200_OK,
    summary="Get scenario by ID",
    description="Retrieves a specific scenario by its ID."
)
async def get_scenario_by_id(
    scenario_id: UUID,
    db: Session = Depends(get_db)
):
    """
    Endpoint to retrieve a specific scenario by ID.
    
    Args:
        scenario_id: The UUID of the scenario
        db: Database session
        
    Returns:
        The scenario output for the specified ID
    """
    # Create a new database session using the context manager
    with next(get_db()) as session:
        scenario = session.query(ScenarioOutput).filter(
            ScenarioOutput.scenarioId == scenario_id
        ).first()
        
        if not scenario:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Scenario not found with ID: {scenario_id}"
            )
        
        # Convert SQLAlchemy model to dictionary
        return {
            "scenarioId": scenario.scenarioId,
            "fileId": scenario.fileId,
            "requirementId": scenario.requirementId,
            "isCompleted": scenario.isCompleted,
            "errorMessage": scenario.errorMessage,
            "outputJson": scenario.outputJson,
            "createdAt": scenario.createdAt,
            "updatedAt": scenario.updatedAt,
            "is_deleted": scenario.is_deleted,
            "displayId": scenario.displayId
        }

@router.get(
    "/usecase/{usecase_id}",
    status_code=status.HTTP_200_OK,
    summary="Get all scenarios for a usecase",
    description="Retrieves all scenarios organized by requirements for a specific usecase ID."
)
async def get_scenarios_by_usecase(
    usecase_id: int,
    db: Session = Depends(get_db)
):
    """
    Endpoint to retrieve all scenarios for a specific usecase, organized by requirements.
    
    Args:
        usecase_id: The ID of the usecase
        db: Database session
        
    Returns:
        A list of requirements with their associated scenarios for the specified usecase
    """
    # Create a new database session using the context manager
    with db as session:
        # First, verify the usecase exists
        usecase = session.query(UsecaseMetadata).filter(
            UsecaseMetadata.usecaseId == usecase_id
        ).first()
        
        if not usecase:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Usecase not found with ID: {usecase_id}"
            )
        
        # Get all files associated with this usecase
        files = session.query(FileMetadata).filter(
            FileMetadata.usecaseId == usecase_id
        ).all()
        
        if not files:
            return {
                "usecase_id": usecase_id,
                "usecase_name": usecase.usecaseName,
                "requirements": []
            }
        
        # Get all file IDs
        file_ids = [file.fileId for file in files]
        
        # Get all requirements for these files
        from models.generator.requirement import RequirementData
        requirements = session.query(RequirementData).filter(
            RequirementData.fileId.in_(file_ids)
        ).all()
        
        if not requirements:
            return {
                "usecase_id": usecase_id,
                "usecase_name": usecase.usecaseName,
                "requirements": []
            }
        
        # Build the response structure
        result = {
            "usecase_id": usecase_id,
            "usecase_name": usecase.usecaseName,
            "requirements": []
        }
        
        for req in requirements:
            # Get scenarios for this requirement
            scenarios = session.query(ScenarioOutput).filter(
                ScenarioOutput.requirementId == req.requirementId,
                ScenarioOutput.isCompleted == True
            ).all()
            
            # Format requirement with its scenarios
            req_data = {
                "requirement_id": req.requirementId,
                "requirement_name": req.requirementName,
                "file_id": req.fileId,
                "is_scenario_generated": req.isScenarioGenerated,
                "scenarios": []
            }
            
            for scenario in scenarios:
                scenario_data = {
                    "scenario_id": scenario.scenarioId,
                    "is_completed": scenario.isCompleted,
                    "is_testcases_generated": scenario.isTestcasesGenerated,
                    "error_message": scenario.errorMessage,
                    "output_json": scenario.outputJson,
                    "created_at": scenario.createdAt,
                    "updated_at": scenario.updatedAt,
                    "is_deleted": scenario.is_deleted,
                    "displayId": scenario.displayId
                }
                req_data["scenarios"].append(scenario_data)
            
            result["requirements"].append(req_data)
        
        return result

@router.get(
    "/requirements",
    response_model=List[Dict[str, Any]],
    status_code=status.HTTP_200_OK,
    summary="Get scenarios for multiple requirements",
    description="Retrieves all generated scenarios for a list of requirement IDs."
)
async def get_scenarios_by_requirements(
    requirement_ids: str = Query(..., description="Comma-separated list of requirement IDs"),
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to retrieve scenarios for multiple requirements.
    
    Args:
        requirement_ids: Comma-separated list of requirement UUIDs
        db_session: Database session
        
    Returns:
        A list of scenario outputs for the specified requirements
    """
    try:
        # Parse the comma-separated IDs into UUID objects
        ids = [UUID(id_str.strip()) for id_str in requirement_ids.split(',')]
        
        if not ids:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No valid requirement IDs provided"
            )
            
        # Create a new database session using the context manager
        with db_session as db:
            scenarios = db.query(ScenarioOutput).filter(
                ScenarioOutput.requirementId.in_(ids)
            ).all()
            
            # Convert SQLAlchemy models to dictionaries
            return [
                {
                    "scenarioId": scenario.scenarioId,
                    "fileId": scenario.fileId,
                    "requirementId": scenario.requirementId,
                    "isCompleted": scenario.isCompleted,
                    "isTestcasesGenerated": scenario.isTestcasesGenerated,
                    "errorMessage": scenario.errorMessage,
                    "outputJson": scenario.outputJson,
                    "createdAt": scenario.createdAt,
                    "updatedAt": scenario.updatedAt,
                    "is_deleted": scenario.is_deleted,
                    "displayId": scenario.displayId
                }
                for scenario in scenarios
            ]
    except ValueError as e:
        # Handle invalid UUID format
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid UUID format: {str(e)}"
        )
    except Exception as e:
        logger.error(f"Error fetching scenarios for requirements: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error fetching scenarios: {str(e)}"
        )

def _generate_scenarios_background(requirement_ids: List[UUID], usecase_id):
    """
    Background task function to generate scenarios.
    
    Args:
        requirement_ids: List of requirement IDs to process
    """
    logger.info(f"Starting background scenario generation for {len(requirement_ids)} requirements")
    
    # Get file IDs for these requirements to track workflow status
    file_ids = set()
    db = SessionLocal()
    
    # Filter requirements to only those that need scenario generation
    filtered_requirement_ids = []
    try:
        for req_id in requirement_ids:
            requirement = db.query(RequirementData).filter(
                RequirementData.requirementId == req_id
            ).first()
            if requirement:
                file_ids.add(requirement.fileId)
                # Only include requirements that haven't had scenarios generated yet
                if not requirement.isScenarioGenerated and requirement.is_deleted is False:
                    filtered_requirement_ids.append(req_id)
                else:
                    logger.info(f"Skipping requirement {req_id} - already has scenarios generated or is deleted")
        
        logger.info(f"Filtered from {len(requirement_ids)} to {len(filtered_requirement_ids)} requirements that need scenario generation")
        
        # If no requirements need processing, exit early
        if not filtered_requirement_ids:
            logger.info("No requirements need scenario generation, exiting early")
            
            # Update usecase metadata to indicate completion
            try:
                usecase = db.query(UsecaseMetadata).filter(
                    UsecaseMetadata.usecaseId == usecase_id
                ).first()
                if usecase:
                    usecase.scenario_generation = "Completed"
                    logger.info(f"No requirements to process for usecase {usecase_id}. Marking scenario_generation as Completed.")
                    db.commit()
            except Exception as e:
                logger.error(f"Error updating usecase status: {str(e)}")
                
            return
            
        # Update workflow trackers to "Started" for all files
        for file_id in file_ids:
            workflow_tracker = db.query(FileWorkflowTracker).filter(
                FileWorkflowTracker.fileId == file_id
            ).first()
            if workflow_tracker:
                workflow_tracker.scenario_generation = "Started"
        db.commit()
    except Exception as e:
        db.rollback()
        logger.error(f"Error updating workflow trackers: {str(e)}")
    finally:
        db.close()
    
    try:
        # Create a new instance of ScenarioGenerator
        generator = ScenarioGenerator()
        
        # Convert UUID objects to strings before passing to generate_scenarios
        requirement_ids_str = [str(req_id) for req_id in filtered_requirement_ids]
        
        # Call generate_scenarios with the string requirement IDs
        scenarios = generator.generate_scenarios(requirement_ids_str, usecase_id)
        logger.info(f"Successfully generated {len(scenarios)} scenarios")
        
        # After all scenarios are generated, update the isScenarioGenerated flag for each requirement
        db = SessionLocal()
        try:
            for req_id in filtered_requirement_ids:
                requirement = db.query(RequirementData).filter(
                    RequirementData.requirementId == req_id
                ).first()
                if requirement:
                    requirement.isScenarioGenerated = True
            
            # Update workflow trackers to "Completed" for all files
            for file_id in file_ids:
                # Check if all requirements for this file have been processed
                file_requirements = db.query(RequirementData).filter(
                    RequirementData.fileId == file_id
                ).all()
                all_completed = all(req.isScenarioGenerated for req in file_requirements)
                
                if all_completed:
                    workflow_tracker = db.query(FileWorkflowTracker).filter(
                        FileWorkflowTracker.fileId == file_id
                    ).first()
                    if workflow_tracker:
                        workflow_tracker.scenario_generation = "Completed"
            
            # Update the usecase metadata to "Completed" when all scenarios have been generated
            try:
                usecase = db.query(UsecaseMetadata).filter(
                    UsecaseMetadata.usecaseId == usecase_id
                ).first()
                if usecase:
                    # Check if all requirements in this usecase have scenarios generated
                    all_reqs_completed = True
                    # Get all requirements for this usecase
                    for file in db.query(FileMetadata).filter(
                        FileMetadata.usecaseId == usecase_id,
                        FileMetadata.is_deleted == False
                    ).all():
                        file_reqs = db.query(RequirementData).filter(
                            RequirementData.fileId == file.fileId,
                            RequirementData.is_deleted == False
                        ).all()
                        if not all(req.isScenarioGenerated for req in file_reqs):
                            all_reqs_completed = False
                            break
                    
                    if all_reqs_completed:
                        usecase.scenario_generation = "Completed"
                        logger.info(f"All requirements for usecase {usecase_id} have scenarios generated. Marking scenario_generation as Completed.")
            except Exception as e:
                logger.error(f"Error updating usecase metadata: {str(e)}")
            
            db.commit()
            logger.info(f"Updated isScenarioGenerated flag for {len(filtered_requirement_ids)} requirements")
        except Exception as db_error:
            db.rollback()
            logger.error(f"Error updating requirement flags: {str(db_error)}")
        finally:
            db.close()
            
    except Exception as e:
        logger.error(f"Error in background scenario generation: {str(e)}")
        # Update workflow trackers to "Failed" for all files
        db = SessionLocal()
        try:
            for file_id in file_ids:
                workflow_tracker = db.query(FileWorkflowTracker).filter(
                    FileWorkflowTracker.fileId == file_id
                ).first()
                if workflow_tracker:
                    workflow_tracker.scenario_generation = "Failed"
                    workflow_tracker.error_msg = f"Error in scenario generation: {str(e)}"
            db.commit()
        except Exception as db_error:
            db.rollback()
            logger.error(f"Error updating workflow trackers to Failed: {str(db_error)}")
        finally:
            db.close()

@router.post(
    "/generate-by-usecase",
    response_model=ScenarioGenerationResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Generate test scenarios from usecase",
    description="Triggers the generation of test scenarios based on the provided usecase ID."
)
async def generate_scenarios_by_usecase(
    request: UsecaseScenarioRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Endpoint to generate test scenarios from usecase.
    
    Args:
        request: Contains the usecase ID
        background_tasks: FastAPI background tasks handler
        db: Database session
        
    Returns:
        A response indicating the task has been accepted for processing
    """
    try:
        # Get all files associated with the usecase
        files = db.query(FileMetadata).filter(
            FileMetadata.usecaseId == request.usecase_id,
            FileMetadata.is_deleted == False
        ).all()
        
        if not files:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No files found for usecase ID: {request.usecase_id}"
            )
        
        # Get all requirements from these files
        requirement_ids = []
        requirements_list = []
        for file in files:
            requirements = db.query(RequirementData).filter(
                RequirementData.fileId == file.fileId,
                RequirementData.is_deleted == False
            ).all()
            requirement_ids.extend([req.requirementId for req in requirements])
            requirements_list.extend(requirements)
        
        if not requirement_ids:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No requirements found for usecase ID: {request.usecase_id}"
            )

        # Print requirements
        logger.info(f"Requirements for usecase {request.usecase_id}:")
        for req in requirements_list:
            logger.info(f"Requirement ID: {req.requirementId}, Name: {req.requirementName}")
        
        # Add the scenario generation task to background tasks
        background_tasks.add_task(
            _generate_scenarios_background,
            requirement_ids=requirement_ids,
            usecase_id=request.usecase_id
        )
        
        # Update usecase status
        usecase = db.query(UsecaseMetadata).filter(
            UsecaseMetadata.usecaseId == request.usecase_id
        ).first()
        if usecase:
            usecase.scenario_generation = "In Progress"
            db.commit()
        
        return ScenarioGenerationResponse(
            message="Scenario generation started",
            requirement_ids=requirement_ids
        )
        
    except HTTPException as he:
        raise he
    except Exception as e:
        logger.error(f"Error initiating scenario generation for usecase {request.usecase_id}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error initiating scenario generation: {str(e)}"
        )
    
@router.post(
    "/delete-by-scenarioid/{scenario_id}",
    response_model = DeleteScenarioResponse,
    status_code = status.HTTP_200_OK,
    summary = "Toggle deletion status for a scenario and all it's child entities",
    description = "Toggles the is_deleted field of a scenario and all its dependent entities"
)
async def delete_scenario_by_id(
    scenario_id: UUID,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to toggle the deletion status of a scenario and all its dependent entities.
    
    Args:
        scenario_id: The UUID of the scenario to delete
        db_session: Database session dependency
        
    Returns:
        A status information about the toggled scenario
    """
    with db_session as db:
        try:
            scenario = db.query(ScenarioOutput).filter(
                ScenarioOutput.scenarioId == scenario_id
            ).first()
            
            if not scenario:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Scenario not found with ID: {scenario_id}"
                )
            
            # Toggle the is_deleted field for the scenario
            scenario.is_deleted = True

            # Get all test cases for this scenario
            test_cases = db.query(TestCases).filter(
                TestCases.scenarioId == scenario_id
            ).all()

            test_case_ids = []
            # Toggle is_deleted for all test cases
            for test_case in test_cases:
                test_case.is_deleted = True
                test_case_ids.append(test_case.testCaseId)
            
            if test_case_ids:
                # Get all test data for these test cases
                test_data_records = db.query(TestData).filter(
                    TestData.testCaseId.in_(test_case_ids)
                ).all()

                # Toggle is_deleted for all test data
                for test_data in test_data_records:
                    test_data.is_deleted = True

            # Commit all changes
            db.commit()

            # Create a descriptive message about what happened
            deleted_count = {
                "scenario": 1,
                "test_cases": len(test_cases) if 'test_cases' in locals() else 0,
                "test_data": len(test_data_records) if 'test_data_records' in locals() else 0
            }

            logger.info(f"Deleted scenario {scenario_id} and related items: {deleted_count}")

            return DeleteScenarioResponse(
                scenario_id = scenario_id,
                is_deleted = True,
                message = f"Scenario and all related items successfully deleted"
            )
        
        except HTTPException as he:
            raise he
        except Exception as e:
            logger.error(f"Error deleting scenario {scenario_id}: {e}", exc_info=True)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error deleting scenario: {str(e)}"
            )
        
@router.get(
    "/requirement-by-scenario/{scenario_id}",
    status_code=status.HTTP_200_OK,
    summary="Get requirement ID for a scenario",
    description="Retrieves the requirement ID associated with a specific scenario ID."
)
async def get_requirement_by_scenario_id(
    scenario_id: UUID,
    db: Session = Depends(get_db)
):
    """
    Endpoint to retrieve the requirement ID for a specific scenario.
    
    Args:
        scenario_id: The UUID of the scenario
        db: Database session
        
    Returns:
        The requirement ID associated with the specified scenario
    """
    try:
        # Create a new database session using the context manager
        with db as session:
            # Query the scenario to get its requirement ID
            scenario = session.query(ScenarioOutput).filter(
                ScenarioOutput.scenarioId == scenario_id,
                ScenarioOutput.is_deleted == False
            ).first()
            
            if not scenario:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Scenario not found with ID: {scenario_id}"
                )
            
            # Return the requirement ID
            return {
                "scenario_id": scenario_id,
                "requirement_id": scenario.requirementId
            }
    except ValueError as e:
        # Handle invalid UUID format
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid UUID format: {str(e)}"
        )
    except Exception as e:
        logger.error(f"Error fetching requirement for scenario {scenario_id}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error fetching requirement: {str(e)}"
        )

@router.put(
    "/rearrange-scenarios/{usecase_id}",
    response_model = Dict,
    status_code = status.HTTP_200_OK,
    summary = "Rearrange scenarios",
    description = "Rearrange scenarios by providing the usecase id and the display ids will be reassigned if mismatched"
)
async def rearrange_scenarios(
    usecase_id: int,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to rearrange scenarios by providing the usecase id.
    If duplicate display IDs are found, they will be reassigned in an incremental fashion.
    
    Args:
        usecase_id: The ID of the usecase
        db_session: Database session dependency
        
    Returns:
        Dict containing success status and information about updated scenarios
    """
    with db_session as db:
        try:
            # Get the scenarios for this usecase through the file relationship
            scenarios = db.query(ScenarioOutput).join(FileMetadata).filter(
                FileMetadata.usecaseId == usecase_id,
                ScenarioOutput.is_deleted == False
            ).order_by(ScenarioOutput.displayId).all()

            if not scenarios:
                raise HTTPException(
                    status_code = status.HTTP_404_NOT_FOUND,
                    detail = f"No scenarios found for the usecase {usecase_id}"
                )
            
            # Create a dictionary to track seen display IDs
            seen_display_ids = {}
            # Track the maximum display ID for use when reassigning IDs
            max_display_id = 0
            # Track scenarios that need their display ID updated
            scenarios_to_update = []
            
            # First pass: identify duplicates and find max display ID
            for scenario in scenarios:
                # Update max display ID if needed
                if scenario.displayId > max_display_id:
                    max_display_id = scenario.displayId
                    
                # Check if this display ID has been seen before
                if scenario.displayId in seen_display_ids:
                    # This is a duplicate, add to list to update
                    scenarios_to_update.append(scenario)
                else:
                    # Mark this display ID as seen
                    seen_display_ids[scenario.displayId] = scenario
            
            # Second pass: update duplicate display IDs
            updated_count = 0
            for scenario in scenarios_to_update:
                # Increment max_display_id and assign to this scenario
                max_display_id += 1
                scenario.displayId = max_display_id
                updated_count += 1
            
            # Commit changes if any were made
            if updated_count > 0:
                db.commit()
                
            return {
                "success": True,
                "message": f"Scenarios rearranged successfully for usecase {usecase_id}",
                "updated_count": updated_count,
                "total_scenarios": len(scenarios)
            }
                
        except HTTPException as he:
            # Re-raise HTTP exceptions
            raise he
        except Exception as e:
            logger.error(f"Error rearranging scenarios for usecase {usecase_id}: {e}", exc_info=True)
            db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error rearranging scenarios: {str(e)}"
            )