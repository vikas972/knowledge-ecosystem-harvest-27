"""
TestCase API Module

This module provides API endpoints for generating test cases from scenarios.
"""

import sys
from pathlib import Path
# Add the parent directory to sys.path to allow importing from sibling packages
sys.path.append(str(Path(__file__).parent.parent.parent))


import logging
from typing import List, Optional, Dict, Any
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, status
from sqlalchemy.orm import Session
from pydantic import BaseModel

from deps import get_db
from models.generator.test_case import TestCases
from services.generator.test_case_generator import TestCaseGenerator
from models.generator.scenario import ScenarioOutput
from models.use_case.usecase_records import UsecaseMetadata
from models.file_processing.file_record import FileMetadata
from models.generator.test_data import TestData
from models.generator.requirement import RequirementData

router = APIRouter()
logger = logging.getLogger(__name__)

class DeleteTestCaseResponse(BaseModel):
    testcase_id: UUID
    is_deleted: bool
    message: str

# Inline schema definitions
class TestCaseGenerationRequest(BaseModel):
    scenario_ids: List[UUID]

class TestCaseGenerationResponse(BaseModel):
    message: str
    scenario_ids: List[UUID]

class TestCaseGenerationByUsecaseRequest(BaseModel):
    usecase_id: int

@router.post(
    "/generate-by-usecase",
    response_model=TestCaseGenerationResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Generate test cases from usecase",
    description="Triggers the generation of test cases based on the provided usecase ID."
)
async def generate_testcases_by_usecase(
    request: TestCaseGenerationByUsecaseRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Endpoint to generate test cases from usecase.
    
    Args:
        request: Contains the usecase ID to process
        background_tasks: FastAPI background tasks handler
        db: Database session
        
    Returns:
        A response indicating the task has been accepted for processing
    """
    # Get file IDs associated with the usecase
    files = db.query(FileMetadata).filter(
        FileMetadata.usecaseId == request.usecase_id,
        FileMetadata.is_deleted == False
    ).all()
    
    if not files:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No files found for usecase ID {request.usecase_id}"
        )
    
    # Get scenarios for all files
    scenario_ids = []
    for file in files:
        scenarios = db.query(ScenarioOutput).filter(
            ScenarioOutput.fileId == file.fileId,
            ScenarioOutput.is_deleted == False,
            ScenarioOutput.isCompleted == True,
            ScenarioOutput.isTestcasesGenerated == False
        ).all()
        
        scenario_ids.extend([scenario.scenarioId for scenario in scenarios])
    
    if not scenario_ids:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No eligible scenarios found for test case generation"
        )
    
    # Add the test case generation task to background tasks
    background_tasks.add_task(
        _generate_testcases_background,
        scenario_ids=scenario_ids,
        usecase_id=request.usecase_id
    )
    
    # Update usecase status
    usecase = db.query(UsecaseMetadata).filter(
        UsecaseMetadata.usecaseId == request.usecase_id
    ).first()
    if usecase:
        usecase.test_case_generation = "In Progress"
        db.commit()
    
    return TestCaseGenerationResponse(
        message="Test case generation started",
        scenario_ids=scenario_ids
    )

@router.post(
    "/generate-by-scenarios",
    response_model=TestCaseGenerationResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Generate test cases from scenarios",
    description="Triggers the generation of test cases based on the provided scenario IDs. "
                "The generation process runs as a background task."
)
async def generate_testcases(
    request: TestCaseGenerationRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Endpoint to generate test cases from scenarios.
    
    Args:
        request: Contains the list of scenario IDs to process
        background_tasks: FastAPI background tasks handler
        db: Database session
        
    Returns:
        A response indicating the task has been accepted for processing
    """
    if not request.scenario_ids:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No scenario IDs provided"
        )
    
    # Add the test case generation task to background tasks
    background_tasks.add_task(
        _generate_testcases_background,
        scenario_ids=request.scenario_ids
    )
    
    return TestCaseGenerationResponse(
        message="Test case generation started",
        scenario_ids=request.scenario_ids
    )

@router.get(
    "/get-testcases-by-scenarioid/{scenario_id}",
    response_model=List[Dict[str, Any]],
    status_code=status.HTTP_200_OK,
    summary="Get test cases for a scenario",
    description="Retrieves all generated test cases for a specific scenario ID."
)
async def get_testcases_by_scenario(
    scenario_id: UUID,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to retrieve test cases for a specific scenario.
    
    Args:
        scenario_id: The UUID of the scenario
        db: Database session
        
    Returns:
        A list of test case outputs for the specified scenario
    """
    with db_session as db:
        # Get the scenario information for its displayId
        scenario = db.query(ScenarioOutput).filter(
            ScenarioOutput.scenarioId == scenario_id
        ).first()
        
        if not scenario:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No scenario found with ID: {scenario_id}"
            )
        
        # Get the requirement information for its displayId
        requirement = None
        if scenario.requirementId:
            requirement = db.query(RequirementData).filter(
                RequirementData.requirementId == scenario.requirementId
            ).first()
        
        testcases = db.query(TestCases).filter(
            TestCases.scenarioId == scenario_id,
            TestCases.isTestDataGenerated == True  # Only return test cases with test steps generated
        ).all()
        
        if not testcases:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No test cases with test steps found for scenario ID: {scenario_id}"
            )
        
        # Include scenario_display_id, requirement_display_id, and requirement_id in the response
        return [
            {
                "testCaseId": testcase.testCaseId,
                "fileId": testcase.fileId,
                "scenarioId": testcase.scenarioId,
                "scenario_display_id": scenario.displayId if scenario else None,
                "requirement_display_id": requirement.displayId if requirement else None,
                "requirement_id": scenario.requirementId if scenario else None,
                "isCompleted": testcase.isCompleted,
                "isTestDataGenerated": testcase.isTestDataGenerated,
                "errorMessage": testcase.errorMessage,
                "testJson": testcase.testJson,
                "createdAt": testcase.createdAt,
                "updatedAt": testcase.updatedAt,
                "is_deleted": testcase.is_deleted,
                "displayId": testcase.displayId
            }
            for testcase in testcases
        ]

@router.get(
    "/get-testcase-by-testcaseid/{testcase_id}",
    status_code=status.HTTP_200_OK,
    summary="Get test case by ID",
    description="Retrieves a specific test case by its ID."
)
async def get_testcase_by_id(
    testcase_id: UUID,
    db: Session = Depends(get_db)
):
    """
    Endpoint to retrieve a specific test case by ID.
    
    Args:
        testcase_id: The UUID of the test case
        db: Database session
        
    Returns:
        The test case output for the specified ID
    """
    with next(get_db()) as session:
        testcase = session.query(TestCases).filter(
            TestCases.testCaseId == testcase_id
        ).first()
        
        if not testcase:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Test case not found with ID: {testcase_id}"
            )
        
        return {
            "testCaseId": testcase.testCaseId,
            "fileId": testcase.fileId,
            "scenarioId": testcase.scenarioId,
            "isCompleted": testcase.isCompleted,
            "isTestDataGenerated": testcase.isTestDataGenerated,
            "errorMessage": testcase.errorMessage,
            "testJson": testcase.testJson,
            "createdAt": testcase.createdAt,
            "updatedAt": testcase.updatedAt,
            "is_deleted": testcase.is_deleted,
            "displayId": testcase.displayId
        }

@router.get(
    "/get-testcases-for-usecase/{usecase_id}",
    status_code=status.HTTP_200_OK,
    summary="Get all test cases for a usecase",
    description="Retrieves all test cases organized by scenarios for a specific usecase ID."
)
async def get_testcases_by_usecase(
    usecase_id: int,
    db: Session = Depends(get_db)
):
    """
    Endpoint to retrieve all test cases for a specific usecase, organized by scenarios.
    
    Args:
        usecase_id: The ID of the usecase
        db: Database session
        
    Returns:
        A list of scenarios with their associated test cases for the specified usecase
    """
    with db as session:
        usecase = session.query(UsecaseMetadata).filter(
            UsecaseMetadata.usecaseId == usecase_id
        ).first()
        
        if not usecase:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Usecase not found with ID: {usecase_id}"
            )
        
        files = session.query(FileMetadata).filter(
            FileMetadata.usecaseId == usecase_id
        ).all()
        
        if not files:
            return {
                "usecase_id": usecase_id,
                "usecase_name": usecase.usecaseName,
                "scenarios": []
            }
        
        file_ids = [file.fileId for file in files]
        
        scenarios = session.query(ScenarioOutput).filter(
            ScenarioOutput.fileId.in_(file_ids)
        ).all()
        
        if not scenarios:
            return {
                "usecase_id": usecase_id,
                "usecase_name": usecase.usecaseName,
                "scenarios": []
            }
        
        result = {
            "usecase_id": usecase_id,
            "usecase_name": usecase.usecaseName,
            "scenarios": []
        }
        
        for scenario in scenarios:
            testcases = session.query(TestCases).filter(
                TestCases.scenarioId == scenario.scenarioId,
                TestCases.isTestDataGenerated == True  # Only return test cases with test steps generated
            ).all()
            
            # Get the requirement information for this scenario
            requirement = None
            if scenario.requirementId:
                requirement = session.query(RequirementData).filter(
                    RequirementData.requirementId == scenario.requirementId
                ).first()
            
            scenario_data = {
                "scenario_id": scenario.scenarioId,
                "file_id": scenario.fileId,
                "is_completed": scenario.isCompleted,
                "test_cases": []
            }
            
            for testcase in testcases:
                if testcase.isCompleted:
                    testcase_data = {
                        "testcase_id": testcase.testCaseId,
                        "is_completed": testcase.isCompleted,
                        "is_test_data_generated": testcase.isTestDataGenerated,
                        "error_message": testcase.errorMessage,
                        "test_json": testcase.testJson,
                        "created_at": testcase.createdAt,
                        "updated_at": testcase.updatedAt,
                        "is_deleted": testcase.is_deleted,
                        "displayId": testcase.displayId,
                        "scenario_display_id": scenario.displayId if scenario else None,
                        "requirement_display_id": requirement.displayId if requirement else None,
                        "requirement_id": scenario.requirementId if scenario else None
                    }
                    scenario_data["test_cases"].append(testcase_data)
            
            result["scenarios"].append(scenario_data)
        
        return result

def _generate_testcases_background(scenario_ids: List[UUID], usecase_id: int):
    """
    Background task function to generate test cases.
    
    Args:
        scenario_ids: List of scenario IDs to process
    """
    logger.info(f"Starting background test case generation for {len(scenario_ids)} scenarios")
    
    # Filter scenarios to only those that need test case generation
    filtered_scenario_ids = []
    try:
        db = next(get_db())
        try:
            for scenario_id in scenario_ids:
                scenario = db.query(ScenarioOutput).filter(
                    ScenarioOutput.scenarioId == scenario_id
                ).first()
                if scenario and not scenario.isTestcasesGenerated and not scenario.is_deleted:
                    filtered_scenario_ids.append(scenario_id)
                else:
                    logger.info(f"Skipping scenario {scenario_id} - already has test cases generated or is deleted")
        finally:
            db.close()
            
        logger.info(f"Filtered from {len(scenario_ids)} to {len(filtered_scenario_ids)} scenarios that need test case generation")
        
        # If no scenarios need processing, exit early
        if not filtered_scenario_ids:
            logger.info("No scenarios need test case generation, exiting early")
            # Update the usecase metadata to indicate completion since there's nothing to process
            db = next(get_db())
            try:
                usecase = db.query(UsecaseMetadata).filter(
                    UsecaseMetadata.usecaseId == usecase_id
                ).first()
                if usecase:
                    usecase.test_case_generation = "Completed"
                    logger.info(f"No scenarios to process for usecase {usecase_id}. Marking test_case_generation as Completed.")
                    db.commit()
            except Exception as e:
                logger.error(f"Error updating usecase status: {str(e)}")
            return
            
        usecase = db.query(UsecaseMetadata).filter(
            UsecaseMetadata.usecaseId == usecase_id
        ).first()
        if usecase:
            # usecase.test_case_generation = "In Progress"
            # db.commit()
            product = usecase.product
        else:
            product = None

        generator = TestCaseGenerator()
        testcases = generator.generate_testcases(filtered_scenario_ids, product, usecase_id)
        logger.info(f"Successfully generated {len(testcases)} test cases")
        
        # Update the isTestcasesGenerated flag for each scenario
        db = next(get_db())
        try:
            for scenario_id in filtered_scenario_ids:
                scenario = db.query(ScenarioOutput).filter(
                    ScenarioOutput.scenarioId == scenario_id
                ).first()
                if scenario:
                    scenario.isTestcasesGenerated = True
            
            # Check if all scenarios for this usecase have test cases generated
            if usecase:
                # Get all files for this usecase
                files = db.query(FileMetadata).filter(
                    FileMetadata.usecaseId == usecase_id,
                    FileMetadata.is_deleted == False
                ).all()
                
                file_ids = [file.fileId for file in files]
                
                # Count total scenarios and scenarios with test cases generated
                total_scenarios = db.query(ScenarioOutput).filter(
                    ScenarioOutput.fileId.in_(file_ids),
                    ScenarioOutput.is_deleted == False,
                    ScenarioOutput.isCompleted == True
                ).count()
                
                scenarios_with_testcases = db.query(ScenarioOutput).filter(
                    ScenarioOutput.fileId.in_(file_ids),
                    ScenarioOutput.is_deleted == False,
                    ScenarioOutput.isCompleted == True,
                    ScenarioOutput.isTestcasesGenerated == True
                ).count()
                
                logger.info(f"Usecase {usecase_id}: {scenarios_with_testcases}/{total_scenarios} scenarios have test cases generated")
                
                # Update usecase status based on completion status
                if total_scenarios > 0 and scenarios_with_testcases == total_scenarios:
                    usecase.test_case_generation = "Completed"
                    logger.info(f"All scenarios for usecase {usecase_id} have test cases generated. Marking as Completed.")
                else:
                    usecase.test_case_generation = "In Progress"
                    logger.info(f"Some scenarios for usecase {usecase_id} still need test case generation. Keeping status as In Progress.")
            
            db.commit()
            logger.info(f"Updated isTestcasesGenerated flag for {len(filtered_scenario_ids)} scenarios")
        except Exception as db_error:
            if usecase:
                usecase.test_case_generation = "Failed"
            db.rollback()
            logger.error(f"Error updating scenario flags: {str(db_error)}")
            
    except Exception as e:
        db = next(get_db())
        usecase = db.query(UsecaseMetadata).filter(
            UsecaseMetadata.usecaseId == usecase_id
        ).first()
        if usecase:
            usecase.test_case_generation = "Failed"
            db.commit()
        logger.error(f"Error in background test case generation: {str(e)}")


@router.post(
    "/delete-by-testcaseid/{testcase_id}",
    response_model = DeleteTestCaseResponse,
    status_code = status.HTTP_200_OK,
    summary = "Toggle deletion status for a test case and all it's child entities",
    description = "Toggles the is_deleted field of a test case and all its dependent entities"
)
async def delete_testcase_by_id(
    testcase_id: UUID,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to toggle the deletion status of a test case and all its dependent entities.
    
    Args:
        testcase_id: The UUID of the test case to delete
        db_session: Database session dependency
    
    Returns:
        A status information about the toggled test case
    """
    with db_session as db:
        try:
            testcase = db.query(TestCases).filter(
                TestCases.testCaseId == testcase_id
            ).first()

            if not testcase:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    
                )
            
            testcase.is_deleted = True

            # Get all test data for this test case
            test_data_records = db.query(TestData).filter(
                TestData.testCaseId == testcase_id
            ).all()

            test_data_ids = []

            for test_data in test_data_records:
                test_data.is_deleted = True
        
            db.commit()

            deleted_count = {
                "test_case": 1,
                "test_data": len(test_data_records) if 'test_data_records' in locals() else 0
            }

            logger.info(f"Deleted test case {testcase_id} and related items: {deleted_count}")
            
            return DeleteTestCaseResponse(
                testcase_id = testcase_id,
                is_deleted = True,
                message = f"Test case and all related items successfully deleted"
            )
    
        except HTTPException as he:
            raise he
        except Exception as e:
            logger.error(f"Error deleting test case {testcase_id}: {e}", exc_info=True)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error deleting test case: {str(e)}"
            )
        

@router.get(
    "/scenario-by-testcaseid/{testcase_id}",
    status_code=status.HTTP_200_OK,
    summary="Get scenario ID for a test case",
    description="Retrieves the scenario ID associated with a specific test case ID."
)
async def get_scenario_by_testcase_id(
    testcase_id: UUID,
    db: Session = Depends(get_db)
):
    """
    Endpoint to retrieve the scenario ID for a specific test case.
    
    Args:
        testcase_id: The UUID of the test case
        db: Database session
        
    Returns:
        The scenario ID associated with the specified test case
    """
    try:
        # Create a new database session using the context manager
        with db as session:
            # Query the test case to get its scenario ID
            testcase = session.query(TestCases).filter(
                TestCases.testCaseId == testcase_id,
                TestCases.is_deleted == False
            ).first()
            
            if not testcase:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Test case not found with ID: {testcase_id}"
                )
            
            # Get the scenario to include its displayId
            scenario = session.query(ScenarioOutput).filter(
                ScenarioOutput.scenarioId == testcase.scenarioId
            ).first()
            
            scenario_display_id = None
            if scenario:
                scenario_display_id = scenario.displayId
            
            # Return testcase_id, scenario_id, and scenario_display_id
            return {
                "testcase_id": testcase_id,
                "scenario_id": testcase.scenarioId,
                "scenario_display_id": scenario_display_id
            }
    except ValueError as e:
        # Handle invalid UUID format
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid UUID format: {str(e)}"
        )
    except Exception as e:
        logger.error(f"Error fetching scenario for test case {testcase_id}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error fetching scenario: {str(e)}"
        )

@router.get(
    "/requirement-by-testcaseid/{testcase_id}",
    status_code=status.HTTP_200_OK,
    summary="Get requirement ID for a test case",
    description="Retrieves the requirement ID associated with a specific test case ID."
)
async def get_requirement_by_testcase_id(
    testcase_id: UUID,
    db: Session = Depends(get_db)
):
    """
    Endpoint to retrieve the requirement ID for a specific test case.
    
    Args:
        testcase_id: The UUID of the test case
        db: Database session
        
    Returns:
        The requirement ID associated with the specified test case
    """
    try:
        # Create a new database session using the context manager
        with db as session:
            # First, query the test case to get its scenario ID
            testcase = session.query(TestCases).filter(
                TestCases.testCaseId == testcase_id,
                TestCases.is_deleted == False
            ).first()
            
            if not testcase:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Test case not found with ID: {testcase_id}"
                )
            
            # Now, query the scenario to get its requirement ID
            scenario = session.query(ScenarioOutput).filter(
                ScenarioOutput.scenarioId == testcase.scenarioId,
                ScenarioOutput.is_deleted == False
            ).first()
            
            if not scenario:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Scenario not found with ID: {testcase.scenarioId}"
                )
            
            # Get the requirement to include its displayId
            requirement = session.query(RequirementData).filter(
                RequirementData.requirementId == scenario.requirementId
            ).first()
            
            requirement_display_id = None
            if requirement:
                requirement_display_id = requirement.displayId
            
            # Return testcase_id, requirement_id, and requirement_display_id
            return {
                "testcase_id": testcase_id,
                "requirement_id": scenario.requirementId,
                "requirement_display_id": requirement_display_id
            }
    except ValueError as e:
        # Handle invalid UUID format
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid UUID format: {str(e)}"
        )
    except Exception as e:
        logger.error(f"Error fetching requirement for test case {testcase_id}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error fetching requirement: {str(e)}"
        )

@router.put(
    "/rearrange-testcases/{usecase_id}",
    response_model = Dict,
    status_code = status.HTTP_200_OK,
    summary = "Rearrange test cases",
    description = "Rearrange test cases by providing the usecase id and the display ids will be reassigned if mismatched"
)
async def rearrange_testcases(
    usecase_id: int,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to rearrange test cases by providing the usecase id.
    If duplicate display IDs are found, they will be reassigned in an incremental fashion.
    
    Args:
        usecase_id: The ID of the usecase
        db_session: Database session dependency
        
    Returns:
        Dict containing success status and information about updated test cases
    """
    with db_session as db:
        try:
            # Get all files associated with this usecase
            files = db.query(FileMetadata).filter(
                FileMetadata.usecaseId == usecase_id,
                FileMetadata.is_deleted == False
            ).all()
            
            if not files:
                raise HTTPException(
                    status_code = status.HTTP_404_NOT_FOUND,
                    detail = f"No files found for the usecase {usecase_id}"
                )
            
            file_ids = [file.fileId for file in files]
            
            # Get the test cases for this usecase through the file relationship
            testcases = db.query(TestCases).filter(
                TestCases.fileId.in_(file_ids),
                TestCases.is_deleted == False
            ).order_by(TestCases.displayId).all()

            if not testcases:
                raise HTTPException(
                    status_code = status.HTTP_404_NOT_FOUND,
                    detail = f"No test cases found for the usecase {usecase_id}"
                )
            
            # Create a dictionary to track seen display IDs
            seen_display_ids = {}
            # Track the maximum display ID for use when reassigning IDs
            max_display_id = 0
            # Track test cases that need their display ID updated
            testcases_to_update = []
            
            # First pass: identify duplicates and find max display ID
            for testcase in testcases:
                # Update max display ID if needed
                if testcase.displayId > max_display_id:
                    max_display_id = testcase.displayId
                    
                # Check if this display ID has been seen before
                if testcase.displayId in seen_display_ids:
                    # This is a duplicate, add to list to update
                    testcases_to_update.append(testcase)
                else:
                    # Mark this display ID as seen
                    seen_display_ids[testcase.displayId] = testcase
            
            # Second pass: update duplicate display IDs
            updated_count = 0
            for testcase in testcases_to_update:
                # Increment max_display_id and assign to this test case
                max_display_id += 1
                testcase.displayId = max_display_id
                updated_count += 1
            
            # Commit changes if any were made
            if updated_count > 0:
                db.commit()
                
            return {
                "success": True,
                "message": f"Test cases rearranged successfully for usecase {usecase_id}",
                "updated_count": updated_count,
                "total_testcases": len(testcases)
            }
                
        except HTTPException as he:
            # Re-raise HTTP exceptions
            raise he
        except Exception as e:
            logger.error(f"Error rearranging test cases for usecase {usecase_id}: {e}", exc_info=True)
            db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error rearranging test cases: {str(e)}"
            )