"""
Requirement API Module

This module provides API endpoints for retrieving and managing requirements.
"""

import sys
from pathlib import Path

from services.generator.requirement_parser import process_user_requirement
# Add the parent directory to sys.path to allow importing from sibling packages
sys.path.append(str(Path(__file__).parent.parent.parent))
import json
import logging
from typing import List, Dict, Any, Optional
from uuid import UUID
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import func
from pydantic import BaseModel, ConfigDict ,field_validator
import uuid
from sqlalchemy.exc import IntegrityError

from deps import get_db
from models.generator.requirement import RequirementData
from models.generator.scenario import ScenarioOutput
from models.generator.test_case import TestCases
from models.generator.test_data import TestData
from models.file_processing.file_record import FileMetadata
from models.use_case.usecase_records import UsecaseMetadata
from core.config import HostingConfigs
from uuid import uuid4

router = APIRouter()
logger = logging.getLogger(__name__)

# Schema for adding a new requirement to a usecase
class NewRequirement(BaseModel):
    requirementName: str
    requirementDescription: str
    userStories: List[str]
    requirements: Dict[str, List[str]]

# Schema for requirement response
class RequirementResponse(BaseModel):
    # fields from the requirement table to be fetched
    requirementId: UUID
    requirementName: str
    isCompleted: bool
    isScenarioGenerated: bool
    errorMessage: Optional[str] = None
    requirementJson: Optional[Dict[str, Any]] = None
    fileId: UUID
    is_deleted: Optional[bool] = None
    displayId: int

    model_config = ConfigDict(from_attributes=True)

    @field_validator('requirementJson', mode='before')
    @classmethod
    def parse_json_string(cls, value):
        if value is None:
            return None
        if isinstance(value, dict):
            return value
        if isinstance(value, str):
            try:
                return json.loads(value)
            except json.JSONDecodeError as e:
                logger.error(f"Error parsing requirementJson: {e}")
                return None
        return value

class RequirementsStatusResponse(BaseModel):
    requirements: List[RequirementResponse]
    all_completed: bool

# Schema for delete requirement response
class DeleteRequirementResponse(BaseModel):
    requirementId: UUID
    is_deleted: bool
    message: str

@router.get(
    "/get-by-usecaseid/{usecase_id}",
    response_model=RequirementsStatusResponse,
    status_code=status.HTTP_200_OK,
    summary="Get requirements for a usecase",
    description="Retrieves all requirements associated with a specific usecase ID."
)
async def get_requirements_by_usecase(
    usecase_id: int,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to retrieve requirements for a specific usecase.
    
    Args:
        usecase_id: The ID of the usecase
        db_session: Database session dependency
        
    Returns:
        A list of requirements for the specified usecase and whether all are completed
    """
    with db_session as db:
        try:
            # First get all files for this usecase
            files = db.query(FileMetadata).filter(
                FileMetadata.usecaseId == usecase_id
            ).all()
            
            if not files:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"No files found for usecase ID: {usecase_id}"
                )
            
            # Get file IDs
            file_ids = [file.fileId for file in files]
            
            # Get all requirements for these files
            requirements = db.query(RequirementData).filter(
                RequirementData.fileId.in_(file_ids)
            ).all()
            
            if not requirements:
                return RequirementsStatusResponse(
                    requirements=[],
                    all_completed=False
                )
            
            # Check if all requirements are completed
            all_completed = all(req.isCompleted for req in requirements)
            
            # Convert SQLAlchemy models to Pydantic models
            requirement_responses = [RequirementResponse.model_validate(req) for req in requirements]
            
            return RequirementsStatusResponse(
                requirements=requirement_responses,
                all_completed=all_completed
            )
            
        except Exception as e:
            logger.error(f"Error fetching requirements for usecase {usecase_id}: {e}", exc_info=True)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error fetching requirements for usecase {usecase_id}: {str(e)}"
            )

@router.get(
    "/get-by-requirementid/{requirement_id}",
    response_model=RequirementResponse,
    status_code=status.HTTP_200_OK,
    summary="Get requirement by ID",
    description="Retrieves a specific requirement by its ID."
)
async def get_requirement_by_id(
    requirement_id: UUID,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to retrieve a specific requirement by ID.
    
    Args:
        requirement_id: The UUID of the requirement
        db_session: Database session dependency
        
    Returns:
        The requirement data for the specified ID
    """
    with db_session as db:
        try:
            requirement = db.query(RequirementData).filter(
                RequirementData.requirementId == requirement_id
            ).first()
            
            if not requirement:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Requirement not found with ID: {requirement_id}"
                )
            
            # Convert SQLAlchemy model to Pydantic model
            return RequirementResponse.model_validate(requirement)
            
        except Exception as e:
            logger.error(f"Error fetching requirement {requirement_id}: {e}", exc_info=True)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error fetching requirement {requirement_id}: {str(e)}"
            ) 
        
@router.post(
    "/generate-by-usecaseid/{usecase_id}",
    response_model=Dict,
    status_code=status.HTTP_200_OK,
    summary="Generate requirements for usecase",
    description="Generates requirements for a specific usecase ID."
)
async def generate_requirements(
    usecase_id: int,
    background_tasks: BackgroundTasks
):
    """
    Endpoint to generate requirements for a specific usecase.
    
    Args:
        usecase_id: The ID of the usecase
        background_tasks: FastAPI BackgroundTasks
        
    Returns:
        Dict containing success status and message
    """
    try:
        background_tasks.add_task(
            process_user_requirement,
            usecase_id=usecase_id
        )
            
        return {
            "success": True,
            "message": f"Requirements generation for usecase {usecase_id} has been started in the background"
        }
        
    except Exception as e:
        logger.error(f"Error generating requirements for usecase {usecase_id}: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error generating requirements for usecase {usecase_id}: {str(e)}"
        )

@router.post(
    "/delete-by-requirementid/{requirement_id}",
    response_model=DeleteRequirementResponse,
    status_code=status.HTTP_200_OK,
    summary="Toggle deletion status of a requirement",
    description="Toggles the is_deleted field of a requirement and all its dependent entities."
)
async def delete_requirement_by_id(
    requirement_id: UUID,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to toggle the deletion status of a requirement by ID and cascade the deletion to all related entities.
    
    Args:
        requirement_id: The UUID of the requirement
        db_session: Database session dependency
        
    Returns:
        Status information about the toggled requirement
    """
    with db_session as db:
        try:
            # Find the requirement
            requirement = db.query(RequirementData).filter(
                RequirementData.requirementId == requirement_id
            ).first()
            
            if not requirement:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Requirement not found with ID: {requirement_id}"
                )
            
            # Toggle the is_deleted field for requirement
            requirement.is_deleted = True
            
            # 1. Get all scenarios for this requirement
            scenarios = db.query(ScenarioOutput).filter(
                ScenarioOutput.requirementId == requirement_id
            ).all()
            
            scenario_ids = []
            # 2. Toggle is_deleted for all scenarios
            for scenario in scenarios:
                scenario.is_deleted = True
                scenario_ids.append(scenario.scenarioId)
            
            if scenario_ids:
                # 3. Get all test cases for these scenarios
                test_cases = db.query(TestCases).filter(
                    TestCases.scenarioId.in_(scenario_ids)
                ).all()
                
                test_case_ids = []
                # 4. Toggle is_deleted for all test cases
                for test_case in test_cases:
                    test_case.is_deleted = True
                    test_case_ids.append(test_case.testCaseId)
                
                if test_case_ids:
                    # 5. Get all test data for these test cases
                    test_data_records = db.query(TestData).filter(
                        TestData.testCaseId.in_(test_case_ids)
                    ).all()
                    
                    # 6. Toggle is_deleted for all test data
                    for test_data in test_data_records:
                        test_data.is_deleted = True
            
            # Commit all changes
            db.commit()
            
            # Create a descriptive message about what happened
            deleted_count = {
                "requirements": 1,
                "scenarios": len(scenarios),
                "test_cases": len(test_cases) if 'test_cases' in locals() else 0,
                "test_data": len(test_data_records) if 'test_data_records' in locals() else 0
            }
            
            logger.info(f"Deleted requirement {requirement_id} and related items: {deleted_count}")
            
            return DeleteRequirementResponse(
                requirementId=requirement_id,
                is_deleted=True,
                message=f"Requirement and all related items successfully deleted"
            )
            
        except HTTPException as he:
            # Re-raise HTTP exceptions as they already have status codes
            raise he
        except Exception as e:
            logger.error(f"Error deleting requirement {requirement_id}: {e}", exc_info=True)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error deleting requirement: {str(e)}"
            )
    
@router.post(
    "/add-requirement-by-usecaseid/{usecase_id}",
    response_model = Dict,
    status_code = status.HTTP_201_CREATED,
    summary = "Add a new requirement to a usecase",
    description = "Add a new requirement to a usecase by providing the usecaseid"
)
async def add_requirement_by_usecaseid(
    usecase_id: int,
    new_requirement: NewRequirement,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to add a new requirement to a usecase.
    
    Args:
        usecase_id: The ID of the usecase
        new_requirement: The new requirement to add
        db_session: The database session
    """
    max_retries = 3
    for attempt in range(max_retries):
        try:
            with db_session as db:
                # check if usecase already exists
                usecase = db.query(UsecaseMetadata).filter(
                    UsecaseMetadata.usecaseId == usecase_id
                ).first()
                
                if not usecase:
                    raise HTTPException(
                        status_code = status.HTTP_404_NOT_FOUND,
                        detail = f"Usecase {usecase_id} does not exist"
                    )
                
                # Get all files associated with this usecase
                files_for_usecase = db.query(FileMetadata).filter(
                    FileMetadata.usecaseId == usecase_id
                ).all()
                
                if not files_for_usecase:
                    raise HTTPException(
                        status_code = status.HTTP_404_NOT_FOUND,
                        detail = f"No files found for the usecase {usecase_id}"
                    )
                
                file_ids = [file.fileId for file in files_for_usecase]
                
                # Get the max displayId
                max_display_id = db.query(func.max(RequirementData.displayId)).filter(
                    RequirementData.fileId.in_(file_ids)
                ).scalar()
                
                new_display_id = 1
                if max_display_id is not None:
                    new_display_id = max_display_id + 1
                
                # Create requirement JSON with user journeys
                requirement_json = {
                    "user_journeys": [
                        {
                            "name": new_requirement.requirementName,
                            "description": new_requirement.requirementDescription,
                            "user_stories": new_requirement.userStories,
                            "requirements": new_requirement.requirements
                        }
                    ]
                }
                
                # Generate a new UUID for the requirement
                new_requirement_id = uuid.uuid4()
                
                # Create a new requirement record
                new_req = RequirementData(
                    requirementId = new_requirement_id,
                    requirementName = new_requirement.requirementName,
                    isCompleted = True,  # Since we're directly creating this requirement
                    isScenarioGenerated = False,
                    requirementJson = json.dumps(requirement_json),
                    fileId = file_ids[0],
                    displayId = new_display_id,
                    errorMessage = None,
                    is_deleted = False
                    # createdAt and updatedAt will use default values from the model
                )
                
                db.add(new_req)
                db.commit()

                # updating usecasemetadata - reseting it back to scenario generation in progress
                db.query(UsecaseMetadata).filter(UsecaseMetadata.usecaseId == usecase_id).update({
                    UsecaseMetadata.scenario_generation: "In Progress",
                    UsecaseMetadata.test_case_generation: "Not Started",
                    UsecaseMetadata.test_data_generation: "Not Started"
                })
                db.commit()

                

                
                return {
                    "success": True,
                    "message": f"New requirement '{new_requirement.requirementName}' added successfully",
                    "requirementId": new_requirement_id,
                    "displayId": new_display_id
                }
                
        except IntegrityError as e:
            # If we encounter a unique constraint violation, retry
            db_session.rollback()
            if attempt == max_retries - 1:  # Last attempt
                logger.error(f"Failed to add requirement after {max_retries} attempts: {e}", exc_info=True)
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Could not generate a unique display ID after {max_retries} attempts"
                )
            logger.warning(f"Retrying requirement creation due to possible race condition (attempt {attempt+1}/{max_retries})")
        except Exception as e:
            logger.error(f"Error adding requirement for usecase {usecase_id}: {e}", exc_info=True)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error adding requirement: {str(e)}"
            )
    
    # This shouldn't be reached due to the exception in the last retry attempt
    raise HTTPException(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        detail="Unexpected error occurred while creating requirement"
    )

@router.put(
    "/rearrange-requirements/{usecase_id}",
    response_model = Dict,
    status_code = status.HTTP_200_OK,
    summary = "Rearrange requirements",
    description = "Rearrange requirements by providing the usecase id and the display ids will be reassigned if mismatched"
)
async def rearrange_requirements(
    usecase_id: int,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to rearrange requirements by providing the usecase id.
    If duplicate display IDs are found, they will be reassigned in an incremental fashion.
    
    Args:
        usecase_id: The ID of the usecase
        db_session: Database session dependency
        
    Returns:
        Dict containing success status and information about updated requirements
    """
    with db_session as db:
        try:
            # Get the requirements for this usecase through the file relationship
            requirements = db.query(RequirementData).join(FileMetadata).filter(
                FileMetadata.usecaseId == usecase_id,
                RequirementData.is_deleted == False
            ).order_by(RequirementData.displayId).all()

            if not requirements:
                raise HTTPException(
                    status_code = status.HTTP_404_NOT_FOUND,
                    detail = f"No requirements found for the usecase {usecase_id}"
                )
            
            # Create a dictionary to track seen display IDs
            seen_display_ids = {}
            # Track the maximum display ID for use when reassigning IDs
            max_display_id = 0
            # Track requirements that need their display ID updated
            requirements_to_update = []
            
            # First pass: identify duplicates and find max display ID
            for req in requirements:
                # Update max display ID if needed
                if req.displayId > max_display_id:
                    max_display_id = req.displayId
                    
                # Check if this display ID has been seen before
                if req.displayId in seen_display_ids:
                    # This is a duplicate, add to list to update
                    requirements_to_update.append(req)
                else:
                    # Mark this display ID as seen
                    seen_display_ids[req.displayId] = req
            
            # Second pass: update duplicate display IDs
            updated_count = 0
            for req in requirements_to_update:
                # Increment max_display_id and assign to this requirement
                max_display_id += 1
                req.displayId = max_display_id
                updated_count += 1
            
            # Commit changes if any were made
            if updated_count > 0:
                db.commit()
                
            return {
                "success": True,
                "message": f"Requirements rearranged successfully for usecase {usecase_id}",
                "updated_count": updated_count,
                "total_requirements": len(requirements)
            }
                
        except HTTPException as he:
            # Re-raise HTTP exceptions
            raise he
        except Exception as e:
            logger.error(f"Error rearranging requirements for usecase {usecase_id}: {e}", exc_info=True)
            db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error rearranging requirements: {str(e)}"
            )