"""
Test Scripts API Module

This module provides API endpoints for retrieving and managing test scripts.
"""

import sys
from pathlib import Path
# Add the parent directory to sys.path to allow importing from sibling packages
sys.path.append(str(Path(__file__).parent.parent.parent))

import logging
from typing import List, Dict, Any, Optional
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, status
from sqlalchemy.orm import Session
from sqlalchemy import func
from pydantic import BaseModel, ConfigDict, field_validator
import json
import uuid

from deps import get_db
from models.generator.test_scripts import TestScripts
from models.generator.test_case import TestCases
from models.generator.scenario import ScenarioOutput
from models.generator.requirement import RequirementData
from models.file_processing.file_record import FileMetadata
from models.use_case.usecase_records import UsecaseMetadata
from services.generator.test_script_generator import TestScriptGenerator

router = APIRouter()
logger = logging.getLogger(__name__)

# Pydantic models for requests and responses
class TestScriptResponse(BaseModel):
    testScriptId: UUID
    testCaseId: UUID
    scenarioId: UUID
    requirementId: Optional[UUID] = None
    fileId: UUID
    displayId: int
    isCompleted: bool
    errorMessage: Optional[str] = None
    testScriptJson: Dict[str, Any]
    is_deleted: Optional[bool] = None
    createdAt: Optional[Any] = None
    updatedAt: Optional[Any] = None
    scenario_display_id: Optional[int] = None
    testcase_display_id: Optional[int] = None
    requirement_display_id: Optional[int] = None

    model_config = ConfigDict(from_attributes=True)

    @field_validator('testScriptJson', mode='before')
    @classmethod
    def parse_json_string(cls, value):
        if value is None:
            return None
        if isinstance(value, dict):
            return value
        if isinstance(value, str):
            try:
                return json.loads(value)
            except json.JSONDecodeError as e:
                logger.error(f"Error parsing testScriptJson: {e}")
                return None
        return value

class TestScriptGenerationRequest(BaseModel):
    testcase_ids: List[UUID]

class TestScriptGenerationResponse(BaseModel):
    message: str
    testcase_ids: List[UUID]

class TestScriptGenerationByUsecaseRequest(BaseModel):
    usecase_id: int

class DeleteTestScriptResponse(BaseModel):
    testscript_id: UUID
    is_deleted: bool
    message: str

class UpdateTestScriptRequest(BaseModel):
    testScriptJson: Dict[str, Any]

class UpdateTestScriptResponse(BaseModel):
    testscript_id: UUID
    message: str

@router.get(
    "/get-testscripts-by-testcaseid/{testcase_id}",
    response_model=List[TestScriptResponse],
    status_code=status.HTTP_200_OK,
    summary="Get test scripts for a test case",
    description="Retrieves all test scripts generated for a specific test case ID."
)
async def get_testscripts_by_testcase(
    testcase_id: UUID,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to retrieve test scripts for a specific test case.
    
    Args:
        testcase_id: The UUID of the test case
        db_session: Database session dependency
        
    Returns:
        A list of test script outputs for the specified test case
    """
    with db_session as db:
        # Get the test case information
        testcase = db.query(TestCases).filter(
            TestCases.testCaseId == testcase_id
        ).first()
        
        if not testcase:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No test case found with ID: {testcase_id}"
            )
        
        # Get the scenario information
        scenario = db.query(ScenarioOutput).filter(
            ScenarioOutput.scenarioId == testcase.scenarioId
        ).first()
        
        # Get the requirement information
        requirement = None
        if scenario and scenario.requirementId:
            requirement = db.query(RequirementData).filter(
                RequirementData.requirementId == scenario.requirementId
            ).first()
        
        testscripts = db.query(TestScripts).filter(
            TestScripts.testCaseId == testcase_id,
            TestScripts.is_deleted == False
        ).all()
        
        if not testscripts:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No test scripts found for test case ID: {testcase_id}"
            )
        
        # Include scenario_display_id, test case display ID, and requirement_display_id in the response
        return [
            {
                "testScriptId": testscript.testScriptId,
                "testCaseId": testscript.testCaseId,
                "scenarioId": testscript.scenarioId,
                "requirementId": testscript.requirementId,
                "fileId": testscript.fileId,
                "displayId": testscript.displayId,
                "isCompleted": testscript.isCompleted,
                "errorMessage": testscript.errorMessage,
                "testScriptJson": testscript.testScriptJson,
                "is_deleted": testscript.is_deleted,
                "createdAt": testscript.createdAt,
                "updatedAt": testscript.updatedAt,
                "scenario_display_id": scenario.displayId if scenario else None,
                "testcase_display_id": testcase.displayId,
                "requirement_display_id": requirement.displayId if requirement else None
            }
            for testscript in testscripts
        ]

@router.get(
    "/get-testscript-by-id/{testscript_id}",
    response_model=TestScriptResponse,
    status_code=status.HTTP_200_OK,
    summary="Get test script by ID",
    description="Retrieves a specific test script by its ID."
)
async def get_testscript_by_id(
    testscript_id: UUID,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to retrieve a specific test script by ID.
    
    Args:
        testscript_id: The UUID of the test script
        db_session: Database session dependency
        
    Returns:
        The test script data for the specified ID
    """
    with db_session as db:
        testscript = db.query(TestScripts).filter(
            TestScripts.testScriptId == testscript_id
        ).first()
        
        if not testscript:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Test script not found with ID: {testscript_id}"
            )
        
        # Get related information
        testcase = db.query(TestCases).filter(
            TestCases.testCaseId == testscript.testCaseId
        ).first()
        
        scenario = db.query(ScenarioOutput).filter(
            ScenarioOutput.scenarioId == testscript.scenarioId
        ).first()
        
        requirement = None
        if testscript.requirementId:
            requirement = db.query(RequirementData).filter(
                RequirementData.requirementId == testscript.requirementId
            ).first()
        
        return {
            "testScriptId": testscript.testScriptId,
            "testCaseId": testscript.testCaseId,
            "scenarioId": testscript.scenarioId,
            "requirementId": testscript.requirementId,
            "fileId": testscript.fileId,
            "displayId": testscript.displayId,
            "isCompleted": testscript.isCompleted,
            "errorMessage": testscript.errorMessage,
            "testScriptJson": testscript.testScriptJson,
            "is_deleted": testscript.is_deleted,
            "createdAt": testscript.createdAt,
            "updatedAt": testscript.updatedAt,
            "scenario_display_id": scenario.displayId if scenario else None,
            "testcase_display_id": testcase.displayId if testcase else None,
            "requirement_display_id": requirement.displayId if requirement else None
        }

@router.get(
    "/get-testscripts-for-usecase/{usecase_id}",
    status_code=status.HTTP_200_OK,
    summary="Get all test scripts for a usecase",
    description="Retrieves all test scripts organized by test cases for a specific usecase ID."
)
async def get_testscripts_by_usecase(
    usecase_id: int,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to retrieve all test scripts for a specific usecase, organized by test cases.
    
    Args:
        usecase_id: The ID of the usecase
        db_session: Database session dependency
        
    Returns:
        A list of test cases with their associated test scripts for the specified usecase
    """
    with db_session as db:
        usecase = db.query(UsecaseMetadata).filter(
            UsecaseMetadata.usecaseId == usecase_id
        ).first()
        
        if not usecase:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Usecase not found with ID: {usecase_id}"
            )
        
        files = db.query(FileMetadata).filter(
            FileMetadata.usecaseId == usecase_id
        ).all()
        
        if not files:
            return {
                "usecase_id": usecase_id,
                "usecase_name": usecase.usecaseName,
                "testcases": []
            }
        
        file_ids = [file.fileId for file in files]
        
        # Get all test cases for these files
        testcases = db.query(TestCases).filter(
            TestCases.fileId.in_(file_ids),
            TestCases.is_deleted == False
        ).all()
        
        if not testcases:
            return {
                "usecase_id": usecase_id,
                "usecase_name": usecase.usecaseName,
                "testcases": []
            }
        
        result = {
            "usecase_id": usecase_id,
            "usecase_name": usecase.usecaseName,
            "testcases": []
        }
        
        for testcase in testcases:
            testscripts = db.query(TestScripts).filter(
                TestScripts.testCaseId == testcase.testCaseId,
                TestScripts.is_deleted == False
            ).all()
            
            # Get scenario information
            scenario = db.query(ScenarioOutput).filter(
                ScenarioOutput.scenarioId == testcase.scenarioId
            ).first()
            
            # Get requirement information
            requirement = None
            if scenario and scenario.requirementId:
                requirement = db.query(RequirementData).filter(
                    RequirementData.requirementId == scenario.requirementId
                ).first()
            
            # If testJson is stored as a string
            if isinstance(testcase.testJson, str):
                test_json = json.loads(testcase.testJson)
            else:
                test_json = testcase.testJson

            testcase_data = {
                "testcase_id": testcase.testCaseId,
                "testcase_name": test_json.get("test case", "Unknown Test Case") if test_json else None,
                "testcase_description": test_json.get("description", "") if test_json else None,
                "testcase_display_id": testcase.displayId,
                "scenario_id": testcase.scenarioId,
                "scenario_display_id": scenario.displayId if scenario else None,
                "requirement_id": scenario.requirementId if scenario else None,
                "requirement_display_id": requirement.displayId if requirement else None,
                "test_scripts": []
            }
            
            for testscript in testscripts:
                testscript_data = {
                    "testscript_id": testscript.testScriptId,
                    "display_id": testscript.displayId,
                    "is_completed": testscript.isCompleted,
                    "error_message": testscript.errorMessage,
                    "test_script_json": testscript.testScriptJson,
                    "created_at": testscript.createdAt,
                    "updated_at": testscript.updatedAt,
                    "is_deleted": testscript.is_deleted
                }
                testcase_data["test_scripts"].append(testscript_data)
            
            result["testcases"].append(testcase_data)
        
        return result

@router.post(
    "/generate-by-testcases",
    response_model=TestScriptGenerationResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Generate test scripts from test cases",
    description="Triggers the generation of test scripts based on the provided test case IDs. "
                "The generation process runs as a background task."
)
async def generate_testscripts(
    request: TestScriptGenerationRequest,
    background_tasks: BackgroundTasks,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to generate test scripts from test cases.
    
    Args:
        request: Contains the list of test case IDs to process
        background_tasks: FastAPI background tasks handler
        db_session: Database session
        
    Returns:
        A response indicating the task has been accepted for processing
    """
    if not request.testcase_ids:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No test case IDs provided"
        )
    
    # Get a usecase_id from one of the test cases to update usecase status
    with db_session as db:
        testcase = db.query(TestCases).filter(
            TestCases.testCaseId == request.testcase_ids[0]
        ).first()
        
        if not testcase:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Test case not found with ID: {request.testcase_ids[0]}"
            )
        
        # Get file and usecase info
        file = db.query(FileMetadata).filter(
            FileMetadata.fileId == testcase.fileId
        ).first()
        
        usecase_id = None
        product = None
        if file:
            usecase_id = file.usecaseId
            # Get usecase for product info
            usecase = db.query(UsecaseMetadata).filter(
                UsecaseMetadata.usecaseId == usecase_id
            ).first()
            if usecase:
                product = usecase.product
                usecase.test_script_generation = "In Progress"
                db.commit()
    
    # Add the test script generation task to background tasks
    background_tasks.add_task(
        _generate_testscripts_background,
        testcase_ids=request.testcase_ids,
        product=product,
        usecase_id=usecase_id
    )
    
    return TestScriptGenerationResponse(
        message="Test script generation started",
        testcase_ids=request.testcase_ids
    )

@router.post(
    "/generate-by-usecase",
    response_model=TestScriptGenerationResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Generate test scripts from usecase",
    description="Triggers the generation of test scripts based on the provided usecase ID."
)
async def generate_testscripts_by_usecase(
    request: TestScriptGenerationByUsecaseRequest,
    background_tasks: BackgroundTasks,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to generate test scripts from usecase.
    
    Args:
        request: Contains the usecase ID to process
        background_tasks: FastAPI background tasks handler
        db_session: Database session
        
    Returns:
        A response indicating the task has been accepted for processing
    """
    usecase_id = request.usecase_id
    
    # Get usecase information
    with db_session as db:
        usecase = db.query(UsecaseMetadata).filter(
            UsecaseMetadata.usecaseId == usecase_id
        ).first()
        
        if not usecase:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Usecase not found with ID: {usecase_id}"
            )
        
        product = usecase.product
        
        # Get files associated with the usecase
        files = db.query(FileMetadata).filter(
            FileMetadata.usecaseId == usecase_id,
            FileMetadata.is_deleted == False
        ).all()
        
        if not files:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No files found for usecase ID {usecase_id}"
            )
        
        file_ids = [file.fileId for file in files]
        
        # Get test cases for all files
        testcases = db.query(TestCases).filter(
            TestCases.fileId.in_(file_ids),
            TestCases.is_deleted == False,
            TestCases.isCompleted == True,
            TestCases.isTestDataGenerated == True
        ).all()
        
        if not testcases:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No eligible test cases found for test script generation"
            )
        
        testcase_ids = [testcase.testCaseId for testcase in testcases]
        
        # Update usecase status
        usecase.test_script_generation = "In Progress"
        db.commit()
    
    # Add the test script generation task to background tasks
    background_tasks.add_task(
        _generate_testscripts_background,
        testcase_ids=testcase_ids,
        product=product,
        usecase_id=usecase_id
    )
    
    return TestScriptGenerationResponse(
        message="Test script generation started",
        testcase_ids=testcase_ids
    )

@router.post(
    "/delete-by-testscriptid/{testscript_id}",
    response_model=DeleteTestScriptResponse,
    status_code=status.HTTP_200_OK,
    summary="Toggle deletion status for a test script",
    description="Toggles the is_deleted field of a test script"
)
async def delete_testscript_by_id(
    testscript_id: UUID,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to toggle the deletion status of a test script.
    
    Args:
        testscript_id: The UUID of the test script to delete
        db_session: Database session dependency
    
    Returns:
        A status information about the toggled test script
    """
    with db_session as db:
        try:
            testscript = db.query(TestScripts).filter(
                TestScripts.testScriptId == testscript_id
            ).first()

            if not testscript:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Test script not found with ID: {testscript_id}"
                )
            
            testscript.is_deleted = True
            db.commit()

            logger.info(f"Deleted test script {testscript_id}")
            
            return DeleteTestScriptResponse(
                testscript_id=testscript_id,
                is_deleted=True,
                message=f"Test script successfully deleted"
            )
    
        except HTTPException as he:
            raise he
        except Exception as e:
            logger.error(f"Error deleting test script {testscript_id}: {e}", exc_info=True)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error deleting test script: {str(e)}"
            )

@router.put(
    "/rearrange-testscripts/{usecase_id}",
    response_model=Dict,
    status_code=status.HTTP_200_OK,
    summary="Rearrange test scripts",
    description="Rearrange test scripts by providing the usecase id and the display ids will be reassigned if mismatched"
)
async def rearrange_testscripts(
    usecase_id: int,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to rearrange test scripts by providing the usecase id.
    If duplicate display IDs are found, they will be reassigned in an incremental fashion.
    
    Args:
        usecase_id: The ID of the usecase
        db_session: Database session dependency
        
    Returns:
        Dict containing success status and information about updated test scripts
    """
    with db_session as db:
        try:
            # Get all files associated with this usecase
            files = db.query(FileMetadata).filter(
                FileMetadata.usecaseId == usecase_id,
                FileMetadata.is_deleted == False
            ).all()
            
            if not files:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"No files found for the usecase {usecase_id}"
                )
            
            file_ids = [file.fileId for file in files]
            
            # Get the test scripts for this usecase through the file relationship
            testscripts = db.query(TestScripts).filter(
                TestScripts.fileId.in_(file_ids),
                TestScripts.is_deleted == False
            ).order_by(TestScripts.displayId).all()

            if not testscripts:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"No test scripts found for the usecase {usecase_id}"
                )
            
            # Create a dictionary to track seen display IDs
            seen_display_ids = {}
            # Track the maximum display ID for use when reassigning IDs
            max_display_id = 0
            # Track test scripts that need their display ID updated
            testscripts_to_update = []
            
            # First pass: identify duplicates and find max display ID
            for testscript in testscripts:
                # Update max display ID if needed
                if testscript.displayId > max_display_id:
                    max_display_id = testscript.displayId
                    
                # Check if this display ID has been seen before
                if testscript.displayId in seen_display_ids:
                    # This is a duplicate, add to list to update
                    testscripts_to_update.append(testscript)
                else:
                    # Mark this display ID as seen
                    seen_display_ids[testscript.displayId] = testscript
            
            # Second pass: update duplicate display IDs
            updated_count = 0
            for testscript in testscripts_to_update:
                # Increment max_display_id and assign to this test script
                max_display_id += 1
                testscript.displayId = max_display_id
                updated_count += 1
            
            # Commit changes if any were made
            if updated_count > 0:
                db.commit()
                
            return {
                "success": True,
                "message": f"Test scripts rearranged successfully for usecase {usecase_id}",
                "updated_count": updated_count,
                "total_testscripts": len(testscripts)
            }
                
        except HTTPException as he:
            # Re-raise HTTP exceptions
            raise he
        except Exception as e:
            logger.error(f"Error rearranging test scripts for usecase {usecase_id}: {e}", exc_info=True)
            db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error rearranging test scripts: {str(e)}"
            )

@router.put(
    "/update-testscript/{testscript_id}",
    response_model=UpdateTestScriptResponse,
    status_code=status.HTTP_200_OK,
    summary="Update test script",
    description="Update the content of a test script by ID"
)
async def update_testscript(
    testscript_id: UUID,
    request: UpdateTestScriptRequest,
    db_session: Session = Depends(get_db)
):
    """
    Endpoint to update a test script's content.
    
    Args:
        testscript_id: The UUID of the test script to update
        request: The update payload containing the new test script JSON
        db_session: Database session dependency
        
    Returns:
        Status information about the updated test script
    """
    with db_session as db:
        try:
            testscript = db.query(TestScripts).filter(
                TestScripts.testScriptId == testscript_id,
                TestScripts.is_deleted == False
            ).first()
            
            if not testscript:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Test script not found with ID: {testscript_id}"
                )
            
            # Update the test script JSON content
            testscript.testScriptJson = request.testScriptJson
            
            # Commit the changes to the database
            db.commit()
            
            logger.info(f"Updated test script {testscript_id}")
            
            return UpdateTestScriptResponse(
                testscript_id=testscript_id,
                message="Test script updated successfully"
            )
            
        except HTTPException as he:
            raise he
        except Exception as e:
            logger.error(f"Error updating test script {testscript_id}: {e}", exc_info=True)
            db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error updating test script: {str(e)}"
            )

def _generate_testscripts_background(testcase_ids, product, usecase_id):
    """
    Background task function to generate test scripts.
    
    Args:
        testcase_ids: List of test case IDs to process
        product: The product name needed for script generation
        usecase_id: The usecase ID to update status
    """
    logger.info(f"Starting background test script generation for {len(testcase_ids)} test cases")
    
    try:
        generator = TestScriptGenerator()
        results, total_cost, total_tokens = generator.generate_test_scripts(testcase_ids, product, usecase_id)
        logger.info(f"Successfully generated {len(results)} test scripts")
        
        # Update the usecase metadata to indicate completion
        db = next(get_db())
        try:
            usecase = db.query(UsecaseMetadata).filter(
                UsecaseMetadata.usecaseId == usecase_id
            ).first()
            if usecase:
                usecase.test_script_generation = "Completed"
                db.commit()
                logger.info(f"Updated usecase {usecase_id} test_script_generation status to 'Completed'")
        finally:
            db.close()
            
    except Exception as e:
        logger.error(f"Error in background test script generation: {str(e)}")
        
        # Update the usecase metadata to indicate failure
        db = next(get_db())
        try:
            usecase = db.query(UsecaseMetadata).filter(
                UsecaseMetadata.usecaseId == usecase_id
            ).first()
            if usecase:
                usecase.test_script_generation = "Failed"
                db.commit()
                logger.error(f"Updated usecase {usecase_id} test_script_generation status to 'Failed'")
        except Exception as db_error:
            logger.error(f"Additional error updating usecase status: {str(db_error)}")
        finally:
            db.close() 