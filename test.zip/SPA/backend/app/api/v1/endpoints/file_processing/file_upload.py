import os
import asyncio
from fastapi import APIRouter, File, Form, UploadFile, HTTPException, Depends, BackgroundTasks
from sqlalchemy.orm import Session
from services.file_processing.file_service import upload_file_to_blob
from services.file_processing.ocr_service import run_all_ocr_batches
from services.generator.requirement_parser import process_user_requirement
from schemas.file_processing.file import FileMetadataSchema, FileWorkflowTrackerSchema
from models.file_processing.file_record import FileMetadata, FileWorkflowTracker
from models.ocr.ocr_records import OCRInfo, OCROutputs
from models.user import User
from deps import get_db
from db.session import SessionLocal
from uuid import uuid4
from datetime import datetime
from core.config import OCRServiceConfigs, settings
from core.configs.pf_configs import PFImageToTextConfigs  # Import PF configs for API details
import logging
from models.use_case.usecase_records import UsecaseMetadata

# Configure logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)

router = APIRouter()

async def check_ocr_completion(usecase_id: int, db_session, max_retries=20, retry_interval=5):
    """
    Check if OCR processing is complete for all files in a usecase.
    
    Args:
        usecase_id (int): The usecase ID
        db_session: Database session
        max_retries (int): Maximum number of retries
        retry_interval (int): Interval between retries in seconds
        
    Returns:
        bool: True if OCR is complete, False otherwise
    """
    for retry in range(max_retries):
        try:
            # Get all files for the usecase
            files = db_session.query(FileMetadata).filter(FileMetadata.usecaseId == usecase_id).all()
            
            if not files:
                logger.warning(f"No files found for usecase {usecase_id}")
                return False
            
            # Check if text extraction is complete for all files
            all_complete = True
            for file in files:
                # Get workflow tracker for the file
                workflow_tracker = db_session.query(FileWorkflowTracker).filter(
                    FileWorkflowTracker.fileId == file.fileId
                ).first()
                
                if not workflow_tracker:
                    logger.warning(f"No workflow tracker found for file {file.fileId}")
                    all_complete = False
                    break
                
                # Check if text extraction is completed
                if workflow_tracker.text_extraction != "Completed":
                    logger.info(f"Text extraction not complete for file {file.fileId}: Status is {workflow_tracker.text_extraction}")
                    all_complete = False
                    break
            
            if all_complete:
                logger.info(f"Text extraction complete for all files in usecase {usecase_id}")
                return True
            
            logger.info(f"Text extraction not yet complete for usecase {usecase_id}, retry {retry+1}/{max_retries}")
            await asyncio.sleep(retry_interval)
        except Exception as e:
            logger.error(f"Error checking text extraction completion: {e}", exc_info=True)
            await asyncio.sleep(retry_interval)
    
    logger.warning(f"Text extraction did not complete within the timeout for usecase {usecase_id}")
    return False

async def process_requirements_after_ocr(usecase_id: int, db_session):
    """
    Background task to process requirements after OCR is complete.
    
    Args:
        usecase_id (int): The usecase ID
        db_session: Database session
    """
    try:
        # Initial sleep to allow OCR processing to start and update the database
        logger.info(f"Waiting 30 seconds before checking OCR completion for usecase {usecase_id}")
        await asyncio.sleep(30)
        
        # Check if OCR processing is complete
        ocr_complete = await check_ocr_completion(usecase_id, db_session)
        
        if not ocr_complete:
            logger.warning(f"Skipping requirement processing for usecase {usecase_id} as OCR is not complete")
            
            # Try again after a longer delay
            logger.info(f"Will retry requirement processing for usecase {usecase_id} after 60 seconds")
            await asyncio.sleep(60)
            
            # Check OCR completion again
            ocr_complete = await check_ocr_completion(usecase_id, db_session)
            
            if not ocr_complete:
                logger.warning(f"OCR still not complete for usecase {usecase_id} after retry, aborting requirement processing")
                return
            else:
                logger.info(f"OCR completed for usecase {usecase_id} after retry, proceeding with requirement processing")
        
        # Process requirements using the usecase ID
        logger.info(f"Starting requirement processing for usecase {usecase_id}")
        result = process_user_requirement(
            usecase_id=usecase_id
        )
        
        logger.info(f"Requirement processing result for usecase {usecase_id}: {result}")
        
        # Update workflow tracker with requirement processing status
        try:
            files = db_session.query(FileMetadata).filter(FileMetadata.usecaseId == usecase_id).all()
            for file in files:
                tracker = db_session.query(FileWorkflowTracker).filter(
                    FileWorkflowTracker.fileId == file.fileId
                ).first()
                
                if tracker:
                    if result.get("success", False):
                        tracker.requirement_processing = "Completed"
                    else:
                        tracker.requirement_processing = "Failed"
                        tracker.errorMsg = result.get("message", "Unknown error")
                    
                    logger.info(f"Updated workflow tracker for file {file.fileId} with status: {tracker.requirement_processing}")
                else:
                    logger.warning(f"No workflow tracker found for file {file.fileId}")
            
            db_session.commit()
            logger.info(f"Updated workflow trackers for usecase {usecase_id}")
        except Exception as db_error:
            db_session.rollback()
            logger.error(f"Error updating workflow tracker: {str(db_error)}")
            
    except Exception as e:
        logger.error(f"Error processing requirements after OCR: {str(e)}")
        
        # Update workflow tracker with error status
        try:
            files = db_session.query(FileMetadata).filter(FileMetadata.usecaseId == usecase_id).all()
            for file in files:
                tracker = db_session.query(FileWorkflowTracker).filter(
                    FileWorkflowTracker.fileId == file.fileId
                ).first()
                
                if tracker:
                    tracker.requirement_processing = "Failed"
                    tracker.errorMsg = str(e)
                    
                    logger.info(f"Updated workflow tracker for file {file.fileId} with error status")
            
            db_session.commit()
            logger.info(f"Updated workflow tracker for usecase {usecase_id} with error status")
        except Exception as db_error:
            logger.error(f"Error updating workflow tracker: {str(db_error)}")

@router.post("/upload_file", response_model=list[FileMetadataSchema])
async def upload_file(background_tasks: BackgroundTasks,
                      files: list[UploadFile] = File(...),
                      document_types: list[str] = Form(...),
                      document_formats: list[str] = Form(...),
                      business_domains: list[str] = Form(...),
                      additional_contexts: list[str] = Form(...),
                      email: str = Form(...),
                      usecase_id: int = Form(...),
                      db_session: Session = Depends(get_db)):
    """
    Upload multiple files and store their metadata in the database.
    
    Args:
        files (list[UploadFile]): List of files to upload
        document_types (list[str]): List of document types for each file
        document_formats (list[str]): List of document formats for each file
        business_domains (list[str]): List of business domains for each file
        additional_contexts (list[str]): List of additional contexts for each file
        email (str): Email of the user uploading the files
        usecase_id (int): ID of the usecase
        db_session (Session): Database session dependency
        background_tasks (BackgroundTasks): Background tasks handler
        
    Returns:
        list[FileMetadataSchema]: List of metadata for successfully uploaded files
        
    Raises:
        HTTPException: 500 error if file upload fails or database operation fails
        HTTPException: 404 error if user not found
        HTTPException: 400 error if file details don't match
    """
    print(f"Starting file upload process for usecase_id: {usecase_id}")
    ocr_batch_size = OCRServiceConfigs.NUM_FILES_PER_BACKGROUND_TASK
    print(f"OCR batch size set to: {ocr_batch_size}")

    if not (len(files) == len(document_types) == len(document_formats) == len(business_domains) == len(additional_contexts)):
        print("Error: Mismatch in number of files and their details")
        raise HTTPException(status_code=400, detail="Number of files and their details must match")

    with db_session as db:
        try:
            print(f"Looking up user with email: {email}")
            # Get user by email
            user = db.query(User).filter(User.email == email).first()
            if not user:
                print(f"User not found for email: {email}")
                raise HTTPException(status_code=404, detail="User not found")
            
            print(f"User found. Using usecase ID: {usecase_id} for user: {email}")

            file_metadata_list = []
            for i, file in enumerate(files):
                print(f"Processing file {i+1}/{len(files)}: {file.filename}")
                success, message, url = upload_file_to_blob(file)
                print(f"Blob storage upload result for {file.filename}: Success={success}, Message={message}")
                print(f"File URL: {url}")
                if success:
                    print(f"Creating metadata entry for file: {file.filename}")
                    file_metadata = FileMetadata(
                        fileId=uuid4(),
                        fileName=file.filename,
                        fileLink=url,
                        userId=user.userId,
                        usecaseId=usecase_id,
                        documentType=document_types[i],
                        documentFormat=document_formats[i],
                        businessDomain=business_domains[i],
                        additionalContext=additional_contexts[i],
                        createdAt=datetime.utcnow(),
                        updatedAt=datetime.utcnow()
                    )
                    db.add(file_metadata)
                    file_metadata_list.append(file_metadata)
                else:
                    print(f"Failed to upload file {file.filename}: {message}")
                    raise HTTPException(status_code=500, detail=message)
            
            print("Committing metadata to database")
            db.commit()

            print("Preparing OCR data for background processing")
            # Extract necessary data before session closes
            ocr_data = [(metadata.fileLink, metadata.fileId) for metadata in file_metadata_list]
            
            print("Adding OCR processing background task")
            # Add OCR processing background task
            background_tasks.add_task(
                run_all_ocr_batches, 
                usecase_id,
                ocr_data, 
                ocr_batch_size,
                PFImageToTextConfigs.api_key,
                PFImageToTextConfigs.username,
                PFImageToTextConfigs.password,
                PFImageToTextConfigs.asset_id,
                OCRServiceConfigs.NUM_WORKERS,
                OCRServiceConfigs.BATCH_SIZE,
                OCRServiceConfigs.MAX_RETRIES
            )
            
            # print("Adding requirement processing background task")
            # Add requirement processing background task
            # background_tasks.add_task(
            #     process_requirements_after_ocr,
            #     usecase_id,
            #     SessionLocal()  # Create a new session for the background task
            # )

            # print("Refreshing metadata objects")
            for metadata in file_metadata_list:
                db.refresh(metadata)
            print(f"File upload process completed successfully for {len(file_metadata_list)} files")
            return [FileMetadataSchema.from_orm(metadata) for metadata in file_metadata_list]
        except Exception as e:
            print(f"Error occurred during file upload: {str(e)}")
            db.rollback()
            logger.error(f"Error in upload_file: {e}", exc_info=True)
            raise HTTPException(status_code=500, detail=str(e))
                
@router.get("/files/{usecase_id}", response_model=list[FileMetadataSchema])
async def get_files_by_usecase(
    usecase_id: int,
    db_session: Session = Depends(get_db)
):
    """
    Get all files associated with a specific usecase ID.
    
    Args:
        usecase_id (int): ID of the usecase
        db_session (Session): Database session dependency
        
    Returns:
        list[FileMetadataSchema]: List of files metadata for the specified usecase
    """
    with db_session as db:
        try:
            files = db.query(FileMetadata).filter(
                FileMetadata.usecaseId == usecase_id
            ).all()
            
            return [FileMetadataSchema.from_orm(file) for file in files]
            
        except Exception as e:
            logger.error(f"Error fetching files for usecase {usecase_id}: {e}", exc_info=True)
            raise HTTPException(
                status_code=500, 
                detail=f"Error fetching files for usecase {usecase_id}: {str(e)}"
            )

@router.get("/files/{usecase_id}/status", response_model=list[FileWorkflowTrackerSchema])
async def get_usecase_file_status(
    usecase_id: int,
    db_session: Session = Depends(get_db)
):
    """
    Get workflow status for all files in a specific usecase.
    
    Args:
        usecase_id (int): ID of the usecase
        db_session (Session): Database session dependency
        
    Returns:
        list[FileWorkflowTrackerSchema]: List of workflow status for files in the usecase
    """
    with db_session as db:
        try:
            workflow_status = db.query(FileWorkflowTracker).join(
                FileMetadata, 
                FileWorkflowTracker.fileId == FileMetadata.fileId
            ).filter(
                FileMetadata.usecaseId == usecase_id
            ).all()
            
            # Initialize empty values if None to satisfy schema validation
            for status in workflow_status:
                status.text_extraction = status.text_extraction or ""
                status.requirement_generation = status.requirement_generation or ""
                status.scenario_generation = status.scenario_generation or ""
                status.test_case_generation = status.test_case_generation or ""
                status.test_data_generation = status.test_data_generation or ""
            
            return [FileWorkflowTrackerSchema.from_orm(status) for status in workflow_status]
            
        except Exception as e:
            logger.error(f"Error fetching workflow status for usecase {usecase_id}: {e}", exc_info=True)
            raise HTTPException(
                status_code=500, 
                detail=f"Error fetching workflow status for usecase {usecase_id}: {str(e)}"
            )