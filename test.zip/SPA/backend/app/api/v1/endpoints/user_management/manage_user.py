from fastapi import APIRouter,HTTPException, Depends
from sqlalchemy.orm import Session
from deps import get_db
from models.user import User

router = APIRouter()

@router.post("/users/add", response_model=None)
async def create_user(email: str, db: Session = Depends(get_db)):
    """
    Create a new user with the provided email address.

    Args:
        email (str): The email address of the user to be created
        db (Session): Database session dependency

    Returns:
        dict: A dictionary containing status code and success message

    Raises:
        HTTPException: 400 if email already exists
        HTTPException: 500 if server error occurs
    """
    try:
        with db as session:
            db_user = session.query(User).filter(User.email == email).first()
            if not db_user:
                new_user = User(email=email)
                session.add(new_user)
                session.commit()
                return {"status_code": 201, "message": "User created successfully"}
            # raise HTTPException(status_code=400, detail="Email already registered")
            return {"status_code": 400, "message": "Email already registered"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")