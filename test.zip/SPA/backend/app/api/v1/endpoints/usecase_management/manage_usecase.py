from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from models.use_case.usecase_records import UsecaseMetadata
from deps import get_db
from typing import List
from datetime import datetime
from pydantic import BaseModel
from sqlalchemy.orm import joinedload
from uuid import UUID
from models.user import User
from models.file_processing.file_record import FileMetadata

class FileMetadataResponse(BaseModel):
    fileId: UUID
    fileName: str

    class Config:
        orm_mode = True

class UsecaseMetadataResponse(BaseModel):
    usecaseId: int
    usecaseName: str
    text_extraction: str
    requirement_generation: str
    scenario_generation: str
    test_case_generation: str
    test_data_generation: str
    files: List[FileMetadataResponse]
    product: str
    sub_product: str
    domain: str
    class Config:
        orm_mode = True


        
router = APIRouter()

@router.post("/create", response_model=UsecaseMetadataResponse)
def create_usecase(usecaseName: str = None, product: str = None, sub_product: str = None, domain: str = None, db_session: Session = Depends(get_db)):
    print("usecaseName", usecaseName)
    print("product", product)
    print("sub_product", sub_product)
    print("domain", domain)
    if not usecaseName:
        raise HTTPException(status_code=422, detail="usecaseName is required")
    if not product:
        raise HTTPException(status_code=422, detail="product is required")
    if not sub_product:
        raise HTTPException(status_code=422, detail="sub_product is required")
    if not domain:
        raise HTTPException(status_code=422, detail="domain is required")
    try:
        db_usecase = UsecaseMetadata(
            usecaseName=usecaseName,
            product=product,
            sub_product=sub_product,
            domain=domain
        )
        db_session.add(db_usecase)
        db_session.commit()
        db_session.refresh(db_usecase)
        return db_usecase
    except Exception as e:
        db_session.rollback()
        raise HTTPException(status_code=400, detail=str(e))

# @router.get("/usecases", response_model=List[UsecaseMetadataResponse])
# def get_all_usecases(db: Session = Depends(get_db)):
#     try:
#         usecases = db.query(UsecaseMetadata).options(
#             joinedload(UsecaseMetadata.files)
#         ).filter(UsecaseMetadata.is_deleted != True).order_by(UsecaseMetadata.usecaseId).all()
#         return usecases
#     except Exception as e:
#         raise HTTPException(status_code=400, detail=str(e))
    
@router.get("/get-usecase-status/{usecase_id}")
def get_usecase_status(usecase_id: int, db: Session = Depends(get_db)):
    try:
        usecase = db.query(UsecaseMetadata).filter(
            UsecaseMetadata.usecaseId == usecase_id,
            UsecaseMetadata.is_deleted != True
        ).first()
        
        if not usecase:
            raise HTTPException(status_code=404, detail="Usecase not found")
            
        return usecase
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/usecases/{user_email}", response_model=List[UsecaseMetadataResponse])
def get_usecases_by_user(user_email: str, db: Session = Depends(get_db)):
    try:
        print(f"Looking up usecases for user email: {user_email}")
        
        # Use a single query with joins to get all usecases associated with the user
        # This query joins the User, FileMetadata, and UsecaseMetadata tables
        # and uses DISTINCT to get unique usecases
        
        query = (
            db.query(UsecaseMetadata)
            .join(FileMetadata, FileMetadata.usecaseId == UsecaseMetadata.usecaseId)
            .join(User, User.userId == FileMetadata.userId)
            .filter(
                User.email == user_email,
                User.is_deleted != True,
                FileMetadata.is_deleted != True,
                UsecaseMetadata.is_deleted != True
            )
            .options(joinedload(UsecaseMetadata.files))
            .distinct()
            .order_by(UsecaseMetadata.usecaseId)
        )
        
        usecases = query.all()
        
        print(f"Found {len(usecases)} usecases for user email: {user_email}")
        return usecases
    except Exception as e:
        print(f"Error in get_usecases_by_user: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
