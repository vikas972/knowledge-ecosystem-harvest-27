from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from db.session import get_db
from models.admin import Admin as AdminModel

router = APIRouter()

@router.post("/login")
async def admin_login(username: str, password: str, db: Session = Depends(get_db)):
    admin = db.query(AdminModel).filter(AdminModel.username == username).first()
    if not admin or admin.hashed_password != password:  # Simple password check
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password"
        )
    return {"message": "Login successful"}

@router.get("/")
async def get_admins(db: Session = Depends(get_db)):
    admins = db.query(AdminModel).all()
    return admins

@router.post("/")
async def create_admin(username: str, password: str, db: Session = Depends(get_db)):
    # Check if admin already exists
    existing_admin = db.query(AdminModel).filter(AdminModel.username == username).first()
    if existing_admin:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username already registered"
        )
    
    # Create new admin
    new_admin = AdminModel(
        username=username,
        hashed_password=password,  # In a real app, you should hash the password
        is_active=True
    )
    db.add(new_admin)
    db.commit()
    db.refresh(new_admin)
    return new_admin 