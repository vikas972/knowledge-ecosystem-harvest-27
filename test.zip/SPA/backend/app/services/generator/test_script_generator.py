"""
Test Script Generator Module

This module is responsible for generating test scripts based on test cases by calling the PF asset service.
It serves as a service that will be called by the generator workflow orchestrator.
"""
import sys
import json
import os
import logging
from pathlib import Path
from contextlib import contextmanager
import time
import threading
import uuid
import re

# Add the parent directory to sys.path to allow importing from sibling packages
sys.path.append(str(Path(__file__).parent.parent.parent))

from models.file_processing.file_record import FileMetadata
from services.llm.pf_asset import invoke_asset, get_asset_id, get_asset_id_as_per_config
from models.generator.test_case import TestCases
from models.generator.test_scripts import TestScripts
from models.generator.scenario import ScenarioOutput
from models.generator.requirement import RequirementData
from models.use_case.usecase_records import UsecaseMetadata
from core.config import settings
from deps import get_db

# Configure logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)

class TestScriptGenerator:
    def __init__(self):
        self.asset_id = ""  # This will be set dynamically based on product
        logger.info(f"TestScriptGenerator initialized")
        # Thread-safe counter for tracking displayIds
        self.display_id_counters = {}
        self.counter_lock = threading.Lock()

    def get_next_display_id(self, usecase_id):
        """
        Thread-safe method to get the next sequential displayId for a usecase.
        Each thread must acquire the lock before accessing and incrementing the counter.
        
        Args:
            usecase_id: The ID of the usecase
            
        Returns:
            int: The next unique displayId
        """
        with self.counter_lock:
            # Initialize counter for this usecase if it doesn't exist
            if usecase_id not in self.display_id_counters:
                # First, initialize from database to handle restarts
                db = next(get_db())
                try:
                    # Get all files for this usecase
                    usecase_files = db.query(FileMetadata.fileId).filter(
                        FileMetadata.usecaseId == usecase_id
                    ).all()
                    
                    # Extract file IDs into a list
                    usecase_file_ids = [f.fileId for f in usecase_files]
                    
                    # Get the maximum displayId from the database
                    max_display_id = 0
                    if usecase_file_ids:
                        testscripts = db.query(
                            TestScripts.displayId
                        ).filter(
                            TestScripts.fileId.in_(usecase_file_ids),
                            TestScripts.is_deleted == False
                        ).order_by(
                            TestScripts.displayId.desc()
                        ).first()
                        
                        if testscripts:
                            max_display_id = testscripts[0]
                    
                    # Initialize counter to the max found + 1, or 1 if none found
                    self.display_id_counters[usecase_id] = max_display_id + 1
                    logger.info(f"Initialized testscript displayId counter for usecase {usecase_id} to {self.display_id_counters[usecase_id]}")
                except Exception as e:
                    logger.error(f"Error initializing counter from DB: {str(e)}")
                    # Default to 1 if there was an error
                    self.display_id_counters[usecase_id] = 1
                finally:
                    db.close()
            
            # Get the current value
            current_id = self.display_id_counters[usecase_id]
            
            # Increment for next use
            self.display_id_counters[usecase_id] += 1
            
            logger.info(f"Thread {threading.current_thread().name} allocated testscript displayId {current_id} for usecase {usecase_id}")
            return current_id

    def get_unique_display_id(self, base_id, thread_id=None):
        """
        Generate a unique displayId by combining base ID with timestamp data.
        This helps resolve race conditions when multiple threads get the same base ID.
        
        Args:
            base_id (int): The base displayId from database
            thread_id (int, optional): Thread identifier for extra uniqueness
            
        Returns:
            int: A unique displayId
        """
        if thread_id is None:
            thread_id = id(threading.current_thread()) % 1000
        
        # Add a small delay (0.1-2.5ms) based on thread ID to reduce collision probability
        time.sleep((thread_id % 25) / 10000)
        
        # Get current timestamp in milliseconds
        timestamp_ms = int(time.time() * 1000) % 100  # Last 2 digits of milliseconds
        
        # We maintain the original ID sequence but add a tiny offset based on timestamp
        unique_id = base_id + (timestamp_ms / 1000)  # Add a fractional part that gets truncated to int
        
        return unique_id

    def get_testcase_details(self, testcase_id):
        """
        Get the test case details for a specific test case ID
        
        Args:
            testcase_id (UUID or str): The ID of the test case
            
        Returns:
            dict: The test case details
        """
        logger.info(f"Retrieving test case details for test case ID: {testcase_id}")
        
        # Convert string to UUID if needed
        try:
            if isinstance(testcase_id, str):
                testcase_id = uuid.UUID(testcase_id)
                logger.debug(f"Converted string to UUID: {testcase_id}")
        except Exception as e:
            logger.error(f"Error converting testcase_id to UUID: {str(e)}")
            # Continue with the original value

        db = next(get_db())
        try:
            # Get test case
            test_case = (
                db.query(TestCases)
                .filter(TestCases.testCaseId == testcase_id)
                .filter(TestCases.is_deleted == False)
                .first()
            )
            
            if not test_case:
                logger.warning(f"Test case not found for ID: {testcase_id}")
                return None
            
            scenario = (
                db.query(ScenarioOutput)
                .filter(ScenarioOutput.scenarioId == test_case.scenarioId)
                .filter(ScenarioOutput.is_deleted == False)
                .first()
            )
            
            if not scenario:
                logger.warning(f"Scenario not found for ID: {test_case.scenarioId}")
                return None
            
            requirement = (
                db.query(RequirementData)
                .filter(RequirementData.requirementId == scenario.requirementId)
                .filter(RequirementData.is_deleted == False)
                .first()
            )
            
            if not requirement:
                logger.warning(f"Requirement not found for ID: {scenario.requirementId}")
                return None
            
            file_metadata = (
                db.query(FileMetadata)
                .filter(FileMetadata.fileId == test_case.fileId)
                .filter(FileMetadata.is_deleted == False)
                .first()
            )
            
            if not file_metadata:
                logger.warning(f"File metadata not found for ID: {test_case.fileId}")
                return None
            
            return {
                "test_case": test_case,
                "scenario": scenario,
                "requirement": requirement,
                "file_metadata": file_metadata
            }
        except Exception as e:
            logger.error(f"Error retrieving test case details: {str(e)}")
            return None
        finally:
            db.close()
    
    def get_application_flow(self, product):
        """
        Get the application flow from the product-specific crawl file.
        
        Args:
            product (str): The product name
            
        Returns:
            str: The application flow content
        """
        try:
            # Determine the file path based on the product
            file_name = "dtb_account_services_crawl.txt"
            
            # Use a mapping if there are different files for different products
            product_files = {
                "DTB": "dtb_account_services_crawl.txt",
                "Paycash CX": "paycash_cx_flow.txt",
                "CTX": "ctx_flow.txt",
                "iColumbus": "icolumbus_flow.txt"
            }
            
            if product in product_files:
                file_name = product_files[product]
            
            file_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                "static", "productdocs", file_name
            )
            
            logger.info(f"Reading application flow from: {file_path}")
            
            # Check if file exists
            if not os.path.exists(file_path):
                logger.warning(f"Application flow file not found: {file_path}. Using default description.")
                # Fall back to default descriptions if file doesn't exist
                default_flows = {
                    "DTB": """
                    DTB (Digital Trade Bank) is a banking application that supports trade finance operations.
                    The application requires test scripts that should include URL, page navigation, element identifiers, 
                    and verification points. The test scripts should be detailed with exact steps for automation.
                    """,
                    "Paycash CX": """
                    Paycash CX is a payment processing application used for customer experience.
                    The application requires test scripts that include API endpoints, payload structures,
                    response validation, and SQL queries where needed.
                    """,
                    "CTX": """
                    CTX is a corporate transaction processing system.
                    The application requires test scripts that should include web element locators,
                    data input specifications, and validation checks.
                    """,
                    "iColumbus": """
                    iColumbus is a trade finance management system.
                    The application requires test scripts that should include database verification steps,
                    screen navigation details, and validation of business rules.
                    """
                }
                return default_flows.get(product, "Unknown product. Please provide application flow details for test script generation.")
                
            # Read the file content
            with open(file_path, 'r') as file:
                content = file.read()
                
            logger.info(f"Successfully read application flow file: {len(content)} characters")
            return content
        except Exception as e:
            logger.error(f"Error reading application flow file: {str(e)}")
            return "Failed to load application flow. Proceed with test script generation using available information."

    def generate_test_scripts(self, testcase_ids, product, usecase_id, batch_size=10, batch_delay=2):
        """
        Generate test scripts for a list of test case IDs
        
        Args:
            testcase_ids (list): List of test case IDs to generate scripts for
            product (str): The product name
            usecase_id (int): The usecase ID
            batch_size (int, optional): The number of test cases to process in parallel
            batch_delay (int, optional): The delay between batches
            
        Returns:
            tuple: A tuple containing the results, cost, and tokens
        """
        logger.info(f"Generating test scripts for {len(testcase_ids)} test cases for product: {product}")
        
        # Get the asset ID for the test script generator
        self.asset_id = get_asset_id_as_per_config(product, "test_scripts_generator")
        if not self.asset_id:
            logger.error(f"No asset ID found for test script generation for product: {product}")
            return [], 0, 0
        
        logger.info(f"Using asset ID for test script generation: {self.asset_id}")
        
        # Define function to process a single test case
        def process_testcase(testcase_id, product, usecase_id):
            """Process a single test case to generate test scripts"""
            logger.info(f"Processing test case ID: {testcase_id}")
            
            # Get test case details
            testcase_details = self.get_testcase_details(testcase_id)
            if not testcase_details:
                logger.error(f"Could not retrieve details for test case ID: {testcase_id}")
                return None
            
            test_case = testcase_details["test_case"]
            scenario = testcase_details["scenario"]
            requirement = testcase_details["requirement"]
            file_metadata = testcase_details["file_metadata"]
            
            # Prepare the prompt for the PF asset
            app_flow = self.get_application_flow(product)
            
            prompt = f"""
            Generate detailed test scripts for the following test case:
            
            Requirement: {requirement.requirementName}
            Requirement Details: {requirement.requirementJson}
            
            Scenario: {scenario.outputJson.get('title', 'N/A')}
            Scenario Details: {json.dumps(scenario.outputJson)}
            
            Test Case: {test_case.testJson.get('title', 'N/A')}
            Test Case Details: {json.dumps(test_case.testJson)}
            
            Application Flow: {app_flow}
            
            """
            
            try:
                # Call the PF asset to generate the test script
                logger.info(f"Calling PF asset to generate test script for test case ID: {testcase_id}")
                # The invoke_asset function returns a tuple (response, cost, tokens), not a dictionary
                response_text, cost, tokens = invoke_asset(self.asset_id, prompt)
                
                if not response_text:
                    logger.error(f"Empty or invalid response from PF asset for test case ID: {testcase_id}")
                    return None
                
                logger.info(f"Received response from PF asset. Cost: {cost}, Tokens: {tokens}")
                logger.info(f"Input prompt for the test script generator: {prompt}")
                logger.info(f"Response Scripttext: {response_text}")
                # Extract the JSON from the response (in case it contains markdown formatting)
                try:
                    # Try to find JSON in the response
                    script_json = json.loads(response_text)
                except json.JSONDecodeError:
                    # If direct parsing fails, try to extract JSON from markdown code blocks
                    # Check if response contains XML
                    xml_match = re.search(r'```xml\s*([\s\S]*?)\s*```', response_text)
                    if xml_match:
                        # If XML is found, wrap it in a JSON structure with TestStepsJXML key
                        xml_content = xml_match.group(1)
                        script_json = {
                            "TestStepsJXML": xml_content
                        }
                        logger.info(f"Successfully extracted XML content and stored with TestStepsJXML key for test case ID: {testcase_id}")
                    else:
                        # Try to find JSON in markdown code blocks
                        json_match = re.search(r'```(?:json)?\s*([\s\S]*?)\s*```', response_text)
                        if json_match:
                            try:
                                script_json = json.loads(json_match.group(1))
                            except json.JSONDecodeError:
                                logger.error(f"Could not parse JSON from markdown for test case ID: {testcase_id}")
                                script_json = {"error": "Failed to parse JSON", "rawResponse": response_text}
                        else:
                            logger.error(f"Could not extract JSON from response for test case ID: {testcase_id}")
                            script_json = {"error": "Failed to extract JSON", "rawResponse": response_text}
                
                # Get a unique display ID for this test script
                display_id = self.get_next_display_id(usecase_id)
                
                # Create the test script record in the database
                db = next(get_db())
                try:
                    # Create new test script record
                    new_script = TestScripts(
                        fileId=test_case.fileId,
                        requirementId=requirement.requirementId,
                        scenarioId=scenario.scenarioId,
                        testCaseId=test_case.testCaseId,
                        testScriptId=uuid.uuid4(),
                        displayId=display_id,
                        isCompleted=True,
                        testScriptJson=script_json
                    )
                    
                    db.add(new_script)
                    db.commit()
                    logger.info(f"Test script created for test case ID: {testcase_id}")
                    
                    # Update the file workflow tracker
                    file_tracker = db.query(FileMetadata).filter(
                        FileMetadata.fileId == test_case.fileId
                    ).first()
                    
                    if file_tracker:
                        from models.file_processing.file_record import FileWorkflowTracker
                        tracker = db.query(FileWorkflowTracker).filter(
                            FileWorkflowTracker.fileId == test_case.fileId
                        ).first()
                        
                        if tracker:
                            tracker.test_script_generation = "Completed"
                            db.commit()
                            logger.info(f"Updated workflow tracker for file ID: {test_case.fileId}")
                    
                    return {
                        "testScriptId": new_script.testScriptId,
                        "testCaseId": testcase_id,
                        "displayId": display_id,
                        "testScriptJson": script_json,
                        "cost": cost,
                        "tokens": tokens
                    }
                except Exception as e:
                    db.rollback()
                    logger.error(f"Database error while creating test script for test case ID {testcase_id}: {str(e)}")
                    return None
                finally:
                    db.close()
            except Exception as e:
                logger.error(f"Error generating test script for test case ID {testcase_id}: {str(e)}")
                return None
        
        # Process test cases in batches
        results = []
        total_cost = 0
        total_tokens = 0
        
        for i in range(0, len(testcase_ids), batch_size):
            batch = testcase_ids[i:i+batch_size]
            logger.info(f"Processing batch {i//batch_size + 1}/{(len(testcase_ids) + batch_size - 1)//batch_size}")
            
            # Process each test case in the batch
            batch_results = []
            for testcase_id in batch:
                result = process_testcase(testcase_id, product, usecase_id)
                if result:
                    batch_results.append(result)
                    total_cost += result.get("cost", 0)
                    total_tokens += result.get("tokens", 0)
            
            results.extend(batch_results)
            
            # Add delay between batches if there are more batches to process
            if i + batch_size < len(testcase_ids):
                time.sleep(batch_delay)
        
        logger.info(f"Completed test script generation for {len(results)} out of {len(testcase_ids)} test cases")
        return results, total_cost, total_tokens


# # Example usage for testing
# def test_test_script_generator():
#     """Test the TestScriptGenerator with dummy data."""
#     generator = TestScriptGenerator()
    
#     # You would need real test case IDs to test this
#     # This is just an example
#     print("\n=== Test Script Generator Test ===")
#     print("This test requires actual test case IDs to run")
#     print("Please implement a proper test with real data")


# if __name__ == "__main__":
#     # Configure logging
#     logging.basicConfig(
#         level=logging.INFO,
#         format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
#     )
    
#     # Run the test
#     test_test_script_generator() 