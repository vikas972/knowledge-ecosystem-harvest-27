"""
Requirement Parser Module

This module is responsible for parsing and analyzing requirements by calling the PF asset service.
It serves as a service that will be called by the generator workflow orchestrator.
"""

import logging
import sys
import os
import json
import uuid
import concurrent.futures
import time
from pathlib import Path
from uuid import UUID

import requests
import sqlalchemy
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from typing import Dict, List, Tuple, Any, Optional, Union
from pydantic import BaseModel, Field, validator
from fastapi import HTTPException

# Add the parent directory to sys.path to allow importing from sibling packages
sys.path.append(str(Path(__file__).parent.parent.parent))

from db.session import get_db
from models.use_case.usecase_records import UsecaseMetadata
from services.llm.pf_asset import invoke_asset
# Import only the functions we need, not the models directly
from utils.db_utils import insert_requirement_data, update_requirement_data, create_dummy_file_metadata
from core.config import HostingConfigs, settings
from models.file_processing.file_record import FileMetadata, FileWorkflowTracker
from models.generator.requirement import RequirementData

# Configure logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)

# Pydantic models for JSON validation
class UIUXRequirements(BaseModel):
    navigation_path: Optional[str] = None
    app_name: Optional[str] = None
    interactions: Optional[List[str]] = None
    mockups: Optional[str] = None
    
    # Allow additional fields
    class Config:
        extra = "allow"

class IntegrationRequirements(BaseModel):
    interfaces: Optional[List[str]] = None
    module_dependencies: Optional[List[str]] = None
    
    # Allow additional fields
    class Config:
        extra = "allow"

class NonFunctionalRequirements(BaseModel):
    performance: Optional[str] = None
    
    # Allow additional fields
    class Config:
        extra = "allow"

class Requirements(BaseModel):
    functional_requirements: Optional[List[str]] = None
    business_rules: Optional[List[str]] = None
    data_elements: Optional[List[str]] = None
    uiux_requirements: Optional[UIUXRequirements] = None
    integration_requirements: Optional[IntegrationRequirements] = None
    non_functional_requirements: Optional[NonFunctionalRequirements] = None
    other_requirements: Optional[List[str]] = None
    
    # Allow additional fields
    class Config:
        extra = "allow"

class UserJourney(BaseModel):
    name: str
    user_stories: Optional[List[str]] = None
    requirements: Optional[Requirements] = None
    
    # Allow additional fields
    class Config:
        extra = "allow"

class RequirementSchema(BaseModel):
    user_journeys: List[UserJourney]

    @validator('user_journeys')
    def validate_user_journeys(cls, v):
        if not v:
            raise ValueError("At least one user journey must be provided")
        return v
    
    # Allow additional fields
    class Config:
        extra = "allow"

class RequirementParser:
    """
    Parses and analyzes requirements by calling the PF asset service.
    """
    
    def __init__(self):
        """Initialize the RequirementParser."""
        self.journey_extraction_asset_id = settings.JOURNEY_EXTRACTION_ASSET_ID
        self.requirement_extraction_asset_id = settings.REQUIREMENT_EXTRACTION_ASSET_ID
        self.requirement_analysis_asset_id = settings.REQUIREMENT_ANALYSIS_ASSET_ID
        self.max_concurrent_requests = settings.MAX_CONCURRENT_REQUESTS if hasattr(settings, 'MAX_CONCURRENT_REQUESTS') else 10
        logger.info(f"RequirementParser initialized with journey extraction asset ID: {self.journey_extraction_asset_id}")
        logger.info(f"RequirementParser initialized with requirement analysis asset ID: {self.requirement_analysis_asset_id}")
        logger.info(f"Max concurrent requests: {self.max_concurrent_requests}")
    
    def debug_json(self, json_obj):
        """
        Helper method to debug JSON objects by printing their structure.
        
        Args:
            json_obj: The JSON object to debug
            
        Returns:
            str: A string representation of the JSON structure
        """
        try:
            if json_obj is None:
                return "None"
                
            if isinstance(json_obj, dict):
                keys = list(json_obj.keys())
                return f"Dict with {len(keys)} keys: {', '.join(keys[:10])}" + ("..." if len(keys) > 10 else "")
            elif isinstance(json_obj, list):
                return f"List with {len(json_obj)} items"
            else:
                return f"{type(json_obj).__name__}: {str(json_obj)[:100]}"
        except Exception as e:
            return f"Error debugging JSON: {str(e)}"
    
    def validate_requirement_json(self, analyzed_req, req_name):
        """
        Validate the requirement JSON structure using basic structure checks.
        Only validates the overall structure, not specific keys or values.
        
        Args:
            analyzed_req (dict): The requirement JSON to validate
            req_name (str): The name of the requirement for logging purposes
            
        Returns:
            tuple: (is_valid, error_message, json_string)
                is_valid (bool): Whether the JSON is valid
                error_message (str): Error message if validation failed, empty string otherwise
                json_string (str): JSON string if validation succeeded, None otherwise
        """
        try:
            # First, check if it's a valid JSON structure by converting to string and back
            req_json = json.dumps(analyzed_req)
            json.loads(req_json)
            
            # Validate the basic structure
            if not isinstance(analyzed_req, dict):
                logger.error(f"JSON structure error: Expected a dict, got {self.debug_json(analyzed_req)}")
                return False, f"Expected a JSON object, got {type(analyzed_req).__name__}", None
            
            # Check for user_journeys array
            if "requirement_entities" not in analyzed_req:
                logger.error(f"JSON structure error: Missing 'user_journeys' key. Available keys: {self.debug_json(analyzed_req)}")
                return False, "Missing 'user_journeys' key in JSON structure", None
                
            if not isinstance(analyzed_req["requirement_entities"], list):
                logger.error(f"JSON structure error: 'user_journeys' must be a list, got {self.debug_json(analyzed_req['user_journeys'])}")
                return False, f"'user_journeys' must be an array, got {type(analyzed_req['user_journeys']).__name__}", None
            
            # Check if at least one user journey exists
            if len(analyzed_req["requirement_entities"]) == 0:
                logger.error("JSON structure error: 'user_journeys' array is empty")
                return False, "At least one user journey must be provided", None
            
            # Check each user journey has a name
            for i, journey in enumerate(analyzed_req["requirement_entities"]):
                if not isinstance(journey, dict):
                    logger.error(f"JSON structure error: User journey at index {i} must be a dict, got {self.debug_json(journey)}")
                    return False, f"User journey at index {i} must be an object, got {type(journey).__name__}", None
                
                if "name" not in journey:
                    logger.error(f"JSON structure error: User journey at index {i} is missing 'name' field. Available keys: {self.debug_json(journey)}")
                    return False, f"User journey at index {i} is missing required 'name' field", None
            
            # Basic structure validation passed
            logger.info(f"Requirement JSON for {req_name} validated successfully")
            return True, "", req_json
            
        except json.JSONDecodeError as json_error:
            error_details = f"Invalid JSON format: {str(json_error)}"
            logger.error(f"JSON validation error for {req_name}: {error_details}")
            return False, error_details, None
            
        except Exception as validation_error:
            error_details = str(validation_error)
            logger.error(f"Validation error for {req_name}: {error_details}")
            
            # Log the problematic JSON structure for debugging
            try:
                error_json = json.dumps(analyzed_req, indent=2)
                logger.error(f"Problematic JSON structure: {error_json[:500]}...")  # Log first 500 chars to avoid huge logs
            except Exception as json_error:
                logger.error(f"Could not serialize the problematic JSON: {str(json_error)}")
            
            return False, error_details, None
    
    def clean_json_response(self, response):
        """
        Clean the response by removing text before JSON content, JSON code block markers, and parse it.
        
        Args:
            response (str): The response from the PF asset
            
        Returns:
            dict: The parsed JSON response
        """
        try:
            # Remove any leading/trailing whitespace
            response = response.strip()
            
            # Find the first occurrence of '{' which likely indicates the start of JSON
            json_start = response.find('{')
            if json_start > 0:
                # Extract only the content from the first '{' onwards
                response = response[json_start:]
            
            # Find the last occurrence of '}' which likely indicates the end of JSON
            json_end = response.rfind('}')
            if json_end > 0 and json_end < len(response) - 1:
                # Extract only the content up to the last '}'
                response = response[:json_end + 1]
            
            # Remove the ```json and ``` markers if present
            if response.startswith('```json'):
                response = response[7:]
            elif response.startswith('```'):
                response = response[3:]
            if response.endswith('```'):
                response = response[:-3]
            
            # Trim again after removing markers
            response = response.strip()
            
            # Parse the JSON string into a Python dict
            parsed_response = json.loads(response)
            
            return parsed_response
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing JSON response: {str(e)}")
            logger.error(f"Response content: {response[:100]}...")
            
            # Try a more aggressive approach to extract JSON
            try:
                # Extract the JSON object using balanced braces
                def extract_json_objects(text):
                    """Extract all valid JSON objects from text using balanced braces."""
                    objects = []
                    i = 0
                    while i < len(text):
                        # Find the next opening brace
                        start_idx = text.find('{', i)
                        if start_idx == -1:
                            break
                        
                        # Track balanced braces
                        brace_count = 0
                        for j in range(start_idx, len(text)):
                            if text[j] == '{':
                                brace_count += 1
                            elif text[j] == '}':
                                brace_count -= 1
                                
                            # When we've found a balanced closing brace, extract the JSON
                            if brace_count == 0:
                                json_str = text[start_idx:j+1]
                                try:
                                    # Only add if it's valid JSON
                                    json.loads(json_str)
                                    objects.append(json_str)
                                except json.JSONDecodeError:
                                    pass
                                i = j + 1
                                break
                        else:
                            # If we get here, braces weren't balanced
                            break
                        
                        if brace_count != 0:
                            # If braces weren't balanced, move to the next character
                            i = start_idx + 1
                    
                    return objects
                
                # Try to extract all JSON objects
                json_objects = extract_json_objects(response)
                
                if json_objects:
                    # Sort by length (descending) to prioritize larger objects
                    json_objects.sort(key=len, reverse=True)
                    
                    # Try to find an object with "user_journeys" key first
                    for json_str in json_objects:
                        try:
                            obj = json.loads(json_str)
                            if isinstance(obj, dict) and "user_journeys" in obj:
                                return obj
                        except json.JSONDecodeError:
                            continue
                    
                    # If no object with "user_journeys" found, return the largest one
                    return json.loads(json_objects[0])
                
                # If that fails, try a simpler approach with regex
                import re
                matches = re.findall(r'{[^{]*}', response)
                if matches:
                    # Try each match until one parses successfully
                    for match in sorted(matches, key=len, reverse=True):
                        try:
                            return json.loads(match)
                        except json.JSONDecodeError:
                            continue
                
                # Return the original response if extraction fails
                return {"error": "Failed to parse JSON", "original_response": response}
            except Exception as nested_error:
                logger.error(f"Error in aggressive JSON extraction: {str(nested_error)}")
                return {"error": "Failed to parse JSON", "original_response": response}
    

    def extract_requirements_from_fsd(self, ocr_text, additional_contexts=None):
        """
        Extract user journeys from the OCR text using LLM.
        
        Args:
            ocr_text (str): OCR text containing user journeys
            additional_contexts (dict, optional): Dictionary mapping file_ids to additional context
            
        Returns:
            tuple: A tuple containing:
                - list: The list of user journeys with their names
                - float: The cost of processing
                - int: The token count
                - bool: Whether the operation was successful
        """
        logger.info("Extracting user Requirements from OCR text")
        
        try:
            # Format additional context if available
            additional_context_str = ""
            if additional_contexts and len(additional_contexts) > 0:
                additional_context_parts = []
                for i, (file_id, context_data) in enumerate(additional_contexts.items()):
                    if context_data.get("context"):
                        file_name = context_data.get("fileName", f"File {i+1}")
                        additional_context_parts.append(f"{i+1}. {file_name}: {context_data['context']}")
            
                if additional_context_parts:
                    additional_context_str = "Additional User Instructions:\n" + "\n".join(additional_context_parts) + "\n\n"
            
            # Prepare the query for the PF asset
            query = f"""Please analyze the following document and extract requirements as a JSON object format given in system instructions.

                {additional_context_str}Document Context:```
                {ocr_text}```"""
            # Call the PF asset service
            response, cost, tokens = invoke_asset(self.requirement_extraction_asset_id, query)
            logger.info(f"Brief Requirement extraction response received. Cost: {cost}, Tokens: {tokens}")
            logger.info(f"Response: {response}")
            # Clean and parse the response
            try:
                parsed_response = self.clean_json_response(response)
                
                # Extract journeys based on the expected structure
                journeys = list(set(req["name"] for req in parsed_response["requirements"]))
                return journeys, cost, tokens, True
                
            except Exception as e:
                logger.error(f"Error parsing user journey extraction response: {str(e)}")
                # If parsing fails, create a single journey from the entire text
                journeys = [{
                    "name": "Complete Document",
                    "journey_text": ocr_text[:1000]  # Limit to first 1000 chars
                }]
                logger.info("Created a single journey from the entire OCR text due to parsing error")
                return journeys, cost, tokens, True
                
        except Exception as e:
            logger.error(f"Error extracting user journeys: {str(e)}")
            return [], 0, 0, False
        
    def extract_user_journeys(self, ocr_text, additional_contexts=None):
        """
        Extract user journeys from the OCR text using LLM.
        
        Args:
            ocr_text (str): OCR text containing user journeys
            additional_contexts (dict, optional): Dictionary mapping file_ids to additional context
            
        Returns:
            tuple: A tuple containing:
                - list: The list of user journeys with their names
                - float: The cost of processing
                - int: The token count
                - bool: Whether the operation was successful
        """
        logger.info("Extracting user journeys from OCR text")
        
        try:
            # Format additional context if available
            additional_context_str = ""
            if additional_contexts and len(additional_contexts) > 0:
                additional_context_parts = []
                for i, (file_id, context_data) in enumerate(additional_contexts.items()):
                    if context_data.get("context"):
                        file_name = context_data.get("fileName", f"File {i+1}")
                        additional_context_parts.append(f"{i+1}. {file_name}: {context_data['context']}")
            
                if additional_context_parts:
                    additional_context_str = "Additional User Instructions:\n" + "\n".join(additional_context_parts) + "\n\n"
            
            # Prepare the query for the PF asset
            query = f"""Please analyze the following document and extract all user journeys as a JSON object with the following structure:
            {{
            "user_journeys": [
                {{
                "name": "Journey Name",
                "user_stories": ["User story 1", "User story 2"],
                "business_requirements": ["Business requirement 1", "Business requirement 2"],
                "business_rules": ["Business rule 1", "Business rule 2"],
                "data_elements": ["Data element 1", "Data element 2"]
                }}
            ]
            }}

            {additional_context_str}Document:
            {ocr_text}"""
            # Call the PF asset service
            response, cost, tokens = invoke_asset(self.journey_extraction_asset_id, query)
            logger.info(f"User journey extraction response received. Cost: {cost}, Tokens: {tokens}")
            
            # Clean and parse the response
            try:
                parsed_response = self.clean_json_response(response)
                
                # Extract journeys based on the expected structure
                journeys = []
                
                # Check if the response has the expected structure
                if isinstance(parsed_response, dict) and "user_journeys" in parsed_response:
                    # Extract journeys from the user_journeys array
                    for journey in parsed_response["user_journeys"]:
                        if isinstance(journey, dict) and "name" in journey:
                            # Create journey_text from the structured fields
                            journey_text_parts = []
                            
                            # Add user stories
                            if "user_stories" in journey and journey["user_stories"]:
                                journey_text_parts.append("User Stories:")
                                for i, story in enumerate(journey["user_stories"]):
                                    journey_text_parts.append(f"{i+1}. {story}")
                            
                            # Add business requirements
                            if "business_requirements" in journey and journey["business_requirements"]:
                                journey_text_parts.append("\nBusiness Requirements:")
                                for i, req in enumerate(journey["business_requirements"]):
                                    journey_text_parts.append(f"{i+1}. {req}")
                            
                            # Add business rules
                            if "business_rules" in journey and journey["business_rules"]:
                                journey_text_parts.append("\nBusiness Rules:")
                                for i, rule in enumerate(journey["business_rules"]):
                                    journey_text_parts.append(f"{i+1}. {rule}")
                            
                            # Add data elements
                            if "data_elements" in journey and journey["data_elements"]:
                                journey_text_parts.append("\nData Elements:")
                                for i, element in enumerate(journey["data_elements"]):
                                    journey_text_parts.append(f"{i+1}. {element}")
                            
                            # Combine all parts into a single journey_text
                            journey_text = "\n".join(journey_text_parts)
                            
                            journeys.append({
                                "name": journey["name"],
                                "journey_text": journey_text,
                                "original_structure": journey  # Store the original structure
                            })
                        elif isinstance(journey, dict) and "name" in journey and "journey_text" in journey:
                            journeys.append(journey)
                elif isinstance(parsed_response, list):
                    # If it's a list, try to extract name and journey_text from each item
                    for i, item in enumerate(parsed_response):
                        if isinstance(item, dict):
                            name = item.get("name", f"Journey {i+1}")
                            journey_text = item.get("journey_text", str(item))
                            journeys.append({
                                "name": name,
                                "journey_text": journey_text
                            })
                        else:
                            # If it's just a string, use a default name
                            journeys.append({
                                "name": f"Journey {i+1}",
                                "journey_text": str(item)
                            })
                
                # If we couldn't extract journeys in the expected format, use a fallback approach
                if not journeys:
                    logger.warning("Could not extract journeys in the expected format, using fallback approach")
                    if isinstance(parsed_response, dict):
                        # Try to extract from any field that might contain journey information
                        for key, value in parsed_response.items():
                            if isinstance(value, list):
                                for i, item in enumerate(value):
                                    if isinstance(item, dict):
                                        name = item.get("name", f"Journey {i+1}")
                                        journey_text = item.get("journey_text", str(item))
                                        journeys.append({
                                            "name": name,
                                            "journey_text": journey_text
                                        })
                    
                    # If still no journeys, create a single journey from the entire text
                    if not journeys:
                        logger.warning("Creating a single journey from the entire OCR text")
                        journeys = [{
                            "name": "Complete Document",
                            "journey_text": ocr_text[:1000]  # Limit to first 1000 chars
                        }]
                
                logger.info(f"Extracted {len(journeys)} user journeys")
                return journeys, cost, tokens, True
                
            except Exception as e:
                logger.error(f"Error parsing user journey extraction response: {str(e)}")
                # If parsing fails, create a single journey from the entire text
                journeys = [{
                    "name": "Complete Document",
                    "journey_text": ocr_text[:1000]  # Limit to first 1000 chars
                }]
                logger.info("Created a single journey from the entire OCR text due to parsing error")
                return journeys, cost, tokens, True
                
        except Exception as e:
            logger.error(f"Error extracting user journeys: {str(e)}")
            return [], 0, 0, False
    


    def analyze_requirement(self, requirement_text, journey):
        """
        Analyze a specific requirement/user journey.
        
        Args:
            requirement_text (str): The original requirement text
            journey (dict): The journey object with name and journey_text
            
        Returns:
            tuple: A tuple containing:
                - dict: The analyzed requirement
                - float: The cost of processing
                - int: The token count
                - str: The journey name
        """
        journey_name = journey
        journey_text = journey
        
        logger.info(f"Analyzing requirement: {journey_name} - {journey_text[:100]}...")
        
        # Concatenate the requirement text with the user journey
        combined_text = f"{requirement_text}\n\nUser journey: {journey_name}"
        
        # Prepare the query for the PF asset
        query = f"Please analyze the following requirement and provide a detailed breakdown in JSON format:\n\n{combined_text}"
        
        try:
            # Call the PF asset service
            response, cost, tokens = invoke_asset(self.requirement_analysis_asset_id, query)
            logger.info(f"Requirement analysis response received for {journey_name}. Cost: {cost}, Tokens: {tokens}")
            
            # Clean and parse the response
            try:
                parsed_response = self.clean_json_response(response)
                return parsed_response, cost, tokens, journey_name
            except Exception as e:
                logger.error(f"Error parsing requirement analysis response for {journey_name}: {str(e)}")
                # If parsing fails, return the raw response
                return {"error": "Failed to parse response", "raw_response": response}, cost, tokens, journey_name
                
        except Exception as e:
            logger.error(f"Error invoking PF asset for requirement analysis of {journey_name}: {str(e)}")
            return {"error": f"Failed to analyze requirement: {str(e)}"}, 0, 0, journey_name
    
    def process_requirement(self, usecase_id=None, file_id=None):
        """
        Process a requirement by sending it to the PF asset service and store the result in the database.
        
        Args:
            usecase_id (UUID, optional): The ID of the usecase to retrieve OCR text for.
            file_id (UUID, optional): The ID of the file associated with this requirement.
                If None, a file ID will be retrieved based on usecase_id or a dummy file ID will be generated.
                
        Returns:
            tuple: A tuple containing:
                - The response text
                - The cost of processing
                - The token count
                - A list of requirement IDs (UUIDs) if stored in the database, None otherwise
        """
        # If usecase_id is provided, try to get OCR text from the database
        if usecase_id is not None:
            logger.info(f"Retrieving OCR text for usecase ID: {usecase_id}")
            # Get OCR text directly without using the model imports
            ocr_text, ocr_file_id, success, document_format, additional_contexts = get_ocr_text_for_usecase(usecase_id)
            
            if success and ocr_text:
                requirement_text = ocr_text
                logger.info(f"Using OCR text from database for usecase ID: {usecase_id}")
                
                # Use the file_id from OCR if none was provided
                if file_id is None:
                    file_id = ocr_file_id
                    logger.info(f"Using file ID from OCR: {file_id}")
            else:
                error_message = f"Failed to retrieve OCR text for usecase ID: {usecase_id}"
                logger.error(error_message)
                return error_message, 0, 0, None
        else:
            error_message = "Usecase ID is required to retrieve OCR text"
            logger.error(error_message)
            return error_message, 0, 0, None
        
        # Use dummy file ID if none provided (in real implementation, this would come from UI)
        if file_id is None:
            # Get a valid file ID from the database or create a new one
            file_id, success = create_dummy_file_metadata()
            if not success:
                logger.error("Failed to create or retrieve a valid file ID")
                file_id = uuid.uuid4()  # Use a random UUID as fallback
            logger.info(f"Using file ID: {file_id}")
        
        try:
            start_time = time.time()
            logger.info(f"Document format is: {document_format}")
            # Step 1: Extract user journeys from OCR text using LLM
            if document_format == "userStories":
                journeys, extraction_cost, extraction_tokens, success = self.extract_requirements_from_fsd(ocr_text, additional_contexts)
            else:
                journeys, extraction_cost, extraction_tokens, success = self.extract_requirements_from_fsd(ocr_text, additional_contexts)
                
            if not success or not journeys:
                error_message = "Failed to extract user journeys from OCR text"
                logger.error(error_message)
                requirement_id, success = insert_requirement_data(
                    file_id=file_id,
                    requirement_name="Failed Extraction",
                    requirement_json="",
                    is_completed=False,
                    error_message=error_message
                )
                return error_message, extraction_cost, extraction_tokens, [requirement_id] if success else None
            
            logger.info(f"Processing {len(journeys)} user journeys")
            
            # Step 2: Analyze each journey in parallel
            total_cost = extraction_cost
            total_tokens = extraction_tokens
            requirement_ids = []
            results = []
            
            # Create a thread pool executor
            with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_concurrent_requests) as executor:
                logger.info(f"Starting concurrent analysis of {len(journeys)} user journeys with {self.max_concurrent_requests} workers")
                
                future_to_journey = {
                        executor.submit(
                        self.analyze_requirement, 
                        requirement_text, 
                        journey
                    ): journey for journey in journeys
                }
                
                # Process completed tasks as they finish
                for future in concurrent.futures.as_completed(future_to_journey):
                    journey = future_to_journey[future]
                    try:
                        analyzed_req, cost, tokens, journey_name = future.result()
                        total_cost += cost
                        total_tokens += tokens
                        
                        # Store the result
                        if "error" in analyzed_req:
                            logger.warning(f"Error in requirement analysis: {analyzed_req.get('error')}")
                            req_name = f"{journey_name} (Error)"
                            # Skip inserting into the database if there's an error in the JSON
                            logger.error(f"Skipping database insertion for {req_name} due to JSON error: {analyzed_req.get('error')}")
                            continue
                        else:
                            # Get the title from the analyzed requirement if available, otherwise use journey name
                            req_name = analyzed_req["requirement_entities"][0].get("name", journey_name)
                        
                            # Validate the JSON structure before inserting
                            is_valid, error_message, req_json = self.validate_requirement_json(analyzed_req, req_name)
                            if not is_valid:
                                logger.error(f"Skipping database insertion for {req_name} due to validation error: {error_message}")
                                
                                # Store the error in the database for tracking
                                requirement_id, success = insert_requirement_data(
                                    file_id=file_id,
                                    requirement_name=f"{req_name} (Invalid JSON)",
                                    requirement_json=json.dumps({"error": error_message}),
                                    is_completed=False,
                                    error_message=f"JSON validation error: {error_message}"
                                )
                                
                                if success:
                                    logger.info(f"Stored validation error in database with ID: {requirement_id}")
                                    requirement_ids.append(requirement_id)
                                
                                continue
                        
                            # Update: Convert the JSON string back to a dict, update the key, and convert back to string
                            req_json_dict = json.loads(req_json)
                            req_json_updated_as_per_db = {"user_journeys": req_json_dict["requirement_entities"]}
                            # Store in database
                            requirement_id, success = insert_requirement_data(
                                file_id=file_id,
                                requirement_name=req_name,
                                requirement_json=json.dumps(req_json_updated_as_per_db),
                                is_completed=True
                            )
                        
                            if success:
                                logger.info(f"Requirement data stored in database with ID: {requirement_id}")
                                requirement_ids.append(requirement_id)
                                results.append(analyzed_req)
                            else:
                                logger.error(f"Failed to store requirement data in database for {req_name}")
                    except Exception as e:
                        logger.error(f"Error processing journey: {str(e)}")
            
            end_time = time.time()
            execution_time = end_time - start_time
            logger.info(f"Completed requirement processing in {execution_time:.2f} seconds")
            
            if not requirement_ids:
                logger.error("No requirements were stored in the database")
                return "No requirements were successfully processed", total_cost, total_tokens, None
            
            # Return the combined results
            combined_results = {
                "requirements": results,
                "processing_time": execution_time,
                "journeys_extracted": len(journeys),
                "requirements_processed": len(requirement_ids)
            }
            
            return combined_results, total_cost, total_tokens, requirement_ids
            
        except Exception as e:
            logger.error(f"Error in process_requirement: {str(e)}")
            
            # Store error in database
            try:
                error_message = f"Error processing requirement: {str(e)}"
                requirement_id, success = insert_requirement_data(
                    file_id=file_id,
                    requirement_name="Processing Error",
                    requirement_json="",
                    is_completed=False,
                    error_message=error_message
                )
                
                if not success:
                    logger.error("Failed to store requirement error in database")
                    return f"Error processing requirement: {str(e)}", 0, 0, None
                
                return f"Error processing requirement: {str(e)}", 0, 0, [requirement_id]
            except Exception as db_error:
                logger.error(f"Error storing requirement error in database: {str(db_error)}")
                return f"Error processing requirement: {str(e)}", 0, 0, None


def get_ocr_text_for_usecase(usecase_id):
    """
    Retrieve OCR text for a specific usecase from the database.
    
    Args:
        usecase_id (int): The usecase ID
        
    Returns:
        tuple: (text, file_id, success, document_format, additional_contexts)
            - text (str): The OCR text
            - file_id (UUID): The file ID
            - success (bool): Whether the operation was successful
            - document_format (str): The format of the document
            - additional_contexts (dict): A dictionary mapping file_ids to their additional context
    """
    try:
        # Import here to avoid circular imports
        from sqlalchemy.orm import Session
        from db.session import engine
        from uuid import UUID
        
        # Use raw SQL queries instead of ORM to avoid model imports
        with Session(engine) as session:
            # Find files belonging to the usecase
            file_query = """
            SELECT "fileId", "documentFormat", "additionalContext", "fileName" FROM file_metadata 
            WHERE "usecaseId" = :usecase_id AND "is_deleted" = FALSE
            """
            files = session.execute(sqlalchemy.text(file_query), {"usecase_id": usecase_id}).fetchall()
            
            if not files:
                logger.error(f"No files found for usecase ID: {usecase_id}")
                return "", None, False, "", {}
            
            # Get the first file ID
            file_id = files[0][0]
            document_format = files[0][1]
            
            # Collect additional context for each file
            additional_contexts = {}
            for file in files:
                file_id_val = file[0]
                additional_context = file[2]
                file_name = file[3]
                
                if additional_context:
                    additional_contexts[file_id_val] = {
                        "context": additional_context,
                        "fileName": file_name
                    }
            
            # Get all OCR outputs for the usecase's files
            all_text = []
            for file in files:
                file_id_val = file[0]
                ocr_query = """
                SELECT "pageText" FROM ocr_outputs 
                WHERE "fileId" = :file_id AND "isCompleted" = TRUE
                ORDER BY "pageNumber"
                """
                ocr_outputs = session.execute(sqlalchemy.text(ocr_query), {"file_id": file_id_val}).fetchall()
                
                for output in ocr_outputs:
                    if output[0]:  # pageText
                        all_text.append(output[0])
            
            if not all_text:
                logger.error(f"No OCR text found for usecase ID: {usecase_id}")
                return "", file_id, False, "", additional_contexts
            
            # Combine all text
            combined_text = "\n\n".join(all_text)
            logger.info(f"Successfully retrieved OCR text for usecase ID: {usecase_id}")
            return combined_text, file_id, True, document_format, additional_contexts
            
    except Exception as e:
        logger.error(f"Error retrieving OCR text: {str(e)}")
        return "", None, False, "", {}


def process_user_requirement(usecase_id):
    """
    Process requirements for a specific usecase by retrieving OCR text from the database.
    
    This function is designed to be called from an API endpoint.
    
    Args:
        usecase_id (int): The usecase ID
        
    Returns:
        dict: A dictionary containing:
            - success (bool): Whether the operation was successful
            - message (str): A message describing the result
            - requirement_ids (list): The IDs of the created requirements if successful
            - cost (float): The cost of processing
            - tokens (int): The token count
    """
    try:
        # Update usecase metadata status to In Progress
        db = next(get_db())
        db.query(UsecaseMetadata).filter(
            UsecaseMetadata.usecaseId == usecase_id
        ).update({
            UsecaseMetadata.requirement_generation: "In Progress"
        })
        db.commit()

        # Create parser and process requirement
        parser = RequirementParser()
        response, cost, tokens, req_ids = parser.process_requirement(
            usecase_id=usecase_id
        )

        # Update status based on response
        status = "Completed" if req_ids and len(req_ids) > 0 else "Failed"
        db.query(UsecaseMetadata).filter(
            UsecaseMetadata.usecaseId == usecase_id
        ).update({
            UsecaseMetadata.requirement_generation: status
        })
        db.commit()

        # Check if any requirements need scenario generation
        need_scenario_generation = False
        if req_ids and len(req_ids) > 0:
            # Check if any of the new requirements need scenario generation
            for req_id in req_ids:
                req = db.query(RequirementData).filter(
                    RequirementData.requirementId == req_id
                ).first()
                if req and not req.isScenarioGenerated and not req.is_deleted:
                    need_scenario_generation = True
                    break

        # Only call scenario generation if needed
        if need_scenario_generation:
            # Call the API endpoint to generate scenarios
            api_url = f"{HostingConfigs.URL}/scenario-management/generate-by-usecase"
            request_body = {
                "usecase_id": usecase_id
            }
            
            # Make API call to generate scenarios based on the processed requirements
            try:
                response = requests.post(api_url, json=request_body)
                response.raise_for_status()
                
                if response.status_code == 202:
                    logger.info(f"Successfully triggered scenario generation for usecase ID: {usecase_id}")
                else:
                    logger.warning(f"Unexpected status code {response.status_code} when generating scenarios")
                    
            except requests.exceptions.RequestException as e:
                logger.error(f"Error calling scenario generation API: {str(e)}")
        else:
            logger.info(f"No need to trigger scenario generation for usecase ID: {usecase_id} - all requirements already processed")
        
        if req_ids and len(req_ids) > 0:
            return {
                "success": True,
                "message": f"Successfully processed {len(req_ids)} requirements",
                "requirement_ids": [str(req_id) for req_id in req_ids],
                "cost": cost,
                "tokens": tokens
            }
        else:
            return {
                "success": False,
                "message": "Failed to process requirements",
                "requirement_ids": [],
                "cost": cost,
                "tokens": tokens
            }
    except Exception as e:
        logger.error(f"Error in process_user_requirement: {str(e)}")
        return {
            "success": False,
            "message": f"Error: {str(e)}",
            "requirement_ids": [],
            "cost": 0,
            "tokens": 0
        }


# Example usage for testing
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Usecase ID for testing - OCR text will be fetched from database using this ID
    usecase_id_str = "20"
    
    print(f"\n=== Testing Process Requirement ===")
    print(f"Usecase ID: {usecase_id_str}")
    
    try:
        # Process requirements using usecase ID and user journey file
        result = process_user_requirement(
            usecase_id=usecase_id_str
        )
        
        # Print results
        print(f"\n=== Results ===")
        print(f"Success: {result['success']}")
        print(f"Message: {result['message']}")
        print(f"Number of Requirements: {len(result['requirement_ids'])}")
        print(f"Requirement IDs: {result['requirement_ids']}")
        print(f"Cost: {result['cost']}")
        print(f"Tokens: {result['tokens']}")
        
    except Exception as e:
        print(f"Error: {str(e)}")
