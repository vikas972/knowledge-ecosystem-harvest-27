"""
Scenario Generator Module

This module is responsible for generating test scenarios based on requirements by calling the PF asset service.
It serves as a service that will be called by the generator workflow orchestrator.
"""

import logging
import sys
import json
import os
from pathlib import Path
from contextlib import contextmanager
import time
import threading

import requests

from models.ocr.ocr_records import OCROutputs

# Add the parent directory to sys.path to allow importing from sibling packages
sys.path.append(str(Path(__file__).parent.parent.parent))

from models.file_processing.file_record import FileMetadata
from models.use_case.usecase_records import UsecaseMetadata
from services.llm.pf_asset import invoke_asset, get_asset_id, get_asset_id_as_per_config
from models.generator.scenario import ScenarioOutput
from models.generator.requirement import RequirementData
from core.config import HostingConfigs, settings
from app.deps import get_db  # Import get_db instead of SessionLocal

# Configure logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)

class ScenarioGenerator:
    def __init__(self):
        self.asset_id = "" #get_asset_id("scenario_generator")
        logger.info(f"ScenarioGenerator initialized with asset ID: {self.asset_id}")
        # Thread-safe counter for tracking displayIds
        self.display_id_counters = {}
        self.counter_lock = threading.Lock()

    def get_next_display_id(self, usecase_id):
        """
        Thread-safe method to get the next sequential displayId for a usecase.
        Each thread must acquire the lock before accessing and incrementing the counter.
        
        Args:
            usecase_id: The ID of the usecase
            
        Returns:
            int: The next unique displayId
        """
        with self.counter_lock:
            # Initialize counter for this usecase if it doesn't exist
            if usecase_id not in self.display_id_counters:
                # First, initialize from database to handle restarts
                db = next(get_db())
                try:
                    # Get all files for this usecase
                    usecase_files = db.query(FileMetadata.fileId).filter(
                        FileMetadata.usecaseId == usecase_id
                    ).all()
                    
                    # Extract file IDs into a list
                    usecase_file_ids = [f.fileId for f in usecase_files]
                    
                    # Get the maximum displayId from the database
                    max_display_id = 0
                    if usecase_file_ids:
                        scenarios = db.query(
                            ScenarioOutput.displayId
                        ).filter(
                            ScenarioOutput.fileId.in_(usecase_file_ids),
                        ).order_by(
                            ScenarioOutput.displayId.desc()
                        ).first()
                        
                        if scenarios:
                            max_display_id = scenarios[0]
                    
                    # Initialize counter to the max found + 1, or 1 if none found
                    self.display_id_counters[usecase_id] = max_display_id + 1
                    logger.info(f"Initialized displayId counter for usecase {usecase_id} to {self.display_id_counters[usecase_id]}")
                except Exception as e:
                    logger.error(f"Error initializing counter from DB: {str(e)}")
                    # Default to 1 if there was an error
                    self.display_id_counters[usecase_id] = 1
                finally:
                    db.close()
            
            # Get the current value
            current_id = self.display_id_counters[usecase_id]
            
            # Increment for next use
            self.display_id_counters[usecase_id] += 1
            
            logger.info(f"Thread {threading.current_thread().name} allocated displayId {current_id} for usecase {usecase_id}")
            return current_id

    def get_unique_display_id(self, base_id, thread_id=None):
        """
        Generate a unique displayId by combining base ID with timestamp data.
        This helps resolve race conditions when multiple threads get the same base ID.
        
        Args:
            base_id (int): The base displayId from database
            thread_id (int, optional): Thread identifier for extra uniqueness
            
        Returns:
            int: A unique displayId
        """
        if thread_id is None:
            thread_id = id(threading.current_thread()) % 1000
        
        # Add a small delay (0.1-2.5ms) based on thread ID to reduce collision probability
        # This creates a small stagger between threads
        time.sleep((thread_id % 25) / 10000)
        
        # Get current timestamp in milliseconds
        # We only need a small, changing component to resolve race conditions
        timestamp_ms = int(time.time() * 1000) % 100  # Last 2 digits of milliseconds
        
        # We maintain the original ID sequence but add a tiny offset based on timestamp
        # This offset is small enough to not disrupt the sequence but enough to resolve collisions
        # The formula creates a unique ID by adding a small fraction based on timestamp
        unique_id = base_id + (timestamp_ms / 1000)  # Add a fractional part that gets truncated to int
        
        return unique_id

    def get_ocr_text_for_supporting_doc_based_on_usecase_id(self, usecase_id):
            """
            Get OCR text for all files associated with a usecase.
            
            Args:
                usecase_id (int): The ID of the usecase
                
            Returns:
                str: Combined OCR text from all files
            """
            logger.info(f"Retrieving OCR text for supporting documents of usecase ID: {usecase_id}")
            db = next(get_db())
            try:
                # Get all files for the usecase
                files = (
                    db.query(FileMetadata)
                    .filter(FileMetadata.usecaseId == usecase_id)
                    .filter(FileMetadata.documentType == "supportingReq")
                    .filter(FileMetadata.is_deleted == False)
                    .all()
                )

                if len(files) == 0:
                    files = (
                        db.query(FileMetadata)
                        .filter(FileMetadata.usecaseId == usecase_id)
                        .filter(FileMetadata.documentType == "mainReq")
                        .filter(FileMetadata.is_deleted == False)
                        .all()
                    )
                
                logger.info(f"Found {len(files)} supporting document files for usecase ID: {usecase_id}")
                all_ocr_text = []
                
                # For each file, get its OCR outputs
                for file in files:
                    logger.info(f"Processing OCR for file: {file.fileName} (ID: {file.fileId})")
                    ocr_outputs = (
                        db.query(OCROutputs)
                        .filter(OCROutputs.fileId == file.fileId)
                        .filter(OCROutputs.is_deleted == False)
                        .filter(OCROutputs.isCompleted == True)
                        .order_by(OCROutputs.pageNumber)
                        .all()
                    )
                    
                    logger.info(f"Found {len(ocr_outputs)} OCR output records for file: {file.fileName}")
                    
                    # Combine OCR text from all pages
                    file_text = "\n".join(
                        f"Page {output.pageNumber}: {output.pageText}"
                        for output in ocr_outputs
                    )
                    
                    if file_text:
                        all_ocr_text.append(f"File: {file.fileName}\n{file_text}")
                        logger.info(f"Added OCR text for file: {file.fileName} ({len(file_text)} characters)")
                    else:
                        logger.warning(f"No OCR text found for file: {file.fileName}")
                
                combined_text = "\n\n".join(all_ocr_text)
                logger.info(f"Retrieved OCR text for usecase ID {usecase_id}: {len(combined_text)} characters total")
                return combined_text
            except Exception as e:
                logger.error(f"Error retrieving OCR text for usecase ID {usecase_id}: {str(e)}")
                return ""
            finally:
                db.close()
    

    def generate_scenarios(self, requirement_ids, usecase_id):
        """
        Generate test scenarios for a list of requirement IDs using requirementJson.
        
        Args:
            requirement_ids (list): List of requirement IDs to process.
            usecase_id (int): The ID of the usecase.
                
        Returns:
            list: A list of ScenarioOutput objects created.
        """
        import concurrent.futures
        from itertools import islice

        logger.info(f"Starting scenario generation for usecase ID {usecase_id} with {len(requirement_ids)} requirements")
        
        scenario_outputs = []
        BATCH_SIZE = 15  # Number of requirements to process in parallel
        logger.info(f"Using batch size of {BATCH_SIZE} for parallel processing")
        
        # Update usecase status to In Progress
        db = next(get_db())
        try:
            usecase = db.query(UsecaseMetadata).filter(UsecaseMetadata.usecaseId == usecase_id).first()
            if usecase:
                usecase.scenario_generation = "In Progress"
                db.commit()
                logger.info(f"Updated usecase {usecase_id} status to 'In Progress'")
                product = usecase.product
            else:
                logger.warning(f"Usecase with ID {usecase_id} not found in database")
                product = None
        except Exception as e:
            logger.error(f"Error updating usecase status: {str(e)}")
        finally:
            db.close()

        def process_requirement(requirement_id, product):
            logger.info(f"Processing requirement ID: {requirement_id}")
            # Get basic requirement information
            db = next(get_db())
            try:
                # Fetch requirementJson from the database using requirement_id
                requirement = db.query(RequirementData).filter(RequirementData.requirementId == requirement_id).first()
                if not requirement or not requirement.requirementJson:
                    logger.error(f"Requirement JSON not found for ID: {requirement_id}")
                    return None
                    
                requirement_json = requirement.requirementJson
                file_id = requirement.fileId
                logger.info(f"Retrieved requirement JSON for ID {requirement_id} (file ID: {file_id})")
                
                # Get the usecase_id from the file_id
                file = db.query(FileMetadata).filter(FileMetadata.fileId == file_id).first()
                if not file:
                    logger.error(f"File not found for file ID: {file_id}")
                    return None
                
                file_usecase_id = file.usecaseId
                logger.info(f"Retrieved usecase ID {file_usecase_id} for file ID {file_id}")
            finally:
                db.close()

            query = f"Please generate test scenarios for the following requirement JSON:```Requirement\n\n{requirement_json}```"
            logger.info(f"Sending requirement ID {requirement_id} to PF asset for scenario generation")

            try:
                # Get supporting document OCR text
                supporting_doc_text = self.get_ocr_text_for_supporting_doc_based_on_usecase_id(usecase_id)
                if supporting_doc_text:
                    logger.info(f"Adding supporting document text ({len(supporting_doc_text)} chars) to query")
                    query = query + "\n\nThis is the supporting document:" + supporting_doc_text
                else:
                    logger.warning(f"No supporting document text found for usecase ID {usecase_id}")
                
                # Invoke PF asset
                logger.info(f"Invoking PF asset for requirement ID {requirement_id}")
                # get asset id
                self.asset_id = get_asset_id_as_per_config(product, "scenario_generator")
                logger.info(f"Asset id for generating scenarios is: {self.asset_id}")
                response, cost, tokens = invoke_asset(self.asset_id, query)
                logger.info(f"PF asset response received for requirement ID {requirement_id}. Cost: {cost}, Tokens: {tokens}")

                # Log the raw response for debugging
                logger.info(f"Raw response type: {type(response)}")
                logger.info(f"Raw response content: {repr(response)[:500]}...")

                # Process the response based on its type
                if isinstance(response, dict):
                    logger.info(f"Response is a dictionary, converting to list")
                    # Check if it's a dictionary with a 'scenarios' array
                    if 'scenarios' in response and isinstance(response['scenarios'], list):
                        logger.info(f"Found 'scenarios' array with {len(response['scenarios'])} scenarios")
                        parsed_response = response['scenarios']
                    else:
                        parsed_response = [response]
                elif isinstance(response, list):
                    logger.info(f"Response is already a list with {len(response)} items")
                    parsed_response = response
                elif isinstance(response, str):
                    logger.info(f"Response is a string, attempting to parse as JSON")
                    clean_response = response.strip()
                    if clean_response:
                        # start_idx = clean_response.find("\n", 3) + 1
                        start_idx = clean_response.rfind("```json") + 7
                        end_idx = clean_response.rfind("```")
                        if start_idx > 0 and end_idx > start_idx:
                            clean_response = clean_response[start_idx:end_idx].strip()
                            logger.info(f"Extracted JSON content from code block")
                    
                    try:
                        json_data = json.loads(clean_response)
                        # Check if it's a dictionary with a 'scenarios' array
                        if isinstance(json_data, dict) and 'scenarios' in json_data and isinstance(json_data['scenarios'], list):
                            logger.info(f"Found 'scenarios' array with {len(json_data['scenarios'])} scenarios in JSON string")
                            parsed_response = json_data['scenarios']
                        elif not isinstance(json_data, list):
                            logger.info(f"Parsed JSON is not a list, converting to list")
                            parsed_response = [json_data]
                        else:
                            parsed_response = json_data
                        logger.info(f"Successfully parsed JSON response with {len(parsed_response)} scenarios")
                    except json.JSONDecodeError as e:
                        logger.error(f"JSON decoding error for requirement ID {requirement_id}: {str(e)}")
                        logger.error(f"Problematic JSON content: {clean_response}...")
                        return None
                        # raise ValueError(f"Invalid JSON format received from PF asset: {clean_response[:100]}...")
                else:
                    logger.error(f"Unexpected response type: {type(response)}")
                    raise ValueError(f"Unexpected response type: {type(response)}")
                
                # Create and save scenario outputs in a single atomic transaction
                db = next(get_db())
                try:
                    # Get the file_id and usecase_id
                    requirement = db.query(RequirementData).filter(RequirementData.requirementId == requirement_id).first()
                    if not requirement or not requirement.requirementJson:
                        logger.error(f"Requirement JSON not found for ID: {requirement_id}")
                        return None
                        
                    file_id = requirement.fileId
                    
                    # Get the usecase_id from the file_id
                    file = db.query(FileMetadata).filter(FileMetadata.fileId == file_id).first()
                    if not file:
                        logger.error(f"File not found for file ID: {file_id}")
                        return None
                    
                    file_usecase_id = file.usecaseId
                    
                    # Prepare list for all scenario outputs
                    req_scenario_outputs = []
                    
                    # For larger batch of scenarios, allocate all displayIds at once under the lock
                    # This avoids holding the lock for too long during database operations
                    scenario_count = len(parsed_response)
                    display_ids = []
                    
                    # Allocate all needed displayIds at once (still thread-safe)
                    for i in range(scenario_count):
                        display_id = self.get_next_display_id(file_usecase_id)
                        display_ids.append(display_id)
                        logger.info(f"Pre-allocated displayId {display_id} for scenario {i+1}/{scenario_count}")
                    
                    # Create all scenarios with pre-allocated displayIds
                    for i, scenario_json in enumerate(parsed_response):
                        logger.info(f"Creating ScenarioOutput for scenario {i+1}/{len(parsed_response)}")
                        
                        # Use the pre-allocated displayId
                        current_display_id = display_ids[i]

                        # Log scenario details for debugging
                        print(f"🔍 type of scenario_json: {type(scenario_json)}")
                        print(f"🔍 scenario_json: {scenario_json}")
                        
                        scenario_output = ScenarioOutput(
                            fileId=file_id,
                            requirementId=requirement_id,
                            displayId=current_display_id,
                            outputJson=scenario_json,
                            isCompleted=True
                        )
                        db.add(scenario_output)
                        req_scenario_outputs.append(scenario_output)
                    
                    # Commit the transaction 
                    db.commit()
                    logger.info(f"Saved {len(req_scenario_outputs)} scenarios to database for requirement ID {requirement_id}")
                    return req_scenario_outputs
                
                except Exception as db_error:
                    db.rollback()
                    logger.error(f"Error saving scenarios to database for requirement ID {requirement_id}: {str(db_error)}")
                    raise
                finally:
                    db.close()

            except (ValueError) as e:
                logger.error(f"Error processing response for requirement ID {requirement_id}: {str(e)}")
                
                # For error scenarios, also use our thread-safe counter
                db = next(get_db())
                try:
                    # Get basic file information
                    requirement = db.query(RequirementData).filter(RequirementData.requirementId == requirement_id).first()
                    if not requirement:
                        logger.error(f"Requirement not found for ID: {requirement_id}")
                        return None
                        
                    file_id = requirement.fileId
                    
                    # Get the usecase_id from the file_id
                    file = db.query(FileMetadata).filter(FileMetadata.fileId == file_id).first()
                    if not file:
                        logger.error(f"File not found for file ID: {file_id}")
                        return None
                    
                    file_usecase_id = file.usecaseId
                    
                    # Get a unique displayId for the error record
                    unique_display_id = self.get_next_display_id(file_usecase_id)
                    
                    scenario_output = ScenarioOutput(
                        fileId=file_id,
                        requirementId=requirement_id,
                        displayId=unique_display_id,
                        outputJson=json.dumps({}),
                        errorMessage=str(e),
                        isCompleted=False
                    )
                    
                    db.add(scenario_output)
                    db.commit()
                    logger.info(f"Saved error record for requirement ID {requirement_id} with displayId {unique_display_id}")
                    return [scenario_output]
                
                except Exception as db_error:
                    db.rollback()
                    logger.error(f"Error saving error record to database: {str(db_error)}")
                finally:
                    db.close()
                    
                # Update usecase status to Failed
                db = next(get_db())
                try:
                    usecase = db.query(UsecaseMetadata).filter(UsecaseMetadata.usecaseId == usecase_id).first()
                    if usecase:
                        usecase.scenario_generation = "Failed"
                        db.commit()
                        logger.info(f"Updated usecase {usecase_id} status to 'Failed'")
                finally:
                    db.close()
                return None

        # Process requirements in batches using ThreadPoolExecutor
        logger.info(f"Starting parallel processing of {len(requirement_ids)} requirements in batches of {BATCH_SIZE}")
        with concurrent.futures.ThreadPoolExecutor(max_workers=BATCH_SIZE) as executor:
            for batch_start in range(0, len(requirement_ids), BATCH_SIZE):
                batch = requirement_ids[batch_start:batch_start + BATCH_SIZE]
                logger.info(f"Processing batch {batch_start//BATCH_SIZE + 1} with {len(batch)} requirements")
                futures = [executor.submit(process_requirement, req_id, product) for req_id in batch]
                
                for future in concurrent.futures.as_completed(futures):
                    result = future.result()
                    if result:
                        scenario_outputs.extend(result)
                        logger.info(f"Added {len(result)} scenarios to output list")
        
        logger.info(f"Completed processing all requirements, generated {len(scenario_outputs)} total scenarios")
        
        # Update usecase status to Completed and trigger test case generation
        try:
            db = next(get_db())
            try:
                usecase = db.query(UsecaseMetadata).filter(UsecaseMetadata.usecaseId == usecase_id).first()
                if usecase:
                    usecase.scenario_generation = "Completed"
                    db.commit()
                    logger.info(f"Updated usecase {usecase_id} status to 'Completed'")
            finally:
                db.close()

            # Get all scenario IDs for the usecase that are eligible for test case generation
            logger.info(f"Starting direct test case generation for usecase {usecase_id}")
            
            # Direct approach: Get all file IDs associated with the usecase
            db = next(get_db())
            try:
                files = db.query(FileMetadata).filter(
                    FileMetadata.usecaseId == usecase_id,
                    FileMetadata.is_deleted == False
                ).all()
                
                if not files:
                    logger.warning(f"No files found for usecase ID {usecase_id}")
                    return scenario_outputs
                
                # Get scenarios for all files
                scenario_ids = []
                for file in files:
                    scenarios = db.query(ScenarioOutput).filter(
                        ScenarioOutput.fileId == file.fileId,
                        ScenarioOutput.is_deleted == False,
                        ScenarioOutput.isCompleted == True,
                        ScenarioOutput.isTestcasesGenerated == False
                    ).all()
                    
                    scenario_ids.extend([scenario.scenarioId for scenario in scenarios])
                
                if not scenario_ids:
                    logger.warning("No eligible scenarios found for test case generation")
                    return scenario_outputs
                
                logger.info(f"Found {len(scenario_ids)} scenarios that need test cases generated")
                
                # Update usecase status
                usecase = db.query(UsecaseMetadata).filter(
                    UsecaseMetadata.usecaseId == usecase_id
                ).first()
                if usecase:
                    usecase.test_case_generation = "In Progress"
                    db.commit()
                    
                # Directly call the test case generator
                from services.generator.test_case_generator import TestCaseGenerator
                generator = TestCaseGenerator()
                logger.info(f"Calling TestCaseGenerator directly with {len(scenario_ids)} scenarios")
                
                # Start the test case generation in a separate thread to avoid blocking
                import threading
                def run_test_case_generation():
                    try:
                        generator.generate_testcases(scenario_ids, product, usecase_id)
                        logger.info(f"Test case generation completed successfully for usecase {usecase_id}")
                        
                        # Update usecase_metadata to mark test_case_generation as "Completed"
                        db = next(get_db())
                        try:
                            usecase = db.query(UsecaseMetadata).filter(
                                UsecaseMetadata.usecaseId == usecase_id
                            ).first()
                            
                            if usecase:
                                usecase.test_case_generation = "Completed"
                                db.commit()
                                logger.info(f"Updated test_case_generation status to 'Completed' for usecase {usecase_id}")
                            else:
                                logger.warning(f"Could not find usecase with ID {usecase_id} to update status")
                        except Exception as db_error:
                            logger.error(f"Error updating usecase status: {str(db_error)}")
                        finally:
                            db.close()
                            
                    except Exception as e:
                        logger.error(f"Error in test case generation: {str(e)}")
                        # Update usecase status to Failed
                        db = next(get_db())
                        try:
                            usecase = db.query(UsecaseMetadata).filter(UsecaseMetadata.usecaseId == usecase_id).first()
                            if usecase:
                                usecase.test_case_generation = "Failed"
                                db.commit()
                        finally:
                            db.close()
                
                # Start the thread for test case generation
                thread = threading.Thread(target=run_test_case_generation)
                thread.daemon = True
                thread.start()
                logger.info(f"Test case generation thread started for usecase {usecase_id}")
                
            except Exception as db_error:
                logger.error(f"Error preparing for test case generation: {str(db_error)}")
            finally:
                db.close()
                
        except Exception as e:
            logger.error(f"Error updating usecase status or initiating test case generation: {str(e)}")
            db = next(get_db())
            try:
                usecase = db.query(UsecaseMetadata).filter(UsecaseMetadata.usecaseId == usecase_id).first()
                if usecase:
                    usecase.scenario_generation = "Failed"
                    db.commit()
                    logger.info(f"Updated usecase {usecase_id} status to 'Failed' due to error")
            finally:
                db.close()
        
        logger.info(f"Scenario generation completed successfully for usecase ID {usecase_id}")
        return scenario_outputs
    
