"""
Generator Workflow Module

This module orchestrates the generation process by calling various services:
1. RequirementParser - for parsing and analyzing requirements
2. ScenarioGenerator - for generating test scenarios based on requirements
3. TestCaseGenerator - for generating test cases based on scenarios
4. TestScriptGenerator - for generating test scripts based on test cases

It acts as an orchestrator that coordinates the flow between these services.
"""

import logging
import sys
import os
from pathlib import Path

# Add the parent directory to sys.path to allow importing from sibling packages
sys.path.append(str(Path(__file__).parent.parent.parent))

from services.generator.requirement_parser import RequirementParser
from services.generator.scenario_generator import ScenarioGenerator
from services.generator.test_case_generator import TestCaseGenerator
from services.generator.test_script_generator import TestScriptGenerator

logger = logging.getLogger(__name__)

class GeneratorWorkflow:
    """
    Orchestrates the generation workflow by calling various services in sequence.
    """
    
    def __init__(self):
        """Initialize the GeneratorWorkflow with its dependent services."""
        self.requirement_parser = RequirementParser()
        self.scenario_generator = ScenarioGenerator()
        self.test_case_generator = TestCaseGenerator()
        self.test_script_generator = TestScriptGenerator()
        logger.info("GeneratorWorkflow initialized with all services")
    
    def run_workflow(self, requirement_text=None):
        """
        Run the complete generation workflow from requirement to test scripts.
        
        Args:
            requirement_text (str, optional): The requirement text to process.
                If None, a dummy text will be used.
                
        Returns:
            dict: A dictionary containing the results of each step in the workflow.
        """
        logger.info("Starting the generation workflow")
        
        # Step 1: Process the requirement
        logger.info("Step 1: Processing requirement")
        requirement_response, req_cost, req_tokens = self.requirement_parser.process_requirement(requirement_text)
        logger.info(f"Requirement processing completed. Cost: {req_cost}, Tokens: {req_tokens}")
        
        # Step 2: Generate scenarios based on the requirement
        logger.info("Step 2: Generating scenarios")
        scenarios_response, scen_cost, scen_tokens = self.scenario_generator.generate_scenarios(requirement_text)
        logger.info(f"Scenario generation completed. Cost: {scen_cost}, Tokens: {scen_tokens}")
        
        # Step 3: Generate test cases based on the scenarios
        logger.info("Step 3: Generating test cases")
        test_cases_response, tc_cost, tc_tokens = self.test_case_generator.generate_test_cases(scenarios_response)
        logger.info(f"Test case generation completed. Cost: {tc_cost}, Tokens: {tc_tokens}")
        
        # Step 4: Generate test scripts based on the test cases
        logger.info("Step 4: Generating test scripts")
        # Extract test case IDs from the test cases response
        testcase_ids = [tc.get("testCaseId") for tc in test_cases_response if tc.get("testCaseId")]
        product = "DTB"  # Default product, should be passed from the caller in real implementation
        usecase_id = 1  # Default usecase ID, should be passed from the caller in real implementation
        
        test_scripts_response, ts_cost, ts_tokens = self.test_script_generator.generate_test_scripts(
            testcase_ids, product, usecase_id
        )
        logger.info(f"Test script generation completed. Cost: {ts_cost}, Tokens: {ts_tokens}")
        
        # Calculate total cost and tokens
        total_cost = req_cost + scen_cost + tc_cost + ts_cost
        total_tokens = req_tokens + scen_tokens + tc_tokens + ts_tokens
        
        logger.info(f"Workflow completed. Total cost: {total_cost}, Total tokens: {total_tokens}")
        
        # Return the results
        return {
            "requirement_analysis": requirement_response,
            "scenarios": scenarios_response,
            "test_cases": test_cases_response,
            "test_scripts": test_scripts_response,
            "metrics": {
                "total_cost": total_cost,
                "total_tokens": total_tokens,
                "requirement_cost": req_cost,
                "requirement_tokens": req_tokens,
                "scenarios_cost": scen_cost,
                "scenarios_tokens": scen_tokens,
                "test_cases_cost": tc_cost,
                "test_cases_tokens": tc_tokens,
                "test_scripts_cost": ts_cost,
                "test_scripts_tokens": ts_tokens
            }
        }


# Example usage for testing
def test_generator_workflow():
    """Test the GeneratorWorkflow with dummy data."""
    workflow = GeneratorWorkflow()
    
    print("\n=== Testing Complete Workflow ===")
    results = workflow.run_workflow()
    
    print("\n=== Requirement Analysis ===")
    print(results["requirement_analysis"])
    
    print("\n=== Generated Scenarios ===")
    print(results["scenarios"])
    
    print("\n=== Generated Test Cases ===")
    print(results["test_cases"])
    
    print("\n=== Generated Test Scripts ===")
    print(results["test_scripts"])
    
    print("\n=== Metrics ===")
    for key, value in results["metrics"].items():
        print(f"{key}: {value}")


if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Run the test
    test_generator_workflow()
