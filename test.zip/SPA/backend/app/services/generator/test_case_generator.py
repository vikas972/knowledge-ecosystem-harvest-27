"""
Test Case Generator Module

This module is responsible for generating test cases based on scenarios by calling the PF asset service.
It serves as a service that will be called by the generator workflow orchestrator.
"""
import sys
import json
import os
import logging
from pathlib import Path
from contextlib import contextmanager
# import psutil
import time
import threading

from models.generator.requirement import RequirementData
from models.ocr.ocr_records import OCROutputs

# Add the parent directory to sys.path to allow importing from sibling packages
sys.path.append(str(Path(__file__).parent.parent.parent))

from models.file_processing.file_record import FileMetadata
from services.llm.pf_asset import invoke_asset, get_asset_id, get_asset_id_as_per_config
from models.generator.test_case import TestCases
from models.generator.scenario import ScenarioOutput
from models.use_case.usecase_records import UsecaseMetadata
from core.config import settings
from deps import get_db

# Configure logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)

class TestCaseGenerator:
    def __init__(self):
        self.asset_id = ""#get_asset_id("testcase_generator")
        logger.info(f"TestCaseGenerator initialized with asset ID: {self.asset_id}")
        # Thread-safe counter for tracking displayIds
        self.display_id_counters = {}
        self.counter_lock = threading.Lock()

    def get_next_display_id(self, usecase_id):
        """
        Thread-safe method to get the next sequential displayId for a usecase.
        Each thread must acquire the lock before accessing and incrementing the counter.
        
        Args:
            usecase_id: The ID of the usecase
            
        Returns:
            int: The next unique displayId
        """
        with self.counter_lock:
            # Initialize counter for this usecase if it doesn't exist
            if usecase_id not in self.display_id_counters:
                # First, initialize from database to handle restarts
                db = next(get_db())
                try:
                    # Get all files for this usecase
                    usecase_files = db.query(FileMetadata.fileId).filter(
                        FileMetadata.usecaseId == usecase_id
                    ).all()
                    
                    # Extract file IDs into a list
                    usecase_file_ids = [f.fileId for f in usecase_files]
                    
                    # Get the maximum displayId from the database
                    max_display_id = 0
                    if usecase_file_ids:
                        testcases = db.query(
                            TestCases.displayId
                        ).filter(
                            TestCases.fileId.in_(usecase_file_ids),
                            TestCases.is_deleted == False
                        ).order_by(
                            TestCases.displayId.desc()
                        ).first()
                        
                        if testcases:
                            max_display_id = testcases[0]
                    
                    # Initialize counter to the max found + 1, or 1 if none found
                    self.display_id_counters[usecase_id] = max_display_id + 1
                    logger.info(f"Initialized testcase displayId counter for usecase {usecase_id} to {self.display_id_counters[usecase_id]}")
                except Exception as e:
                    logger.error(f"Error initializing counter from DB: {str(e)}")
                    # Default to 1 if there was an error
                    self.display_id_counters[usecase_id] = 1
                finally:
                    db.close()
            
            # Get the current value
            current_id = self.display_id_counters[usecase_id]
            
            # Increment for next use
            self.display_id_counters[usecase_id] += 1
            
            logger.info(f"Thread {threading.current_thread().name} allocated testcase displayId {current_id} for usecase {usecase_id}")
            return current_id

    def get_unique_display_id(self, base_id, thread_id=None):
        """
        Generate a unique displayId by combining base ID with timestamp data.
        This helps resolve race conditions when multiple threads get the same base ID.
        
        Args:
            base_id (int): The base displayId from database
            thread_id (int, optional): Thread identifier for extra uniqueness
            
        Returns:
            int: A unique displayId
        """
        if thread_id is None:
            thread_id = id(threading.current_thread()) % 1000
        
        # Add a small delay (0.1-2.5ms) based on thread ID to reduce collision probability
        # This creates a small stagger between threads
        time.sleep((thread_id % 25) / 10000)
        
        # Get current timestamp in milliseconds
        # We only need a small, changing component to resolve race conditions
        timestamp_ms = int(time.time() * 1000) % 100  # Last 2 digits of milliseconds
        
        # We maintain the original ID sequence but add a tiny offset based on timestamp
        # This offset is small enough to not disrupt the sequence but enough to resolve collisions
        # The formula creates a unique ID by adding a small fraction based on timestamp
        unique_id = base_id + (timestamp_ms / 1000)  # Add a fractional part that gets truncated to int
        
        return unique_id

    def get_file_text(self, scenario_id):
            """
            Get the OCR text from the supporting document associated with the scenario.
            
            Args:
                scenario_id (UUID): The ID of the scenario
                
            Returns:
                str: Combined OCR text from all pages of the supporting document
            """
            logger.info(f"Retrieving OCR text for supporting document related to scenario ID: {scenario_id}")
            db = next(get_db())
            try:
                # Get scenario and its file ID
                scenario = (
                    db.query(ScenarioOutput)
                    .filter(ScenarioOutput.scenarioId == scenario_id)
                    .filter(ScenarioOutput.is_deleted == False)
                    .first()
                )
                
                if not scenario:
                    logger.warning(f"Scenario not found for ID: {scenario_id}")
                    return None
                    
                # Get the usecase ID from the file metadata
                file_metadata = (
                    db.query(FileMetadata)
                    .filter(FileMetadata.fileId == scenario.fileId)
                    .filter(FileMetadata.is_deleted == False)
                    .first()
                )
                
                if not file_metadata:
                    logger.warning(f"File metadata not found for file ID: {scenario.fileId}")
                    return None
                    
                logger.debug(f"Found file metadata for usecase ID: {file_metadata.usecaseId}")
                
                # Get the supporting document file ID for this usecase
                supporting_doc = (
                    db.query(FileMetadata)
                    .filter(FileMetadata.usecaseId == file_metadata.usecaseId)
                    .filter(FileMetadata.documentType == "supportingReq")
                    .filter(FileMetadata.is_deleted == False)
                    .first()
                )

                if not supporting_doc:
                    supporting_doc = (
                        db.query(FileMetadata)
                        .filter(FileMetadata.usecaseId == file_metadata.usecaseId)
                        .filter(FileMetadata.documentType == "mainReq")
                        .filter(FileMetadata.is_deleted == False)
                        .first()
                    )
                
                if not supporting_doc:
                    logger.warning(f"No supporting document found for usecase ID: {file_metadata.usecaseId}")
                    return None
                    
                logger.debug(f"Found supporting document: {supporting_doc.fileName} (ID: {supporting_doc.fileId})")
                
                # Get all OCR outputs for the supporting document
                ocr_outputs = (
                    db.query(OCROutputs)
                    .filter(OCROutputs.fileId == supporting_doc.fileId)
                    .filter(OCROutputs.is_deleted == False)
                    .order_by(OCROutputs.pageNumber)
                    .all()
                )
                
                if not ocr_outputs:
                    logger.warning(f"No OCR outputs found for supporting document ID: {supporting_doc.fileId}")
                    return None
                    
                logger.debug(f"Found {len(ocr_outputs)} OCR output records for supporting document")
                
                # Combine all page texts
                combined_text = " ".join(output.pageText for output in ocr_outputs)
                logger.info(f"Retrieved OCR text for scenario ID {scenario_id}: {len(combined_text)} characters")
                return combined_text
                
            except Exception as e:
                logger.error(f"Error retrieving OCR text for scenario ID {scenario_id}: {str(e)}")
                return None
            finally:
                db.close()

    def get_requirement_for_scenario_id(self, scenario_id):
                """
                Get requirement data for a specific scenario ID.
                
                Args:
                    scenario_id (UUID): The ID of the scenario
                    
                Returns:
                    dict: Requirement data including requirement JSON and name
                """
                logger.info(f"Retrieving requirement data for scenario ID: {scenario_id}")
                db = next(get_db())
                try:
                    # Get scenario and its associated requirement
                    scenario = (
                        db.query(ScenarioOutput)
                        .filter(ScenarioOutput.scenarioId == scenario_id)
                        .filter(ScenarioOutput.is_deleted == False)
                        .first()
                    )
                    
                    if not scenario:
                        logger.warning(f"Scenario not found for ID: {scenario_id}")
                        return None
                        
                    requirement = (
                        db.query(RequirementData)
                        .filter(RequirementData.requirementId == scenario.requirementId)
                        .filter(RequirementData.is_deleted == False)
                        .first()
                    )
                    
                    if not requirement:
                        logger.warning(f"Requirement not found for ID: {scenario.requirementId}")
                        return None
                        
                    logger.info(f"Retrieved requirement '{requirement.requirementName}' for scenario ID: {scenario_id}")
                    return {
                        "requirementName": requirement.requirementName,
                        "requirementJson": requirement.requirementJson,
                        "fileId": requirement.fileId
                    }
                    
                except Exception as e:
                    logger.error(f"Error retrieving requirement for scenario ID {scenario_id}: {str(e)}")
                    return None
                finally:
                    db.close()
        
    def get_application_flow(self, product):
        """
        Get the application flow from the product-specific crawl file.
        
        Args:
            product (str): The product name
            
        Returns:
            str: The application flow content
        """
        try:
            # Determine the file path based on the product
            file_name = "dtb_account_services_crawl.txt"
            file_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                "static", "productdocs", file_name
            )
            
            logger.info(f"Reading application flow from: {file_path}")
            
            # Check if file exists
            if not os.path.exists(file_path):
                logger.warning(f"Application flow file not found: {file_path}")
                return ""
                
            # Read the file content
            with open(file_path, 'r') as file:
                content = file.read()
                
            logger.info(f"Successfully read application flow file: {len(content)} characters")
            return content
        except Exception as e:
            logger.error(f"Error reading application flow file: {str(e)}")
            return ""

    def generate_testcases(self, scenario_ids, product, usecase_id, batch_size=10, batch_delay=2):
        """
        Generate test cases for a list of scenario IDs using scenarioJson in parallel batches.
        
        Args:
            scenario_ids (list): List of scenario IDs to process.
            product (str): Product name for asset selection.
            usecase_id (int): ID of the usecase for status updates.
            batch_size (int): Number of scenarios to process in parallel.
            batch_delay (int): Delay in seconds between batches.
                
        Returns:
            list: A list of TestCases objects created.
        """
        import concurrent.futures
        
        logger.info(f"Starting test case generation for {len(scenario_ids)} scenarios with batch size {batch_size}")
        testcase_outputs = []
        all_testcase_ids = []  # To collect all test case IDs for test script generation

        def process_scenario(scenario_id, product, usecase_id):
            try:
                # Get scenario information
                db = next(get_db())
                try:
                    logger.debug(f"Retrieving scenario data for ID: {scenario_id}")
                    scenario = (
                        db.query(ScenarioOutput)
                        .filter(ScenarioOutput.scenarioId == scenario_id)
                        .filter(ScenarioOutput.is_deleted == False)
                        .first()
                    )
                    
                    if not scenario:
                        logger.error(f"Scenario not found for ID: {scenario_id}")
                        return None
                    
                    logger.debug(f"Successfully retrieved scenario JSON for ID: {scenario_id}")
                    scenario_json = scenario.outputJson
                    file_id = scenario.fileId
                    
                    # Get the usecase_id from the file_id
                    file = db.query(FileMetadata).filter(FileMetadata.fileId == file_id).first()
                    if not file:
                        logger.error(f"File not found for file ID: {file_id}")
                        return None
                    
                    file_usecase_id = file.usecaseId
                    logger.info(f"Retrieved usecase ID {file_usecase_id} for file ID {file_id}")
                finally:
                    logger.debug("Closing database connection")
                    db.close()
                
                # Get requirement and OCR text
                requirement = str(self.get_requirement_for_scenario_id(scenario_id))
                ocr_text = str(self.get_file_text(scenario_id))
                
                # Prepare query for PF asset
                query = f"""
                Please generate test cases for the following scenario JSON:```Scenario \n\n{scenario_json} ```
                \n\nAbove scenario is associated with the following requirement:```Requirement \n\n{requirement} ```
                \n\n This is the supporting documents shared by user for above scenario and requirement :```Supporting Text \n\n{ocr_text}```
                """
                logger.info(f"Sending scenario ID {scenario_id} to PF asset for test case generation")

                try:
                    # Invoke PF asset
                    logger.debug(f"Invoking PF asset for scenario ID {scenario_id}")
                    self.asset_id = get_asset_id_as_per_config(product, "testcase_generator")
                    logger.info(f"Asset id for generating scenarios is: {self.asset_id}")

                    response, cost, tokens = invoke_asset(self.asset_id, query)
                    logger.info(f"PF asset response received for scenario ID {scenario_id}. Cost: {cost}, Tokens: {tokens}")

                    # Log the raw response for debugging
                    logger.debug(f"Raw response type: {type(response)}")
                    logger.debug(f"Raw response content: {repr(response)[:500]}...")

                    # Process the response based on its type
                    if isinstance(response, dict):
                        logger.debug(f"Response is a dictionary, converting to list")
                        # Check if it's a dictionary with a 'testCases' array
                        if 'testCases' in response and isinstance(response['testCases'], list):
                            logger.debug(f"Found 'testCases' array with {len(response['testCases'])} test cases")
                            parsed_response = response['testCases']
                        else:
                            parsed_response = [response]
                    elif isinstance(response, list):
                        logger.debug(f"Response is already a list with {len(response)} items")
                        parsed_response = response
                    elif isinstance(response, str):
                        logger.debug(f"Response is a string, attempting to parse as JSON")
                        clean_response = response.strip()
                        if clean_response.startswith("") and "" in clean_response[3:]:
                            # start_idx = clean_response.find("\n", 3) + 1
                            # end_idx = clean_response.rfind("```")
                            start_idx = clean_response.rfind("```json") + 7
                            end_idx = clean_response.rfind("```")
                            if start_idx > 0 and end_idx > start_idx:
                                clean_response = clean_response[start_idx:end_idx].strip()
                                logger.debug(f"Extracted JSON content from code block")
                        
                        try:
                            json_data = json.loads(clean_response)
                            # Check if it's a dictionary with a 'testCases' array
                            if isinstance(json_data, dict) and 'testCases' in json_data and isinstance(json_data['testCases'], list):
                                logger.debug(f"Found 'testCases' array with {len(json_data['testCases'])} test cases in JSON string")
                                parsed_response = json_data['testCases']
                            elif not isinstance(json_data, list):
                                logger.debug(f"Parsed JSON is not a list, converting to list")
                                parsed_response = [json_data]
                            else:
                                parsed_response = json_data
                            logger.info(f"Successfully parsed JSON response with {len(parsed_response)} test cases")
                        except json.JSONDecodeError as e:
                            logger.error(f"JSON decoding error for scenario ID {scenario_id}: {str(e)}")
                            logger.error(f"Problematic JSON content: {clean_response[:200]}...")
                            raise ValueError(f"Invalid JSON format received from PF asset: {clean_response[:100]}...")
                    else:
                        logger.error(f"Unexpected response type: {type(response)}")
                        raise ValueError(f"Unexpected response type: {type(response)}")
                    
                    # Create and save test case outputs
                    db = next(get_db())
                    try:
                        # Prepare list for all test case outputs
                        scenario_testcase_outputs = []
                        
                        # For larger batch of test cases, allocate all displayIds at once under the lock
                        # This avoids holding the lock for too long during database operations
                        testcase_count = len(parsed_response)
                        display_ids = []
                        
                        # Allocate all needed displayIds at once (still thread-safe)
                        for i in range(testcase_count):
                            display_id = self.get_next_display_id(file_usecase_id)
                            display_ids.append(display_id)
                            logger.debug(f"Pre-allocated displayId {display_id} for test case {i+1}/{testcase_count}")
                        
                        # Create all test cases with pre-allocated displayIds
                        for i, testcase_json in enumerate(parsed_response):
                            logger.debug(f"Creating TestCase for test case {i+1}/{len(parsed_response)}")
                            
                            # Use the pre-allocated displayId
                            current_display_id = display_ids[i]
                            
                            # Create test case object without saving to database yet
                            testcase_output = TestCases(
                                fileId=file_id,
                                scenarioId=scenario_id,
                                displayId=current_display_id,
                                testJson=testcase_json,
                                isCompleted=True,
                                isTestDataGenerated=False  # Mark as not having test steps yet
                            )
                            scenario_testcase_outputs.append(testcase_output)
                        
                        # Do a final check to ensure no displayId is None
                        for tc in scenario_testcase_outputs:
                            if tc.displayId is None:
                                tc.displayId = self.get_next_display_id(file_usecase_id)
                                logger.warning(f"Found testcase with None displayId before commit. Fixed with value: {tc.displayId}")
                        
                        # Get the application flow content once for all test cases
                        application_flow = self.get_application_flow(product)
                        
                        # Generate test steps for each test case before saving to database
                        for testcase in scenario_testcase_outputs:
                            try:
                                # Prepare query for teststeps generator
                                teststeps_query = f"""
                                Please generate test steps for the following scenario JSON:```Scenario \n\n{scenario_json} ```
                                \n\nAbove scenario is associated with the following test case:```Test Case Name  \n\n {testcase.testJson.get("test case", "Unknown Test Case")} ```
                                \n\n Application Flow: ``` \n\n{application_flow}```
                                """

                                # Invoke teststeps generator asset
                                teststeps_asset_id = get_asset_id_as_per_config(product, "teststeps_generator")
                                teststeps_response, teststeps_cost, teststeps_tokens = invoke_asset(teststeps_asset_id, teststeps_query)
                                logger.info(f"Teststeps generator response received for test case {testcase.displayId}. Cost: {teststeps_cost}, Tokens: {teststeps_tokens}")
                                
                                # Log the raw response for debugging
                                logger.debug(f"Raw teststeps response type: {type(teststeps_response)}")
                                logger.debug(f"Raw teststeps response content: {repr(teststeps_response)[:500]}...")
                                
                                # Process the teststeps response
                                teststeps_added = False
                                if isinstance(teststeps_response, str):
                                    try:
                                        # Try to parse as JSON
                                        teststeps_data = json.loads(teststeps_response)
                                        if isinstance(teststeps_data, dict) and 'testSteps' in teststeps_data:
                                            # Update the testJson with the generated test steps
                                            testcase.testJson['testSteps'] = teststeps_data['testSteps']
                                            teststeps_added = True
                                            logger.info(f"Updated test case {testcase.displayId} with {len(teststeps_data['testSteps'])} test steps")
                                        else:
                                            logger.warning(f"Teststeps response doesn't contain 'testSteps' key: {teststeps_response[:100]}...")
                                    except json.JSONDecodeError:
                                        # If not valid JSON, try to extract from markdown code blocks
                                        clean_response = teststeps_response.strip()
                                        if "```json" in clean_response:
                                            start_idx = clean_response.find("```json") + 7
                                            end_idx = clean_response.rfind("```")
                                            if start_idx > 0 and end_idx > start_idx:
                                                json_str = clean_response[start_idx:end_idx].strip()
                                                try:
                                                    teststeps_data = json.loads(json_str)
                                                    if isinstance(teststeps_data, dict) and 'testSteps' in teststeps_data:
                                                        testcase.testJson['testSteps'] = teststeps_data['testSteps']
                                                        logger.info(f"\n\n **************************************** Test Steps Data: {testcase.testJson['testSteps']}")
                                                        teststeps_added = True
                                                        logger.info(f"Updated test case {testcase.displayId} with {len(teststeps_data['testSteps'])} test steps from code block")
                                                except json.JSONDecodeError:
                                                    logger.error(f"Failed to parse JSON from code block: {json_str[:100]}...")
                                elif isinstance(teststeps_response, dict) and 'testSteps' in teststeps_response:
                                    # Update the testJson with the generated test steps
                                    testcase.testJson['testSteps'] = teststeps_response['testSteps']
                                    teststeps_added = True
                                    logger.info(f"Updated test case {testcase.displayId} with {len(teststeps_response['testSteps'])} test steps")
                                else:
                                    logger.warning(f"Unexpected teststeps response format: {type(teststeps_response)}")
                                
                                # Mark the test case as having test steps generated
                                if teststeps_added:
                                    testcase.isTestDataGenerated = True
                                    logger.info(f"Test case {testcase.displayId} has test steps generated")
                            except Exception as e:
                                logger.error(f"Error generating test steps for test case {testcase.displayId}: {str(e)}")
                                # Continue with the next test case if this one fails
                        
                        # Now save all test cases to the database with test steps already generated
                        for testcase in scenario_testcase_outputs:
                            db.add(testcase)
                        
                        db.commit()
                        logger.info(f"Saved {len(scenario_testcase_outputs)} test cases to database for scenario ID {scenario_id}")

                        # update testcase generation status for the scenario
                        try:
                            scenario = db.query(ScenarioOutput).filter(
                                ScenarioOutput.scenarioId == scenario_id
                            ).first()
                            if scenario:
                                scenario.isTestcasesGenerated = True
                            
                            if usecase_id:
                                usecase = db.query(UsecaseMetadata).filter(
                                    UsecaseMetadata.usecaseId == usecase_id
                                ).first()
                                if usecase:
                                    usecase.test_case_generation = "In Progress"
                            db.commit()
                            logger.info(f"Updated isTestcasesGenerated flag for scenario {scenario_id}")
                        except Exception as db_error:
                            if usecase_id:
                                usecase = db.query(UsecaseMetadata).filter(
                                    UsecaseMetadata.usecaseId == usecase_id
                                ).first()
                                if usecase:
                                    usecase.test_case_generation = "Failed"
                            db.rollback()
                            logger.error(f"Error updating scenario flags: {str(db_error)}")
                        
                        return scenario_testcase_outputs
                
                    except Exception as db_error:
                        db.rollback()
                        logger.error(f"Error saving test cases to database for scenario ID {scenario_id}: {str(db_error)}")
                        raise
                    finally:
                        db.close()

                except (ValueError) as e:
                    logger.error(f"Error processing response for scenario ID {scenario_id}: {str(e)}")
                    
                    # For error scenarios, also use our thread-safe counter
                    db = next(get_db())
                    try:
                        # Get a unique displayId for the error record
                        unique_display_id = self.get_next_display_id(file_usecase_id)
                        
                        testcase_output = TestCases(
                            fileId=file_id,
                            scenarioId=scenario_id,
                            displayId=unique_display_id,
                            testJson={},
                            errorMessage=str(e),
                            isCompleted=False,
                            isTestDataGenerated=False
                        )
                        
                        # Final check for displayId before commit
                        if testcase_output.displayId is None:
                            testcase_output.displayId = self.get_next_display_id(file_usecase_id)
                            logger.warning(f"Final check: Error testcase had None displayId. Set to a new ID for scenario ID {scenario_id}")
                        
                        db.add(testcase_output)
                        db.commit()
                        logger.info(f"Saved error record for scenario ID {scenario_id} with displayId {unique_display_id}")
                        return [testcase_output]
                    except Exception as db_error:
                        db.rollback()
                        logger.error(f"Error saving error record to database: {str(db_error)}")
                    finally:
                        db.close()
                    return None

            except Exception as e:
                # Catch ALL exceptions at the top level of the thread function
                logger.error(f"Unexpected error in process_scenario for scenario ID {scenario_id}: {str(e)}")
                return None

        # Process scenarios in batches using ThreadPoolExecutor
        logger.info(f"Starting parallel processing of {len(scenario_ids)} scenarios in batches of {batch_size}")
        with concurrent.futures.ThreadPoolExecutor(max_workers=batch_size) as executor:
            for batch_start in range(0, len(scenario_ids), batch_size):
                batch = scenario_ids[batch_start:batch_start + batch_size]
                logger.info(f"Processing batch {batch_start//batch_size + 1} with {len(batch)} scenarios")
                
                # Submit batch to executor
                futures = [executor.submit(process_scenario, scenario_id, product, usecase_id) for scenario_id in batch]
                
                # Process results as they complete
                batch_results = []
                for future in concurrent.futures.as_completed(futures):
                    try:
                        result = future.result()
                        if result and isinstance(result, list):
                            batch_results.extend(result)
                            # Extract test case IDs for test script generation
                            testcase_ids = [testcase.testCaseId for testcase in result]
                            all_testcase_ids.extend(testcase_ids)
                    except Exception as e:
                        logger.error(f"Error processing scenario batch result: {str(e)}")
                
                testcase_outputs.extend(batch_results)
                logger.info(f"Batch {batch_start//batch_size + 1} completed. Total test cases so far: {len(testcase_outputs)}")
                
                # Add delay between batches if not the last batch
                if batch_start + batch_size < len(scenario_ids):
                    time.sleep(batch_delay)

        logger.info(f"Completed processing all scenarios, generated {len(testcase_outputs)} total test cases")
        
        # Update usecase status to Completed
        try:
            db = next(get_db())
            try:
                usecase = db.query(UsecaseMetadata).filter(UsecaseMetadata.usecaseId == usecase_id).first()
                if usecase:
                    usecase.test_case_generation = "Completed"
                    db.commit()
                    logger.info(f"Updated usecase {usecase_id} test_case_generation status to 'Completed'")
            finally:
                db.close()
                
            # Start test script generation for all test cases
            logger.info(f"Starting direct test script generation for {len(all_testcase_ids)} test cases")
            
            # Update usecase status for test script generation
            db = next(get_db())
            try:
                usecase = db.query(UsecaseMetadata).filter(
                    UsecaseMetadata.usecaseId == usecase_id
                ).first()
                if usecase:
                    usecase.test_script_generation = "In Progress"
                    db.commit()
                    logger.info(f"Updated usecase {usecase_id} test_script_generation status to 'In Progress'")
            finally:
                db.close()
            
            # Directly call the test script generator
            from services.generator.test_script_generator import TestScriptGenerator
            # script_generator = TestScriptGenerator()
            logger.info(f"Calling TestScriptGenerator directly with {len(all_testcase_ids)} test cases")
            
            # Start the test script generation in a separate thread to avoid blocking
            import threading
            def run_test_script_generation():
                try:
                    # Instead of relying on all_testcase_ids collected during processing,
                    # we'll query the database directly for all test cases associated with this usecase
                    logger.info(f"Fetching test case IDs from database for usecase_id: {usecase_id}")
                    
                    db = next(get_db())
                    try:
                        # First get all files for this usecase
                        files = db.query(FileMetadata).filter(
                            FileMetadata.usecaseId == usecase_id,
                            FileMetadata.is_deleted == False
                        ).all()
                        
                        if not files:
                            logger.warning(f"No files found for usecase ID {usecase_id}")
                            return
                        
                        # Get all test cases for all files in this usecase
                        file_ids = [file.fileId for file in files]
                        test_cases = db.query(TestCases).filter(
                            TestCases.fileId.in_(file_ids),
                            TestCases.isCompleted == True,
                            TestCases.is_deleted == False,
                            TestCases.isTestDataGenerated == True
                        ).all()
                        
                        # Extract the test case IDs
                        testcase_id_strings = [str(tc.testCaseId) for tc in test_cases]
                        
                        logger.info(f"Found {len(testcase_id_strings)} test cases in database for usecase {usecase_id}")
                        logger.info(f"Sample test case IDs: {testcase_id_strings[:5] if len(testcase_id_strings) >= 5 else testcase_id_strings}")
                        
                        if not testcase_id_strings:
                            logger.warning("No test case IDs found in database for script generation")
                            return
                            
                        # Call the test script generator with the database-fetched test case IDs
                        script_generator = TestScriptGenerator()
                        logger.info(f"Calling TestScriptGenerator with {len(testcase_id_strings)} test cases")
                        
                        # Generate test scripts for each test case ID
                        script_results, ts_cost, ts_tokens = script_generator.generate_test_scripts(
                            testcase_id_strings, product, usecase_id
                        )
                        
                        logger.info(f"Test script generation completed with {len(script_results)} scripts generated")
                    finally:
                        db.close()
                        
                    # Update usecase_metadata to mark test_script_generation as "Completed"
                    db = next(get_db())
                    try:
                        usecase = db.query(UsecaseMetadata).filter(
                            UsecaseMetadata.usecaseId == usecase_id
                        ).first()
                        
                        if usecase:
                            usecase.test_script_generation = "Completed"
                            db.commit()
                            logger.info(f"Updated test_script_generation status to 'Completed' for usecase {usecase_id}")
                        else:
                            logger.warning(f"Could not find usecase with ID {usecase_id} to update status")
                    except Exception as db_error:
                        logger.error(f"Error updating usecase status: {str(db_error)}")
                    finally:
                        db.close()
                        
                except Exception as e:
                    logger.error(f"Error in test script generation: {str(e)}")
                    # Include stack trace for better debugging
                    import traceback
                    logger.error(f"Stack trace: {traceback.format_exc()}")
                    
                    # Update usecase status to Failed
                    db = next(get_db())
                    try:
                        usecase = db.query(UsecaseMetadata).filter(UsecaseMetadata.usecaseId == usecase_id).first()
                        if usecase:
                            usecase.test_script_generation = "Failed"
                            db.commit()
                            logger.info(f"Updated usecase {usecase_id} test_script_generation status to 'Failed'")
                    finally:
                        db.close()

            
            # Start the thread for test script generation
            thread = threading.Thread(target=run_test_script_generation)
            thread.daemon = True
            thread.start()
            logger.info(f"Test script generation thread started for usecase {usecase_id}")
                
        except Exception as e:
            logger.error(f"Error updating usecase status or initiating test script generation: {str(e)}")
            db = next(get_db())
            try:
                usecase = db.query(UsecaseMetadata).filter(UsecaseMetadata.usecaseId == usecase_id).first()
                if usecase:
                    usecase.test_case_generation = "Failed"
                    db.commit()
                    logger.info(f"Updated usecase {usecase_id} test_case_generation status to 'Failed' due to error")
            finally:
                db.close()
        
        return testcase_outputs, 0, 0  # Return dummy cost and token values since they're calculated per test case

# Example usage for testing
# def test_testcase_generator():
#     generator = TestCaseGenerator()
#     scenario_ids = ["17b96064-601b-4dd1-a60b-5b039e7c350e", "1fd5cbb6-bc29-4c95-8444-82e4061bfcdf"]
#     testcase_outputs = generator.generate_testcases(scenario_ids)    
#     for output in testcase_outputs:
#         print(f"TestCase: {output}")

# if __name__ == "__main__":
#     logging.basicConfig(
#         level=logging.INFO,
#         format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
#     )
#     test_testcase_generator()