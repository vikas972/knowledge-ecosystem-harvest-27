"""
Example Usage of Requirement Parser with Database Storage

This script demonstrates how to use the RequirementParser to process requirements
and store the results in the database.
"""

import logging
import uuid
import sys
import os
from pathlib import Path

# Add the parent directory to sys.path to allow importing from sibling packages
sys.path.append(str(Path(__file__).parent.parent.parent))

from services.generator.requirement_parser import RequirementParser
from utils.db_utils import get_requirement_by_id, create_dummy_file_metadata

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

def main():
    """
    Main function to demonstrate the usage of RequirementParser with database storage.
    """
    # Initialize the parser
    parser = RequirementParser()
    
    # Sample requirement text
    requirement_text = """
    As a customer, I want to be able to reset my password through email verification,
    so that I can regain access to my account if I forget my password.
    
    Acceptance Criteria:
    1. The login page should have a "Forgot Password" link.
    2. Clicking the link should open a form to enter the registered email.
    3. The system should send a password reset link to the provided email.
    4. The link should be valid for 24 hours.
    5. The user should be able to set a new password after clicking the link.
    6. The system should confirm the password reset with a success message.
    """
    
    # Get a valid file ID (optional - if not provided, the parser will handle it)
    file_id, success = create_dummy_file_metadata()
    if success:
        logger.info(f"Using file ID: {file_id}")
    else:
        logger.warning("Could not create or retrieve a valid file ID. The parser will handle this.")
        file_id = None
    
    # Process the requirement and store in database
    logger.info("Processing requirement and storing in database...")
    response, cost, tokens, requirement_id = parser.process_requirement(
        requirement_text=requirement_text,
        file_id=file_id,
        requirement_name="Password Reset Feature"
    )
    
    # Print the results
    print("\n=== Requirement Processing Results ===")
    print(f"Requirement ID: {requirement_id}")
    print(f"Cost: {cost}")
    print(f"Tokens: {tokens}")
    print(f"Response: {response}")
    
    # Retrieve the requirement from the database
    if requirement_id:
        logger.info(f"Retrieving requirement with ID {requirement_id} from database...")
        requirement = get_requirement_by_id(requirement_id)
        
        if requirement:
            print("\n=== Retrieved from Database ===")
            print(f"Requirement Name: {requirement.requirementName}")
            print(f"File ID: {requirement.fileId}")
            print(f"Is Completed: {requirement.isCompleted}")
            print(f"Error Message: {requirement.errorMessage}")
            print(f"Created At: {requirement.createdAt}")
            
            # Print a portion of the JSON data
            json_data = requirement.requirementJson
            print(f"\nRequirement JSON (first 200 chars): {json_data[:200]}...")
        else:
            print("\nFailed to retrieve requirement from database.")

if __name__ == "__main__":
    main() 