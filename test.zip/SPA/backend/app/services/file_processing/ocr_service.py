from datetime import datetime
import os
import subprocess
import asyncio
from PIL import Image, ImageDraw
import requests
import fitz
from api.v1.endpoints.generator_api.scenario_api import generate_scenarios_by_usecase
from models.use_case.usecase_records import UsecaseMetadata
from services.generator.requirement_parser import process_user_requirement
from services.llm.pf_image2text_automation.asset_invoker import AssetInvoker
from deps import get_db
from models.file_processing.file_record import FileWorkflowTracker
from models.ocr.ocr_records import OCROutputs, OCRInfo
from concurrent.futures import ThreadPoolExecutor
from core.config import HostingConfigs


class OCRPipeline:
    def __init__(self, blob_url, file_id, api_key, username, password, asset_id, num_workers=4, batch_size=10, max_retries=3):
        """
        Initializes the OCRPipeline with the provided parameters.
        Expects an Azure blob storage file link and the file's identifier (for the FileWorkflowTracker table).
        """
        self.blob_url = blob_url
        self.file_id = file_id
        self.num_workers = num_workers
        self.batch_size = batch_size
        self.max_retries = max_retries

        # Instantiate the AssetInvoker for LLM/PF related asset operations.
        self.asset_invoker = AssetInvoker(api_key, username, password, asset_id)

    def download_blob(self, blob_url):
        """
        Downloads a file from the provided Azure blob storage URL and saves it locally.
        
        Returns:
            str: The local file path of the downloaded file.
        """
        local_filename = os.path.basename(blob_url.split('?')[0])
        response = requests.get(blob_url, stream=True)
        if response.status_code != 200:
            raise Exception(f"Failed to download file from {blob_url}: Status code {response.status_code}")
        with open(local_filename, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
        return local_filename
    def docx_to_pdf(self, docx_file_path):
        """
        Converts a DOCX file to PDF using LibreOffice on Linux.
        The PDF is saved in the same directory with the original base name appended by the current datetime.
        
        Returns:
            str: The file path of the saved PDF document.
        """
        if not os.path.isfile(docx_file_path):
            raise FileNotFoundError(f"File not found: {docx_file_path}")

        directory, filename = os.path.split(docx_file_path)
        base_name, _ = os.path.splitext(filename)

        convert_command = [
            "soffice",
            "--headless",
            "--convert-to", "pdf",
            docx_file_path,
            "--outdir", directory
        ]
        subprocess.run(convert_command, check=True)

        generated_pdf_path = os.path.join(directory, f"{base_name}.pdf")
        if not os.path.exists(generated_pdf_path):
            raise FileNotFoundError(f"Converted PDF not found: {generated_pdf_path}")

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        new_pdf_filename = f"{base_name}_{timestamp}.pdf"
        new_pdf_path = os.path.join(directory, new_pdf_filename)

        os.rename(generated_pdf_path, new_pdf_path)

        return new_pdf_path

    def convert_pdf_to_images(self, pdf_file):
        """
        Converts a PDF file into images, one per page. The images are saved in a folder
        named after the PDF file (without its extension) appended with a timestamp.
        
        Args:
            pdf_file (str): Path to the PDF file.
        
        Returns:
            str: The folder path where the page images are saved.
        """
        base_name = os.path.splitext(os.path.basename(pdf_file))[0]
        folder_path = base_name + "_" + datetime.now().strftime('%Y%m%d_%H%M%S')
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        doc = fitz.open(pdf_file)
        print(f"Number of PDF pages: {doc.page_count}")
        for page_number in range(doc.page_count):
            page = doc.load_page(page_number)
            pix = page.get_pixmap()
            mode = "RGBA" if pix.alpha else "RGB"
            img = Image.frombytes(mode, [pix.width, pix.height], pix.samples)
            draw = ImageDraw.Draw(img)
            draw.text((10, 10), f"Page {page_number + 1}", fill="red")
            image_filename = f"{page_number + 1:03d}.png"
            image_filepath = os.path.join(folder_path, image_filename)
            img.save(image_filepath)
        doc.close()
        return folder_path

    async def _process_batch(self, batch, semaphore, status_list, outputs):
        """
        Processes a batch of image file paths using the asset invoker's invoke_asset method with retries.
        Updates the status_list and outputs dictionaries accordingly.
        """
        for attempt in range(self.max_retries):
            for fp in batch:
                status_list[os.path.basename(fp)] = "in-progress"
            async with semaphore:
                try:
                    result = await self.asset_invoker.invoke_asset(batch)
                    db = next(get_db())
                    try:
                        for j, fp in enumerate(batch):
                            image_name = os.path.basename(fp)
                            image_output = result[j] if j < len(result) else ""
                            status_list[image_name] = "success"
                            outputs[image_name] = image_output
                            print(f"Adding to database: page_number: {image_name}")
                            try:
                                page_num = int(os.path.splitext(image_name)[0])
                            except Exception:
                                page_num = 0
                            record = db.query(OCROutputs).filter(
                                OCROutputs.fileId == self.file_id,
                                OCROutputs.pageNumber == page_num
                            ).first()
                            if not record:
                                record = OCROutputs(
                                    fileId=self.file_id,
                                    pageNumber=page_num,
                                    pageText=image_output,
                                    isCompleted=True
                                )
                                db.add(record)
                            else:
                                record.pageText = image_output
                                record.errorMsg = None
                                record.isCompleted = True
                        db.commit()
                    finally:
                        db.close()
                    return
                except asyncio.TimeoutError:
                    print(f"Batch {[os.path.basename(fp) for fp in batch]} timed out after 60 seconds. Marking as error.")
                    db = next(get_db())
                    try:
                        for fp in batch:
                            image_name = os.path.basename(fp)
                            status_list[image_name] = "error"
                            print(f"Adding to database: page_number: {image_name}")
                            try:
                                page_num = int(os.path.splitext(image_name)[0])
                            except Exception:
                                page_num = 0
                            record = db.query(OCROutputs).filter(
                                OCROutputs.fileId == self.file_id,
                                OCROutputs.pageNumber == page_num
                            ).first()
                            if not record:
                                record = OCROutputs(
                                    fileId=self.file_id,
                                    pageNumber=page_num,
                                    pageText="",
                                    errorMsg="Timeout occurred during asset invocation",
                                    isCompleted=False
                                )
                                db.add(record)
                            else:
                                record.pageText = ""
                                record.errorMsg = "Timeout occurred during asset invocation"
                                record.isCompleted = False
                        db.commit()
                    except Exception as db_error:
                        db.rollback()
                        print(f"Database error: {db_error}")
                    finally:
                        db.close()
                    return
                except Exception as e:
                    print(f"Error processing batch {[os.path.basename(fp) for fp in batch]} on attempt {attempt + 1}/{self.max_retries}: {e}. Retrying...")
            await asyncio.sleep(1)
        
        db = next(get_db())
        try:
            for fp in batch:
                image_name = os.path.basename(fp)
                status_list[image_name] = "error"
                print(f"Page: {image_name} - Status: {status_list[image_name]}")
                try:
                    page_num = int(os.path.splitext(image_name)[0])
                except Exception:
                    page_num = 0
                record = db.query(OCROutputs).filter(
                    OCROutputs.fileId == self.file_id,
                    OCROutputs.pageNumber == page_num
                ).first()
                if not record:
                    record = OCROutputs(
                        fileId=self.file_id,
                        pageNumber=page_num,
                        pageText="",
                        errorMsg="Processing failed after maximum retries",
                        isCompleted=False
                    )
                    db.add(record)
                else:
                    record.pageText = ""
                    record.errorMsg = "Processing failed after maximum retries"
                    record.isCompleted = False
            db.commit()
        except Exception as db_error:
            db.rollback()
            print(f"Database error: {db_error}")
        finally:
            db.close()

    async def _display_statuses(self, status_list):
        """
        Continuously displays the current statuses of image processing.
        """
        while True:
            pending = sum(1 for s in status_list.values() if s == "pending")
            in_progress = sum(1 for s in status_list.values() if s == "in-progress")
            success = sum(1 for s in status_list.values() if s == "success")
            error = sum(1 for s in status_list.values() if s == "error")
            print(f"Pending: {pending}, In-progress: {in_progress}, Success: {success}, Error: {error}")
            await asyncio.sleep(1)

    async def generate_final_info(self, folder_path):
        """
        Asynchronously processes the images in the specified folder in batches.
        Divides the images into batches, processes each batch with retries, and
        maintains a status and output for each image.
        
        Returns:
            tuple: (image_names, outputs, status_list)
                image_names: List of image file names in sorted order.
                outputs: Dictionary mapping image names to their invoke_asset output.
                status_list: Dictionary mapping image names to their current status.
        """
        image_files = sorted(os.listdir(folder_path))
        image_file_paths = [os.path.join(folder_path, f) for f in image_files if os.path.isfile(os.path.join(folder_path, f))]
        image_names = [os.path.basename(fp) for fp in image_file_paths]

        status_list = {name: "pending" for name in image_names}
        outputs = {name: "" for name in image_names}

        batches_dict = {}
        for i in range(0, len(image_file_paths), self.batch_size):
            batch_key = i // self.batch_size
            batches_dict[batch_key] = image_file_paths[i:i + self.batch_size]

        semaphore = asyncio.Semaphore(self.num_workers)
        display_task = asyncio.create_task(self._display_statuses(status_list))
        tasks = [asyncio.create_task(self._process_batch(batch, semaphore, status_list, outputs))
                 for batch in batches_dict.values()]
        for task in tasks:
            await task
        display_task.cancel()
        try:
            await display_task
        except asyncio.CancelledError:
            pass
        return image_names, outputs, status_list

    async def _run_pipeline_async(self):
        """
        Asynchronously executes the pipeline:
          1. Downloads the file from Azure blob storage.
          2. Checks if the file is a DOCX or PDF.
             - If DOCX, converts the file to PDF.
             - If PDF, proceeds directly.
          3. Converts the PDF into images (one per page).
          4. Divides the images into batches and invokes asset processing.
          5. Waits for process completion and returns the outputs.
        
        Returns:
            list: A list of dictionaries containing image name, status, and output.
        """
        local_file = self.download_blob(self.blob_url)
        pdf_path = None
        try:
            if local_file.lower().endswith('.docx'):
                pdf_path = self.docx_to_pdf(local_file)
                os.remove(local_file)  # Remove the DOCX file after conversion
            elif local_file.lower().endswith('.pdf'):
                pdf_path = local_file
            else:
                raise ValueError("Unsupported file type. Only DOCX and PDF are supported.")

            image_folder = self.convert_pdf_to_images(pdf_path)
            image_names, outputs, status_list = await self.generate_final_info(image_folder)
            images_info = []
            for name in image_names:
                images_info.append({
                    "image_name": name,
                    "status": status_list.get(name, "pending"),
                    "output": outputs.get(name, "")
                })

            # Update summary OCR record in OCRInfo once all assets have been invoked
            total_pages = len(image_names)
            completed_pages = sum(1 for s in status_list.values() if s == "success")
            error_pages = sum(1 for s in status_list.values() if s == "error")
            db = next(get_db())
            try:
                ocr_info = db.query(OCRInfo).filter(OCRInfo.fileId == self.file_id).first()
                if not ocr_info:
                    ocr_info = OCRInfo(
                        fileId=self.file_id,
                        totalPages=total_pages,
                        completedPages=completed_pages,
                        errorPages=error_pages
                    )
                    db.add(ocr_info)
                else:
                    ocr_info.totalPages = total_pages
                    ocr_info.completedPages = completed_pages
                    ocr_info.errorPages = error_pages
                db.commit()
            except Exception as db_error:
                db.rollback()
                print(f"Database error updating OCRInfo: {db_error}")
            finally:
                db.close()

            # Clean up temporary files and folders
            if pdf_path:
                os.remove(pdf_path)
            if image_folder and os.path.exists(image_folder):
                for file in os.listdir(image_folder):
                    os.remove(os.path.join(image_folder, file))
                os.rmdir(image_folder)

            return images_info
        except Exception as e:
            # Clean up in case of error
            if local_file and os.path.exists(local_file):
                os.remove(local_file)
            if pdf_path and os.path.exists(pdf_path):
                os.remove(pdf_path)
            if image_folder and os.path.exists(image_folder):
                for file in os.listdir(image_folder):
                    os.remove(os.path.join(image_folder, file))
                os.rmdir(image_folder)
            raise e    
    
    def run(self):
        """
        Runs the OCR pipeline, updates the file workflow tracker, and returns the processed images information.
        """
        from datetime import datetime
        try:
            # Insert initial tracker record with text_extraction set to "Not Started"
            db = next(get_db())
            try:
                tracker = FileWorkflowTracker(
                    fileId=self.file_id,
                    text_extraction="Not Started",
                )
                db.add(tracker)
                db.commit()
            except Exception as e:
                db.rollback()
                print(f"Error creating tracker: {e}")
                raise e
            finally:
                db.close()

            # Update tracker to set text_extraction to "In Progress"
            db = next(get_db())
            try:
                tracker = db.query(FileWorkflowTracker).filter(FileWorkflowTracker.fileId == self.file_id).first()
                if tracker:
                    tracker.text_extraction = "In Progress"
                db.commit()
            except Exception as e:
                db.rollback()
                print(f"Error updating tracker to In Progress: {e}")
                raise e
            finally:
                db.close()

            # Get the current event loop if possible, or create a new one
            try:
                loop = asyncio.get_event_loop()
            except RuntimeError:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
            
            # Run the pipeline with the current event loop
            images_info = loop.run_until_complete(self._run_pipeline_async())

            # Update tracker record to mark completion on success by setting text_extraction to "Completed"
            db = next(get_db())
            try:
                tracker = db.query(FileWorkflowTracker).filter(FileWorkflowTracker.fileId == self.file_id).first()
                if tracker:
                    tracker.text_extraction = "Completed"
                db.commit()
            except Exception as e:
                db.rollback()
                print(f"Error updating tracker to Completed: {e}")
                raise e
            finally:
                db.close()
            
            return images_info
        except Exception as e:
            # Update tracker record with error details
            db = next(get_db())
            try:
                tracker = db.query(FileWorkflowTracker).filter(FileWorkflowTracker.fileId == self.file_id).first()
                if tracker:
                    tracker.errorMsg = str(e)
                db.commit()
            except Exception as db_error:
                db.rollback()
                print(f"Error updating tracker with error message: {db_error}")
            finally:
                db.close()
            raise e
def run_parallel_ocr(batch, api_key, username, password, asset_id, num_workers, batch_size, max_retries):
    """
    Runs OCR processing on a batch of files in parallel.
    
    Args:
        batch: List of tuples containing (blob_url, file_id)
        api_key: API key for the PF service
        username: Username for the PF service
        password: Password for the PF service
        asset_id: Asset ID for the PF service
        num_workers: Number of parallel workers
        batch_size: Size of each OCR batch
        max_retries: Maximum number of retries for OCR processing
        
    Returns:
        List of processing results for each file
    """
    def process_single_file(file_data):
        blob_url, file_id = file_data
        try:
            # Create a new event loop for this thread
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            pipeline_instance = OCRPipeline(
                blob_url=blob_url,
                file_id=file_id,
                api_key=api_key,
                username=username,
                password=password,
                asset_id=asset_id,
                num_workers=num_workers,
                batch_size=batch_size,
                max_retries=max_retries
            )
            
            # Run the pipeline without using asyncio.run() since we already set up our event loop
            try:
                result = loop.run_until_complete(pipeline_instance._run_pipeline_async())
                return result
            finally:
                # Close the loop when done
                loop.close()
        except Exception as e:
            print(f"Error processing file {file_id}: {str(e)}")
            return None
    
    with ThreadPoolExecutor(max_workers=len(batch)) as executor:
        results = list(executor.map(process_single_file, batch))
    print(f"OCR processing complete for current batch. Results: {results}")
    return results

def run_all_ocr_batches(usecase_id, ocr_data, batch_size, api_key, username, password, asset_id, num_workers, ocr_batch_size, max_retries):   
    """
    Process OCR data in batches sequentially until all files are processed.
    
    Args:
        ocr_data: List of tuples containing (blob_url, file_id)
        batch_size: Size of each batch to process
        api_key: API key for the PF service
        username: Username for the PF service
        password: Password for the PF service
        asset_id: Asset ID for the PF service
        num_workers: Number of parallel workers
        ocr_batch_size: Size of OCR batches
        max_retries: Maximum number of retries for OCR processing
        
    Returns:
        None
    """
    try:
        # Update status to In Progress
        db = next(get_db())
        usecase = db.query(UsecaseMetadata).filter(UsecaseMetadata.usecaseId == usecase_id).first()
        if usecase:
            usecase.text_extraction = "In Progress"
            db.commit()
   
        total_files = len(ocr_data)
        for i in range(0, total_files, batch_size):
            current_batch = ocr_data[i:i + batch_size]
            run_parallel_ocr(current_batch, api_key, username, password, asset_id, num_workers, ocr_batch_size, max_retries)
        
        # Update status to Completed after successful processing
        db = next(get_db())
        usecase = db.query(UsecaseMetadata).filter(UsecaseMetadata.usecaseId == usecase_id).first()
        if usecase:
            usecase.text_extraction = "Completed"
            db.commit()
    
        # Send POST request to generate test scenarios for the given usecase ID
        try:
            response = requests.post(
                f"{HostingConfigs.URL}/requirements/generate-by-usecaseid/{usecase_id}",
                headers={"Content-Type": "application/json"}
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Error generating requirements for usecase {usecase_id}: {str(e)}")
            return None
    except Exception as e:
        raise e