from azure.storage.blob import BlobServiceClient
from core.config import AzureBlobStorageConfigs

def upload_file_to_blob(file):
    try:
        blob_service_client = BlobServiceClient.from_connection_string(AzureBlobStorageConfigs.CONNECTION_STRING)
        container_client = blob_service_client.get_container_client(AzureBlobStorageConfigs.CONTAINER_NAME)
        blob_client = container_client.get_blob_client(file.filename)
        
        file_content = file.file.read()
        blob_client.upload_blob(file_content, overwrite=True)
        url = blob_client.url
        return True, f"File '{file.filename}' uploaded successfully to blob storage.", url
    except Exception as e:
        return False, f"Error uploading file to blob: {e}", None