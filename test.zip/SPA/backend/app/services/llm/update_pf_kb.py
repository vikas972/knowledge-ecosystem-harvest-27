import requests
import time
import json
import logging
import sys
import os
import argparse

# Add the parent directory to the Python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../')))
from app.core.config import KnowledgeBaseConfigs

logger = logging.getLogger(__name__)



class KBDocumentProcessor:
    def __init__(self, base_url, api_key, username, password):
        self.base_url = base_url
        self.api_key = api_key
        self.username = username
        self.password = password
        self.token = None
        self.doc_id = None
        self.run_id = None

    def get_token(self):
        """Step 1: Get authentication token"""
        headers = {
            'apikey': self.api_key,
            'username': self.username,
            'password': self.password
        }
        response = requests.get(
            f"{self.base_url}/accesstoken/idxpigtb",
            headers=headers
        )
        
        self.token = response.json()['access_token']
        return self.token

    def upload_document(self, file_path, doc_lib, file_name):
        """Step 2: Upload document to document library"""
        headers = {
            'accept': 'application/json',
            'apikey': self.api_key,
            'Authorization': f'Bearer {self.token}'
        }
        files = {
            'files': (file_name, open(file_path, 'rb'), 'application/pdf')
        }
        response = requests.post(
            f"{self.base_url}/magicplatform/v1/document-library/dataset/{doc_lib}/folder/root/documents",
            headers=headers,
            files=files
        )
        self.doc_id = response.json()['data'][0]['doc_id']
        
        return self.doc_id

    def add_metadata(self, doc_lib):
        """Step 3: Add metadata to the document"""
        headers = {
            'accept': 'application/json, text/plain, */*',
            'apikey': self.api_key,
            'Authorization': f'Bearer {self.token}',
            'Content-Type': 'application/json',
            'pragma': 'no-cache',
            'origin': 'https://magicplatform.intellectseecstag.com'
        }
        payload = {
            "metadata": {
                "dept": ["fin"],
                "id": ["ed"]
            },
            "doc_id": [self.doc_id],
            "folder_id": []
        }
        response = requests.put(
            f"{self.base_url}/magicplatform/v1/document-library/metadata/documents/{doc_lib}",
            headers=headers,
            json=payload
        )
        return response.json()

    def get_run_id(self, kb_id):
        """Step 4: Get run ID for chunking"""
        headers = {
            'apikey': self.api_key,
            'Authorization': f'Bearer {self.token}',
            'Content-Type': 'application/json'
        }
        query = """
        mutation {
            createAssetRun(asset_version_id: "%s", run_type:CHUNKING)  {
                asset_run_id
                run_type
                run_no
                status
            }
        }
        """ % kb_id
        response = requests.post(
            f"{self.base_url}/magicplatform/v1/assets",
            headers=headers,
            json={'query': query}
        )
        
        self.run_id = response.json()['data']['createAssetRun']['asset_run_id']
        return self.run_id

    def import_to_kb(self, doc_lib, kb_id):
        """Step 5: Import document to knowledge base"""
        headers = {
            'accept': 'application/json, text/plain, */*',
            'apikey': self.api_key,
            'Authorization': f'Bearer {self.token}',
            'Content-Type': 'application/json',
            'cache-control': 'no-cache',
            'pragma': 'no-cache',
            'origin': 'https://magicplatform.intellectseecstag.com',
            'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'
        }
        
        payload = {
            "dataset_id": doc_lib,
            "doc_id": self.doc_id,
            "folder_id": "",
            "run_id": self.run_id,
            "run_type": "CHUNKING",
            "asset_type": "KNOWLEDGEBASE",
            "annotation_summary_required": "true",
            "old_asset_version_id": ""
        }
        response = requests.post(
            f"{self.base_url}/magicplatform/v1/document-library/dataset/asset/{kb_id}/document/draft",
            headers=headers,
            json=payload
        )
        return response.json()

    def start_chunking(self, kb_id):
        """Step 6: Start chunking process"""
        headers = {
            'accept': 'application/json',
            'apikey': self.api_key,
            'Authorization': f'Bearer {self.token}'
        }
        response = requests.post(
            f"{self.base_url}/magicplatform/v1/chunk/initialize/{kb_id}?asset_run_id={self.run_id}",
            headers=headers
        )
        return response.json()

    def check_chunking_status(self, kb_id):
        """Step 7: Check chunking status"""
        headers = {
            'accept': 'application/json',
            'apikey': self.api_key,
            'Authorization': f'Bearer {self.token}'
        }
        response = requests.get(
            f"{self.base_url}/magicplatform/v1/chunk/progress/status/{kb_id}",
            headers=headers
        )
        return response.json()

    def wait_for_completion(self, kb_id, timeout=300):
        """Wait for both chunking and embedding to complete"""
        start_time = time.time()
        while time.time() - start_time < timeout:
            status = self.check_chunking_status(kb_id)
            
            chunk_status = status.get('chunk', {}).get('status')
            embedding_status = status.get('embedding', {}).get('status')
            
            if chunk_status == 'FAILED' or embedding_status == 'FAILED':
                raise Exception("Processing failed. Check the KB platform for details.")
            
            if chunk_status == 'COMPLETED' and embedding_status == 'COMPLETED':
                return True
                
            time.sleep(60)
        
        raise TimeoutError(f"Process did not complete within {timeout} seconds")

def main():
    
    # Set the values for below variables as per your assets
    BASE_URL = KnowledgeBaseConfigs.BASE_URL #this is staging url
    API_KEY =  KnowledgeBaseConfigs.API_KEY # your api key from staging
    USERNAME = KnowledgeBaseConfigs.USERNAME # username
    PASSWORD = KnowledgeBaseConfigs.PASSWORD # password
    DOC_LIB = KnowledgeBaseConfigs.DOC_LIB # document library id
    KB_ID = KnowledgeBaseConfigs.KB_ID # knowledge base id
    FILE_PATH = KnowledgeBaseConfigs.DEFAULT_FILE_PATH # local system file path
    file_name = KnowledgeBaseConfigs.DEFAULT_FILE_NAME # file name

    # Initialize processor
    processor = KBDocumentProcessor(BASE_URL, API_KEY, USERNAME, PASSWORD)

    try:
        print("\n=== Starting KB Document Update Process ===")
        
        print("\n1. Authenticating...")
        processor.get_token()
        print("✓ Authentication successful")

        print("\n2. Uploading document...")
        doc_id = processor.upload_document(FILE_PATH, DOC_LIB, file_name)
        print(f"✓ Document uploaded successfully (ID: {doc_id})")

        print("\n3. Adding metadata...")
        processor.add_metadata(DOC_LIB)
        print("✓ Metadata added successfully")

        print("\n4. Initializing processing...")
        run_id = processor.get_run_id(KB_ID)
        print(f"✓ Process initialized (Run ID: {run_id})")
        time.sleep(60)

        print("\n5. Importing to knowledge base...")
        import_response = processor.import_to_kb(DOC_LIB, KB_ID)
        if import_response.get('api_status') != 'SUCCESS':
            raise Exception("Failed to import to knowledge base")
        print("✓ Document imported to knowledge base")
        time.sleep(60)

        print("\n6. Starting document processing...")
        processor.start_chunking(KB_ID)
        print("✓ Processing started")

        print("\n7. Waiting for processing to complete...")
        processor.wait_for_completion(KB_ID)
        print("✓ Document processing completed successfully")

        print("\n=== Document Successfully Updated in Knowledge Base ===")
        print(f"Document ID: {doc_id}")
        print(f"Run ID: {run_id}")
        print("\nYou can now access this document in your knowledge base.")

    except requests.exceptions.RequestException as e:
        print("\n❌ ERROR: Network or API Error")
        print(f"Details: {str(e)}")
        print("\nPlease check your internet connection and API endpoint availability.")
    
    except TimeoutError as e:
        print("\n❌ ERROR: Process Timeout")
        print(f"Details: {str(e)}")
        print("\nThe process took longer than expected. Please check the KB platform for status.")
    
    except Exception as e:
        print("\n❌ ERROR: Process Failed")
        print(f"Details: {str(e)}")
        print("\nPlease verify your configurations and try again.")
    
    finally:
        print("\n=== Process Completed ===")

if __name__ == "__main__":
    main()