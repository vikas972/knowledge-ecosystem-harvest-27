"""
This file is the common module to invoke Conversation Asset of PF.

PF is a Gen AI framework used to get LLM responses.
"""

import requests as req
import time
import os
import logging
import sys

# Add the parent directory to the Python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../')))
from app.core.config import settings

# Configure logger with console handler if not already configured
logger = logging.getLogger(__name__)
if not logger.handlers:
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    logger.setLevel(logging.INFO)

# Load configurable values from settings
api_key = settings.API_KEY
asset_id = settings.ASSET_ID
pf_username = settings.PF_USERNAME
pf_password = settings.PF_PASSWORD

# API endpoints from settings
PF_ACCESS_TOKEN_URL = settings.PF_ACCESS_TOKEN_URL
PF_CREATE_CONVERSATION_URL = settings.PF_CREATE_CONVERSATION_URL
PF_ADD_MESSAGE_URL = settings.PF_ADD_MESSAGE_URL
PF_GET_RESPONSE_BASE_URL = settings.PF_GET_RESPONSE_BASE_URL


headers_QA = {
    'apikey': api_key,
    'username': pf_username,
    'password': pf_password
}

# Define a dictionary to store asset IDs
# asset_ids = {
#     "scenario_generator": "51e6b021-544a-4de7-a4bf-dc3dee5ef214",#"8b22d431-fc67-437c-b69d-a47574ec010e" #note:commendted id is RAG latest asset
#     "testcase_generator": "87ea1342-aaed-48e1-951d-1d30484d2212" #"3eb21dc8-af75-4ab6-bcb7-251da7bd91cc" #note:commendted id is RAG latest asset
# }


asset_ids_as_per_config = {
    "DTB": {
        "scenario_generator": "dc4f3e58-78fa-4f4a-bcab-c57f8579d672", #"bb2aac02-2849-44da-b7ac-450bf64600ce",#"8b22d431-fc67-437c-b69d-a47574ec010e",
        "testcase_generator": "a4b8196f-4b21-46bf-b4b0-b0f97743af95",
        "teststeps_generator" : "72ce23a7-dda3-47d3-9af9-30da617e89e7",
        "test_scripts_generator": "9c4a3464-f9fe-4e53-8741-7c2235fb2daa"}, # Dummy asset ID - replace with the actual ID
    "Paycash CX":{
            "scenario_generator": "6b637d32-e03e-49ed-9d45-31f8a3903fe6",
            "testcase_generator": "e711302e-cc8f-4e6a-b493-2bb8a5caeb4d", #"c02cebfa-6f6d-4b8a-a151-1df1893d9881"
            "teststeps_generator" : "72ce23a7-dda3-47d3-9af9-30da617e89e7",
            "test_scripts_generator": "9c4a3464-f9fe-4e53-8741-7c2235fb2daa"}, # Dummy asset ID - replace with the actual ID
    "CTX":{
            "scenario_generator": "6b637d32-e03e-49ed-9d45-31f8a3903fe6",
            "testcase_generator": "e711302e-cc8f-4e6a-b493-2bb8a5caeb4d", #"c02cebfa-6f6d-4b8a-a151-1df1893d9881"
            "teststeps_generator" : "72ce23a7-dda3-47d3-9af9-30da617e89e7",
            "test_scripts_generator": "9c4a3464-f9fe-4e53-8741-7c2235fb2daa"}, # Dummy asset ID - replace with the actual ID
    "iColumbus":{
            "scenario_generator": "6b637d32-e03e-49ed-9d45-31f8a3903fe6",
            "testcase_generator": "e711302e-cc8f-4e6a-b493-2bb8a5caeb4d", #"c02cebfa-6f6d-4b8a-a151-1df1893d9881"
            "teststeps_generator" : "72ce23a7-dda3-47d3-9af9-30da617e89e7",
            "test_scripts_generator": "9c4a3464-f9fe-4e53-8741-7c2235fb2daa"} # Dummy asset ID - replace with the actual ID
}

def get_asset_id(asset_name):
    """
    Retrieve the asset ID for a given asset name.

    Args:
        asset_name (str): The name of the asset.

    Returns:
        str: The asset ID associated with the given name.
    """
    return asset_ids.get(asset_name, "")


def get_asset_id_as_per_config(product, asset_name):
    """
    Retrieve the asset ID for a given product details.

    Args:
        asset_name (str): The name of the asset.

    Returns:
        str: The asset ID associated with the given name.
    """
    try:
        logger.info(f"Getting asset_id for product:{product} and asset_name:{asset_name}")
        logger.info(f"asset_ids_as_per_config: {asset_ids_as_per_config[product][asset_name]}")
        return asset_ids_as_per_config[product][asset_name]
    except Exception as e:
        logger.error(f"Error in getting asset_id for Scenario generation: {e}")


def get_access_token(headers):
    """
    Retrieve an access token using the provided headers.

    Args:
        headers (dict): The headers containing authentication details.

    Returns:
        str: The access token or an empty string if the token retrieval fails.
    """
    value = ""
    res = req.get(PF_ACCESS_TOKEN_URL, headers=headers)
    if res.status_code == 200:
        data = res.json()
        value = data['access_token']
    else:
        logger.error(f"Unable to create Access token. Status code: {res.status_code}")
        logger.error(f"Response: {res.text}")
    return value



def create_chat(asset_headers, payload):
    """
    Create a new chat conversation.

    Args:
        asset_headers (dict): The headers for the API request.
        payload (dict): The payload containing the conversation details.

    Returns:
        str: The conversation ID of the created chat.
    """
    logger.info(f"Creating chat with payload: {payload}")
    response = req.post(
        PF_CREATE_CONVERSATION_URL,
        headers=asset_headers, json=payload)
    logger.info(f"Response from PF: {response.status_code}")
    conversation_id = response.json()['conversation_details']['conversation_id']
    return conversation_id


def asset_post(asset_headers, asset_payload):
    """
    Post a message to an existing chat conversation.

    Args:
        asset_headers (dict): The headers for the API request.
        asset_payload (dict): The payload containing the message details.

    Returns:
        str: The message ID of the posted message.
    """
    asset_post = req.post(
        PF_ADD_MESSAGE_URL,
        headers=asset_headers, json=asset_payload)
    
    message_id = asset_post.json()['message_id']
    return message_id


def get_response(asset_headers, conversation_id, message_id):
    """
    Retrieve the response for a posted message in a chat conversation.

    Args:
        asset_headers (dict): The headers for the API request.
        conversation_id (str): The conversation ID.
        message_id (str): The message ID.

    Returns:
        tuple: A tuple containing the response text and the total cost of the response.
    """
    retry_count = 0
    
    while True:
        time.sleep(5)
        try:
            response = req.get(
                f"{PF_GET_RESPONSE_BASE_URL}/{conversation_id}/{message_id}",
                headers=asset_headers)
        except Exception as e:
            access_token = get_access_token(headers_QA)
            asset_headers = {
                'Content-Type': 'application/json',
                'apikey': api_key,
                'Authorization': 'Bearer ' + access_token,
            }
        try:
            response_ = response.json()
            if response_['error_code'] == "GenaiBaseException":
                logger.info(f"PF Error: Failed with {response_['error_description']}")
                raise Exception(response_['error_description'])
        except:
            pass

        try:  
            res = response.json()['message_content'][0]['response']
            cost = response.json()['message_content'][0]['metrics']['total_cost']
            tokens = response.json()['message_content'][0]['metrics']['total_tokens']
            return res, cost, tokens
            
        except Exception as e:            
            logger.info("Waiting for response from PF...")
            time.sleep(4)
    

def invoke_asset(asset_id_param=None, query=None):
    """
    Invoke a conversation asset with the given query and retrieve the response.

    Args:
        asset_id_param (str, optional): The asset ID to be invoked. Defaults to the one from settings.
        query (str): The query to be sent to the asset.

    Returns:
        tuple: A tuple containing the response text and the total cost of the response.
    """
    # Use provided asset_id or fall back to the one from settings
    used_asset_id = asset_id_param if asset_id_param else asset_id
    
    start_time = time.time()
    logger.info(f"Invoking asset with ID: {used_asset_id}")
    # logger.info(f"Query: {query}")
    
    # Get fresh access token
    access_token = get_access_token(headers_QA)
    
    asset_headers = {
        'Content-Type': 'application/json',
        'apikey': api_key,
        'Authorization': 'Bearer ' + access_token,
    }

    # Create conversation
    create_payload = {"conversation_name": "spa_ea", "asset_version_id": used_asset_id, "mode": "EXPERIMENT"}
    conversation_id = create_chat(asset_headers, create_payload)
    
    if not conversation_id:
        return "Error: Failed to create conversation", 0, 0
        
    logger.info(f"Conversation created with ID: {conversation_id}")

    # Invoke asset
    asset_payload = {"conversation_id": conversation_id, "query": query, "KB_Types": []}
    message_id = asset_post(asset_headers, asset_payload)
    
    if not message_id:
        return "Error: Failed to post message", 0, 0
        
    logger.info(f"Message posted with ID: {message_id}")

    # Get response
    output = get_response(asset_headers, conversation_id, message_id)
    
    total_time = time.time() - start_time
    logger.info(f"Total PF request completed in {total_time:.2f} seconds")
    
    return output


# if __name__ == "__main__":
#     # Example usage when script is run directly
#     test_asset_id = "531cbf1b-5969-4651-8314-bff3fc2c39f1"
#     test_query = "What is the count of failed instructions?"
    
#     # Configure logging
#     logging.basicConfig(level=logging.INFO, 
#                         format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
#     print("Invoking asset...")
#     response, cost, tokens = invoke_asset(test_asset_id, test_query)
#     print(f"\nResponse: {response}")
#     print(f"Cost: {cost}")
#     print(f"Tokens: {tokens}")