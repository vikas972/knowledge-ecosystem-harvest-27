from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

#uncomment_below_if you want to use alembic
# from app.models.user import User