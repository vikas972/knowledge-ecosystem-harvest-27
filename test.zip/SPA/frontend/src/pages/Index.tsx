import { useState, useRef, useEffect } from "react";
import { Header } from "@/components/Header";
import { WizardSteps } from "@/components/WizardSteps";
import { SourceSelection } from "@/components/steps/SourceSelection";
import { RequirementsCaptured } from "@/components/steps/RequirementsCaptured";
import { ScenarioGeneration } from "@/components/steps/ScenarioGeneration";
import { TestCases } from "@/components/steps/TestCases";
import { TestData } from "@/components/steps/TestData";
import { TestScripts } from "@/components/steps/TestScripts";
import { Metrics } from "@/components/steps/Metrics";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import axios from "axios";
import { ENV } from "@/config/env";

const STEPS = [
  "Source Selection",
  "Requirements Captured",
  "Scenario Generation",
  "Test Cases",
  // "Test Data",
  "Test Scripts",
  "Metrics & Export",
];

interface SelectedFile {
  id: string;
  name: string;
  uploadTime: Date;
}
interface UserAssociationInfo {
  product: string;
  sub_product: string;
  domain: string;
}

const Index = () => {
  const [currentStep, setCurrentStep] = useState(0);
  // const [currentStep, setCurrentStep] = useState(1);

  const [selectedFile, setSelectedFile] = useState<SelectedFile | null>(null);
    
  // Add a mock selected file
  // const [selectedFile, setSelectedFile] = useState<SelectedFile | null>({
  //   id: "mock-file-1",
  //   name: "requirements-doc.pdf",
  //   uploadTime: new Date()
  // });
 
  // const [usecaseId, setUsecaseId] = useState<number>(1); // Use an ID that exists in your database

  const [usecaseId, setUsecaseId] = useState<string | null>(null);
  const [requirementIds, setRequirementIds] = useState<string[]>([]);

  const [isUploading, setIsUploading] = useState(false);
  const sourceSelectionRef = useRef<{
    isBundleSelected(): false; 
    uploadFiles: () => Promise<{ success: boolean; usecaseId: string | null }>;
    getUserAssociations: () => UserAssociationInfo;
    areFilesSubmitted: () => boolean;
  }>(null);

  const [checkingStatus, setCheckingStatus] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Add state variables to store the user association data
  const [userProduct, setUserProduct] = useState<string>("");
  const [userSub_product, setUserSub_product] = useState<string>("");
  const [userDomain, setUserDomain] = useState<string>("");

  // Add this state variable after the other user association states
  const [bundleName, setBundleName] = useState<string>("");

  // Add near your other state variables
  const [selectedBundleType, setSelectedBundleType] = useState<"new" | "existing" | null>(null);

  const handleNextClick = async () => {
    if (currentStep === 0) {
      // validation for bundle selection at the beginning
      if (!selectedBundleType) {
        toast.error("Please create a new bundle or select from existing before proceeding", {
          duration: 1000
        });
        return;
      }
      
      // Check if we have a usecaseId when using existing bundle
      if (selectedBundleType === "existing" && !usecaseId) {
        toast.error("Please select an existing bundle before proceeding", {
          duration: 1000
        });
        return;
      }
      
      // Check if the bundle is actually selected in the UI
      if (sourceSelectionRef.current && !sourceSelectionRef.current.isBundleSelected()) {
        toast.error("Please select a bundle before proceeding", {
          duration: 1000
        });
        return;
      }
      
      // If using an existing bundle, we can directly proceed
      if (selectedBundleType === "existing" && usecaseId) {
        try {
          // Check if requirements are already generated for this bundle
          const statusResponse = await axios.get(
            `${ENV.API_URL}/usecase-management/get-usecase-status/${usecaseId}`
          );
          
          if (statusResponse.data.requirement_generation === "Completed" || statusResponse.data.requirement_generation === "In Progress") {
            // Directly proceed to the next step
            setCurrentStep((prev) => Math.min(STEPS.length - 1, prev + 1));
            return;
          } else {
            // Add this else block to provide feedback
            toast.error("Requirements generation must be completed or in progress before proceeding", {
              duration: 1000
            });
            return; // Add return to prevent further execution
          }
        } catch (error) {
          console.error("Error checking existing bundle status:", error);
          toast.error("Failed to check bundle status");
        }
      } 
      // For new bundle, check if files have been submitted
      else if (selectedBundleType === "new") {
        // Check if files have been submitted yet
        if (sourceSelectionRef.current && !sourceSelectionRef.current.areFilesSubmitted()) {
          toast.error("Please submit files first before proceeding", {
            duration: 1000
          });
          return;
        }
        
        // Continue with your existing code for checking status
        if (usecaseId) {
          try {
            const statusResponse = await axios.get(
              `${ENV.API_URL}/usecase-management/get-usecase-status/${usecaseId}`
            );
            
            if (statusResponse.data.requirement_generation === "Completed"|| statusResponse.data.requirement_generation === "In Progress") {
              // Proceed to the next step
              setCurrentStep((prev) => Math.min(STEPS.length - 1, prev + 1));
              return;
            } else {
              // Show loading and check status periodically
              setCheckingStatus(true);
              let isCompleted = false;
              let checkAttempts = 0;
              let isCancelled = false;
              
              // Existing code for status checking
              while (!isCompleted && !isCancelled && checkAttempts < 30) {
                try {
                  const statusResponse = await axios.get(
                    `${ENV.API_URL}/usecase-management/get-usecase-status/${usecaseId}`
                  );
                  
                  if (statusResponse.data.requirement_generation === "Completed") {
                    isCompleted = true;
                    setCurrentStep((prev) => Math.min(STEPS.length - 1, prev + 1));
                  } else if (statusResponse.data.requirement_generation === "Failed") {
                    toast.error("Requirement generation failed. Please try again.");
                    isCancelled = true;
                  } else {
                    // Wait before checking again
                    await new Promise(resolve => setTimeout(resolve, 2000));
                    checkAttempts++;
                  }
                } catch (error) {
                  console.error("Error checking status:", error);
                  isCancelled = true;
                }
              }
              
              setCheckingStatus(false);
            }
          } catch (error) {
            console.error("Error checking new bundle status:", error);
            toast.error("Failed to check bundle status");
          }
        } else {
          toast.error("No usecase ID found. Please submit files first.",{duration: 500});
          return;
        }
      }
      
      // Existing code for other cases...
    } else if (currentStep === 1) {
      // Requirements to Scenario Generation logic
      if (!usecaseId) {
        toast.error("No usecase ID found. Cannot proceed.");
        return;
      }
      
      // Set loading state
      setIsUploading(true);
      
      try {
        // Check if scenario generation has started
        const initialStatusResponse = await axios.get(
          `${ENV.API_URL}/usecase-management/get-usecase-status/${usecaseId}`
        );
        
        // Modify this block to proceed earlier
        if (initialStatusResponse.data.scenario_generation === "Completed" || 
            initialStatusResponse.data.scenario_generation === "In Progress") {
          // If generation is already in progress or complete, we can navigate now
          toast.success(`Navigating to scenarios. You'll see them as they're generated.`, {
            duration: 1000
          });
          setCurrentStep((prev) => Math.min(STEPS.length - 1, prev + 1));
        } else if (initialStatusResponse.data.scenario_generation === "Failed") {
          toast.error("Scenario generation failed. Please try again later.", {
            duration: 500
          });
        } else {
          // If not yet started, initiate and wait for it to begin
          toast.info("Initiating scenario generation...", {
            duration: 500
          });
          
          let isStarted = false;
          let isCancelled = false;
          
          // Check until scenario generation at least starts
          while (!isStarted && !isCancelled) {
            try {
              const statusResponse = await axios.get(
                `${ENV.API_URL}/usecase-management/get-usecase-status/${usecaseId}`
              );
              
              if (statusResponse.data.scenario_generation === "Completed" || statusResponse.data.scenario_generation === "In Progress") {
                isStarted = true;
                toast.success(`Navigating to scenarios. You'll see them as they're generated.`, {
                  duration: 500
                });
                // Navigate to the next step once generation has started
                setCurrentStep((prev) => Math.min(STEPS.length - 1, prev + 1));
              } else if (statusResponse.data.scenario_generation === "Failed") {
                toast.error("Scenario generation failed. Please try again later.", {
                  duration: 500
                });
                isCancelled = true;
              } else {
                // Wait before checking again
                await new Promise(resolve => setTimeout(resolve, 2000));
              }
            } catch (error) {
              console.error("Error checking scenario generation status:", error);
              toast.error("Failed to check scenario generation status");
              isCancelled = true;
            }
          }
        }
      } finally {
        setIsUploading(false);
      }
    } else if (currentStep === 2) {
      // Scenario Generation to Test Cases logic
      if (!usecaseId) {
        toast.error("No usecase ID found. Cannot proceed.");
        return;
      }
      
      // Set loading state
      setIsUploading(true);
      
      try {
        // Check status
        const statusResponse = await axios.get(
          `${ENV.API_URL}/usecase-management/get-usecase-status/${usecaseId}`
        );
        
        // Updated logic to handle different states correctly
        const currentStatus = statusResponse.data;
        
        // If we're on Requirements screen checking to go to Scenario generation
        if (currentStatus.requirement_generation === "Completed") {
        // if (currentStatus.test_case_generation === "In Progress") {
          // If requirements are completed, allow navigation even if scenario generation is in progress
          toast.success(`Navigating to test cases`, {
            duration: 1000
          });
          setCurrentStep((prev) => Math.min(STEPS.length - 1, prev + 1));
        } else {
          toast.error("Scenario generation must be completed before proceeding.", {
            duration: 500
          });
        }
      } catch (error) {
        console.error("Error checking status:", error);
        toast.error("Failed to check generation status");
      } finally {
        setIsUploading(false);
      }
    } else if (currentStep === 3) {
      // Test Cases to Test Scripts
      // Check if test script generation has started before proceeding
      if (!usecaseId) {
        toast.error("No usecase ID found. Cannot proceed.");
        return;
      }
      
      // Set loading state
      setIsUploading(true);
      
      try {
        // Check status
        const statusResponse = await axios.get(
          `${ENV.API_URL}/usecase-management/get-usecase-status/${usecaseId}`
        );
        
        // Only proceed if test script generation is completed or in progress
        const currentStatus = statusResponse.data;
        
        if (currentStatus.test_script_generation === "Completed" || 
            currentStatus.test_script_generation === "In Progress") {
          toast.success(`Navigating to test scripts`, {
            duration: 1000
          });
          setCurrentStep((prev) => Math.min(STEPS.length - 1, prev + 1));
        } else {
          toast.error("Test Cases generation must be completed before proceeding.", {
            duration: 500
          });
        }
      } catch (error) {
        console.error("Error checking test script generation status:", error);
        toast.error("Failed to check test script generation status");
      } finally {
        setIsUploading(false);
      }
    } 
    else if (currentStep === 4) {
      // Test Data to Test Scripts
      setIsUploading(true);
      
      try {
        toast.info("Loading test scripts...", { duration: 500 });
        // Simulate a brief load time for UX consistency
        await new Promise(resolve => setTimeout(resolve, 500));
        setCurrentStep((prev) => Math.min(STEPS.length - 1, prev + 1));
      } finally {
        setIsUploading(false);
      }
    } 
    else {
      setIsUploading(true);
      
      try {
        toast.info("Loading next step...", { duration: 500 });
        // Simulate a brief load time for UX consistency
        await new Promise(resolve => setTimeout(resolve, 500));
        setCurrentStep((prev) => Math.min(STEPS.length - 1, prev + 1));
      } finally {
        setIsUploading(false);
      }
    }
  };

  // Create a function to handle the "Previous" button click
  const handlePreviousClick = () => {
    // Reset loading states when navigating back
    setIsUploading(false);
    setIsLoading(false);
    setCheckingStatus(false);
    
    // Navigate to the previous step
    setCurrentStep((prev) => Math.max(0, prev - 1));
  };

  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return <SourceSelection 
          ref={sourceSelectionRef} 
          onFileSelect={setSelectedFile}
          onUserAssociations={(userAssociations: UserAssociationInfo) => {
            setUserProduct(userAssociations.product);
            setUserSub_product(userAssociations.sub_product);
            setUserDomain(userAssociations.domain);
          }}
          onBundleSelect={(name: string, type: "new" | "existing", bundleUsecaseId?: string) => {
            setBundleName(name);
            setSelectedBundleType(type);
            // If existing bundle selected with a usecase ID, update it
            if (type === "existing" && bundleUsecaseId) {
              setUsecaseId(bundleUsecaseId);
              // Reset loading indicators when selecting existing bundle
              setIsUploading(false);
              setCheckingStatus(false);
            }
          }}
        />;
      case 1:
        return <RequirementsCaptured 
          selectedFile={selectedFile} 
          usecaseId={usecaseId}
          onRequirementsGenerated={(ids: string[]) => setRequirementIds(ids)}
          product={userProduct}
          subProduct={userSub_product}
          domain={userDomain}
          bundleName={bundleName}
        />;
      case 2:
        return <ScenarioGeneration 
          selectedFile={selectedFile}
          usecaseId={usecaseId}
          requirementIds={requirementIds}
          product={userProduct}
          subProduct={userSub_product}
          domain={userDomain}
          bundleName={bundleName}
        />;
      case 3:
        return <TestCases 
          selectedFile={selectedFile} 
          usecaseId={usecaseId}
          requirementIds={requirementIds}
          product={userProduct}
          subProduct={userSub_product}
          domain={userDomain}
          bundleName={bundleName}
        />;
      // case 4:
      //   return <TestData 
      //     selectedFile={selectedFile}
      //     product={userProduct}
      //     subProduct={userSub_product}
      //     domain={userDomain}
      //     bundleName={bundleName}
      //     usecaseId={usecaseId}
      //   />;
      // case 5:
      case 4:
        return <TestScripts selectedFile={selectedFile} 
          product={userProduct}
          subProduct={userSub_product}
          domain={userDomain}
          bundleName={bundleName}
          usecaseId={usecaseId}
        />;
      // case 6:
      case 5:
        return <Metrics 
          selectedFile={selectedFile}
          product={userProduct}
          subProduct={userSub_product}
          domain={userDomain}
          bundleName={bundleName}
          usecaseId={usecaseId}
        />;
      default:
        return <div>Step {currentStep + 1}</div>;
    }
  };

  // In Index.tsx, add logic to manage session state
  const clearSessionState = () => {
    // Clear any persisted state
    setSelectedBundleType(null);
    setUsecaseId(null);
    setBundleName("");
    setCurrentStep(0);
    // Any other state that should be reset
  };

  // Add a reset button or trigger on page load
  useEffect(() => {
    clearSessionState();
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* <Header /> */}
      <Header onHomeClick={clearSessionState} />
      <WizardSteps currentStep={currentStep} steps={STEPS} />
      <main className="flex-1 flex flex-col">
        {renderStep()}
        <div className="border-t mt-auto">
          <div className="container mx-auto px-4 py-4 flex justify-end gap-4">
            {currentStep > 0 && (
              <Button
                variant="outline"
                onClick={handlePreviousClick}
              >
                Previous
              </Button>
            )}
            {currentStep < STEPS.length - 1 && (
              <Button 
                onClick={handleNextClick} 
                // disabled={isUploading || isLoading || checkingStatus || currentStep === 3} // disabled for test data page
                disabled={isUploading || isLoading || checkingStatus} // disabled for test data page
                className="bg-blue-500 hover:bg-blue-600 text-white"
              >
                {(isUploading || isLoading || checkingStatus) ? (
                  <>
                    <span className="mr-2">Please wait</span>
                    {/* <span className="animate-spin">⟳</span> */}
                    <svg 
                      className="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline-block" 
                      xmlns="http://www.w3.org/2000/svg" 
                      fill="none" 
                      viewBox="0 0 24 24"
                    >
                      <circle 
                        className="opacity-25" 
                        cx="12" 
                        cy="12" 
                        r="10" 
                        stroke="currentColor" 
                        strokeWidth="4"
                      ></circle>
                      <path 
                        className="opacity-75" 
                        fill="currentColor" 
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      ></path>
                    </svg>
                  </>
                ) : (
                  "Next"
                )}
              </Button>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Index;
