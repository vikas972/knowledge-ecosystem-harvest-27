import axios from 'axios';
import { useAuth } from '../hooks/useAuth';
import { ENV } from '../config/env';

const api = axios.create({
  baseURL: ENV.API_URL,
});

export const useApi = () => {
  const { getToken } = useAuth();

  api.interceptors.request.use(async (config) => {
    const token = await getToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  });

  return api;
};