import { useAuth0 } from "@auth0/auth0-react";
import { useCallback } from "react";
import { toast } from "sonner";

export const useAuth = () => {
  const {
    isAuthenticated,
    isLoading,
    user,
    getAccessTokenSilently,
    loginWithRedirect,
    logout: auth0Logout,
  } = useAuth0();

  const getToken = useCallback(async () => {
    try {
      return await getAccessTokenSilently();
    } catch (error) {
      console.error('Error getting token:', error);
      return null;
    }
  }, [getAccessTokenSilently]);
  
  // Enhanced logout with optional confirmation
  const logout = useCallback((skipConfirmation = false) => {
    const performLogout = () => {
      // Clear any stored user data before logout
      sessionStorage.removeItem('userEmail');
      localStorage.removeItem('auth_last_refresh');
      
      // Log out with Auth0 and redirect to home page
      auth0Logout({ 
        logoutParams: { 
          returnTo: window.location.origin 
        }
      });
    };
    
    if (skipConfirmation) {
      performLogout();
      return;
    }
    
    // Show confirmation dialog using the toast component
    toast.warning("Are you sure you want to log out?", {
      duration: 6000,
      action: {
        label: "Logout",
        onClick: performLogout
      },
      cancel: {
        label: "Cancel",
        onClick: () => {}
      },
      position: "top-center",
    });
  }, [auth0Logout]);

  return {
    isAuthenticated,
    isLoading,
    user,
    getToken,
    login: loginWithRedirect,
    logout,
  };
}; 