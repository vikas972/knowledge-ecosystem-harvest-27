import { useAuth } from './useAuth';

export const useUserEmail = () => {
  const { user, isLoading } = useAuth();
  
  return {
    email: user?.email,
    isLoading,
    // For debugging
    // debug: () => {
    //   console.log('UserEmail Debug - Current Email:', user?.email);
    //   console.log('UserEmail Debug - Loading State:', isLoading);
    // }
  };
}; 