import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Auth0Provider, withAuthenticationRequired } from "@auth0/auth0-react";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import { KnowledgeBaseLayout } from "./components/knowledge-base/KnowledgeBaseLayout";
import { AUTH_CONFIG } from '@/config/auth';
import AuthHandler from "@/components/auth/AuthHandler";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: false,
    },
  },
});

const userEmail = sessionStorage.getItem('userEmail');
console.log("userEmail", userEmail);

// Ensure Index page requires authentication
const ProtectedPage = () => {
  const AuthenticatedIndex = withAuthenticationRequired(Index);
  return (
    <>
      <AuthHandler /> {/* Ensure AuthHandler runs only after login */}
      <AuthenticatedIndex />
    </>
  );
};

// Redirect after login
const onRedirectCallback = (appState: any) => {
  window.location.href = appState?.returnTo || window.location.pathname;
};

function App() {
  return (
    <Auth0Provider
      domain={AUTH_CONFIG.domain}
      clientId={AUTH_CONFIG.clientId}
      authorizationParams={{
        redirect_uri: window.location.origin,
        scope: AUTH_CONFIG.scope,
      }}
      onRedirectCallback={onRedirectCallback} // Ensure redirect after login
    >
      <QueryClientProvider client={queryClient}>
        <BrowserRouter>
          <TooltipProvider>
            <Routes>
              <Route path="/" element={<ProtectedPage />} />
	      <Route path="/knowledge-base" element={<KnowledgeBaseLayout />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
            <Toaster />
            <Sonner />
          </TooltipProvider>
        </BrowserRouter>
      </QueryClientProvider>
    </Auth0Provider>
  );
}

export default App;
