import axios from 'axios';
import { API_ENDPOINTS } from './config/api';

// Function to debug requirement-testcase mapping for a use case
export const debugRequirementTestcaseMapping = async (usecaseId: string): Promise<any> => {
  try {
    const response = await axios.get(`${API_ENDPOINTS.debugRequirementTestcaseMapping}/${usecaseId}`);
    return response.data;
  } catch (error) {
    console.error('Error getting requirement-testcase mapping debug:', error);
    throw error;
  }
};

// Function to get detailed information about a specific requirement
export const getRequirementDetails = async (requirementId: string): Promise<any> => {
  try {
    const response = await axios.get(`${API_ENDPOINTS.getRequirementDetails}/${requirementId}`);
    return response.data;
  } catch (error) {
    console.error('Error getting requirement details:', error);
    throw error;
  }
}; 