import { useEffect } from "react";
import { useAuth0 } from "@auth0/auth0-react";
import { API_ENDPOINTS } from "@/config/api";
import { toast } from "sonner";

const AuthHandler = () => {
  const { user, getAccessTokenSilently, isAuthenticated } = useAuth0();

  useEffect(() => {
    const initializeUser = async () => {
      if (!isAuthenticated || !user?.email) return;

      // Store email in session storage
      sessionStorage.setItem('userEmail', user.email);

      try {
        const accessToken = await getAccessTokenSilently();
        const apiUrl = `${API_ENDPOINTS.manageUser}?email=${encodeURIComponent(user.email)}`;

        // console.log("Sending request to:", apiUrl);

        const response = await fetch(apiUrl, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        });

        const data = await response.json();
        
        // Check the status code in the response
        if (data.status_code === 400 && data.message.includes("Email already registered")) {
          // console.log("User already registered:", user.email);
          // toast.success("Welcome back!");
          return;
        }
        
        if (!response.ok) {
          throw new Error(`Failed to initialize user: ${JSON.stringify(data)}`);
        }

        toast.success("User initialized successfully");
        console.log("User initialized:", data);
      } catch (error) {
        console.error("Error initializing user:", error);
        
        // Only show error toast for actual errors, not for "already registered"
        if (!error.message?.includes("Email already registered")) {
          toast.error("Failed to initialize user");
        }
      }
    };

    initializeUser();

    // Clean up session storage on unmount
    return () => {
      sessionStorage.removeItem('userEmail');
    };
  }, [isAuthenticated, user, getAccessTokenSilently]);

  return null;
};

export default AuthHandler;
