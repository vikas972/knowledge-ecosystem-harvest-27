import { Card } from "@/components/ui/card";
import { RequirementHeader } from "./RequirementHeader";
import { RequirementContent } from "./RequirementContent";
import { type Requirement } from "./types";
import { cn } from "@/lib/utils";
import { useState, useEffect, Suspense } from "react";
import { Loader2 } from "lucide-react";
import React from "react";

// Error boundary fallback component
const ErrorFallback = () => (
  <div className="p-6 text-red-500 bg-red-50 rounded-md">
    <h3 className="font-semibold mb-2">Error Loading Content</h3>
    <p>There was a problem loading the requirement details. Please try again or contact support if the issue persists.</p>
  </div>
);

// Loading component
const LoadingContent = () => (
  <div className="p-6 flex flex-col items-center justify-center">
    <Loader2 className="h-8 w-8 animate-spin text-primary mb-2" />
    <p className="text-gray-500">Loading requirement details...</p>
  </div>
);

interface RequirementCardProps {
  requirement: Requirement;
  isExpanded: boolean;
  isEditing: boolean;
  isSelected: boolean;
  onToggleSelect: (checked: boolean) => void;
  onEdit: (e: React.MouseEvent) => void;
  onSave: (e: React.MouseEvent) => void;
  onCancel: (e: React.MouseEvent) => void;
  onClick: () => void;
  onDelete: () => void;
  onFunctionalAreaChange: (value: string) => void;
  onSourceChange: (field: 'page' | 'paragraph', value: number) => void;
  onStatusChange: (status: "completed" | "needs_review" | "in_progress") => void;
  onUserStoriesChange?: (requirementId: string, stories: string[]) => void;
  isNew?: boolean;
}

// Custom error boundary class
class RequirementErrorBoundary extends React.Component<{ children: React.ReactNode }> {
  state = { hasError: false };
  
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  
  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error("Error in requirement content:", error, info);
  }
  
  render() {
    if (this.state.hasError) {
      return <ErrorFallback />;
    }
    
    return this.props.children;
  }
}

export const RequirementCard = ({
  requirement,
  isExpanded,
  isEditing,
  isSelected,
  onToggleSelect,
  onEdit,
  onSave,
  onCancel,
  onClick,
  onDelete,
  onFunctionalAreaChange,
  onSourceChange,
  onStatusChange,
  onUserStoriesChange,
  isNew = false,
}: RequirementCardProps) => {
  const [isContentReady, setIsContentReady] = useState(false);
  
  // Reset content ready state when requirement changes or expansion state changes
  useEffect(() => {
    if (isExpanded) {
      // Small delay to ensure DOM is ready
      const timer = setTimeout(() => {
        setIsContentReady(true);
      }, 100);
      return () => clearTimeout(timer);
    } else {
      setIsContentReady(false);
    }
  }, [requirement?.id, isExpanded]);

  // Add a check to not render if requirement is deleted
  if (!requirement) {
    return null;
  }

  const handleUpdateUserStories = (stories: string[]) => {
    try {
      onUserStoriesChange?.(requirement.id, stories);
      return stories;
    } catch (error) {
      console.error("Error updating user stories:", error);
      return requirement.userStories || [];
    }
  };

  const handleUpdateBusinessRules = (rules: Requirement['businessRules']) => {
    try {
      const updatedRules = requirement.businessRules.filter(rule => rules.some(r => r.id === rule.id));
      onFunctionalAreaChange(requirement.functionalArea);
      return updatedRules;
    } catch (error) {
      console.error("Error updating business rules:", error);
      return requirement.businessRules || [];
    }
  };

  const handleUpdateDataElements = (elements: Requirement['dataElements']) => {
    try {
      const updatedElements = requirement.dataElements.filter(element => elements.some(e => e.id === element.id));
      onFunctionalAreaChange(requirement.functionalArea);
      return updatedElements;
    } catch (error) {
      console.error("Error updating data elements:", error);
      return requirement.dataElements || [];
    }
  };

  // Create a handler for the edit button click
  const handleEditClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Edit functionality disabled
  };

  // Safely render the content with proper error handling
  const renderContent = () => {
    if (!isExpanded) return null;
    
    if (!isContentReady) {
      return <LoadingContent />;
    }

    // Wrap the content in error boundary and suspense
    return (
      <RequirementErrorBoundary>
        <Suspense fallback={<LoadingContent />}>
          <RequirementContent
            requirement={requirement}
            isEditing={isEditing}
            onUpdateUserStories={handleUpdateUserStories}
            onUpdateBusinessRules={handleUpdateBusinessRules}
            onUpdateDataElements={handleUpdateDataElements}
          />
        </Suspense>
      </RequirementErrorBoundary>
    );
  };

  return (
    <Card 
      className={cn(
        "transition-all border", 
        isExpanded ? "shadow-md" : "shadow-sm", 
        isNew ? "bg-blue-50 animate-pulse border-blue-200" : "bg-white",
        "mb-4 relative"
      )}
    >
      <RequirementHeader
        requirement={requirement}
        isEditing={isEditing}
        isExpanded={isExpanded}
        isSelected={isSelected}
        onToggleSelect={onToggleSelect}
        onEdit={handleEditClick}
        onSave={onSave}
        onCancel={onCancel}
        onClick={onClick}
        onDelete={onDelete}
        onFunctionalAreaChange={onFunctionalAreaChange}
        onSourceChange={onSourceChange}
        onStatusChange={onStatusChange}
      />
      {renderContent()}
    </Card>
  );
};
