import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, Maximize2, ChevronLeft, ChevronRight } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useState } from "react";
import { Requirement } from "../types";
import * as XLSX from 'xlsx';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface RequirementGridDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  requirements: Requirement[];
  title?: string;
}

export const RequirementGridDialog = ({ 
  open, 
  onOpenChange, 
  requirements = [], 
  title = "Requirements"
}: RequirementGridDialogProps) => {
  const [isFullScreen, setIsFullScreen] = useState(false);
  
  // Add pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [jumpToPageValue, setJumpToPageValue] = useState<string>('');
  
  // Sort requirements by displayId
  const sortedRequirements = [...requirements].sort((a, b) => {
    // Extract displayId from requirementId format "REQ-123"
    const aDisplayId = parseInt(a.requirementId.replace('REQ-', '')) || 0;
    const bDisplayId = parseInt(b.requirementId.replace('REQ-', '')) || 0;
    return aDisplayId - bDisplayId;
  });
  
  // Calculate total pages from sorted requirements
  const totalPages = Math.ceil(sortedRequirements.length / itemsPerPage);

  const toggleFullScreen = () => {
    setIsFullScreen(!isFullScreen);
  };

  const handleExport = () => {
    // Ensure we have requirements to export
    if (!sortedRequirements || sortedRequirements.length === 0) {
      console.warn("No requirements to export");
      return;
    }

    try {
      console.log("Exporting requirements to Excel...");
      
      // Get all the requirement section keys to ensure we export all fields
      const allSectionKeys = getAllRequirementSectionKeys();
      
      // Prepare data for export with all details
      const exportData = sortedRequirements.map(req => {
        // Base requirement data (simple string properties first)
        const baseData: Record<string, any> = {
          ID: req.requirementId || "N/A",
          "Functional Area": req.functionalArea || "N/A",
          Description: req.description || "N/A"
        };
        
        // Add all dynamic fields based on section keys
        allSectionKeys.forEach(key => {
          const value = req[key];
          const formattedKey = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
          
          // Handle array types
          if (Array.isArray(value)) {
            if (value.length === 0) {
              baseData[formattedKey] = "None";
            } else if (typeof value[0] === 'string') {
              baseData[formattedKey] = value.join("; ");
            } else if (value[0] && typeof value[0] === 'object') {
              // Check for common fields in our object arrays
              if ('description' in value[0]) {
                baseData[formattedKey] = value.map(item => item.description).join("; ");
              } else if ('name' in value[0] && 'value' in value[0]) {
                baseData[formattedKey] = value.map(item => `${item.name}: ${item.value}`).join("; ");
              } else if ('name' in value[0]) {
                baseData[formattedKey] = value.map(item => item.name).join("; ");
              } else {
                // Fallback for objects without known properties
                baseData[formattedKey] = value.map(item => JSON.stringify(item)).join("; ");
              }
            }
          } 
          // Handle object types
          else if (value && typeof value === 'object') {
            baseData[formattedKey] = JSON.stringify(value);
          }
          // Other primitive types
          else if (value !== undefined && value !== null) {
            baseData[formattedKey] = value;
          } else {
            baseData[formattedKey] = "None";
          }
        });
        
        // Special case handling for specific known fields to ensure they're formatted nicely
        
        // User Stories
        if (!baseData["User Stories"] && Array.isArray(req.userStories)) {
          baseData["User Stories"] = req.userStories.length > 0 ? 
            req.userStories.join("; ") : "None";
        }
        
        // Business Requirements
        if (!baseData["Business Requirements"] && Array.isArray(req.businessRequirements)) {
          baseData["Business Requirements"] = req.businessRequirements.length > 0 ? 
            req.businessRequirements.map(item => item.description).join("; ") : "None";
        }
        
        // Business Rules
        if (!baseData["Business Rules"] && Array.isArray(req.businessRules)) {
          baseData["Business Rules"] = req.businessRules.length > 0 ? 
            req.businessRules.map(item => item.description).join("; ") : "None";
        }
        
        // Data Elements
        if (!baseData["Data Elements"] && Array.isArray(req.dataElements)) {
          baseData["Data Elements"] = req.dataElements.length > 0 ? 
            req.dataElements.map(item => item.name).join("; ") : "None";
        }
        
        return baseData;
      });

      // Create worksheet
      const ws = XLSX.utils.json_to_sheet(exportData);

      // Create workbook
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Requirements');

      // Generate Excel file
      XLSX.writeFile(wb, 'requirements_overview.xlsx');
      console.log("Export complete!");
    } catch (error) {
      console.error("Error exporting to Excel:", error);
    }
  };

  const dialogClass = isFullScreen 
    ? "w-screen h-screen max-w-none rounded-none" 
    : "w-[95vw] h-[90vh] max-w-[1500px]";

  // Add a function to get all unique requirement section keys
  const getAllRequirementSectionKeys = () => {
    const allKeys = new Set<string>();
    
    sortedRequirements.forEach(req => {
      Object.keys(req).forEach(key => {
        // Only include array or object properties that might be requirement sections
        if (
          (Array.isArray(req[key]) || typeof req[key] === 'object') && 
          req[key] !== null &&
          !['id', 'requirementId', 'functionalArea', 'description', 'status', 'confidence', 'source', 'is_deleted'].includes(key)
        ) {
          allKeys.add(key);
        }
      });
    });
    
    return Array.from(allKeys);
  };

  // Then in your render method, dynamically generate table headers
  const renderTableHeaders = () => {
    const fixedHeaders = [
      { key: 'id', label: 'ID', width: 'w-[80px]' },
      { key: 'functionalArea', label: 'Functional Area', width: 'w-[120px]' },
      { key: 'description', label: 'Description', width: 'min-w-[200px]' }
    ];
    
    const dynamicHeaders = getAllRequirementSectionKeys().map(key => ({
      key,
      label: key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase()),
      width: 'min-w-[200px]'
    }));
    
    return [...fixedHeaders, ...dynamicHeaders].map(header => (
      <TableHead 
        key={header.key} 
        className={`${header.width} whitespace-nowrap px-2 py-2 text-xs font-semibold text-gray-700`}
      >
        {header.label}
      </TableHead>
    ));
  };

  // And dynamically render table cells
  const renderTableRow = (req: Requirement, index: number) => {
    const fixedCells = [
      <TableCell key="id" className="whitespace-nowrap font-medium px-2 py-1.5 border-r border-gray-200">
        {req.requirementId}
      </TableCell>,
      <TableCell key="functionalArea" className="whitespace-nowrap px-2 py-1.5 border-r border-gray-200">
        {req.functionalArea}
      </TableCell>,
      <TableCell key="description" className="px-2 py-1.5 border-r border-gray-200 text-xs leading-tight">
        {req.description}
      </TableCell>
    ];
    
    const dynamicCells = getAllRequirementSectionKeys().map(key => {
      const value = req[key];
      
      return (
        <TableCell key={key} className="px-2 py-1.5 border-r border-gray-200">
          {renderCellContent(key, value)}
        </TableCell>
      );
    });
    
    return (
      <TableRow 
        key={req.id} 
        className={`
          border-b border-gray-200
          ${index % 2 === 0 ? "bg-white" : "bg-gray-50"}
          hover:bg-blue-50 transition-colors text-xs
        `}
      >
        {[...fixedCells, ...dynamicCells]}
      </TableRow>
    );
  };

  // Helper function to render cell content based on data type
  const renderCellContent = (key: string, value: any) => {
    if (!value || (Array.isArray(value) && value.length === 0)) {
      return <span className="text-gray-500 italic text-xs">None</span>;
    }
    
    if (Array.isArray(value)) {
      return (
        <ul className="list-disc pl-3 text-xs space-y-0.5">
          {value.map((item, idx) => {
            if (typeof item === 'string') {
              return <li key={idx} className="text-gray-700 leading-tight">{item}</li>;
            }
            
            if (typeof item === 'object' && item !== null) {
              // Handle objects with id and description/name/value properties
              const displayText = item.description || item.name || item.value || JSON.stringify(item);
              return <li key={idx} className="text-gray-700 leading-tight">{displayText}</li>;
            }
            
            return <li key={idx} className="text-gray-700 leading-tight">{String(item)}</li>;
          })}
        </ul>
      );
    }
    
    // Handle object type values
    if (typeof value === 'object' && value !== null) {
      return (
        <ul className="list-disc pl-3 text-xs space-y-0.5">
          {Object.entries(value).map(([itemKey, itemValue], idx) => (
            <li key={idx} className="text-gray-700 leading-tight">
              <strong className="text-gray-800">
                {itemKey.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}:
              </strong> {String(itemValue)}
            </li>
          ))}
        </ul>
      );
    }
    
    return <span className="text-xs">{String(value)}</span>;
  };

  // Pagination handlers
  const goToNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const goToPreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const goToPage = (pageNumber: number) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  const handleItemsPerPageChange = (value: string) => {
    setItemsPerPage(parseInt(value));
    setCurrentPage(1); // Reset to first page when changing items per page
  };

  const handleJumpToPage = (e: React.FormEvent) => {
    e.preventDefault();
    const pageNumber = parseInt(jumpToPageValue);
    
    if (!isNaN(pageNumber) && pageNumber >= 1 && pageNumber <= totalPages) {
      goToPage(pageNumber);
    }
    
    // Reset the input field after jumping
    setJumpToPageValue('');
  };

  // Get paginated requirements
  const getPaginatedRequirements = () => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return sortedRequirements.slice(startIndex, endIndex);
  };

  // Render page numbers for pagination
  const renderPageNumbers = () => {
    const pageNumbers = [];
    const maxPageButtons = 5; // Maximum number of page buttons to show
    
    let startPage = Math.max(1, currentPage - Math.floor(maxPageButtons / 2));
    let endPage = Math.min(totalPages, startPage + maxPageButtons - 1);
    
    // Adjust if we're at the end
    if (endPage - startPage + 1 < maxPageButtons) {
      startPage = Math.max(1, endPage - maxPageButtons + 1);
    }
    
    // Always show first page
    if (startPage > 1) {
      pageNumbers.push(
        <Button 
          key={1} 
          variant={currentPage === 1 ? "default" : "outline"} 
          size="sm" 
          onClick={() => goToPage(1)}
          className="h-8 w-8 p-0"
        >
          1
        </Button>
      );
      
      // Add ellipsis if there's a gap
      if (startPage > 2) {
        pageNumbers.push(
          <span key="start-ellipsis" className="px-2">...</span>
        );
      }
    }
    
    // Add page numbers
    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(
        <Button 
          key={i} 
          variant={currentPage === i ? "default" : "outline"} 
          size="sm" 
          onClick={() => goToPage(i)}
          className="h-8 w-8 p-0"
        >
          {i}
        </Button>
      );
    }
    
    // Always show last page
    if (endPage < totalPages) {
      // Add ellipsis if there's a gap
      if (endPage < totalPages - 1) {
        pageNumbers.push(
          <span key="end-ellipsis" className="px-2">...</span>
        );
      }
      
      pageNumbers.push(
        <Button 
          key={totalPages} 
          variant={currentPage === totalPages ? "default" : "outline"} 
          size="sm" 
          onClick={() => goToPage(totalPages)}
          className="h-8 w-8 p-0"
        >
          {totalPages}
        </Button>
      );
    }
    
    return pageNumbers;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={dialogClass}>
        <DialogHeader className="flex flex-row items-center justify-between border-b pb-4 px-6">
          <div>
            <DialogTitle className="text-xl font-semibold text-gray-900">{title} Overview</DialogTitle>
            {/* <DialogDescription className="text-sm text-gray-500 mt-1">
              View and export your requirements in a grid format
            </DialogDescription> */}
          </div>
          <div className="flex items-center gap-3">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="outline" 
                    onClick={toggleFullScreen} 
                    className="h-9 w-9 p-0 border-gray-200 hover:bg-gray-100 transition-colors"
                  >
                    <Maximize2 className="h-4 w-4 text-gray-600" />
                  </Button>
                </TooltipTrigger>
                {/* <TooltipContent>
                  <p>Toggle fullscreen</p>
                </TooltipContent> */}
              </Tooltip>
            </TooltipProvider>

            <Button 
              onClick={handleExport} 
              className="bg-blue-600 hover:bg-blue-700 text-white h-9 px-4 shadow-sm transition-colors flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              <span className="font-medium">Export to Excel</span>
            </Button>
          </div>
        </DialogHeader>
        <ScrollArea className="h-[calc(100%-80px)]">
          <div className="p-4">
            <div className="overflow-x-auto rounded-md border border-gray-200 shadow-sm">
              <Table className="compact-table">
                <TableHeader className="bg-gray-50 sticky top-0 z-10">
                  <TableRow className="border-b-2 border-gray-200">
                    {renderTableHeaders()}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {getPaginatedRequirements().map((req, index) => renderTableRow(req, index))}
                </TableBody>
              </Table>
              {(!sortedRequirements || sortedRequirements.length === 0) && (
                <div className="text-center py-8 text-gray-500 bg-gray-50">
                  <p className="text-lg">No requirements available</p>
                  <p className="text-sm mt-1">Requirements will appear here once they are added to the project.</p>
                </div>
              )}
            </div>
          </div>
        </ScrollArea>

        {/* Pagination Controls */}
        {sortedRequirements.length > 0 && (
          <div className="flex justify-between items-center border-t py-1 px-4 bg-gray-50">
            <div className="flex items-center gap-2 text-xs text-gray-600">
              <Select 
                value={itemsPerPage.toString()} 
                onValueChange={handleItemsPerPageChange}
              >
                <SelectTrigger className="h-7 w-16 text-xs">
                  <SelectValue placeholder="10" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">5</SelectItem>
                  <SelectItem value="10">10</SelectItem>
                  <SelectItem value="20">20</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                </SelectContent>
              </Select>
              <span>per page</span>
              <span className="ml-2">
                {`${(currentPage - 1) * itemsPerPage + 1}-${Math.min(currentPage * itemsPerPage, sortedRequirements.length)} of ${sortedRequirements.length}`}
              </span>
            </div>
            
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="icon"
                onClick={goToPreviousPage}
                disabled={currentPage === 1}
                className="h-7 w-7"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              
              <div className="flex items-center">
                <input
                  type="number"
                  min="1"
                  max={totalPages}
                  value={currentPage}
                  onChange={(e) => {
                    const page = parseInt(e.target.value);
                    if (page >= 1 && page <= totalPages) {
                      setCurrentPage(page);
                    }
                  }}
                  className="h-7 w-12 px-2 border rounded text-xs text-center"
                />
                <span className="text-xs text-gray-600 mx-1">of {totalPages}</span>
              </div>

              <Button
                variant="outline"
                size="icon"
                onClick={goToNextPage}
                disabled={currentPage === totalPages}
                className="h-7 w-7"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}; 