import { cn } from "@/lib/utils";
import { type Requirement } from "../types";
import { RequirementsHeader } from "./RequirementsHeader";
import { RequirementsList } from "./RequirementsList";
import { RequirementGridDialog } from "../dialogs/RequirementGridDialog";
import { useState } from "react";

interface RequirementsSectionProps {
  fileName: string | undefined;
  isMaximized: boolean;
  isSourceMaximized: boolean;
  requirements: Requirement[];
  allRequirements?: Requirement[];
  editingRequirement: string | null;
  selectedRequirements: string[];
  expandedRequirement: string | null;
  onSelectAll: (checked: boolean) => void;
  onSelect: (requirementId: string, checked: boolean) => void;
  onAddNew: () => void;
  onRegenerate: () => void;
  onBulkStatusChange: (status: "completed" | "needs_review" | "in_progress") => void;
  onBulkDelete: () => void;
  onToggleMaximize: () => void;
  onEdit: (requirement: Requirement, e: React.MouseEvent) => void;
  onSave: (e: React.MouseEvent) => void;
  onCancel: (e: React.MouseEvent) => void;
  onClick: (requirement: Requirement) => void;
  onDelete: (requirementId: string) => void;
  onFunctionalAreaChange: (requirementId: string, value: string) => void;
  onSourceChange: (requirementId: string, field: 'page' | 'paragraph', value: number) => void;
  onStatusChange: (requirementId: string, status: "completed" | "needs_review" | "in_progress") => void;
  onUserStoriesChange: (requirementId: string, stories: string[]) => void;
  displayTotal?: number;
  newlyAddedRequirementIds?: string[];
  usecaseId?: string | number;
  onRequirementAdded?: () => void;
}

export const RequirementsSection = ({
  fileName,
  isMaximized,
  isSourceMaximized,
  requirements,
  allRequirements,
  editingRequirement,
  selectedRequirements,
  expandedRequirement,
  onSelectAll,
  onSelect,
  onAddNew,
  onRegenerate,
  onBulkStatusChange,
  onBulkDelete,
  onToggleMaximize,
  onEdit,
  onSave,
  onCancel,
  onClick,
  onDelete,
  onFunctionalAreaChange,
  onSourceChange,
  onStatusChange,
  onUserStoriesChange,
  displayTotal,
  newlyAddedRequirementIds = [],
  usecaseId,
  onRequirementAdded,
}: RequirementsSectionProps) => {
  const [showGridDialog, setShowGridDialog] = useState(false);

  // New: Add console logging for selection changes
  const handleSelect = (requirementId: string, checked: boolean) => {
    console.log(`Requirement selection changed: ${requirementId}, selected: ${checked}`);
    console.log("Current selectedRequirements:", selectedRequirements);
    onSelect(requirementId, checked);
    
    // Log again after the selection has been processed
    setTimeout(() => {
      console.log("Updated selectedRequirements:", selectedRequirements);
    }, 0);
  };

  // A wrapper for the handleUserStoriesChange function that just passes on the call
  const handleUserStoriesChange = (requirementId: string, stories: string[]) => {
    // This is a placeholder - in a real implementation, you would update the stories
    onUserStoriesChange(requirementId, stories);
  };

  // Add this filter function
  const getFilteredRequirements = (reqs: Requirement[]) => {
    return reqs.filter(req => !req.is_deleted);
  };

  return (
    <div className={cn(
      "flex flex-col h-full transition-all duration-300",
      isMaximized ? "w-full" : "flex-1",
      isSourceMaximized ? "hidden" : "flex"
    )}>
      <RequirementsHeader
        fileName={fileName || "Untitled Document"}
        isMaximized={isMaximized}
        selectedCount={selectedRequirements.length}
        totalCount={requirements.length}
        allRequirementsCount={allRequirements?.length || requirements.length}
        displayTotal={displayTotal}
        onSelectAll={(checked) => {
          console.log("RequirementsSection - onSelectAll called with:", checked);
          console.log("Current selectedRequirements:", selectedRequirements);
          onSelectAll(checked);
        }}
        onAddNew={onAddNew}
        onRegenerate={onRegenerate}
        onBulkStatusChange={onBulkStatusChange}
        onDelete={onBulkDelete}
        onToggleMaximize={onToggleMaximize}
        onShowGrid={() => setShowGridDialog(true)}
        selectedRequirements={selectedRequirements}
        usecaseId={usecaseId}
        onRequirementAdded={onRequirementAdded}
      />

      <div className="flex-1 overflow-auto px-6 py-4">
        <RequirementsList
          requirements={getFilteredRequirements(requirements)}
          editingRequirement={editingRequirement}
          selectedRequirements={selectedRequirements}
          expandedRequirement={expandedRequirement}
          onSelect={handleSelect}
          onEdit={onEdit}
          onSave={onSave}
          onCancel={onCancel}
          onClick={onClick}
          onDelete={onDelete}
          onFunctionalAreaChange={onFunctionalAreaChange}
          onSourceChange={onSourceChange}
          onStatusChange={onStatusChange}
          onUserStoriesChange={handleUserStoriesChange}
          newlyAddedRequirementIds={newlyAddedRequirementIds}
        />
      </div>

      {/* Grid Dialog */}
      <RequirementGridDialog
        open={showGridDialog}
        onOpenChange={setShowGridDialog}
        requirements={getFilteredRequirements(allRequirements || requirements)}
        title="Requirements"
      />
    </div>
  );
};
