import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Plus, RefreshCw, CheckSquare, Trash2, Maximize2, Minimize2, Grid, X } from "lucide-react";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
// import { toast } from "@/components/ui/use-toast";
import { toast } from "sonner";
import axios from "axios";
import { ENV } from "@/config/env";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

interface RequirementsHeaderProps {
  fileName: string;
  isMaximized: boolean;
  selectedCount: number;
  totalCount: number;
  allRequirementsCount: number;
  onSelectAll: (checked: boolean) => void;
  onAddNew: () => void;
  onRegenerate: () => void;
  onBulkStatusChange: (status: "completed" | "needs_review" | "in_progress") => void;
  onDelete: () => void;
  onToggleMaximize: () => void;
  onShowGrid: () => void;
  selectedRequirements?: string[];
  displayTotal?: number;
  usecaseId?: string | number;
  onRequirementAdded?: () => void;
}

interface RequirementHeader {
  id: string;
  name: string;
  items: string[];
}

export const RequirementsHeader = ({
  fileName,
  isMaximized,
  selectedCount,
  totalCount,
  allRequirementsCount,
  onSelectAll,
  onAddNew,
  onRegenerate,
  onBulkStatusChange,
  onDelete,
  onToggleMaximize,
  onShowGrid,
  selectedRequirements = [],
  displayTotal,
  usecaseId,
  onRequirementAdded,
}: RequirementsHeaderProps) => {
  const [isBulkDeleteDialogOpen, setIsBulkDeleteDialogOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isAddRequirementDialogOpen, setIsAddRequirementDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // New requirement state
  const [requirementName, setRequirementName] = useState("");
  const [requirementDescription, setRequirementDescription] = useState("");
  const [userStories, setUserStories] = useState<string[]>([""]);
  const [requirementHeaders, setRequirementHeaders] = useState<RequirementHeader[]>([
    { id: crypto.randomUUID(), name: "Functional Requirements", items: [""] }
  ]);

  const handleDeleteClick = () => {
    if (selectedCount === 0) {
      toast.error("Please select at least one requirement to delete");
      return;
    }
    setIsBulkDeleteDialogOpen(true);
  };

  const handleConfirmBulkDelete = async () => {
    setIsDeleting(true);
    
    try {
      let successCount = 0;
      let failureCount = 0;
      
      for (const requirementId of selectedRequirements) {
        try {
          await axios.post(
            `${ENV.API_URL}/requirements/delete-by-requirementid/${requirementId}`
          );
          successCount++;
        } catch (error) {
          console.error(`Error deleting requirement ${requirementId}:`, error);
          failureCount++;
        }
      }
      
      if (successCount > 0) {
        toast.success(`Successfully deleted ${successCount} requirement(s)`);
      }
      
      if (failureCount > 0) {
        toast.error(`Failed to delete ${failureCount} requirement(s)`);
      }
      
      onDelete();
    } catch (error) {
      console.error("Error in bulk delete operation:", error);
      toast.error("An error occurred during bulk delete operation");
    } finally {
      setIsDeleting(false);
      setIsBulkDeleteDialogOpen(false);
    }
  };

  const handleCancelBulkDelete = () => {
    setIsBulkDeleteDialogOpen(false);
  };

  const displayedTotal = displayTotal !== undefined ? displayTotal : allRequirementsCount;

  // Add New Requirement Modal handlers
  const openAddRequirementDialog = () => {
    // Reset form fields
    setRequirementName("");
    setRequirementDescription("");
    setUserStories([""]);
    setRequirementHeaders([
      { id: crypto.randomUUID(), name: "Functional Requirements", items: [""] }
    ]);
    setIsAddRequirementDialogOpen(true);
  };

  const handleAddUserStory = () => {
    setUserStories([...userStories, ""]);
  };

  const handleUserStoryChange = (index: number, value: string) => {
    const updatedStories = [...userStories];
    updatedStories[index] = value;
    setUserStories(updatedStories);
  };

  const handleRemoveUserStory = (index: number) => {
    if (userStories.length > 1) {
      const updatedStories = userStories.filter((_, i) => i !== index);
      setUserStories(updatedStories);
    }
  };

  const handleAddHeader = () => {
    setRequirementHeaders([
      ...requirementHeaders,
      { id: crypto.randomUUID(), name: "", items: [""] }
    ]);
  };

  const handleHeaderNameChange = (index: number, value: string) => {
    const updatedHeaders = [...requirementHeaders];
    updatedHeaders[index].name = value;
    setRequirementHeaders(updatedHeaders);
  };

  const handleRemoveHeader = (index: number) => {
    if (requirementHeaders.length > 1) {
      const updatedHeaders = requirementHeaders.filter((_, i) => i !== index);
      setRequirementHeaders(updatedHeaders);
    }
  };

  const handleAddHeaderItem = (headerIndex: number) => {
    const updatedHeaders = [...requirementHeaders];
    updatedHeaders[headerIndex].items.push("");
    setRequirementHeaders(updatedHeaders);
  };

  const handleHeaderItemChange = (headerIndex: number, itemIndex: number, value: string) => {
    const updatedHeaders = [...requirementHeaders];
    updatedHeaders[headerIndex].items[itemIndex] = value;
    setRequirementHeaders(updatedHeaders);
  };

  const handleRemoveHeaderItem = (headerIndex: number, itemIndex: number) => {
    if (requirementHeaders[headerIndex].items.length > 1) {
      const updatedHeaders = [...requirementHeaders];
      updatedHeaders[headerIndex].items = updatedHeaders[headerIndex].items.filter(
        (_, i) => i !== itemIndex
      );
      setRequirementHeaders(updatedHeaders);
    }
  };

  const handleSubmitRequirement = async () => {
    // Validate form
    if (!requirementName.trim()) {
      toast.error("Requirement name is required");
      return;
    }

    if (requirementName.length > 150) {
      toast.error("Requirement name must be 150 characters or less");
      return;
    }

    if (!requirementDescription.trim()) {
      toast.error("Requirement description is required");
      return;
    }

    const validUserStories = userStories.filter(story => story.trim() !== "");
    if (validUserStories.length === 0) {
      toast.error("At least one user story is required");
      return;
    }

    // Validate that all headers have names and items
    for (const header of requirementHeaders) {
      if (!header.name.trim()) {
        toast.error("All requirement headers must have a name");
        return;
      }

      const validItems = header.items.filter(item => item.trim() !== "");
      if (validItems.length === 0) {
        toast.error(`Header "${header.name}" must have at least one item`);
        return;
      }
    }

    setIsSubmitting(true);

    try {
      // Prepare payload
      const requirementsPayload: Record<string, string[]> = {};
      requirementHeaders.forEach(header => {
        // Convert header name to snake_case for the API
        const headerKey = header.name.toLowerCase().replace(/\s+/g, '_');
        requirementsPayload[headerKey] = header.items.filter(item => item.trim() !== "");
      });

      const payload = {
        requirementName: requirementName,
        requirementDescription: requirementDescription,
        userStories: validUserStories,
        requirements: requirementsPayload
      };

      // Send to API to add requirement
      const response = await axios.post(
        `${ENV.API_URL}/requirements/add-requirement-by-usecaseid/${usecaseId}`,
        payload
      );

      if (response.status === 201) {
        toast.success("Requirement added successfully");
        
        // Extract the requirementId from the response
        const newRequirementId = response.data.requirementId;
        
        // Generate scenarios based on the new requirement using the specific requirementId
        try {
          const scenarioResponse = await axios.post(
            `${ENV.API_URL}/scenario-management/generate`,
            { requirement_ids: [newRequirementId] }
          );
          
          if (scenarioResponse.status === 202) {
            toast.success("Scenario generation started");
          }
        } catch (scenarioError) {
          console.error("Error generating scenarios:", scenarioError);
          toast.error("Failed to generate scenarios");
        }
        
        setIsAddRequirementDialogOpen(false);
        
        // Trigger refresh
        if (onRequirementAdded) {
          onRequirementAdded();
        }
      }
    } catch (error) {
      console.error("Error adding requirement:", error);
      toast.error("Failed to add requirement");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col">
      {/* Header with title and expand button */}
      <div className="flex justify-between items-center p-4 pb-2">
        <h2 className="text-lg font-semibold">Requirements Captured</h2>
        {/* <Button
          variant="ghost"
          size="sm"
          onClick={onToggleMaximize}
          className="h-8 w-8 p-0"
        >
          {isMaximized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
        </Button> */}
      </div>
      
      {/* Actions bar with select all and buttons */}
      <div className="flex justify-between items-center px-4 pb-2">
        <div className="flex items-center gap-2">
          <Checkbox 
            checked={selectedCount > 0 && selectedCount === totalCount}
            onCheckedChange={onSelectAll}
            aria-label="Select all requirements"
          />
          <label className="text-sm text-gray-600">
            Select All ({displayedTotal})
          </label>
        </div>

        <div className="flex items-center gap-2">
          <Button 
            className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
            size="sm"
            onClick={onShowGrid}
          >
            <Grid className="h-4 w-4 mr-2" />
            Grid
          </Button>
          <Button 
            className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
            size="sm"
            onClick={openAddRequirementDialog}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add New
          </Button>
          <Button 
            onClick={onRegenerate}
            disabled={true}
            size="sm"
            className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Regenerate
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
                size="sm"
                disabled={true}
              >
                <CheckSquare className="h-4 w-4 mr-2" />
                Change Status
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onSelect={() => {}}>
                Mark as Completed
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => {}}>
                Mark as Needs Review
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => {}}>
                Mark as In Progress
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button 
            onClick={handleDeleteClick}
            disabled={selectedCount === 0}
            variant="destructive"
            size="sm"
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Delete Selected
          </Button>
        </div>
      </div>

      {/* Bulk Delete Dialog */}
      <Dialog open={isBulkDeleteDialogOpen} onOpenChange={setIsBulkDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Bulk Deletion</DialogTitle>
            <DialogDescription>
              <p className="mt-2 text-gray-600">
                You are about to delete {selectedCount} requirement{selectedCount !== 1 ? 's' : ''}.
              </p>
              <p className="mt-2 text-gray-600">
                This action will permanently remove these requirements and all related information.
              </p>
              <p className="mt-2 text-gray-600">
                This will affect test scenarios, traceability, and coverage metrics that depend on these requirements.
              </p>
              <p className="mt-4 font-medium text-red-600">
                Are you sure you want to delete {selectedCount} requirement{selectedCount !== 1 ? 's' : ''}?
              </p>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={handleCancelBulkDelete} disabled={isDeleting}>Cancel</Button>
            <Button 
              variant="destructive" 
              onClick={handleConfirmBulkDelete}
              disabled={isDeleting}
            >
              {isDeleting ? "Deleting..." : "Delete Requirements"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add New Requirement Dialog */}
      <Dialog open={isAddRequirementDialogOpen} onOpenChange={setIsAddRequirementDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add New Requirement</DialogTitle>
            <DialogDescription>
              Create a new requirement with user journeys and detailed requirements.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-6 py-4 px-7">
            {/* Requirement Name */}
            <div className="grid gap-2">
              <Label htmlFor="requirementName">User Journey Name <span className="text-red-500">*</span></Label>
              <Input 
                id="requirementName" 
                value={requirementName}
                onChange={(e) => setRequirementName(e.target.value)}
                placeholder="Enter journey name (max 150 chars)"
                maxLength={150}
                className="w-full"
              />
              <div className="text-xs text-gray-500 flex justify-end">
                {requirementName.length}/150
              </div>
            </div>
            
            {/* Requirement Description */}
            <div className="grid gap-2">
              <Label htmlFor="requirementDescription">User Journey Description <span className="text-red-500">*</span></Label>
              <Textarea 
                id="requirementDescription" 
                value={requirementDescription}
                onChange={(e) => setRequirementDescription(e.target.value)}
                placeholder="Enter a detailed description of the user journey"
                className="w-full"
                rows={3}
              />
            </div>
            
            {/* User Stories */}
            <div className="grid gap-2">
              <div className="flex justify-between items-center">
                <Label>User Stories <span className="text-red-500">*</span></Label>
                <Button 
                  type="button" 
                  size="sm" 
                  variant="outline"
                  onClick={handleAddUserStory}
                  className="h-8"
                >
                  <Plus className="h-4 w-4 mr-1" /> Add Story
                </Button>
              </div>
              <div className="space-y-3">
                {userStories.map((story, index) => (
                  <div key={index} className="flex gap-2">
                    <Input 
                      value={story}
                      onChange={(e) => handleUserStoryChange(index, e.target.value)}
                      placeholder={`As a user, I want to...`}
                      className="flex-1"
                    />
                    <Button 
                      type="button" 
                      size="icon"
                      variant="ghost"
                      onClick={() => handleRemoveUserStory(index)}
                      disabled={userStories.length <= 1}
                      className="h-10 w-10"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Requirement Headers */}
            <div className="grid gap-4">
              <div className="flex justify-between items-center">
                <Label>Requirements <span className="text-red-500">*</span></Label>
                <Button 
                  type="button" 
                  size="sm" 
                  variant="outline"
                  onClick={handleAddHeader}
                  className="h-8"
                >
                  <Plus className="h-4 w-4 mr-1" /> Add Category
                </Button>
              </div>
              
              {requirementHeaders.map((header, headerIndex) => (
                <div key={header.id} className="border p-4 rounded-md">
                  <div className="flex gap-2 mb-3 items-center">
                    <Input 
                      value={header.name}
                      onChange={(e) => handleHeaderNameChange(headerIndex, e.target.value)}
                      placeholder="Category Name (e.g., Functional Requirements)"
                      className="flex-1"
                    />
                    <Button 
                      type="button" 
                      size="icon"
                      variant="ghost"
                      onClick={() => handleRemoveHeader(headerIndex)}
                      disabled={requirementHeaders.length <= 1}
                      className="h-10 w-10"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="space-y-3 pl-4 border-l-2 border-gray-200">
                    {header.items.map((item, itemIndex) => (
                      <div key={`${header.id}-${itemIndex}`} className="flex gap-2">
                        <Input 
                          value={item}
                          onChange={(e) => handleHeaderItemChange(headerIndex, itemIndex, e.target.value)}
                          placeholder={`Add ${header.name}`}
                          className="flex-1"
                        />
                        <Button 
                          type="button" 
                          size="icon"
                          variant="ghost"
                          onClick={() => handleRemoveHeaderItem(headerIndex, itemIndex)}
                          disabled={header.items.length <= 1}
                          className="h-10 w-10"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                    
                    <Button 
                      type="button" 
                      size="sm" 
                      variant="outline"
                      onClick={() => handleAddHeaderItem(headerIndex)}
                      className="mt-2"
                    >
                      <Plus className="h-4 w-4 mr-1" /> Add Item
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsAddRequirementDialogOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSubmitRequirement}
              disabled={isSubmitting}
              className="bg-blue-500 hover:bg-blue-600"
            >
              {isSubmitting ? "Adding..." : "Add Requirement"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
