import { CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { MapPin, Edit, Save, X, ChevronDown, ChevronRight, Trash } from "lucide-react";
import { type Requirement } from "./types";
import { getStatusVariant } from "./requirementUtils";
import { useState, useEffect } from "react";
import axios from "axios";
import { toast } from "sonner";
import { ENV } from "@/config/env";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface RequirementHeaderProps {
  requirement: Requirement;
  isEditing: boolean;
  isExpanded: boolean;
  isSelected: boolean;
  onToggleSelect: (checked: boolean) => void;
  onEdit: (e: React.MouseEvent) => void;
  onSave: (e: React.MouseEvent) => void;
  onCancel: (e: React.MouseEvent) => void;
  onClick: () => void;
  onDelete: () => void;
  onFunctionalAreaChange: (value: string) => void;
  onSourceChange?: (field: 'page' | 'paragraph', value: number) => void;
  onStatusChange?: (status: "completed" | "needs_review" | "in_progress") => void;
}

export const RequirementHeader = ({
  requirement,
  isEditing,
  isExpanded,
  isSelected,
  onToggleSelect,
  onEdit,
  onSave,
  onCancel,
  onClick,
  onDelete,
  onFunctionalAreaChange,
  onSourceChange,
  onStatusChange,
}: RequirementHeaderProps) => {
  // Local state to track the functional area value
  const [functionalArea, setFunctionalArea] = useState(requirement.functionalArea);
  const [isSaveDialogOpen, setIsSaveDialogOpen] = useState(false);
  const [pendingSaveEvent, setPendingSaveEvent] = useState<React.MouseEvent | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  // Update local state when the requirement changes
  useEffect(() => {
    setFunctionalArea(requirement.functionalArea);
  }, [requirement.functionalArea]);

  // Handle functional area change
  const handleFunctionalAreaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setFunctionalArea(newValue);
    onFunctionalAreaChange(newValue);
  };

  // Handle save button click
  const handleSaveClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setPendingSaveEvent(e);
    setIsSaveDialogOpen(true);
  };

  // Handle confirmation dialog confirm
  const handleConfirmSave = () => {
    setIsSaveDialogOpen(false);
    if (pendingSaveEvent) {
      onSave(pendingSaveEvent);
    }
    setPendingSaveEvent(null);
  };

  // Handle confirmation dialog cancel
  const handleCancelSave = () => {
    setIsSaveDialogOpen(false);
    setPendingSaveEvent(null);
  };

  // Handle delete button click
  const handleDeleteClick = async (e: React.MouseEvent) => {
    e.stopPropagation();
    console.log("Requirement ID:", requirement.id);
    setIsDeleteDialogOpen(true);
  };

  // Handle confirmation dialog confirm
  const handleConfirmDelete = async () => {
    setIsDeleteDialogOpen(false);
    try {
      const response = await axios.post(
        `${ENV.API_URL}/requirements/delete-by-requirementid/${requirement.id}`
      );
      
      toast.success(response.data.message || "Requirement successfully deleted");
      onDelete();
    } catch (error) {
      console.error("Error deleting requirement:", error);
      toast.error("Failed to delete requirement. Please try again.");
    }
  };

  // Handle confirmation dialog cancel
  const handleCancelDelete = () => {
    setIsDeleteDialogOpen(false);
  };

  return (
    <>
      <CardHeader 
        className="py-3 cursor-pointer hover:bg-gray-50"
        onClick={onClick}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Checkbox
              checked={isSelected}
              onCheckedChange={onToggleSelect}
              onClick={(e) => e.stopPropagation()}
            />
            <div className="flex items-center gap-2">
              <Badge variant="outline">{requirement.requirementId}</Badge>
              {isEditing ? (
                <Input
                  value={functionalArea}
                  onChange={handleFunctionalAreaChange}
                  className="w-64"
                  onClick={(e) => e.stopPropagation()}
                />
              ) : (
                <CardTitle className="text-lg">{functionalArea}</CardTitle>
              )}
            </div>
          </div>
          <div className="flex items-center gap-4">
            {/* <div className="flex items-center gap-1 text-gray-500">
              <MapPin className="h-4 w-4" />
              {isEditing ? (
                <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                  <span className="text-xs">Page</span>
                  <Input
                    type="number"
                    value={requirement.source.page}
                    onChange={(e) => onSourceChange?.('page', Number(e.target.value))}
                    className="w-16 h-7 text-xs"
                  />
                  <span className="text-xs">¶</span>
                  <Input
                    type="number"
                    value={requirement.source.paragraph}
                    onChange={(e) => onSourceChange?.('paragraph', Number(e.target.value))}
                    className="w-16 h-7 text-xs"
                  />
                </div>
              ) : (
                <span className="text-xs">
                  Page {requirement.source.page}, ¶{requirement.source.paragraph}
                </span>
              )}
            </div> */}
            {isEditing ? (
              <div onClick={(e) => e.stopPropagation()}>
                <Select
                  value={requirement.status}
                  onValueChange={onStatusChange}
                >
                  <SelectTrigger className="w-[140px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="needs_review">Needs Review</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            ) : (
              <Badge variant={getStatusVariant(requirement.status)}>
                {requirement.status.replace("_", " ")}
              </Badge>
            )}
            {isEditing ? (
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={(e) => {
                    e.stopPropagation();
                    onCancel(e);
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={handleSaveClick}
                >
                  <Save className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    // onEdit(e);
                    // Edit functionality disabled
                  }}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleDeleteClick}
                  className="text-gray-500 hover:text-red-500"
                >
                  <Trash className="h-4 w-4" />
                </Button>
              </div>
            )}
            {isExpanded ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronRight className="h-4 w-4" />
            )}
          </div>
        </div>
      </CardHeader>

      {/* Save Confirmation Dialog */}
      <Dialog open={isSaveDialogOpen} onOpenChange={setIsSaveDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Changes</DialogTitle>
            <DialogDescription>
              <p className="mt-2 text-gray-600">
                Modifying requirement content may impact related test scenarios and other downstream artifacts.
              </p>
              <p className="mt-2 text-gray-600">
                These changes could affect test coverage and traceability. Please ensure all stakeholders are informed of these changes.
              </p>
              <p className="mt-4 font-medium">
                Are you sure you want to save these changes?
              </p>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={handleCancelSave}>Cancel</Button>
            <Button onClick={handleConfirmSave}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              <p className="mt-2 text-gray-600">
                Deleting this requirement will permanently remove it and all related information.
              </p>
              <p className="mt-2 text-gray-600">
                This will affect test scenarios, traceability, and coverage metrics that depend on this requirement.
              </p>
              <p className="mt-4 font-medium text-red-600">
                Are you sure you want to delete this requirement?
              </p>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={handleCancelDelete}>Cancel</Button>
            <Button variant="destructive" onClick={handleConfirmDelete}>Delete Requirement</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};
