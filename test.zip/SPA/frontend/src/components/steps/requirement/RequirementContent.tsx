import { useState, useEffect } from "react";
import { CardContent } from "@/components/ui/card";
import { BusinessRule, DataElement, type Requirement } from "./types";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Trash } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";

interface RequirementContentProps {
  requirement: Requirement;
  isEditing?: boolean;
  onUpdateRequirement?: (key: string, value: any) => void;
  onUpdateUserStories?: (stories: string[]) => string[];
  onUpdateBusinessRules?: (rules: BusinessRule[]) => BusinessRule[];
  onUpdateDataElements?: (elements: DataElement[]) => DataElement[];
}

export const RequirementContent = ({ 
  requirement,
  isEditing = false,
  onUpdateRequirement
}: RequirementContentProps) => {
  const [isAddItemDialogOpen, setIsAddItemDialogOpen] = useState(false);
  const [currentSection, setCurrentSection] = useState<string>('');
  const [newItemValue, setNewItemValue] = useState('');
  
  // Create a local copy of the requirement that we can modify
  const [localRequirement, setLocalRequirement] = useState<Requirement>(requirement);
  
  // Update local state when the requirement prop changes
  useEffect(() => {
    setLocalRequirement(requirement);
  }, [requirement]);
  
  // Handle adding a new item to a section
  const handleAddItem = () => {
    if (!currentSection || !newItemValue.trim()) return;
    
    const updatedItems = [...(localRequirement[currentSection] || [])];
    updatedItems.push({
      id: `${currentSection}${updatedItems.length + 1}`,
      description: newItemValue.trim()
    });
    
    setLocalRequirement({
      ...localRequirement,
      [currentSection]: updatedItems
    });
    
    if (onUpdateRequirement) {
      onUpdateRequirement(currentSection, updatedItems);
    }
    
    setNewItemValue('');
    setIsAddItemDialogOpen(false);
  };
  
  // Handle updating an item in a section
  const handleUpdateItem = (section: string, index: number, value: string) => {
    const updatedItems = [...localRequirement[section]];
    
    if (typeof updatedItems[index] === 'string') {
      updatedItems[index] = value;
    } else {
      updatedItems[index] = { ...updatedItems[index], description: value };
    }
    
    setLocalRequirement({
      ...localRequirement,
      [section]: updatedItems
    });
    
    if (onUpdateRequirement) {
      onUpdateRequirement(section, updatedItems);
    }
  };
  
  // Handle deleting an item from a section
  const handleDeleteItem = (section: string, index: number) => {
    const updatedItems = localRequirement[section].filter((_, i) => i !== index);
    
    setLocalRequirement({
      ...localRequirement,
      [section]: updatedItems
    });
    
    if (onUpdateRequirement) {
      onUpdateRequirement(section, updatedItems);
    }
  };
  
  // Open the add item dialog for a specific section
  const openAddItemDialog = (section: string) => {
    setCurrentSection(section);
    setNewItemValue('');
    setIsAddItemDialogOpen(true);
  };
  
  // Render all sections dynamically
  const renderSections = () => {
    // These are the base fields that should not be rendered as sections
    const baseFields = [
      'id', 'requirementId', 'functionalArea', 'description', 'status', 
      'confidence', 'source', 'is_deleted'
    ];
    
    // Get all keys that should be rendered as sections
    const sectionKeys = Object.keys(localRequirement).filter(key => 
      !baseFields.includes(key) && 
      localRequirement[key] !== undefined && 
      localRequirement[key] !== null
    );
    
    // Sort sections to ensure consistent order
    // Put userStories at the top
    sectionKeys.sort((a, b) => {
      if (a === 'userStories') return -1;
      if (b === 'userStories') return 1;
      return a.localeCompare(b);
    });
    
    return sectionKeys.map(key => {
      const items = localRequirement[key];
      
      // Format the key for display (convert camelCase to Title Case)
      const formattedKey = key === 'userStories' ? 'User Stories' :
        key.replace(/([A-Z])/g, ' $1').replace(/^./, c => c.toUpperCase());
      
      return (
        <div key={key} className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-sm font-semibold text-gray-900 border-b pb-1">
              {formattedKey}
            </h4>
            {isEditing && Array.isArray(items) && (
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => openAddItemDialog(key)}
              >
                <Plus className="h-4 w-4 mr-1" /> Add
              </Button>
            )}
          </div>
          
          {/* Render content based on type */}
          {Array.isArray(items) ? (
            // Array items
            items.length > 0 ? (
              <div className="space-y-2">
                {items.map((item, index) => (
                  <div key={index} className="py-2 border-b border-gray-100">
                    {isEditing ? (
                      <div className="flex items-center">
                        <Input 
                          value={typeof item === 'string' ? item : item.description}
                          onChange={(e) => handleUpdateItem(key, index, e.target.value)}
                          className="flex-1"
                        />
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleDeleteItem(key, index)}
                          className="text-red-500 ml-2"
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    ) : (
                      <p className="text-sm text-gray-600 pl-2">
                        {typeof item === 'string' ? item : item.description}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-500 italic pl-2">No {formattedKey.toLowerCase()} defined</p>
            )
          ) : (
            // Object or other type
            <p className="text-sm text-gray-600 pl-2">
              {typeof items === 'object' ? JSON.stringify(items) : String(items)}
            </p>
          )}
        </div>
      );
    });
  };
  
  return (
    <CardContent className="p-4">
      <div className="space-y-6">
        {/* Always render Description at the top */}
        <div className="mb-6">
          <h4 className="text-base font-semibold text-gray-900 border-b pb-1">Description</h4>
          <p className="text-sm text-gray-600 leading-relaxed pl-1 mt-2">
            {requirement.description || "No description available"}
          </p>
        </div>
        
        {/* Then render all other sections */}
        {renderSections()}
      </div>
      
      {/* Add Item Dialog */}
      <Dialog open={isAddItemDialogOpen} onOpenChange={setIsAddItemDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              Add {currentSection?.replace(/([A-Z])/g, ' $1').replace(/^./, c => c.toUpperCase())}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="newItem">Item</Label>
              <Textarea
                id="newItem"
                placeholder="Enter item"
                value={newItemValue}
                onChange={(e) => setNewItemValue(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddItemDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddItem}>Add</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </CardContent>
  );
};
