import { useState, useEffect } from "react";
import { toast } from "sonner";
import { type Requirement } from "../types";
import axios from "axios";
import { ENV } from "@/config/env";

export const useRequirements = (
  paginatedRequirements: Requirement[] = [], 
  allRequirements: Requirement[] = []
) => {
  const [requirements, setRequirements] = useState<Requirement[]>(paginatedRequirements);
  const [editingRequirement, setEditingRequirement] = useState<string | null>(null);
  const [selectedRequirements, setSelectedRequirements] = useState<string[]>([]);
  const [expandedRequirement, setExpandedRequirement] = useState<string | null>(null);

  useEffect(() => {
    setRequirements(paginatedRequirements);
  }, [paginatedRequirements]);

  const handleSelectRequirement = (requirementId: string, checked: boolean) => {
    console.log(`Selection change for ${requirementId}: ${checked}`);
    
    setSelectedRequirements((prev) => {
      if (checked) {
        if (!prev.includes(requirementId)) {
          const updated = [...prev, requirementId];
          console.log("Updated selectedRequirements:", updated);
          return updated;
        }
      } else {
        const updated = prev.filter((id) => id !== requirementId);
        console.log("Updated selectedRequirements:", updated);
        return updated;
      }
      return prev;
    });
  };

  const handleSelectAll = (checked: boolean) => {
    console.log(`Select all requirements: ${checked}`);
    
    if (checked) {
      const allIds = requirements.map((req) => req.id);
      console.log("Selecting all requirement IDs:", allIds);
      setSelectedRequirements(allIds);
    } else {
      console.log("Clearing all selected requirements");
      setSelectedRequirements([]);
    }
  };

  const handleEditRequirement = (requirement: Requirement, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingRequirement(requirement.id);
  };

  const handleSaveRequirement = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingRequirement(null);
    toast.success("Changes saved successfully");
  };

  const handleCancelEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingRequirement(null);
  };

  const handleDeleteRequirement = async (requirementId: string) => {
    try {
      // Call the API to toggle deletion status
      const response = await axios.post(
        `${ENV.API_URL}/requirements/delete-by-requirementid/${requirementId}`
      );
      
      // Update the requirements state with the filtered requirements
      setRequirements(prevReqs => {
        const updatedReqs = prevReqs.filter(req => req.id !== requirementId);
        console.log('Requirements after deletion:', updatedReqs);
        return updatedReqs;
      });

      // Clear any related states
      setSelectedRequirements(prev => prev.filter(id => id !== requirementId));
      setExpandedRequirement(prev => prev === requirementId ? null : prev);
      setEditingRequirement(prev => prev === requirementId ? null : prev);

      // Show success message from API or default
      toast.success(response.data.message || "Requirement successfully deleted");
    } catch (error) {
      console.error(`Error deleting requirement ${requirementId}:`, error);
      toast.error("Failed to delete requirement. Please try again.");
    }
  };

  const handleBulkDelete = async () => {
    if (selectedRequirements.length === 0) {
      toast.error("Please select at least one requirement to delete");
      return;
    }
    
    console.log("Starting bulk delete for requirements:", selectedRequirements);
    
    // Track success and failures
    let successCount = 0;
    let failureCount = 0;
    const successfullyDeletedIds = [];
    
    // Process each selected requirement with API calls
    for (const requirementId of selectedRequirements) {
      console.log(`Processing deletion for requirement ID: ${requirementId}`);
      
      try {
        const apiUrl = `${ENV.API_URL}/requirements/delete-by-requirementid/${requirementId}`;
        console.log("Calling API:", apiUrl);
        
        const response = await axios.post(apiUrl);
        console.log(`API response for ${requirementId}:`, response.data);
        
        successCount++;
        successfullyDeletedIds.push(requirementId);
      } catch (error) {
        console.error(`Error deleting requirement ${requirementId}:`, error);
        failureCount++;
      }
    }
    
    // After all API calls, update the UI state once
    if (successfullyDeletedIds.length > 0) {
      console.log("Removing successfully deleted requirements from UI:", successfullyDeletedIds);
      setRequirements(prevReqs => 
        prevReqs.filter(req => !successfullyDeletedIds.includes(req.id))
      );
    }
    
    // Show appropriate toast messages
    if (successCount > 0) {
      toast.success(`Successfully deleted ${successCount} requirement(s)`);
    }
    
    if (failureCount > 0) {
      toast.error(`Failed to delete ${failureCount} requirement(s)`);
    }
    
    // Clear selection after deletion
    setSelectedRequirements([]);
  };

  const handleBulkStatusChange = (newStatus: "completed" | "needs_review" | "in_progress") => {
    if (selectedRequirements.length === 0) {
      toast.error("Please select at least one requirement");
      return;
    }

    setRequirements(prevReqs =>
      prevReqs.map(req =>
        selectedRequirements.includes(req.id)
          ? { ...req, status: newStatus }
          : req
      )
    );

    toast.success(`Updated status to ${newStatus.replace("_", " ")} for ${selectedRequirements.length} requirements`);
  };

  const handleStatusChange = (requirementId: string, newStatus: "completed" | "needs_review" | "in_progress") => {
    setRequirements(prevReqs =>
      prevReqs.map(req =>
        req.id === requirementId
          ? { ...req, status: newStatus }
          : req
      )
    );
    toast.success(`Status updated to ${newStatus.replace("_", " ")}`);
  };

  const handleRequirementClick = (requirement: Requirement) => {
    setExpandedRequirement(expandedRequirement === requirement.id ? null : requirement.id);
  };

  const handleFunctionalAreaChange = (requirementId: string, value: string) => {
    setRequirements(prevReqs =>
      prevReqs.map(req =>
        req.id === requirementId
          ? { ...req, functionalArea: value }
          : req
      )
    );
  };

  const handleSourceChange = (requirementId: string, field: 'page' | 'paragraph', value: number) => {
    setRequirements(prevReqs =>
      prevReqs.map(req =>
        req.id === requirementId
          ? {
              ...req,
              source: {
                ...req.source,
                [field]: value
              }
            }
          : req
      )
    );
  };

  const handleUserStoriesChange = (requirementId: string, stories: string[]) => {
    setRequirements(prev => 
      prev.map(req => 
        req.id === requirementId 
          ? { ...req, userStories: stories } 
          : req
      )
    );
  };

  return {
    requirements,
    setRequirements,
    editingRequirement,
    selectedRequirements,
    setSelectedRequirements,
    expandedRequirement,
    handleSelectRequirement,
    handleSelectAll,
    handleEditRequirement,
    handleSaveRequirement,
    handleCancelEdit,
    handleDeleteRequirement,
    handleBulkDelete,
    handleBulkStatusChange,
    handleStatusChange,
    handleRequirementClick,
    handleFunctionalAreaChange,
    handleSourceChange,
    handleUserStoriesChange,
  };
};
