import { Button } from "@/components/ui/button";
import { Plus, Trash } from "lucide-react";
import { Input } from "@/components/ui/input";
import { type DataElement } from "../types";

interface DataElementsSectionProps {
  elements: DataElement[];
  isEditing?: boolean;
  onAddClick?: () => void;
  onDelete?: (id: string) => void;
  onUpdate?: (id: string, name: string) => void;
}

export const DataElementsSection = ({ 
  elements, 
  isEditing = false,
  onAddClick, 
  onDelete,
  onUpdate
}: DataElementsSectionProps) => {
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-md font-semibold">Data Elements</h3>
        {isEditing && (
          <Button 
            variant="ghost" 
            size="sm"
            onClick={onAddClick}
          >
            <Plus className="h-4 w-4 mr-1" /> Add
          </Button>
        )}
      </div>
      {elements.length > 0 ? (
        elements.map((element) => (
          <div key={element.id} className="py-2 border-b border-gray-100 flex justify-between items-center">
            {isEditing ? (
              <Input 
                value={element.name} 
                onChange={(e) => onUpdate?.(element.id, e.target.value)}
                className="flex-1"
              />
            ) : (
              <p className="text-sm">{element.name}</p>
            )}
            {isEditing && (
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => onDelete?.(element.id)}
                className="text-red-500"
              >
                <Trash className="h-4 w-4" />
              </Button>
            )}
          </div>
        ))
      ) : (
        <p className="text-sm text-gray-500 italic">No data elements defined</p>
      )}
    </div>
  );
};
