import { Button } from "@/components/ui/button";
import { Plus, Trash } from "lucide-react";
import { Input } from "@/components/ui/input";
import { type BusinessRule } from "../types";

interface BusinessRulesSectionProps {
  rules: BusinessRule[];
  isEditing?: boolean;
  onAddClick?: () => void;
  onDelete?: (id: string) => void;
  onUpdate?: (id: string, description: string) => void;
}

export const BusinessRulesSection = ({ 
  rules, 
  isEditing = false,
  onAddClick, 
  onDelete,
  onUpdate
}: BusinessRulesSectionProps) => {
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-md font-semibold">Business Rules</h3>
        {isEditing && (
          <Button 
            variant="ghost" 
            size="sm"
            onClick={onAddClick}
          >
            <Plus className="h-4 w-4 mr-1" /> Add
          </Button>
        )}
      </div>
      {rules.length > 0 ? (
        rules.map((rule) => (
          <div key={rule.id} className="py-2 border-b border-gray-100 flex justify-between items-center">
            {isEditing ? (
              <Input 
                value={rule.description} 
                onChange={(e) => onUpdate?.(rule.id, e.target.value)}
                className="flex-1"
              />
            ) : (
              <p className="text-sm">{rule.description}</p>
            )}
            {isEditing && (
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => onDelete?.(rule.id)}
                className="text-red-500"
              >
                <Trash className="h-4 w-4" />
              </Button>
            )}
          </div>
        ))
      ) : (
        <p className="text-sm text-gray-500 italic">No business rules defined</p>
      )}
    </div>
  );
};
