import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { API_ENDPOINTS } from "@/config/api";
import { Loader2 } from "lucide-react";
import axios from "axios";
import { ENV } from "@/config/env";

interface UseCase {
  usecaseId: number;
  usecaseName: string;
  createdAt: string;
  updatedAt: string;
  product?: string;
  subProduct?: string;
  domain?: string;
}

interface ExistingUseCaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectUseCase: (useCaseId: string, useCaseName: string, product: string, subProduct: string, domain: string) => void;
}

export const ExistingUseCaseModal = ({
  isOpen,
  onClose,
  onSelectUseCase,
}: ExistingUseCaseModalProps) => {
  const [selectedUseCaseId, setSelectedUseCaseId] = useState<number | null>(null);
  const [useCases, setUseCases] = useState<UseCase[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch existing bundles when modal opens
  useEffect(() => {
    if (isOpen) {
      fetchUseCases();
    }
  }, [isOpen]);

  const fetchUseCases = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Get current user ID from session storage
      const userEmail = sessionStorage.getItem('userEmail');
      
      if (!userEmail) {
        throw new Error('User email not found in session storage');
      }
      
      // Fetch the user's usecases
      const response = await fetch(`${API_ENDPOINTS.getUserUseCases}/${userEmail}`);
      
      if (!response.ok) {
        throw new Error(`Failed to fetch bundles: ${response.statusText}`);
      }
      
      const data: UseCase[] = await response.json();
      
      // For each use case, fetch the metadata (product, subProduct, domain)
      const useCasesWithMetadata = await Promise.all(
        data.map(async (useCase) => {
          try {
            const metadataResponse = await axios.get(
              `${ENV.API_URL}/usecase-management/get-usecase-status/${useCase.usecaseId}`
            );
            console.log(metadataResponse.data.product, metadataResponse.data.sub_product, metadataResponse.data.domain, "metadataResponse.data.product, metadataResponse.data.subProduct, metadataResponse.data.domain");
            return {
              ...useCase,
              product: metadataResponse.data.product,
              subProduct: metadataResponse.data.sub_product,
              domain: metadataResponse.data.domain,
            };
          } catch (err) {
            console.error(`Error fetching metadata for use case ${useCase.usecaseId}:`, err);
            return useCase; // Return the original use case without metadata
          }
        })
      );
      
      setUseCases(useCasesWithMetadata);
    } catch (err) {
      console.error("Error fetching bundles:", err);
      setError("Failed to load existing bundle. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleConfirm = () => {
    if (selectedUseCaseId) {
      // Find the selected bundle object
      const useCase = useCases.find(uc => uc.usecaseId === selectedUseCaseId);
      console.log("Selected use case with metadata:", useCase);
      
      if (useCase) {
        onSelectUseCase(
          useCase.usecaseId.toString(), 
          useCase.usecaseName,
          useCase.product,
          useCase.subProduct,
          useCase.domain
        );
        onClose();
      }
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Select Existing Bundle</DialogTitle>
        </DialogHeader>
        
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : error ? (
          <div className="text-red-500 text-center py-4">
            {error}
            <Button 
              variant="outline" 
              className="mt-2 mx-auto block" 
              onClick={fetchUseCases}
            >
              Retry
            </Button>
          </div>
        ) : useCases.length === 0 ? (
          <div className="text-center py-4 text-gray-500">
            No existing bundles found. Please create a new bundle.
          </div>
        ) : (
          <div className="max-h-[40vh] overflow-y-auto pr-2">
            <RadioGroup
              value={selectedUseCaseId?.toString() || ""}
              onValueChange={(value) => setSelectedUseCaseId(parseInt(value))}
              className="gap-4"
            >
              {useCases.map((useCase) => (
                <div key={useCase.usecaseId} className="flex items-center space-x-2 border p-3 rounded-md">
                  <RadioGroupItem value={useCase.usecaseId.toString()} id={`usecase-${useCase.usecaseId}`} />
                  <Label htmlFor={`usecase-${useCase.usecaseId}`} className="flex-1 cursor-pointer">
                    <div className="font-medium">{useCase.usecaseName}</div>
                    <div className="text-sm text-gray-500">
                      Created: {new Date(useCase.createdAt).toLocaleDateString()}
                    </div>
                    {(useCase.product || useCase.subProduct || useCase.domain) && (
                      <div className="text-xs text-gray-500 mt-1">
                        {useCase.product && <span className="mr-2">Product: {useCase.product}</span>}
                        {useCase.subProduct && <span className="mr-2">Sub-Product: {useCase.subProduct}</span>}
                        {useCase.domain && <span>Domain: {useCase.domain}</span>}
                      </div>
                    )}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>
        )}

        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button 
            onClick={handleConfirm} 
            disabled={!selectedUseCaseId || isLoading}
          >
            Select Bundle
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}; 