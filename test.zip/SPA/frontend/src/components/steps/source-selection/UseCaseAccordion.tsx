import { useState, useEffect, useRef } from "react";
import { ChevronDown, ChevronUp, Loader2, XCircle, CheckCircle, RefreshCw, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { API_ENDPOINTS } from "@/config/api";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { UploadedFile } from "./types";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface UseCase {
  usecaseId: number;
  usecaseName: string;
  createdAt: string;
  updatedAt: string;
  status?: string;
  files?: UploadedFile[];
  workflowStatus?: {
    text_extraction: string;
    requirement_generation: string;
    scenario_generation: string;
    test_case_generation: string;
    test_data_generation: string;
    test_script_generation: string;
  };
  product?: string;
  subProduct?: string;
  domain?: string;
  filesLoaded?: boolean; // New field to track if files are loaded
}

interface UseCaseAccordionProps {
  selectedFiles: string[];
  onFileSelect: (fileId: string, isSelected: boolean, silent?: boolean) => void;
  onRetry: (fileId: string) => void;
  onDelete: (fileId: string) => void;
  allowMultiSelect: boolean;
  onUseCaseSelect?: (useCaseId: string, useCaseName: string, type: string, product?: string, subProduct?: string, domain?: string) => void;
}

export const UseCaseAccordion = ({
  selectedFiles,
  onFileSelect,
  onRetry,
  onDelete,
  allowMultiSelect,
  onUseCaseSelect
}: UseCaseAccordionProps) => {
  const [useCases, setUseCases] = useState<UseCase[]>([]);
  const [expandedUseCases, setExpandedUseCases] = useState<number[]>([]);
  const [selectedUseCases, setSelectedUseCases] = useState<number[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [loadingFiles, setLoadingFiles] = useState<number[]>([]);
  const useCasesRef = useRef<UseCase[]>([]);
  
  // Fix type definition for polling intervals
  const pollingIntervalsRef = useRef<{
    last: ReturnType<typeof setInterval> | null;
    others: ReturnType<typeof setInterval> | null;
  }>({
    last: null,
    others: null
  });

  // Update ref whenever useCases changes
  useEffect(() => {
    useCasesRef.current = useCases;
  }, [useCases]);

  // Initial data fetch
  useEffect(() => {
    fetchUseCases();
    
    // Clean up any existing intervals when component unmounts
    return () => {
      if (pollingIntervalsRef.current.last) {
        clearInterval(pollingIntervalsRef.current.last);
      }
      if (pollingIntervalsRef.current.others) {
        clearInterval(pollingIntervalsRef.current.others);
      }
    };
  }, []);

  // Set up polling whenever useCases changes
  useEffect(() => {
    // Clean up any existing intervals first
    if (pollingIntervalsRef.current.last) {
      clearInterval(pollingIntervalsRef.current.last);
      pollingIntervalsRef.current.last = null;
    }
    
    if (pollingIntervalsRef.current.others) {
      clearInterval(pollingIntervalsRef.current.others);
      pollingIntervalsRef.current.others = null;
    }
    
    // Only set up polling if we have useCases
    if (useCases.length === 0) {
      // console.log("No use cases available, skipping polling setup");
      return;
    }
    
    // console.log(`Setting up polling with ${useCases.length} use cases`);
    
    // Set up polling for last useCase
    pollingIntervalsRef.current.last = setInterval(() => {
      const currentUseCases = useCasesRef.current;
      if (currentUseCases.length === 0) return;
      
      // console.log("30-second interval triggered for last use case");
      const lastUseCase = currentUseCases[currentUseCases.length - 1];
      
      fetchUseCaseStatus(lastUseCase).then(updatedUseCase => {
        setUseCases(prev => 
          prev.map(uc => 
            uc.usecaseId === updatedUseCase.usecaseId ? 
              { ...updatedUseCase, files: uc.files || [], filesLoaded: uc.filesLoaded || false } : 
              uc
          )
        );
      }).catch(err => {
        console.error("Error updating last useCase status:", err);
      });
    }, 30000);
    
    // Set up polling for other useCases only if we have more than one
    if (useCases.length > 1) {
      // console.log("Setting up 1-minute polling interval for other use cases");
      
      pollingIntervalsRef.current.others = setInterval(() => {
        // console.log("1-minute interval triggered for other use cases");
        
        // Define a custom function to poll only other use cases
        const pollOtherUseCases = async () => {
          try {
            const currentUseCases = useCasesRef.current;
            if (currentUseCases.length <= 1) return;
            
            // Get all but the last use case
            const otherUseCases = currentUseCases.slice(0, -1);
            console.log(`Polling ${otherUseCases.length} other use cases`);
            
            // Fetch status updates for other use cases
            const updatedOtherUseCases = await Promise.all(
              otherUseCases.map(useCase => fetchUseCaseStatus(useCase))
            );
            
            // Update state while preserving the last use case and file data
            setUseCases(prev => {
              // Keep the last use case as is
              const lastUseCase = prev[prev.length - 1];
              
              // Map the updated use cases with preserved file data
              const updatedWithFiles = updatedOtherUseCases.map(updatedUseCase => {
                const existingUseCase = prev.find(uc => uc.usecaseId === updatedUseCase.usecaseId);
                return {
                  ...updatedUseCase,
                  files: existingUseCase?.files || [],
                  filesLoaded: existingUseCase?.filesLoaded || false
                };
              });
              
              // Return updated array with preserved last use case
              return [...updatedWithFiles, lastUseCase];
            });
          } catch (err) {
            console.error("Error polling other use cases:", err);
          }
        };
        
        // Execute the polling function
        pollOtherUseCases();
      }, 60000);
    }
    
    // Clean up when component unmounts or useCases changes
    return () => {
      if (pollingIntervalsRef.current.last) {
        clearInterval(pollingIntervalsRef.current.last);
      }
      if (pollingIntervalsRef.current.others) {
        clearInterval(pollingIntervalsRef.current.others);
      }
    };
  }, [useCases.length]); // Only depends on length change, not the entire array

  // Modified to lazy load files when expanding a usecase
  const toggleUseCase = (usecaseId: number) => {
    const isExpanding = !expandedUseCases.includes(usecaseId);
    
    setExpandedUseCases(prev => 
      isExpanding
        ? [...prev, usecaseId]
        : prev.filter(id => id !== usecaseId)
    );
    
    // If expanding this usecase, load its files
    if (isExpanding) {
      loadFilesForUseCase(usecaseId);
      
      // If this usecase is selected, ensure all its files are selected
      if (selectedUseCases.includes(usecaseId)) {
        const useCase = useCases.find(uc => uc.usecaseId === usecaseId);
        if (useCase && useCase.files) {
          useCase.files.forEach(file => {
            if (file.status !== "failed") {
              onFileSelect(file.id, true);
            }
          });
        }
      }
    }
  };

  const handleUseCaseSelect = (usecaseId: number, checked: boolean) => {
    if (!checked) {
      setSelectedUseCases(prev => prev.filter(id => id !== usecaseId));

      // Notify parent that NO bundles are selected if this was the last one
      if (selectedUseCases.length === 1 && selectedUseCases[0] === usecaseId) {
        // Call parent with null values to indicate nothing is selected
        if (onUseCaseSelect) {
          onUseCaseSelect(null, null, null, null, null, null);
        }
      }
    
      // Deselect all files in this bundle
      const useCase = useCases.find(uc => uc.usecaseId === usecaseId);
      if (useCase && useCase.files) {
        useCase.files.forEach(file => {
          onFileSelect(file.id, false, true);
        });
      }
      
      // Collapse when deselected
      setExpandedUseCases(prev => prev.filter(id => id !== usecaseId));
    } else {
      // If checking, implement radio button-like behavior
      // First update state to only the newly selected bundle
      setSelectedUseCases([usecaseId]);
      
      // Batch file selection changes and notify parent only once
      const filesToSelect: string[] = [];
      
      // First deselect all files from previously selected bundle
      selectedUseCases.forEach(prevUseCaseId => {
        const prevUseCase = useCases.find(uc => uc.usecaseId === prevUseCaseId);
        if (prevUseCase && prevUseCase.files) {
          prevUseCase.files.forEach(file => {
            onFileSelect(file.id, false);
          });
        }
      });
      
      // Make sure files are loaded for this usecase before selecting them
      const useCase = useCases.find(uc => uc.usecaseId === usecaseId);
      
      // If files aren't loaded yet, load them first
      if (useCase && !useCase.filesLoaded) {
        loadFilesForUseCase(usecaseId).then(() => {
          // After loading, select the files and notify parent
          const loadedUseCase = useCases.find(uc => uc.usecaseId === usecaseId);
          if (loadedUseCase && loadedUseCase.files) {
            loadedUseCase.files.forEach(file => {
              if (file.status !== "failed") {
                onFileSelect(file.id, true);
              }
            });
            
            if (onUseCaseSelect) {
              onUseCaseSelect(
                usecaseId.toString(), 
                loadedUseCase.usecaseName,
                "existing",
                loadedUseCase.product, 
                loadedUseCase.subProduct, 
                loadedUseCase.domain
              );
            }
          }
        });
      } else if (useCase && useCase.files) {
        // If files already loaded, select them directly
        useCase.files.forEach(file => {
          if (file.status !== "failed") {
            filesToSelect.push(file.id);
          }
        });
        
        // Now select all files
        filesToSelect.forEach(fileId => {
          onFileSelect(fileId, true);
        });
        
        // Notify parent component of selection AFTER selecting files
        if (onUseCaseSelect) {
          setTimeout(() => {
            onUseCaseSelect(
              usecaseId.toString(), 
              useCase.usecaseName,
              "existing",
              useCase.product, 
              useCase.subProduct, 
              useCase.domain
            );
          }, 0);
        }
      }
      
      // Ensure the useCase is expanded when selected
      if (!expandedUseCases.includes(usecaseId)) {
        setExpandedUseCases(prev => [...prev, usecaseId]);
      }
    }
  };

  const handleFileSelect = (fileId: string, checked: boolean, useCase: any, silent: boolean = false) => {
    // Return early if the bundle status is disabled
    if (isStatusDisabled(useCase.status)) {
      return;
    }
    
    onFileSelect(fileId, checked, silent);
    // When a file is selected, also select its bundle
    if (checked && onUseCaseSelect) {
      onUseCaseSelect(
        useCase.usecaseId.toString(), 
        useCase.usecaseName,
        "existing",
        useCase.product, 
        useCase.subProduct, 
        useCase.domain
      );
    }
  };

  // Helper function to determine overall workflow status
  const determineWorkflowStatus = (workflowStatus: any) => {
    if (!workflowStatus) {
      return "unknown";
    }
    
    const stages = [
      { name: "text_extraction", label: "Text Extraction" },
      { name: "requirement_generation", label: "Requirement Generation" },
      { name: "scenario_generation", label: "Scenario Generation" },
      { name: "test_case_generation", label: "Test Case Generation" },
      // { name: "test_data_generation", label: "Test Data Generation" },
      { name: "test_script_generation", label: "Test Script Generation" }
    ];
    
    // Case-insensitive check for "In Progress" states
    const inProgressStage = stages.find(stage => {
      const status = workflowStatus[stage.name];
      return status && (
        status === "In Progress" || 
        status === "in progress" || 
        status.toLowerCase() === "in progress"
      );
    });
    
    if (inProgressStage) return `${inProgressStage.label} - In Progress`;
    
    // Check if all stages are completed
    const allCompleted = stages.every(stage => 
      workflowStatus[stage.name] === "Completed");
    if (allCompleted) return "completed";
    
    // Find the first stage that failed
    const failedStage = stages.find(stage => 
      workflowStatus[stage.name] === "Failed");
    if (failedStage) return `${failedStage.label} - Failed`;
    
    // Check if all stages are in "Not Started" state
    const allNotStarted = stages.every(stage => 
      workflowStatus[stage.name] === "Not Started");
    if (allNotStarted) return "not-started";
    
    // Find the next stage that's "Not Started" after the last completed stage
    let lastCompletedIndex = -1;
    for (let i = stages.length - 1; i >= 0; i--) {
      if (workflowStatus[stages[i].name] === "Completed") {
        lastCompletedIndex = i;
        break;
      }
    }
    
    // Get the next stage after the last completed one
    if (lastCompletedIndex !== -1 && lastCompletedIndex < stages.length - 1) {
      const nextStage = stages[lastCompletedIndex + 1];
      if (workflowStatus[nextStage.name] === "Not Started") {
        return `${nextStage.label} - Not Started`;
      }
    }
    
    // If no specific next stage is found, return generic "Not Started"
    return "not-started";
  };

  // Get status icon for a file
  const getStatusIcon = (status: UploadedFile["status"]) => {
    switch (status) {
      case "parsing":
        return <Loader2 className="h-4 w-4 animate-spin text-yellow-500" />;
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "failed":
        return <XCircle className="h-4 w-4 text-red-500" />;
    }
  };

  // Enhanced status badge function to handle workflow status
  const getStatusBadge = (status: string) => {
    // Handle workflow-specific statuses
    if (status.includes("In Progress")) {
      return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">{status}</Badge>;
    } else if (status.includes("Failed")) {
      return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">{status}</Badge>;
    } else if (status.includes("Not Started")) {
      return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">{status}</Badge>;
    } else if (status === "not-started") {
      return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">Not Started</Badge>;
    }
    
    // Handle standard statuses
    switch (status) {
      case "completed":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Test Script Generation - Completed</Badge>;
      case "in-progress":
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">In Progress</Badge>;
      case "failed":
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Failed</Badge>;
      case "empty":
        return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">Empty</Badge>;
      default:
        return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">Unknown</Badge>;
    }
  };

  const isStatusDisabled = (status: string): boolean => {
    const disabledStatuses = [
      "Text Extraction - Not Started",
      "Text Extraction - In Progress",
      "Text Extraction - In progress",
      "text extraction - in progress",
      "Requirement Generation - Failed"
    ];
    
    return disabledStatuses.some(disabledStatus => 
      status.toLowerCase() === disabledStatus.toLowerCase()
    );
  };

  // Helper function to fetch status for a single useCase
  const fetchUseCaseStatus = async (useCase: UseCase) => {
    if (!useCase) {
      console.error("Attempted to fetch status for undefined useCase");
      return { usecaseId: -1, usecaseName: "", createdAt: "", updatedAt: "" };
    }
    
    try {
      const workflowStatusResponse = await fetch(`${API_ENDPOINTS.getUseCaseStatus}/${useCase.usecaseId}`);
      
      if (workflowStatusResponse.ok) {
        const statusData = await workflowStatusResponse.json();
        
        // Defensive programming - ensure all required fields exist
        const workflowStatus = {
          text_extraction: statusData.text_extraction || "Unknown",
          requirement_generation: statusData.requirement_generation || "Unknown",
          scenario_generation: statusData.scenario_generation || "Unknown",
          test_case_generation: statusData.test_case_generation || "Unknown",
          test_data_generation: statusData.test_data_generation || "Unknown",
          test_script_generation: statusData.test_script_generation || "Unknown"
        };
        
        const newStatus = determineWorkflowStatus(workflowStatus);
        
        return {
          ...useCase, // preserve all existing useCase properties
          workflowStatus,
          status: newStatus,
          product: statusData.product || useCase.product,
          subProduct: statusData.sub_product || useCase.subProduct,
          domain: statusData.domain || useCase.domain
        };
      }
      
      // Return unchanged useCase if response not OK
      return useCase;
    } catch (err) {
      console.error(`Error polling status for use case ${useCase.usecaseId}:`, err);
      // Return unchanged useCase on error
      return useCase;
    }
  };

  // Enhanced fetchUseCases function to set up polling after initial data fetch
  const fetchUseCases = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Get current user ID from session storage
      const userEmail = sessionStorage.getItem('userEmail');
      
      if (!userEmail) {
        throw new Error('User email not found in session storage');
      }
      
      // Fetch the user's usecases (basic info only)
      const response = await fetch(`${API_ENDPOINTS.getUserUseCases}/${userEmail}`);
      
      if (!response.ok) {
        throw new Error(`Failed to fetch bundles: ${response.statusText}`);
      }
      
      const data: UseCase[] = await response.json();
      
      // Only fetch status for all usecases initially, not files
      const useCasesWithStatus = await Promise.all(
        data.map(async (useCase) => {
          try {
            // Fetch initial status and metadata in one call
            const statusResponse = await fetch(`${API_ENDPOINTS.getUseCaseStatus}/${useCase.usecaseId}`);
            
            if (statusResponse.ok) {
              const statusData = await statusResponse.json();
              const workflowStatus = {
                text_extraction: statusData.text_extraction || "Unknown",
                requirement_generation: statusData.requirement_generation || "Unknown",
                scenario_generation: statusData.scenario_generation || "Unknown",
                test_case_generation: statusData.test_case_generation || "Unknown",
                test_data_generation: statusData.test_data_generation || "Unknown",
                test_script_generation: statusData.test_script_generation || "Unknown"
              };
              
              // Determine status from workflow status
              const status = determineWorkflowStatus(workflowStatus);
              
              return {
                ...useCase,
                workflowStatus,
                status,
                product: statusData.product,
                subProduct: statusData.sub_product,
                domain: statusData.domain,
                filesLoaded: false  // Mark that files haven't been loaded yet
              };
            }
            
            return { ...useCase, status: "unknown", filesLoaded: false };
          } catch (err) {
            console.error(`Error fetching status for bundle ${useCase.usecaseId}:`, err);
            return { ...useCase, status: "error", filesLoaded: false };
          }
        })
      );
      
      setUseCases(useCasesWithStatus);
      // console.log(`Fetched ${useCasesWithStatus.length} use cases - polling will start automatically`);
    } catch (err) {
      console.error("Error fetching bundles:", err);
      setError("Failed to load existing bundles. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  // New function to load files for a specific usecase
  const loadFilesForUseCase = async (usecaseId: number) => {
    // Avoid reloading files if already loaded
    const useCase = useCases.find(uc => uc.usecaseId === usecaseId);
    if (useCase?.filesLoaded) return;

    // Set loading state for this specific usecase
    setLoadingFiles(prev => [...prev, usecaseId]);
    
    try {
      const filesResponse = await fetch(`${API_ENDPOINTS.getFiles}/${usecaseId}`);
      
      if (filesResponse.ok) {
        const filesData = await filesResponse.json();
        // Transform API file data to match UploadedFile format
        const files: UploadedFile[] = filesData.map((file: any) => {
          // Parse the ISO string from API as UTC date
          const dateString = file.uploadedAt || file.createdAt;
          const uploadTime = new Date(dateString);
          
          // Log the date info for debugging
          // console.log(`File ${file.fileId} date:`, {
          //   originalString: dateString,
          //   utcTime: uploadTime.toISOString(),
          //   localTime: uploadTime.toLocaleString()
          // });
          
          return {
            id: file.fileId.toString(),
            name: file.fileName,
            uploadTime, // Keep as UTC for conversion during display
            status: file.status === "COMPLETED" ? "completed" : 
                   file.status === "FAILED" ? "failed" : "parsing"
          };
        });
        
        // Update only this specific usecase with the files
        setUseCases(prev => prev.map(uc => 
          uc.usecaseId === usecaseId 
            ? { ...uc, files, filesLoaded: true } 
            : uc
        ));
      }
    } catch (err) {
      console.error(`Error fetching files for bundle ${usecaseId}:`, err);
    } finally {
      setLoadingFiles(prev => prev.filter(id => id !== usecaseId));
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-red-500 text-center py-4">
        {error}
        <Button 
          variant="outline" 
          className="mt-2 mx-auto block" 
          onClick={fetchUseCases}
        >
          Retry
        </Button>
      </div>
    );
  }

  if (useCases.length === 0) {
    return (
      <div className="p-8 text-center">
        <p className="text-gray-500">
          No existing bundles found. Please create a new bundle.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {useCases.map((useCase) => (
        <div key={useCase.usecaseId} className="border rounded-lg overflow-hidden">
          <div className="flex items-center justify-between p-4 bg-gray-50 cursor-pointer" 
            onClick={() => toggleUseCase(useCase.usecaseId)}> 
            <div className="flex items-center gap-3">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div>
                        <Checkbox
                          checked={selectedUseCases.includes(useCase.usecaseId)}
                          disabled={isStatusDisabled(useCase.status)}
                          onCheckedChange={(checked) => {
                            handleUseCaseSelect(useCase.usecaseId, !!checked);
                          }}
                          className={`h-5 w-5 ${isStatusDisabled(useCase.status) ? 'opacity-50 cursor-not-allowed' : ''}`}
                        />
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      {isStatusDisabled(useCase.status) 
                        ? "Bundle cannot be selected while processing or in failed state" 
                        : "Select this bundle"}
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              <div>
                <h3 className="text-base font-medium">{useCase.usecaseName}</h3>
                {(useCase.product || useCase.subProduct) && (
                  <p className="text-xs text-gray-500">
                    {/* Product/subproduct information */}
                  </p>
                )}
              </div>
              
              {/* Display workflow status badge */}
              {useCase.status && (
                <div className="ml-2">{getStatusBadge(useCase.status)}</div>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-500">
                {loadingFiles.includes(useCase.usecaseId) ? (
                  <Loader2 className="h-4 w-4 animate-spin text-primary mr-1 inline" />
                ) : null}
                {useCase.files ? useCase.files.length : "..."} files
              </span>
              {expandedUseCases.includes(useCase.usecaseId) ? 
                <ChevronUp className="h-5 w-5 text-gray-500" /> : 
                <ChevronDown className="h-5 w-5 text-gray-500" />}
            </div>
          </div>
          
          {expandedUseCases.includes(useCase.usecaseId) && (
            <div className="overflow-x-auto">
              {loadingFiles.includes(useCase.usecaseId) ? (
                <div className="p-4 text-center">
                  <Loader2 className="h-6 w-6 animate-spin text-primary mx-auto" />
                  <p className="text-sm text-gray-500 mt-2">Loading files...</p>
                </div>
              ) : useCase.files && useCase.files.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[50px]"></TableHead>
                      <TableHead>File Name</TableHead>
                      <TableHead>Upload Time</TableHead>
                      {/* <TableHead className="text-right">Actions</TableHead> */}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {useCase.files.map((file) => (
                      <TableRow key={file.id}>
                        <TableCell>
                          <Checkbox
                            checked={selectedFiles.includes(file.id)}
                            disabled={isStatusDisabled(useCase.status) || file.status === "failed"}
                            onCheckedChange={(checked) => handleFileSelect(file.id, !!checked, useCase)}
                            className={`h-4 w-4 ${
                              (isStatusDisabled(useCase.status) || file.status === "failed") 
                                ? 'opacity-50 cursor-not-allowed' 
                                : ''
                            }`}
                          />
                        </TableCell>
                        <TableCell className="font-medium">{file.name}</TableCell>
                        <TableCell>
                          {(() => {
                            // Parse the UTC time from API
                            const utcDate = file.uploadTime;
                            
                            // Add 5 hours and 30 minutes to convert to IST (UTC+5:30)
                            const istDate = new Date(utcDate.getTime() + (5.5 * 60 * 60 * 1000));
                            
                            // Format the date in IST
                            return istDate.toLocaleString('en-IN', {
                              year: 'numeric',
                              month: '2-digit',
                              day: '2-digit',
                              hour: '2-digit',
                              minute: '2-digit',
                              second: '2-digit',
                              hour12: false
                            });
                          })()}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            {file.status === "failed" && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => onRetry(file.id)}
                                className="text-yellow-600 hover:text-yellow-700 hover:bg-yellow-50"
                              >
                                <RefreshCw className="h-4 w-4" />
                              </Button>
                            )}
                            {/* <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onDelete(file.id)}
                              className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button> */}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="p-4 text-center text-gray-500">
                  No files found for this bundle.
                </div>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};