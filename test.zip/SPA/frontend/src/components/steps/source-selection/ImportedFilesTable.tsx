import { Loader2, XCircle, CheckCircle, RefreshCw, Trash2, ChevronDown, ChevronUp, ArrowDown } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { UploadedFile } from "./types";
import { Checkbox } from "@/components/ui/checkbox";
import { UseCaseAccordion } from "./UseCaseAccordion";
import { useEffect, useState, useRef } from "react";
import { ImportStatusSection } from "./ImportStatusSection";

interface ImportedFilesTableProps {
  uploadedFiles: UploadedFile[];
  selectedFiles: string[];
  onFileSelect: (fileId: string, checked: boolean, silent?: boolean) => void;
  onRetry: (fileId: string) => void;
  onDelete: (fileId: string) => void;
  selectedUseCase?: { id: string; name: string } | null;
  selectedUseCaseType?: string | null;
  allowMultiSelect?: boolean;
  onFilesStatusChanged?: (files: UploadedFile[]) => void;
  onFilesLoaded?: (files: UploadedFile[]) => void;
  onUseCaseSelect?: (useCaseId: string, useCaseName: string, product?: string, subProduct?: string, domain?: string) => void;
  bundleName?: string;
  bundleCreatedAt?: Date;
  showImportButton?: boolean;
  onImportFiles?: () => void;
  isImporting?: boolean;
}

export const ImportedFilesTable = ({
  uploadedFiles,
  selectedFiles,
  onFileSelect,
  onRetry,
  onDelete,
  selectedUseCase,
  selectedUseCaseType,
  allowMultiSelect = true,
  onFilesStatusChanged,
  onUseCaseSelect,
  bundleName,
  bundleCreatedAt,
  showImportButton,
  onImportFiles,
  isImporting,
}: ImportedFilesTableProps) => {
  const [isBundlesTableExpanded, setIsBundlesTableExpanded] = useState(false);
  const bundlesContainerRef = useRef<HTMLDivElement>(null);
  const [isScrollable, setIsScrollable] = useState(false);
  
  useEffect(() => {
    // console.log("ImportedFilesTable selectedFiles changed:", selectedFiles);
  }, [selectedFiles]);

  // Check if content is scrollable
  useEffect(() => {
    if (isBundlesTableExpanded && bundlesContainerRef.current) {
      const checkScrollability = () => {
        const container = bundlesContainerRef.current;
        if (container) {
          const hasScrollbar = container.scrollHeight > container.clientHeight;
          setIsScrollable(hasScrollbar);
        }
      };

      // Check initially
      checkScrollability();

      // Add resize observer to check when content changes size
      const resizeObserver = new ResizeObserver(checkScrollability);
      resizeObserver.observe(bundlesContainerRef.current);

      return () => {
        if (bundlesContainerRef.current) {
          resizeObserver.unobserve(bundlesContainerRef.current);
        }
        resizeObserver.disconnect();
      };
    } else {
      setIsScrollable(false);
    }
  }, [isBundlesTableExpanded, uploadedFiles]);

  const getStatusIcon = (status: UploadedFile["status"]) => {
    switch (status) {
      case "parsing":
        return <Loader2 className="h-4 w-4 animate-spin text-yellow-500" />;
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "failed":
        return <XCircle className="h-4 w-4 text-red-500" />;
    }
  };

  // Generate title based on selection
  const getTableTitle = () => {
    if (selectedUseCase) {
      return "Imported Requirement Bundles";
    }
    return "Imported Requirement Bundles";
  };

  const handleSelectFile = (fileId: string, checked: boolean, silent: boolean = false) => {
    // console.log(`ImportedFilesTable selectedFile: ${fileId} (Checked: ${checked}, Silent: ${silent})`);
    
    // Find the selected file
    const selectedFile = uploadedFiles.find(file => file.id === fileId);
    // console.log("Selected file details:", selectedFile);
    
    // If radio button mode (not multi-select), deselect other files
    if (!allowMultiSelect && checked && !silent) {
      // Clear other selections first
      const currentSelectedFiles = [...selectedFiles]; // Make a copy to avoid modification during iteration
      currentSelectedFiles.forEach(existingFileId => {
        if (existingFileId !== fileId) {
          console.log(`Deselecting ${existingFileId} due to single select mode`);
          onFileSelect(existingFileId, false, true);  // Use silent=true
        }
      });
    }
    
    // Pass the silent parameter to the parent component
    onFileSelect(fileId, checked, silent);
    
    // Verify the change was made
    setTimeout(() => {
      // console.log(`After selection, is ${fileId} in selectedFiles?`, selectedFiles.includes(fileId));
    }, 0);
  };

  const toggleBundlesTable = () => {
    setIsBundlesTableExpanded(!isBundlesTableExpanded);
  };

  const scrollToBottom = () => {
    if (bundlesContainerRef.current) {
      bundlesContainerRef.current.scrollTo({
        top: bundlesContainerRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div>
      {/* Updated ImportStatusSection with bundle information and import button */}
      {selectedUseCaseType === "new" && (
        <ImportStatusSection
          uploadedFiles={uploadedFiles}
          selectedFiles={selectedFiles}
          onFileSelect={handleSelectFile}
          onRetry={onRetry}
          onDelete={onDelete}
          bundleName={bundleName || (selectedUseCase?.name || "New Bundle")}
          bundleCreatedAt={bundleCreatedAt || new Date()}
          showImportButton={showImportButton}
          onImportFiles={onImportFiles}
          isImporting={isImporting}
        />
      )}
      
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden mt-8">
        <div 
          className="p-6 border-b border-gray-200 flex justify-between items-center cursor-pointer"
          onClick={toggleBundlesTable}
        >
          <div>
            <h3 className="text-lg font-semibold text-gray-800">{getTableTitle()}</h3>
            {/* <p className="text-sm text-gray-600 mt-1">
              Files associated with each bundle
            </p> */}
          </div>
          <div className="flex items-center gap-2">
            {isBundlesTableExpanded && isScrollable && (
              <div className="relative inline-block">
                <Button 
                  variant="outline" 
                  size="icon"
                  onClick={(e) => { 
                    e.stopPropagation(); // Prevent toggling the table expansion
                    scrollToBottom(); 
                  }}
                  className="relative flex items-center justify-center rounded-full h-10 w-10 bg-gradient-to-br from-white to-gray-50 border border-gray-200/80 shadow-md text-gray-600 hover:text-primary hover:border-primary/50 hover:from-white hover:to-primary/5 transition-all duration-300 transform hover:scale-105 active:scale-95 group overflow-hidden"
                  title="Jump to bottom"
                  aria-label="Scroll to bottom"
                >
                  {/* Ripple effect on click */}
                  <span className="absolute inset-0 bg-primary/10 pointer-events-none opacity-0 group-active:animate-ripple rounded-full" />
                  
                  {/* Glow effect */}
                  <span className="absolute inset-0 bg-primary/5 rounded-full opacity-0 group-hover:opacity-100 blur-md transition-opacity duration-300" />
                  
                  {/* Icon with animation */}
                  <div className="relative z-10 group-hover:animate-bounce-subtle">
                    <ArrowDown className="h-5 w-5" strokeWidth={2} />
                  </div>
                </Button>
              </div>
            )}
            {isBundlesTableExpanded ? 
              <ChevronUp className="h-5 w-5 text-gray-500" /> : 
              <ChevronDown className="h-5 w-5 text-gray-500" />
            }
          </div>
        </div>
        
        {/* COMMENTED OUT: Original Import Status Accordion section */}
        {/* {selectedUseCaseType === "new" && (
          <div className="p-4">
            <h4 className="font-medium text-gray-700 mb-3">Import Status</h4>
            {uploadedFiles.length === 0 ? (
              <div className="p-8 text-center">
                <p className="text-gray-500">
                  No files have been imported yet. Select a file from existing bundle or upload new files.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[50px]"></TableHead>
                      <TableHead>File Name</TableHead>
                      <TableHead>Upload Time</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {uploadedFiles.map((file) => (
                      <TableRow key={file.id}>
                        <TableCell>
                          <Checkbox
                            checked={selectedFiles.includes(file.id)}
                            disabled={file.status === "failed"}
                            onCheckedChange={(checked) => handleSelectFile(file.id, !!checked)}
                            className="h-4 w-4"
                          />
                        </TableCell>
                        <TableCell className="font-medium">{file.name}</TableCell>
                        <TableCell>
                          {file.uploadTime.toLocaleString()}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            {file.status === "failed" && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => onRetry(file.id)}
                                className="text-yellow-600 hover:text-yellow-700 hover:bg-yellow-50"
                              >
                                <RefreshCw className="h-4 w-4" />
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onDelete(file.id)}
                              className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>
        )} */}

        {/* Always show the bundle accordion section, but only if expanded */}
        {isBundlesTableExpanded && (
          <div 
            ref={bundlesContainerRef}
            className="p-4 border-b border-gray-100 max-h-[400px] overflow-y-auto"
          >
            {/* <h4 className="font-medium text-gray-700 mb-3">Existing Bundles</h4> */}
            <UseCaseAccordion
              selectedFiles={selectedFiles}
              onFileSelect={handleSelectFile}
              onRetry={onRetry}
              onDelete={onDelete}
              allowMultiSelect={allowMultiSelect}
              onUseCaseSelect={onUseCaseSelect}
            />
          </div>
        )}
      </div>
    </div>
  );
};
