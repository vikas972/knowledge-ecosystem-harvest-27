import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface UserAssociationsProps {
  product: string;
  subProduct: string;
  domain: string;
  onProductChange: (value: string) => void;
  onSubProductChange: (value: string) => void;
  onDomainChange: (value: string) => void;
}

export const UserAssociations = ({
  product,
  subProduct,
  domain,
  onProductChange,
  onSubProductChange,
  onDomainChange
}: UserAssociationsProps) => {
  return (
    <div className="mb-8">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">User Associations</h3>
      <div className="grid md:grid-cols-3 gap-6">
        <div className="space-y-2">
          <Label htmlFor="product">Product</Label>
          <Select value={product} onValueChange={onProductChange}>
            <SelectTrigger id="product">
              <SelectValue placeholder="Select product" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="DTB">DTB</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="subProduct">Sub-Product</Label>
          <Select value={subProduct} onValueChange={onSubProductChange}>
            <SelectTrigger id="subProduct">
              <SelectValue placeholder="Select sub-product" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="CBX">CBX</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="domain">Domain</Label>
          <Select value={domain} onValueChange={onDomainChange}>
            <SelectTrigger id="domain">
              <SelectValue placeholder="Select domain" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Payments">Payments</SelectItem>
              <SelectItem value="Accounts">Accounts</SelectItem>
              <SelectItem value="Lending">Lending</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
};
