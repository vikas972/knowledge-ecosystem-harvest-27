import { useState } from "react";
import { ChevronDown, ChevronUp, CheckCircle, XCircle, Loader2, File } from "lucide-react";
import { UploadedFile } from "./types";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";

interface ImportStatusSectionProps {
  uploadedFiles: UploadedFile[];
  selectedFiles: string[];
  onFileSelect: (fileId: string, checked: boolean, silent?: boolean) => void;
  onRetry: (fileId: string) => void;
  onDelete: (fileId: string) => void;
  bundleName?: string;
  bundleCreatedAt?: Date;
  showImportButton?: boolean;
  onImportFiles?: () => void;
  isImporting?: boolean;
}

export const ImportStatusSection = ({
  uploadedFiles,
  selectedFiles,
  onFileSelect,
  onRetry,
  onDelete,
  bundleName = "Unnamed Bundle",
  bundleCreatedAt = new Date(),
  showImportButton = false,
  onImportFiles,
  isImporting = false,
}: ImportStatusSectionProps) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [expandedItems, setExpandedItems] = useState<string[]>(["default"]);
  
  // Count metrics
  const importing = uploadedFiles.filter(file => file.status === "parsing").length;
  const imported = uploadedFiles.filter(file => file.status === "completed").length;
  const totalFiles = uploadedFiles.length;
  
  const toggleExpand = () => {
    setIsExpanded(!isExpanded);
  };
  
  const toggleItem = (itemId: string) => {
    setExpandedItems(prev => 
      prev.includes(itemId) 
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };
  
  const getStatusIcon = (status: UploadedFile["status"]) => {
    switch (status) {
      case "parsing":
        return <Loader2 className="h-4 w-4 animate-spin text-yellow-500" />;
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "failed":
        return <XCircle className="h-4 w-4 text-red-500" />;
    }
  };
  
  // Helper function to get readable file category name
  const getFileCategory = (documentType: string) => {
    switch (documentType) {
      case "mainReq":
        return "Main Requirement Document";
      case "supportingReq":
        return "Supporting Requirement Document";
      default:
        return "Not Specified";
    }
  };
  
  // If there are no uploaded files, don't render anything
  if (uploadedFiles.length === 0) {
    return null;
  }
  
  // Format creation date
  const formattedDate = bundleCreatedAt.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  }).replace(/\//g, '/');
  
  // Bundle status based on files
  const bundleStatus = uploadedFiles.some(f => f.status === "parsing") 
    ? "parsing" 
    : uploadedFiles.some(f => f.status === "failed") ? "failed" : "completed";
  
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden mt-6 mb-6">
      <div 
        className="p-4 border-b border-gray-200 flex justify-between items-center cursor-pointer"
        onClick={toggleExpand}
      >
        <h3 className="text-lg font-semibold text-gray-800">
          Import Status ({totalFiles})
        </h3>
        <div className="flex items-center">
          {isExpanded ? 
            <ChevronUp className="h-5 w-5 text-gray-500" /> : 
            <ChevronDown className="h-5 w-5 text-gray-500" />
          }
        </div>
      </div>
      
      {isExpanded && (
        <div className="px-4 py-2">
          <div className="flex gap-4 text-sm text-gray-600 mb-2">
            {/* <span className="flex items-center">
              <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin text-yellow-500" /> 
              Importing: {importing}
            </span> */}
            <span className="flex items-center">
              <CheckCircle className="h-3.5 w-3.5 mr-1 text-green-500" /> 
              Imported: {imported}
            </span>
            <span>Files: {imported}/{totalFiles}</span>
          </div>
          
          <div className="space-y-2">
            <div className="border rounded-md">
              <div 
                className="flex items-center justify-between p-3 bg-gray-50 cursor-pointer"
                onClick={() => toggleItem('default')}
              >
                <div className="flex items-center gap-2">
                  <Checkbox
                    checked={uploadedFiles.every(file => selectedFiles.includes(file.id))}
                    onCheckedChange={(checked) => {
                      uploadedFiles.forEach(file => {
                        onFileSelect(file.id, !!checked);
                      });
                    }}
                    className="h-4 w-4"
                    onClick={(e) => e.stopPropagation()}
                  />
                  <div className="flex items-center gap-2">
                    <div className="text-gray-500">
                      <File className="h-4 w-4" />
                    </div>
                    <span className="font-medium">{bundleName}</span>
                  </div>
                  <span className="text-sm text-gray-500">
                    Created: {formattedDate} • Imported +{uploadedFiles.length} files
                  </span>
                </div>
                
                <div className="flex items-center gap-2">
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                    bundleStatus === "completed" ? "bg-green-100 text-green-800" :
                    bundleStatus === "failed" ? "bg-red-100 text-red-800" :
                    "bg-yellow-100 text-yellow-800"
                  }`}>
                    {bundleStatus === "completed" ? "Imported" : 
                     bundleStatus === "parsing" ? "Importing" : "Failed"}
                  </span>
                  {expandedItems.includes('default') ? 
                    <ChevronUp className="h-4 w-4 text-gray-500" /> : 
                    <ChevronDown className="h-4 w-4 text-gray-500" />
                  }
                </div>
              </div>
              
              {expandedItems.includes('default') && (
                <div className="p-3 border-t border-gray-100">
                  <div className="space-y-2">
                    {uploadedFiles.map((file) => (
                      <div key={file.id} className="flex items-center justify-between p-2 hover:bg-gray-50 rounded-md">
                        <div className="flex items-center gap-2">
                          <Checkbox
                            checked={selectedFiles.includes(file.id)}
                            disabled={file.status === "failed"}
                            onCheckedChange={(checked) => onFileSelect(file.id, !!checked)}
                            className="h-4 w-4"
                          />
                          <span className="font-medium text-sm">{file.name}</span>
                          <span className={`text-xs ${
                            file.documentContext?.documentType === "mainReq" ? "text-green-600" : "text-gray-500"
                          }`}>
                            {file.documentContext?.documentType ? 
                              getFileCategory(file.documentContext.documentType) : 
                              "Category Not Specified"}
                          </span>
                        </div>
                        <div className="flex items-center">
                          <span className={`mr-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                            file.status === "completed" ? "bg-green-100 text-green-800" :
                            file.status === "failed" ? "bg-red-100 text-red-800" :
                            "bg-yellow-100 text-yellow-800"
                          }`}>
                            {file.status === "completed" ? "Completed" : 
                             file.status === "parsing" ? "Processing" : "Failed"}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
          
          {showImportButton && (
            <div className="mt-4 mb-2 flex justify-end">
              <Button 
                onClick={onImportFiles}
                disabled={isImporting || selectedFiles.length === 0}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                {isImporting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  "Import Files"
                )}
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
