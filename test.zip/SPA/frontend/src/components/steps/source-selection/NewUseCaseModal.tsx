import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { API_ENDPOINTS } from "@/config/api";
import { toast } from "sonner";

interface NewUseCaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateUseCase: (useCaseName: string, usecaseId: number) => void;
  product?: string;
  subProduct?: string;
  domain?: string;
}

export const NewUseCaseModal = ({
  isOpen,
  onClose,
  onCreateUseCase,
  product,
  subProduct,
  domain,
}: NewUseCaseModalProps) => {
  const [useCaseName, setUseCaseName] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const handleSubmit = async () => {
    if (!useCaseName.trim()) {
      toast.error("Please enter a bundle name");
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Build the URL with all required parameters
      let url = `${API_ENDPOINTS.createUseCase}?usecaseName=${encodeURIComponent(useCaseName)}`;
      // console.log("product", product);
      // console.log("subProduct", subProduct);
      // console.log("domain", domain);
      // Add optional parameters if they exist
      // these are not optional
      url += `&product=${encodeURIComponent(product)}`;
      url += `&sub_product=${encodeURIComponent(subProduct)}`;
      url += `&domain=${encodeURIComponent(domain)}`;
      // console.log("url", url);
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || "Failed to create bundle");
      }

      const data = await response.json();
      
      toast.success(`Bundle created successfully`, {
        duration: 1000
      });
      onCreateUseCase(useCaseName, data.usecaseId);
      onClose();
      setUseCaseName("");
    } catch (error) {
      console.error("Error creating bundle:", error);
      toast.error("First select a Product, Sub-Product and Domain from User Association.", {
        duration: 1500
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !isSubmitting) {
      handleSubmit();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create New Bundle</DialogTitle>
        </DialogHeader>
        <div className="py-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="usecaseName">Bundle Name</Label>
              <Input
                id="usecaseName"
                placeholder="Enter a name for the new bundle"
                value={useCaseName}
                onChange={(e) => setUseCaseName(e.target.value)}
                onKeyDown={handleKeyDown}
                disabled={isSubmitting}
              />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit} 
            disabled={!useCaseName.trim() || isSubmitting}
          >
            {isSubmitting ? "Creating..." : "Create Bundle"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}; 