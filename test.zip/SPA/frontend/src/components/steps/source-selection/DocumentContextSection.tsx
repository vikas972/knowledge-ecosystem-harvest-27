import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { DocumentContext, UploadedFile } from "./types";
import { useState, useEffect } from "react";

interface DocumentContextSectionProps {
  isExpanded: boolean;
  onToggleExpand: () => void;
  selectedFile: string | null;
  uploadedFiles: UploadedFile[];
  documentContext: DocumentContext;
  onContextUpdate: (field: keyof DocumentContext, value: any) => void;
  onReset: () => void;
  onImport: (fileIndex?: number) => void;
  pendingFile: File[] | null;
}

export const DocumentContextSection = ({
  selectedFile,
  uploadedFiles,
  documentContext,
  onContextUpdate,
  onReset,
  onImport,
  pendingFile,
}: DocumentContextSectionProps) => {
  // State to track which pending file is currently selected in the dropdown
  const [currentFileIndex, setCurrentFileIndex] = useState<number>(0);
  
  // Reset current file index when pendingFile changes
  useEffect(() => {
    setCurrentFileIndex(0);
  }, [pendingFile]);

  // Get the current file being configured
  const currentFile = pendingFile && pendingFile.length > 0 ? pendingFile[currentFileIndex] : null;

  // Check if all required fields are filled
  const isFormValid = 
    currentFile && 
    documentContext.documentType && 
    // documentContext.documentFormat &&
    // documentContext.documentName &&
    documentContext.requirementType &&
    documentContext.customer &&
    documentContext.breakRequirementsBy;

  // Handler for file selection in dropdown
  const handleFileChange = (fileIndex: string) => {
    const index = parseInt(fileIndex);
    setCurrentFileIndex(index);
  };

  // console.log("Current file:", currentFile);
  // console.log("Document context:", documentContext);

  return (
    <Card className="mb-8 shadow-sm border-gray-200">
      <CardHeader className="pb-2 border-b border-gray-200">
        <div className="flex items-center gap-3">
          <CardTitle className="text-xl font-semibold">Document Context</CardTitle>
          {currentFile ? (
            <span className="text-sm text-gray-500">
              Selected: {currentFile.name}
            </span>
          ) : selectedFile && (
            <span className="text-sm text-gray-500">
              Selected: {uploadedFiles.find(f => f.id === selectedFile)?.name}
            </span>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="space-y-6 pt-6">
        {/* File selection dropdown - only show if multiple files are pending */}
        {pendingFile && pendingFile.length > 1 && (
          <div className="space-y-2">
            <Label htmlFor="fileSelector">Select File to Configure</Label>
            <Select
              value={currentFileIndex.toString()}
              onValueChange={handleFileChange}
            >
              <SelectTrigger id="fileSelector">
                <SelectValue placeholder="Select file" />
              </SelectTrigger>
              <SelectContent>
                {pendingFile.map((file, index) => (
                  <SelectItem key={index} value={index.toString()}>
                    {file.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          {/* Document Name */}
          <div className="space-y-2">
            <Label htmlFor="documentName">Document Name</Label>
            <Input
              id="documentName"
              placeholder="Enter document name"
              value={documentContext.documentName || ''}
              onChange={(e) => onContextUpdate("documentName", e.target.value)}
            />
          </div>

          {/* File Category */}
          <div className="space-y-2">
            <Label htmlFor="documentType">File Category</Label>
            <Select
              onValueChange={(value) => onContextUpdate("documentType", value)}
              value={documentContext.documentType}
            >
              <SelectTrigger id="documentType">
                <SelectValue placeholder="Select a document type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="mainReq">Main Requirement Document</SelectItem>
                <SelectItem value="supportingReq">Supporting Requirement Document</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Document Category - Commented out
          <div className="space-y-2">
            <Label htmlFor="documentFormat">Document Category</Label>
            <Select
              onValueChange={(value) => onContextUpdate("documentFormat", value)}
              value={documentContext.documentFormat}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="fsd">Functional Specifications Document</SelectItem>
                <SelectItem value="brd">Business Requirements Document</SelectItem>
                <SelectItem value="srs">Software Requirements Specification</SelectItem>
                <SelectItem value="userStories">User Stories</SelectItem>
                <SelectItem value="technicalSpec">Technical Specification</SelectItem>
              </SelectContent>
            </Select>
          </div>
          */}

          {/* Requirement Type */}
          <div className="space-y-2">
            <Label htmlFor="requirementType">Requirement Type</Label>
            <Select
              onValueChange={(value) => onContextUpdate("requirementType", value)}
              value={documentContext.requirementType}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select requirement type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="k1">K1</SelectItem>
                <SelectItem value="k2">K2</SelectItem>
                <SelectItem value="k3">K3</SelectItem>
                <SelectItem value="k4">K4</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Customer */}
          <div className="space-y-2">
            <Label htmlFor="customer">Customer</Label>
            <Select
              onValueChange={(value) => onContextUpdate("customer", value)}
              value={documentContext.customer}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a customer" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="hdfc">HDFC</SelectItem>
                <SelectItem value="icici">ICICI</SelectItem>
                <SelectItem value="citybank">Citybank</SelectItem>
                <SelectItem value="jpmorgan">JP Morgan Chase</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Break Requirements By */}
          <div className="space-y-2">
            <Label htmlFor="breakRequirementsBy">Break Requirements By</Label>
            <Select
              onValueChange={(value) => onContextUpdate("breakRequirementsBy", value)}
              value={documentContext.breakRequirementsBy}
            >
              <SelectTrigger>
                <SelectValue placeholder="Break Requirements By" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="userJourney">User Journey</SelectItem>
                <SelectItem value="userStories">User Stories</SelectItem>
                <SelectItem value="section">Section</SelectItem>
                <SelectItem value="paragraph">Paragraph</SelectItem>
                <SelectItem value="page">Page</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Additional Context */}
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="agentContext">Additional Context for SPA Agent</Label>
            <Textarea 
              placeholder="Provide any additional context that will help the SPA agent process this document..."
              value={documentContext.agentContext}
              onChange={(e) => onContextUpdate("agentContext", e.target.value)}
              className="h-24"
            />
          </div>
        </div>

        {/* <div className="border-t pt-6">
          <h3 className="text-sm font-semibold mb-4">Output Preferences</h3>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="requirementFormat">Requirement ID Format</Label>
              <Input 
                placeholder="e.g., REQ-XXX"
                value={documentContext.outputPreferences.requirementFormat}
                onChange={(e) => onContextUpdate("outputPreferences", {
                  ...documentContext.outputPreferences,
                  requirementFormat: e.target.value
                })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="validationGranularity">Validation Detail Level</Label>
              <Select
                onValueChange={(value) => onContextUpdate("outputPreferences", {
                  ...documentContext.outputPreferences,
                  validationGranularity: value
                })}
                value={documentContext.outputPreferences.validationGranularity}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="basic">Basic</SelectItem>
                  <SelectItem value="detailed">Detailed</SelectItem>
                  <SelectItem value="comprehensive">Comprehensive</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="namingConvention">Naming Convention</Label>
              <Select
                onValueChange={(value) => onContextUpdate("outputPreferences", {
                  ...documentContext.outputPreferences,
                  namingConvention: value
                })}
                value={documentContext.outputPreferences.namingConvention}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="camelCase">camelCase</SelectItem>
                  <SelectItem value="PascalCase">PascalCase</SelectItem>
                  <SelectItem value="snake_case">snake_case</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div> */}

        <div className="flex justify-end space-x-4 pt-4">
          <Button
            variant="outline"
            onClick={onReset}
            disabled={!currentFile}
          >
            Reset to Defaults
          </Button>
          <Button
            onClick={() => onImport(currentFileIndex)}
            disabled={!isFormValid}
          >
            Import File
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

