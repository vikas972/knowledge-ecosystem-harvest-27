import { FolderOpen, Plus } from "lucide-react";
import { SourceCard } from "../../SourceCard";

interface UseCaseSelectionProps {
  selectedUseCase: string | null;
  onUseCaseSelect: (useCaseType: string) => void;
}

export const UseCaseSelection = ({
  selectedUseCase,
  onUseCaseSelect
}: UseCaseSelectionProps) => {
  const useCaseOptions = [
    // {
    //   id: "existing",
    //   title: "Existing Bundle",
    //   description: "Continue working with a previously created bundle",
    //   icon: <FolderOpen className="w-6 h-6" />
    // },
    {
      id: "new",
      // title: "New Use Case",
      title: "New Bundle",
      // description: "Create a new bundle from scratch",
      description: "Create a new bundle from scratch",
      icon: <Plus className="w-6 h-6" />
    }
  ];

  return (
    <div className="mb-8">
      {/* <h3 className="text-lg font-semibold mb-4">Select Bundle Type</h3> */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
      {/* <div className="flex justify-center items-center w-full">    // centre allign */}
        {useCaseOptions.map((option) => (
          <SourceCard
            key={option.id}
            title={option.title}
            description={option.description}
            icon={option.icon}
            selected={selectedUseCase === option.id}
            onClick={() => onUseCaseSelect(option.id)}
          />
        ))}
      </div>
    </div>
  );
}; 