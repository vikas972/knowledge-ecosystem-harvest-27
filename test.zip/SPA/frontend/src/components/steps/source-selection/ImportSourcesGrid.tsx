import { Globe, Cloud, FileText, Database } from "lucide-react";
import { SourceCard } from "../../SourceCard";
import { useRef } from "react";
import { API_ENDPOINTS } from '@/config/api';
import { useUserEmail } from "@/hooks/useUserEmail";

interface ImportSourcesGridProps {
  selectedSource: string | null;
  onSourceSelect: (sourceId: string) => void;
  onFileSelect: (files: File[]) => void;
  isEnabled: boolean;
}

export const ImportSourcesGrid = ({ 
  selectedSource, 
  onSourceSelect,
  onFileSelect,
  isEnabled = true
}: ImportSourcesGridProps) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSourceClick = (sourceId: string) => {
    if (!isEnabled) return;

      // Get the source object
  const source = sources.find(s => s.id === sourceId);
  
  // If source is disabled, return early
  if (source?.disabled) return;
    
    onSourceSelect(sourceId);
    
    if (sourceId === "local" && fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const { email } = useUserEmail();

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    if (files.length === 0) {
      console.error('No files selected');
      return;
    }

    const validFiles: File[] = [];
    const maxSize = 10 * 1024 * 1024; // 10MB in bytes
    const allowedTypes = ['.docx', '.pdf'];

    for (const file of files) {
      // Validate file size
      if (file.size > maxSize) {
        console.error(`File ${file.name} is too large. Maximum size is 10MB`);
        continue;
      }

      // Validate file type
      const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
      if (!allowedTypes.includes(fileExtension)) {
        console.error(`Invalid file type for ${file.name}. Allowed types are: ${allowedTypes.join(', ')}`);
        continue;
      }

      validFiles.push(file);
    }

    if (validFiles.length > 0) {
      console.log('Files selected:', validFiles.map(f => f.name).join(', '));
      onFileSelect(validFiles);
    } else {
      console.error('No valid files were selected');
    }
  };

  const sources = [
    {
      id: "jira",
      title: "JIRA",
      description: "Import test cases from JIRA issues and epics",
      icon: <Globe className="w-6 h-6" />,
      disabled: true,  // Add this line to disable JIRA
    },
    {
      id: "confluence",
      title: "Confluence",
      description: "Import from Confluence pages and spaces",
      icon: <Cloud className="w-6 h-6" />,
      disabled: true,  // Add this line to disable JIRA
    },
    {
      id: "local",
      title: "Local Files",
      description: "Import from local files and directories",
      icon: <FileText className="w-6 h-6" />,
    },
    {
      id: "database",
      title: "Database",
      description: "Import from existing test databases",
      icon: <Database className="w-6 h-6" />,
      disabled: true,  // Add this line to disable JIRA
    },
  ];

  return (
    <>
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        onChange={handleFileChange}
        accept=".doc,.docx,.pdf,.txt"
        multiple
        disabled={!isEnabled}
      />
      <div className={`grid md:grid-cols-2 gap-6 mb-12 ${!isEnabled ? 'opacity-60 pointer-events-none' : ''}`}>
        {sources.map((source) => (
          <SourceCard
            key={source.id}
            title={source.title}
            description={source.description}
            icon={source.icon}
            selected={selectedSource === source.id}
            onClick={() => handleSourceClick(source.id)}
            disabled={source.disabled}
          />
        ))}
      </div>
    </>
  );
};
