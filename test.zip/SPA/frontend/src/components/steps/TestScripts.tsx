import { Button } from "@/components/ui/button";
import { Loader2, Code, Copy, Play, Minimize2, Plus, CheckSquare, Trash2, Grid, ChevronLeft, ChevronRight, FileQuestion, Pencil, CheckCircle, XCircle } from "lucide-react";
import { useEffect, useState, useCallback, useRef } from "react";
import { UserAssociationInfo } from "../UserAssociationInfo";
import { BundleInfo } from "../BundleInfo";
import { Checkbox } from "@/components/ui/checkbox";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { TestScriptsGridDialog } from './test-scripts/dialogs/TestScriptsGridDialog';
import JSZip from 'jszip';
import * as XLSX from 'xlsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import axios from "axios";
import { API_ENDPOINTS } from "@/config/api";
import { ENV } from "@/config/env";
import { useInterval } from "@/hooks/useInterval";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";

interface TestScriptsProps {
  selectedFile: { id: string; name: string; uploadTime: Date } | null;
  product: string;
  subProduct: string;
  domain: string;
  bundleName: string;
  usecaseId?: string | number;
}

export const TestScripts = ({ selectedFile, product, subProduct, domain, bundleName, usecaseId 
}: TestScriptsProps) => {
  // Replace the static testScripts array with a state variable
  const [testScripts, setTestScripts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedScript, setSelectedScript] = useState(0);
  const [selectedScripts, setSelectedScripts] = useState<number[]>([]);
  const [showGridDialog, setShowGridDialog] = useState(false);
  const [isBulkDeleteDialogOpen, setIsBulkDeleteDialogOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  // Calculate totalPages dynamically based on testScripts length
  const totalPages = Math.ceil(testScripts.length / itemsPerPage);
  // const [activeView, setActiveView] = useState<"script" | "xml">("script");
  const [activeView, setActiveView] = useState<"script" | "xml">("xml");
  // Add error state to handle API errors
  const [error, setError] = useState<string | null>(null);
  
  // Add streaming-related states
  const [isStreaming, setIsStreaming] = useState(true);
  const previousTestScriptIdsRef = useRef<Set<string>>(new Set());
  const [newlyAddedTestScriptIds, setNewlyAddedTestScriptIds] = useState<string[]>([]);
  const [initialLoadComplete, setInitialLoadComplete] = useState(false);

  // Add new state variables for XML editing
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editableXml, setEditableXml] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [currentEditingScriptId, setCurrentEditingScriptId] = useState<string | null>(null);
  const [validationStatus, setValidationStatus] = useState<{
    message: string; 
    isValid: boolean | null;
    fullError?: string;
  }>({
    message: "",
    isValid: null
  });

  // Fetch test scripts from the API when the component mounts or usecaseId changes
  const fetchTestScripts = useCallback(async () => {
    if (!usecaseId) {
      setIsLoading(false);
      return;
    }
    
    if (!initialLoadComplete) {
      setIsLoading(true);
    }
    setError(null);
    
    try {
      // Make request to the API
      const response = await axios.get(`${API_ENDPOINTS.getTestScriptsByUsecase}/${usecaseId}`);
      console.log("Test Scripts API Response:", response.data);
      const data = response.data;
      
      // Transform the data to match the expected format
      const transformedTestScripts = [];
      
      // Create a set to track current IDs
      const currentTestScriptIds = new Set();
      
      // Loop through testcases and map them to our format
      for (const testcase of data.testcases) {
        // Skip testcases without test scripts
        if (!testcase.test_scripts || testcase.test_scripts.length === 0) {
          continue;
        }
        
        // For each testcase, get the first script (or we could support multiple later)
        const script = testcase.test_scripts[0];
        console.log("Test Script example:", script);
        
        // Only add if we have XML content
        if (script && script.test_script_json && script.test_script_json.TestStepsJXML) {
          const scriptId = script.testscript_id || `script-${Math.random().toString(36).substr(2, 9)}`;
          
          transformedTestScripts.push({
            id: scriptId,
            name: testcase.testcase_name || "Unnamed Test Case",
            description: testcase.testcase_description || "",
            // Using test_script_json.TestStepsJXML for XML
            xml: script.test_script_json.TestStepsJXML,
            // For script property, we could leave it empty or generate it from XML in the future
            script: "", // Placeholder for now
            isNew: !previousTestScriptIdsRef.current.has(scriptId),
            display_id: script.display_id,
            testcase_display_id: testcase.testcase_display_id,
            scenario_display_id: testcase.scenario_display_id,
            requirement_display_id: testcase.requirement_display_id
          });
          
          currentTestScriptIds.add(scriptId);
        }
      }
      
      // Find newly added test scripts
      const newTestScriptIds = [...currentTestScriptIds].filter(id => 
        typeof id === 'string' && !previousTestScriptIdsRef.current.has(id)
      ) as string[];
      
      // Update refs and states
      previousTestScriptIdsRef.current = new Set([...currentTestScriptIds].filter(id => 
        typeof id === 'string'
      ) as string[]);
      
      // Update the test scripts state
      setTestScripts(transformedTestScripts);
      
      // Only highlight new test scripts if we've completed initial loading
      if (initialLoadComplete && newTestScriptIds.length > 0) {
        setNewlyAddedTestScriptIds(newTestScriptIds);
        
        // Remove highlighting after 1 second
        setTimeout(() => {
          setNewlyAddedTestScriptIds([]);
        }, 1000);
        
        // Show toast notification for new test scripts
        toast.success(`${newTestScriptIds.length} new test script(s) generated!`, { 
          duration: 1000 
        });
      }
      
      // Check if test script generation is complete
      const statusResponse = await axios.get(
        `${API_ENDPOINTS.getUseCaseStatus}/${usecaseId}`
      );
      
      if (statusResponse.data.test_script_generation === "Completed") {
        setIsStreaming(false); // Stop streaming when complete
      }
      
      // Update loading states
      if (!initialLoadComplete) {
        setInitialLoadComplete(true);
      }
      setIsLoading(false);
      
      // Only set error if not streaming and no scripts were found
      if (transformedTestScripts.length === 0 && !isStreaming) {
        setError("No test scripts found for this use case");
      }
    } catch (err) {
      console.error("Error fetching test scripts:", err);
      // Only set error if not the initial load during streaming
      if (!(isStreaming && !initialLoadComplete)) {
        setError("Failed to load test scripts. Please try again later.");
      }
      setIsLoading(false);
    }
  }, [usecaseId, initialLoadComplete, isStreaming]);
  
  // Check status function to determine if we should be streaming
  const checkStatus = async () => {
    if (!usecaseId) return;
    
    try {
      const statusResponse = await axios.get(
        `${API_ENDPOINTS.getUseCaseStatus}/${usecaseId}`
      );
      
      if (statusResponse.data.test_script_generation === "Completed") {
        setIsStreaming(false);
      } else {
        setIsStreaming(true);
      }
    } catch (error) {
      console.error("Error checking test script generation status:", error);
    }
  };
  
  // Initial fetch when component mounts or usecaseId changes
  useEffect(() => {
    if (usecaseId) {
      fetchTestScripts();
      checkStatus();
    }
  }, [usecaseId, fetchTestScripts]);
  
  // Add polling mechanism using custom useInterval hook
  useInterval(
    () => {
      if (usecaseId && isStreaming) {
        fetchTestScripts();
      }
    },
    isStreaming ? 5000 : null // Poll every 5 seconds, or stop if isStreaming is false
  );
  
  // Reset selected script when test scripts change
  useEffect(() => {
    // Only reset selections on initial load, not on every update
    if (!initialLoadComplete) {
      setSelectedScript(0);
      setSelectedScripts([]);
    }
  }, [testScripts, initialLoadComplete]);

  // Then declare the state variables that depend on it
  const [selectedFileState, setSelectedFileState] = useState(selectedFile);
  const [productState, setProductState] = useState(product);
  const [subProductState, setSubProductState] = useState(subProduct);
  const [domainState, setDomainState] = useState(domain);
  const [bundleNameState, setBundleNameState] = useState(bundleName);
  const [usecaseIdState, setUsecaseIdState] = useState(usecaseId);

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedScripts([...Array(testScripts.length).keys()]);
    } else {
      setSelectedScripts([]);
    }
  };

  const handleStatusChange = (status: "completed" | "in_progress" | "needs_review") => {
    console.log(`Changing status to ${status} for scripts:`, selectedScripts);
  };

  const handleBulkDeleteClick = () => {
    if (selectedScripts.length === 0) {
      toast.error("Please select at least one test script to delete");
      return;
    }
    setIsBulkDeleteDialogOpen(true);
  };

  const handleConfirmBulkDelete = () => {
    setIsDeleting(true);
    
    try {
      console.log("Deleting scripts:", selectedScripts);
      
      setTimeout(() => {
        toast.success(`Successfully deleted ${selectedScripts.length} test script${selectedScripts.length !== 1 ? 's' : ''}` );
        
        setIsBulkDeleteDialogOpen(false);
        
        setSelectedScripts([]);
        
        setIsDeleting(false);
      }, 1000);
    } catch (error) {
      console.error("Error performing bulk delete:", error);
      toast.error("An error occurred during bulk deletion");
      setIsDeleting(false);
    }
  };

  const handleCancelBulkDelete = () => {
    setIsBulkDeleteDialogOpen(false);
  };

  const handleItemsPerPageChange = (value: string) => {
    setItemsPerPage(Number(value));
    setCurrentPage(1); // Reset to first page when changing items per page
  };

  const goToPreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const goToNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const getPaginatedTestScripts = () => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return testScripts.slice(startIndex, endIndex);
  };

  // Add function to handle opening the edit dialog
  const handleEditClick = () => {
    if (testScripts.length === 0 || selectedScript < 0) return;
    
    const script = testScripts[selectedScript];
    setEditableXml(script.xml);
    setCurrentEditingScriptId(script.id);
    setIsEditDialogOpen(true);
  };
  
  // Update the handleSaveXml function to fix the JSON structure issue
  const handleSaveXml = async () => {
    if (!currentEditingScriptId || !editableXml) return;
    
    // If not validated yet or validation failed, validate first
    if (validationStatus.isValid !== true) {
      const isValid = validateXml();
      if (!isValid) {
        toast.error("Please fix XML validation errors before saving");
        return;
      }
    }
    
    setIsSaving(true);
    try {
      // Get the current test script to update its JSON
      const response = await axios.get(`${API_ENDPOINTS.getTestScriptById}/${currentEditingScriptId}`);
      const currentScript = response.data;
      
      // Important: Make sure we're handling the structure correctly
      let updatedJson;
      
      if (currentScript.testScriptJson) {
        // Update keeping the original structure
        updatedJson = {
          ...currentScript.testScriptJson,
          TestStepsJXML: editableXml
        };
      } else {
        // Create new structure if none exists
        updatedJson = {
          TestStepsJXML: editableXml
        };
      }
      
      console.log("Sending update with JSON structure:", updatedJson);
      
      // Call the update endpoint with the properly structured JSON
      await axios.put(`${API_ENDPOINTS.updateTestScript}/${currentEditingScriptId}`, {
        testScriptJson: updatedJson
      });
      
      // Update the local state with the new XML
      const updatedTestScripts = [...testScripts];
      updatedTestScripts[selectedScript].xml = editableXml;
      setTestScripts(updatedTestScripts);
      
      toast.success("Test script XML updated successfully");
      setIsEditDialogOpen(false);
    } catch (error) {
      console.error("Error updating test script XML:", error);
      // Log detailed error information for debugging
      if (error.response) {
        console.error("Error response data:", error.response.data);
        console.error("Error response status:", error.response.status);
      }
      toast.error("Failed to update test script XML");
    } finally {
      setIsSaving(false);
    }
  };

  // Add XML validation function
  const validateXml = () => {
    if (!editableXml.trim()) {
      setValidationStatus({
        message: "XML content is empty",
        isValid: false
      });
      return false;
    }
    
    try {
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(editableXml, "text/xml");
      
      // Check if parsing created a parsererror element
      const parserError = xmlDoc.getElementsByTagName("parsererror");
      if (parserError.length > 0) {
        // Extract error message
        const errorMessage = parserError[0].textContent || "Unknown parsing error";
        setValidationStatus({
          message: `Error: ${errorMessage.slice(0, 60)}...`,
          isValid: false,
          fullError: errorMessage
        });
        return false;
      }
      
      // XML is valid
      setValidationStatus({
        message: "Valid XML",
        isValid: true
      });
      return true;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      setValidationStatus({
        message: `Error: ${errorMessage.slice(0, 60)}...`,
        isValid: false,
        fullError: errorMessage
      });
      return false;
    }
  };

  if (isLoading || (testScripts.length === 0 && isStreaming)) {
    return (
      <div className="flex flex-col flex-1 h-full overflow-hidden p-4">
        <UserAssociationInfo 
          product={product} 
          subProduct={subProduct} 
          domain={domain} 
        />
        <BundleInfo 
          bundleName={bundleName} 
          usecaseId={usecaseId?.toString()}
        />
        
        <div className="flex justify-between items-center py-2">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-semibold">Test Scripts</h2>
          </div>
        </div>

        <div className="mb-1 overflow-hidden">
          <div className="p-2 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Checkbox
                checked={false}
                disabled={true}
              />
              <span className="text-sm text-gray-500">
                Select All (0)
              </span>
            </div>
            
            <div className="flex items-center gap-2">
              <Button 
                className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
                size="sm"
                disabled={true}
              >
                <Grid className="h-4 w-4 mr-2" />
                Grid
              </Button>

              <Button 
                className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
                size="sm"
                disabled={true}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Test Script
              </Button>

              <Button
                className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
                size="sm"
                disabled={true}
              >
                Download Zip
              </Button>

              <Button
                className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
                size="sm"
                disabled={true}
              >
                Change Status
              </Button>

              <Button
                variant="destructive"
                size="sm"
                disabled={true}
              >
                Delete Selected
              </Button>
            </div>
          </div>
        </div>

        <div className="flex flex-col items-center py-20 text-center">
          <FileQuestion className="h-12 w-12 text-gray-400 mb-2" />
          <p className="text-gray-600 mb-1">No test scripts found</p>
          <p className="text-xs text-gray-500">
            Try generating test scripts from your test cases first
          </p>
        </div>

        {isStreaming && (
          <div className="flex items-center gap-2 mt-2 p-2 bg-blue-50 border border-blue-200 rounded-md">
            <div className="h-2 w-2 bg-blue-500 rounded-full animate-pulse"></div>
            <span className="text-sm text-blue-700">
              Streaming test scripts as they are generated...
            </span>
          </div>
        )}
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="flex flex-1 items-center justify-center">
        <div className="flex flex-col items-center gap-4 text-center">
          <p className="text-lg font-medium text-red-600">{error}</p>
          {usecaseId && (
            <Button
              onClick={() => {
                setIsLoading(true);
                setError(null);
                fetchTestScripts();
              }}
            >
              Retry
            </Button>
          )}
        </div>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col flex-1 h-full overflow-hidden p-4">
      <UserAssociationInfo 
        product={product} 
        subProduct={subProduct} 
        domain={domain} 
      />
      <BundleInfo bundleName={bundleName} 
        usecaseId={usecaseId?.toString()}
      />
      
      <div className="flex justify-between items-center py-2">
        <div className="flex items-center gap-2">
          <h2 className="text-lg font-semibold">Test Scripts</h2>
        </div>
        {/* <Button variant="ghost" size="sm">
          <Minimize2 className="h-4 w-4" />
        </Button> */}
      </div>

      <div className="mb-1 overflow-hidden">
        <div className="p-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Checkbox
              checked={selectedScripts.length === testScripts.length && testScripts.length > 0}
              onCheckedChange={(checked) => {
                if (checked) {
                  handleSelectAll(true);
                } else {
                  handleSelectAll(false);
                }
              }}
              disabled={testScripts.length === 0}
            />
            <span className="text-sm text-gray-500">
              Select All ({testScripts.length})
            </span>
          </div>
          
          <div className="flex items-center gap-2">
            {/* <Button 
              className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
              size="sm"
              onClick={() => setShowGridDialog(true)}
              disabled={true}
            >
              <Grid className="h-4 w-4 mr-2" />
              Grid
            </Button> */}
            <Button 
              className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
              size="sm"
              disabled={true}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Test Script
            </Button>
            <Button
              className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
              size="sm"
              disabled={selectedScripts.length === 0}
              onClick={async () => {
                try {
                  // Show download preparation toast
                  // toast.info("Preparing files for download...");
                  
                  // Create a new ZIP file
                  const zip = new JSZip();
                  
                  // Define headers
                  const headers = ["Object", "Value", "Extra", "Action", "Description"].join(",");
                  
                  // Add each selected script as both Excel and XML file to the ZIP
                  selectedScripts.forEach(index => {
                    const script = testScripts[index];
                    const scriptBaseName = script.name.replace(/\s+/g, '_');
                    
                    // --- Excel file generation ---
                    // const excelFileName = `${scriptBaseName}.xlsx`;
                    
                    // Parse the script content into rows
                    // const rows = script.script.split('\n')
                    //   .map(line => {
                    //     if (!line.trim()) return null;
                        
                    //     // Split the line while preserving quoted values
                    //     const values = [];
                    //     let currentValue = '';
                    //     let insideQuotes = false;
                        
                    //     for (let i = 0; i < line.length; i++) {
                    //       const char = line[i];
                          
                    //       if (char === '"') {
                    //         insideQuotes = !insideQuotes;
                    //       } else if (char === ',' && !insideQuotes) {
                    //         values.push(currentValue.replace(/^"|"$/g, ''));
                    //         currentValue = '';
                    //       } else {
                    //         currentValue += char;
                    //       }
                    //     }
                    //     values.push(currentValue.replace(/^"|"$/g, '')); // Add the last value
                        
                    //     return values;
                    //   })
                    //   .filter(row => row !== null);
                    
                    // Add headers as the first row
                    // const headers = ["Object", "Value", "Extra", "Action", "Description"];
                    // rows.unshift(headers);
                    
                    // Create a new workbook and worksheet
                    // const wb = XLSX.utils.book_new();
                    // const ws = XLSX.utils.aoa_to_sheet(rows);
                    
                    // Add the worksheet to the workbook
                    // XLSX.utils.book_append_sheet(wb, ws, 'Test Script');
                    
                    // Generate Excel file content
                    // const excelContent = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });
                    
                    // Add Excel file to ZIP
                    // zip.file(excelFileName, excelContent, { binary: true });
                    
                    // --- XML file generation ---
                    const xmlFileName = `${scriptBaseName}.xml`;
                    
                    // Add XML file to ZIP
                    zip.file(xmlFileName, script.xml);
                  });
                  
                  // Create a folder structure (optional) to organize files
                  // const scriptsFolder = zip.folder("scripts");
                  // const xmlFolder = zip.folder("xml");
                  
                  // Generate ZIP file
                  const zipBlob = await zip.generateAsync({
                    type: "blob",
                    compression: "DEFLATE",
                    compressionOptions: {
                      level: 9
                    }
                  });
                  
                  // Create and trigger download
                  const url = URL.createObjectURL(zipBlob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `test_scripts_${new Date().toISOString().slice(0,10)}.zip`;
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
                  URL.revokeObjectURL(url);
                  
                  toast.success(`Downloaded ${selectedScripts.length} test script${selectedScripts.length !== 1 ? 's' : ''} with XML files`);
                } catch (error) {
                  console.error("Error preparing download:", error);
                  toast.error("Failed to prepare download");
                }
              }}
            >
              <svg className="h-4 w-4 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
              </svg>
              Download Zip
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
                  size="sm"
                  disabled={true}
                >
                  <CheckSquare className="h-4 w-4 mr-2" />
                  Change Status
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onSelect={() => handleStatusChange("completed")}>
                  Mark as Completed
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => handleStatusChange("needs_review")}>
                  Mark as Needs Review
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => handleStatusChange("in_progress")}>
                  Mark as In Progress
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button
              variant="destructive"
              size="sm"
              // disabled={selectedScripts.length === 0}
              disabled={true}
              onClick={handleBulkDeleteClick}
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Delete Selected
            </Button>
          </div>
        </div>
      </div>

      {/* Conditional Content Area */}
      {testScripts.length === 0 ? (
        /* Empty or Loading State */
        <div className="flex-1 flex items-center justify-center border rounded-md bg-white">
          {isStreaming ? (
            /* Streaming, but no test scripts yet */
            <div className="flex flex-col items-center gap-4 text-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-lg font-medium text-gray-600">
                Please wait, generating the test scripts...
              </p>
            </div>
          ) : (
            /* Not streaming, truly empty */
            <div className="flex flex-col items-center gap-4 text-center p-8">
              <FileQuestion className="h-12 w-12 text-gray-400 mb-2" />
              <p className="text-gray-600 mb-1">No test scripts found</p>
              <p className="text-xs text-gray-500">
                Try generating test scripts from your test cases first
              </p>
            </div>
          )}
        </div>
      ) : (
        /* Regular content - existing grid and details */
        <div className="grid grid-cols-12 gap-4">
          {/* Test Script List */}
          <div className="col-span-5 bg-white rounded-lg border border-gray-200 p-4 h-[600px] flex flex-col">
            <h3 className="font-semibold text-lg mb-4">Available Test Scripts</h3>
            
            {/* Scrollable content area - scrollbar only visible on hover */}
            <div className="flex-1 overflow-hidden hover:overflow-auto">
              <div className="space-y-2">
                {getPaginatedTestScripts().map((script, index) => {
                  // Calculate the actual index in the full array for selection purposes
                  const actualIndex = (currentPage - 1) * itemsPerPage + index;
                  
                  return (
                    <div 
                      key={actualIndex}
                      className={`p-3 rounded-md cursor-pointer transition-colors ${
                        selectedScript === actualIndex 
                          ? "bg-primary/10 border-l-4 border-primary" 
                          : "hover:bg-gray-100 border-l-4 border-transparent"
                      }`}
                      onClick={() => setSelectedScript(actualIndex)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <h5 className="font-medium flex items-center flex-wrap">
                            {script.display_id ? (
                              <>
                                <Badge variant="outline" className="mr-2 bg-blue-50 text-blue-700 border-blue-200">
                                  Test Script - {script.display_id}
                                </Badge>
                                <span className="inline-block">{script.name}</span>
                              </>
                            ) : script.name}
                          </h5>
                          <p className="text-xs text-gray-600 mb-1">{script.description}</p>
                          <div className="flex items-center gap-2 text-sm">
                            {script.testcase_display_id && (
                              <Badge
                                variant="outline"
                                className="cursor-pointer hover:bg-primary/10"
                              >
                                TC-{script.testcase_display_id}
                              </Badge>
                            )}
                            {script.scenario_display_id && (
                              <Badge
                                variant="outline"
                                className="cursor-pointer hover:bg-primary/10"
                              >
                                TS-{script.scenario_display_id}
                              </Badge>
                            )}
                            {script.requirement_display_id && (
                              <Badge
                                variant="outline"
                                className="cursor-pointer hover:bg-primary/10"
                              >
                                REQ-{script.requirement_display_id}
                              </Badge>
                            )}
                          </div>
                        </div>
                        <Checkbox
                          checked={selectedScripts.includes(actualIndex)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedScripts(prev => [...prev, actualIndex]);
                            } else {
                              setSelectedScripts(prev => prev.filter(i => i !== actualIndex));
                            }
                          }}
                          onClick={(e) => e.stopPropagation()}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Fixed pagination bar */}
            {testScripts.length > 0 && (
              <div className="mt-4 pt-4 border-t flex justify-between items-center">
                <div className="flex items-center gap-2 text-xs text-gray-600">
                  <Select 
                    value={itemsPerPage.toString()} 
                    onValueChange={handleItemsPerPageChange}
                  >
                    <SelectTrigger className="h-7 w-16 text-xs">
                      <SelectValue placeholder="5" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5</SelectItem>
                      <SelectItem value="10">10</SelectItem>
                      <SelectItem value="20">20</SelectItem>
                      <SelectItem value="50">50</SelectItem>
                    </SelectContent>
                  </Select>
                  <span>per page</span>
                  <span className="ml-2">
                    {`${(currentPage - 1) * itemsPerPage + 1}-${Math.min(currentPage * itemsPerPage, testScripts.length)} of ${testScripts.length}`}
                  </span>
                </div>
                
                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={goToPreviousPage}
                    disabled={currentPage === 1}
                    className="h-7 w-7"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  
                  <div className="flex items-center">
                    <input
                      type="number"
                      min="1"
                      max={totalPages}
                      value={currentPage}
                      onChange={(e) => {
                        const page = parseInt(e.target.value);
                        if (page >= 1 && page <= totalPages) {
                          setCurrentPage(page);
                        }
                      }}
                      className="h-7 w-12 px-2 border rounded text-xs text-center"
                    />
                    <span className="text-xs text-gray-600 mx-1">of {totalPages}</span>
                  </div>

                  <Button
                    variant="outline"
                    size="icon"
                    onClick={goToNextPage}
                    disabled={currentPage === totalPages}
                    className="h-7 w-7"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Test Script Content - Updated with tabs for script/XML toggle */}
          <div className="col-span-7 bg-white rounded-lg border border-gray-200 p-4 h-[600px]">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h5 className="font-semibold text-lg flex items-center flex-wrap">
                  {testScripts[selectedScript].display_id ? (
                    <>
                      <Badge variant="outline" className="mr-2 bg-blue-50 text-blue-700 border-blue-200">
                        Test Script - {testScripts[selectedScript].display_id}
                      </Badge>
                      <span className="inline-block">{testScripts[selectedScript].name}</span>
                    </>
                  ) : testScripts[selectedScript].name}
                </h5>
                <p className="text-xs text-gray-600 mb-2">{testScripts[selectedScript].description}</p>
                <div className="flex items-center gap-2 text-sm">
                  {testScripts[selectedScript].testcase_display_id && (
                    <Badge
                      variant="outline"
                      className="cursor-pointer hover:bg-primary/10"
                    >
                      TC-{testScripts[selectedScript].testcase_display_id}
                    </Badge>
                  )}
                  {testScripts[selectedScript].scenario_display_id && (
                    <Badge
                      variant="outline"
                      className="cursor-pointer hover:bg-primary/10"
                    >
                      TS-{testScripts[selectedScript].scenario_display_id}
                    </Badge>
                  )}
                  {testScripts[selectedScript].requirement_display_id && (
                    <Badge
                      variant="outline"
                      className="cursor-pointer hover:bg-primary/10"
                    >
                      REQ-{testScripts[selectedScript].requirement_display_id}
                    </Badge>
                  )}
                </div>
              </div>
              {/* Buttons have been moved to the tab bar */}
            </div>
            
            {/* Toggle tabs for Script/XML views */}
            <div className="border-b mb-3">
              <div className="flex justify-between items-center">
                <div className="flex gap-4">
                  {/* <button
                    className={`pb-2 px-1 font-medium text-sm transition-colors ${
                      activeView === "script" 
                        ? "border-b-2 border-primary text-primary" 
                        : "text-gray-500 hover:text-gray-800"
                    }`}
                    onClick={() => setActiveView("script")}
                  >
                    Script
                  </button> */}
                  <button
                    className={`pb-2 px-1 font-medium text-sm transition-colors ${
                      activeView === "xml" 
                        ? "border-b-2 border-primary text-primary" 
                        : "text-gray-500 hover:text-gray-800"
                    }`}
                    onClick={() => setActiveView("xml")}
                  >
                    XML
                  </button>
                </div>
                <div className="flex items-center space-x-2">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => {
                      const contentToCopy = activeView === "script" 
                        ? testScripts[selectedScript].script 
                        : testScripts[selectedScript].xml;
                      
                      navigator.clipboard.writeText(contentToCopy)
                        .then(() => toast.success(`${activeView === "script" ? "Script" : "XML"} copied to clipboard`, { duration: 500 }))
                        .catch(() => toast.error(`Failed to copy ${activeView === "script" ? "script" : "XML"}`));
                    }}
                  >
                    <Copy className="h-4 w-4 mr-1" />
                    Copy
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handleEditClick}
                    className="flex items-center gap-1.5 bg-white text-blue-700 border-blue-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-800 transition-all duration-150 shadow-sm hover:shadow rounded-md px-3 font-medium"
                  >
                    <Pencil className="h-4 w-4 mr-1" />
                    Edit XML
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      try {
                        const xmlContent = testScripts[selectedScript].xml;
                          const blob = new Blob([xmlContent], { type: 'application/xml' });
                          const url = URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = `${testScripts[selectedScript].name.replace(/\s+/g, '_')}.xml`;
                          document.body.appendChild(a);
                          a.click();
                          document.body.removeChild(a);
                          URL.revokeObjectURL(url);
                          
                          toast.success("XML file downloaded");
                      } catch (error) {
                        console.error(`Error generating ${activeView === "script" ? "Excel" : "XML"} file:`, error);
                        toast.error(`Failed to download ${activeView === "script" ? "Excel" : "XML"} file`);
                      }
                    }}
                    className="flex items-center gap-1.5 bg-white text-green-700 border-green-200 hover:bg-green-50 hover:border-green-300 hover:text-green-800 transition-all duration-150 shadow-sm hover:shadow rounded-md px-3 font-medium"
                  >
                    <svg className="h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                    </svg>
                    Download XML
                  </Button>
                </div>
              </div>
            </div>
            
            {/* Script view */}
            {activeView === "script" && (
              <div className="bg-gray-50 rounded-md h-[450px] overflow-hidden hover:overflow-auto border border-gray-200">
                <table className="w-full text-sm">
                  <thead className="sticky top-0 bg-gray-100 text-gray-700">
                    <tr>
                      <th className="w-12 px-2 py-2 text-left font-medium border-b">No</th>
                      <th className="px-3 py-2 text-left font-medium border-b">Object</th>
                      <th className="px-3 py-2 text-left font-medium border-b">Value</th>
                      <th className="px-3 py-2 text-left font-medium border-b">Extra</th>
                      <th className="px-3 py-2 text-left font-medium border-b">Action</th>
                      <th className="px-3 py-2 text-left font-medium border-b">Description</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white">
                    {testScripts[selectedScript].script.split('\n').map((line, index) => {
                      if (!line.trim()) return null;
                      
                      // Parse CSV line, handling quoted values properly
                      const getCSVValues = (line) => {
                        const values = [];
                        let inQuote = false;
                        let currentValue = "";
                        
                        for (let i = 0; i < line.length; i++) {
                          const char = line[i];
                          
                          if (char === '"') {
                            inQuote = !inQuote;
                          } else if (char === ',' && !inQuote) {
                            values.push(currentValue);
                            currentValue = "";
                          } else {
                            currentValue += char;
                          }
                        }
                        
                        values.push(currentValue); // Add the last value
                        return values;
                      };
                      
                      const values = getCSVValues(line);
                      
                      // Determine row color based on content (optional styling)
                      let rowClass = "";
                      if (values[3] === "GoToComponent") {
                        rowClass = "bg-blue-50";
                      } else if (values[3] === "PerformClick") {
                        rowClass = "bg-green-50";
                      } else if (values[3] === "VerifyElementPresent" || values[3] === "VerifyElementText") {
                        rowClass = "bg-amber-50";
                      } else if (values[3] === "Wait" || values[3] === "wait") {
                        rowClass = "bg-gray-50";
                      }
                      
                      // Remove quotes from displayed values
                      const cleanValues = values.map(val => val.replace(/^"|"$/g, ''));
                      
                      return (
                        <tr key={index} className={`hover:bg-gray-50 ${rowClass}`}>
                          <td className="px-2 py-1.5 text-gray-500 border-b border-gray-100 font-mono">{index + 1}</td>
                          <td className="px-3 py-1.5 border-b border-gray-100 font-mono">
                            {cleanValues[0] && (
                              <span className="text-blue-600">{cleanValues[0]}</span>
                            )}
                          </td>
                          <td className="px-3 py-1.5 border-b border-gray-100 font-mono">
                            {cleanValues[1] && (
                              <span className="text-emerald-600">{cleanValues[1]}</span>
                            )}
                          </td>
                          <td className="px-3 py-1.5 border-b border-gray-100 font-mono">
                            {cleanValues[2] && (
                              <span className="text-purple-600">{cleanValues[2]}</span>
                            )}
                          </td>
                          <td className="px-3 py-1.5 border-b border-gray-100 font-mono">
                            {cleanValues[3] && (
                              <span className="font-medium text-gray-800">{cleanValues[3]}</span>
                            )}
                          </td>
                          <td className="px-3 py-1.5 border-b border-gray-100">
                            {cleanValues[4] && (
                              <span className="text-gray-600">{cleanValues[4]}</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
            
            {/* XML view */}
            {activeView === "xml" && (
              // <div className="bg-gray-50 rounded-md flex-1 h-full max-h-[calc(100%-125px)] overflow-hidden hover:overflow-auto border border-gray-200 font-mono text-xs p-4">
              <div className="bg-[#1e2028] rounded-md flex-1 h-full max-h-[calc(100%-125px)] overflow-hidden hover:overflow-auto border border-gray-200 font-mono text-xs p-4">
                {/* <pre className="text-gray-800 whitespace-pre-wrap w-full overflow-x-auto"> */}
                <pre className="text-[#cdd6f4] whitespace-pre-wrap w-full overflow-x-auto">
                  {testScripts[selectedScript].xml}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}

      <Dialog open={isBulkDeleteDialogOpen} onOpenChange={setIsBulkDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription asChild>
              <div>
                <div className="mt-2 text-gray-600">
                  You are about to delete {selectedScripts.length} test script{selectedScripts.length !== 1 ? 's' : ''}.
                </div>
                <div className="mt-2 text-gray-600">
                  This action will permanently remove these test scripts and all related information.
                </div>
                <div className="mt-4 font-medium text-red-600">
                  Are you sure you want to delete {selectedScripts.length} test script{selectedScripts.length !== 1 ? 's' : ''}?
                </div>
              </div>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={handleCancelBulkDelete} disabled={isDeleting}>Cancel</Button>
            <Button 
              variant="destructive" 
              onClick={handleConfirmBulkDelete}
              disabled={isDeleting}
            >
              {isDeleting ? "Deleting..." : "Delete Test Scripts"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <TestScriptsGridDialog
        open={showGridDialog}
        onOpenChange={setShowGridDialog}
        testScripts={testScripts}
        title="Test Scripts"
      />

      {/* Streaming indicator in the UI */}
      {isStreaming && (
        <div className="flex items-center gap-2 mt-2 p-2 bg-blue-50 border border-blue-200 rounded-md">
          <div className="h-2 w-2 bg-blue-500 rounded-full animate-pulse"></div>
          <span className="text-sm text-blue-700">
            Streaming test scripts as they are generated...
          </span>
        </div>
      )}

      {/* Add Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-4xl h-[80vh] flex flex-col" onPointerDownOutside={(e) => {
          // Prevent closing when clicking outside
          e.preventDefault();
        }}>
          <DialogHeader>
            <DialogTitle>Edit XML</DialogTitle>
            <DialogDescription>
              Make changes to the XML content below. Click save when you're done.
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex-1 min-h-0 my-4">
            <textarea
              className="w-full h-full p-4 font-mono text-xs border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
              value={editableXml}
              onChange={(e) => {
                setEditableXml(e.target.value);
                // Clear validation status if it was previously set
                if (validationStatus.isValid !== null) {
                  setValidationStatus({ message: "", isValid: null });
                }
              }}
              spellCheck={false}
            />
          </div>
          
          <DialogFooter>
            <div className="flex items-center gap-2 mr-auto">
              <Button 
                variant="outline" 
                onClick={validateXml} 
                disabled={isSaving}
                className="bg-white text-purple-700 border-purple-200 hover:bg-purple-50 hover:border-purple-300 hover:text-purple-800"
              >
                Validate XML
              </Button>
              {validationStatus.isValid !== null && (
                <div className="flex items-center gap-1">
                  {validationStatus.isValid ? (
                    <>
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm text-green-600 font-medium">
                        {validationStatus.message}
                      </span>
                    </>
                  ) : (
                    <>
                      <XCircle className="h-4 w-4 text-red-600" />
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span className="text-sm text-red-600 font-medium cursor-help">
                              {validationStatus.message}
                            </span>
                          </TooltipTrigger>
                          <TooltipContent className="max-w-[400px] p-2">
                            <div className="flex flex-col gap-2">
                              <p className="text-xs font-mono whitespace-pre-wrap">{validationStatus.fullError}</p>
                              <Button 
                                size="sm" 
                                variant="outline" 
                                className="ml-auto"
                                onClick={() => {
                                  if (validationStatus.fullError) {
                                    navigator.clipboard.writeText(validationStatus.fullError)
                                      .then(() => toast.success("Error message copied to clipboard", { duration: 500 }))
                                      .catch(() => toast.error("Failed to copy error message"));
                                  }
                                }}
                              >
                                <Copy className="h-3 w-3 mr-1" />
                                Copy Error
                              </Button>
                            </div>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </>
                  )}
                </div>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                onClick={() => {
                  setIsEditDialogOpen(false);
                  setValidationStatus({ message: "", isValid: null }); // Reset validation status when closing
                }} 
                disabled={isSaving}
              >
                Cancel
              </Button>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div> {/* Wrapper div to ensure tooltip works with disabled button */}
                      <Button 
                        onClick={handleSaveXml} 
                        disabled={isSaving || validationStatus.isValid !== true}
                        className={validationStatus.isValid !== true ? "opacity-50 cursor-not-allowed" : ""}
                      >
                        {isSaving ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          "Save Changes"
                        )}
                      </Button>
                    </div>
                  </TooltipTrigger>
                  {validationStatus.isValid !== true && !isSaving && (
                    <TooltipContent side="left">
                      <p className="text-sm">Please validate XML before saving</p>
                    </TooltipContent>
                  )}
                </Tooltip>
              </TooltipProvider>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};