import React, { useEffect, useState, useCallback, useRef } from "react";
import { type TestScenario, type TestScenarioFlow } from "./scenario/types";
import { RequirementsCoverage } from "./scenario/RequirementsCoverage";
import { AddScenarioDialog } from "./scenario/dialogs/AddScenarioDialog";
import { ScenarioHeader } from "./scenario/components/ScenarioHeader";
import { ScenarioList } from "./scenario/components/ScenarioList";
import { RequirementDialog } from "./scenario/dialogs/RequirementDialog";
import { ScenarioActions } from "./scenario/components/ScenarioActions";
import { useScenarioState } from "./scenario/hooks/useScenarioState";
import { toast } from "sonner";
import { ScenarioGridDialog } from "./scenario/dialogs/ScenarioGridDialog";
import { Loader2, Maximize2, Minimize2, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import axios from "axios";
import { API_ENDPOINTS } from "@/config/api";
import { initialScenarios } from "./scenario/scenarioData";
import { UserAssociationInfo } from '@/components/UserAssociationInfo';
import { BundleInfo } from "../BundleInfo";
import { ENV } from "@/config/env";
import { useInterval } from "@/hooks/useInterval";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";

interface ScenarioGenerationProps {
  selectedFile: { id: string; name: string; uploadTime: Date } | null;
  usecaseId?: number | string;
  requirementIds: string[];
  product: string;
  subProduct: string;
  domain: string;
  bundleName: string;
}

export const ScenarioGeneration = ({ 
  selectedFile, 
  usecaseId, 
  requirementIds, 
  product, 
  subProduct, 
  domain,
  bundleName
}: ScenarioGenerationProps) => {
  const [isLeftPanelMaximized, setIsLeftPanelMaximized] = useState(true);
  const [isRightPanelMaximized, setIsRightPanelMaximized] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [requirements, setRequirements] = useState<any[]>([]);
  const [requirementLoadError, setRequirementLoadError] = useState<string | null>(null);

  // Add state for delete confirmation dialogs
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [scenarioToDelete, setScenarioToDelete] = useState<string | null>(null);
  const [bulkDeleteDialogOpen, setBulkDeleteDialogOpen] = useState(false);

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(5);
  const [jumpToPageValue, setJumpToPageValue] = useState<string>('');

  // Add these new states for streaming
  const [isStreaming, setIsStreaming] = useState(true);
  const previousScenarioIdsRef = useRef<Set<string>>(new Set());
  const [newlyAddedScenarioIds, setNewlyAddedScenarioIds] = useState<string[]>([]);
  const [initialLoadComplete, setInitialLoadComplete] = useState(false);

  // Add state for polling interval with progressive backoff
  const [pollingInterval, setPollingInterval] = useState(3000);
  const maxPollingInterval = 20000; // Cap at 20 seconds

  // Add this function to check workflow status
  const checkWorkflowStatus = async () => {
    try {
      // console.log("[ScenarioGeneration] Checking workflow status for usecase:", usecaseId);
      
      // Use the API_ENDPOINTS.getUseCaseStatus endpoint
      const response = await axios.get(
        `${API_ENDPOINTS.getUseCaseStatus}/${usecaseId}`
      );
      product=response.data.product;
      subProduct=response.data.sub_product;
      domain=response.data.domain;
      // console.log(product, subProduct, domain, "product, subProduct, domain");
      // console.log("[ScenarioGeneration] Workflow status response:", response.data);
      
      // Check if scenario generation is completed
      const scenarioStatus = response.data.scenario_generation === "Completed";
      if (scenarioStatus) {
        // If scenarios are generated, fetch them and stop streaming
        fetchScenariosByUsecase();
        setIsStreaming(false);
      } else {
        // If no scenarios are generated yet, keep streaming
        setIsLoading(true);
        setIsStreaming(true);
      }
    } catch (error) {
      console.error("[ScenarioGeneration] Error checking workflow status:", error);
      setRequirementLoadError("Failed to check workflow status. Please try again.");
      setIsLoading(false);
      setIsStreaming(false);
    }
  };

  // Update useEffect to call checkWorkflowStatus instead of fetchScenariosByUsecase
  useEffect(() => {
    // console.log("[ScenarioGeneration] Component mounted with:", {
    //   usecaseId,
    //   requirementIds,
    //   requirementIdsLength: requirementIds.length
    // });
    
    // Call checkWorkflowStatus once when the component mounts
    checkWorkflowStatus();
    
  }, [usecaseId, requirementIds]);

  // Modify useInterval to implement progressive backoff
  useInterval(
    () => {
      if (usecaseId && isStreaming) {
        fetchScenariosByUsecase();
        
        // Increase polling interval progressively
        setPollingInterval(prev => Math.min(prev * 1.5, maxPollingInterval));
      }
    },
    isStreaming ? pollingInterval : null
  );

  // Reset polling interval when component mounts or when streaming starts
  useEffect(() => {
    if (isStreaming) {
      setPollingInterval(5000);
    }
  }, [isStreaming]);

  // Function to transform API scenario data to UI format
  const transformScenarioData = (apiScenarios: any[]): TestScenario[] => {
    if (!apiScenarios || !apiScenarios.length) return [];

    const transformedScenarios: any[] = [];
    // Track display IDs to handle duplicates
    const displayIdCounts: Record<string, number> = {};

    // Reset the display ID counts
    const resetDisplayIdCounts = () => {
      Object.keys(displayIdCounts).forEach(key => delete displayIdCounts[key]);
    };

    // Reset counts before processing
    resetDisplayIdCounts();

    apiScenarios.forEach(scenario => {
      // Skip if no output_json
      if (!scenario.output_json) return;

      // Case 1: output_json contains an array of scenarios
      if (scenario.output_json.scenarios && Array.isArray(scenario.output_json.scenarios)) {
        // Add displayId, scenario_id, and parent requirement info to each scenario in the array
        const scenariosWithIds = scenario.output_json.scenarios.map((s: any, index: number) => {
          // Track duplicate display IDs
          const displayId = scenario.displayId;
          displayIdCounts[displayId] = (displayIdCounts[displayId] || 0) + 1;
          
          // If this is a duplicate (not the first occurrence), add a suffix
          const displayIdWithSuffix = displayIdCounts[displayId] > 1 
            ? `${displayId}.${displayIdCounts[displayId] - 1}` 
            : displayId.toString();
            
          return {
            ...s,
            displayId: displayIdWithSuffix,
            scenario_id: scenario.scenario_id,
            parent_requirement_id: scenario.parent_requirement_id,
            parent_requirement_displayId: scenario.parent_requirement_displayId,
            is_deleted: scenario.is_deleted || false
          };
        });
        transformedScenarios.push(...scenariosWithIds);
      }
      // Case 2: output_json is a single scenario object
      else if (scenario.output_json.ScenarioID) {
        // Add displayId, scenario_id, and parent requirement info to the scenario
        transformedScenarios.push({
          ...scenario.output_json,
          displayId: scenario.displayId,
          scenario_id: scenario.scenario_id,
          parent_requirement_id: scenario.parent_requirement_id,
          parent_requirement_displayId: scenario.parent_requirement_displayId,
          is_deleted: scenario.is_deleted || false
        });
      }
    });

    // Map the transformed scenarios to our UI format
    return transformedScenarios.map(scenario => ({
      // Instead of using ScenarioID directly, use "TS-" + displayId
      id: `TS-${scenario.displayId}`,
      title: scenario.ScenarioName,
      description: scenario.ScenarioDescription,
      requirementId: scenario.RequirementID, // Keep original RequirementID like UI010_001
      priority: "medium", // Default value
      status: "completed", // Since is_completed is true in API response
      flows: scenario.Flows.map((flow: any) => ({
        type: flow.Type.toLowerCase().split(' ')[0],
        description: flow.Description,
        subflows: [{
          name: flow.Type,
          coverage: flow.Coverage,
          expectedResults: flow.ExpectedResults,
          entries: []
        }]
      })),
      is_deleted: scenario.is_deleted || false, // Use API value or default to false
      scenario_id: scenario.scenario_id, // Store the backend scenario_id
      parent_requirement_id: scenario.parent_requirement_id, // Store parent requirement UUID
      parent_requirement_displayId: scenario.parent_requirement_displayId // Store parent requirement displayId
    }));
  };

  // Add a function to fetch requirement details by ID
  const fetchRequirementById = async (requirementId: string) => {
    try {
      const response = await axios.get(`${ENV.API_URL}/requirements/get-by-requirementid/${requirementId}`);
      return response.data;
    } catch (error) {
      console.error(`Error fetching requirement ${requirementId}:`, error);
      return null;
    }
  };

  const fetchScenariosByUsecase = useCallback(async () => {
    if (!usecaseId) {
      console.error("No usecase ID provided");
      return;
    }

    // Only show loading indicator during initial load
    if (!initialLoadComplete) {
      setIsLoading(true);
    }
    
    try {
      // Call the rearrange-scenarios API during streaming
      if (isStreaming && usecaseId) {
        try {
          await axios.put(`${ENV.API_URL}/scenario-management/rearrange-scenarios/${usecaseId}`);
        } catch (error) {
          console.error("Error rearranging scenarios:", error);
          // Continue with fetching even if rearranging fails
        }
      }

      const response = await axios.get(`${API_ENDPOINTS.getScenariosByUsecase}/${usecaseId}`);
      // console.log("API Response:", response.data);
      
      // Create a mapping between requirement UUIDs and their display IDs directly from the API response
      const requirementDisplayIdMap: Record<string, number> = {};
      const requirementIdMapping: Record<string, string> = {}; // Map RequirementID (UI010_001) to requirement UUID
      
      // Loop through each requirement in the response to build our mappings
      response.data.requirements.forEach((req: any) => {
        // Map the requirement UUID to its displayId
        requirementDisplayIdMap[req.requirement_id] = req.displayId || 0;
        
        // Map each scenario's RequirementID to the parent requirement UUID
        if (req.scenarios && req.scenarios.length > 0) {
          req.scenarios.forEach((scenario: any) => {
            if (scenario.output_json && scenario.output_json.RequirementID) {
              requirementIdMapping[scenario.output_json.RequirementID] = req.requirement_id;
            }
          });
        }
      });
      
      // Extract scenarios from all requirements
      const allScenarios = response.data.requirements.flatMap(
        (req: any) => req.scenarios?.map((scenario: any) => ({
          ...scenario,
          parent_requirement_id: req.requirement_id, // Add parent requirement UUID to each scenario
          parent_requirement_displayId: req.displayId // Add parent requirement displayId
        })) || []
      );
      
      // Transform the API data to our UI format
      const transformedScenarios = transformScenarioData(allScenarios);
      
      // For scenarios that might be missing parent requirement info, fetch it directly
      const updatedScenarios = await Promise.all(transformedScenarios.map(async (scenario) => {
        // If parent_requirement_displayId is missing but we have parent_requirement_id
        if (!scenario.parent_requirement_displayId && scenario.parent_requirement_id) {
          // Fetch requirement details directly
          const requirementDetails = await fetchRequirementById(scenario.parent_requirement_id);
          if (requirementDetails && requirementDetails.displayId) {
            return {
              ...scenario,
              requirementId: `REQ-${requirementDetails.displayId}`,
              parent_requirement_displayId: requirementDetails.displayId
            };
          }
        }
        
        // If we have parent_requirement_displayId, use that
        if (scenario.parent_requirement_displayId) {
          return {
            ...scenario,
            requirementId: `REQ-${scenario.parent_requirement_displayId}`
          };
        }
        
        // Fallback: For anything else, use RequirementID mapping if available
        const originalReqId = scenario.requirementId; // This is like UI010_001
        const parentReqUuid = requirementIdMapping[originalReqId];
        if (parentReqUuid && requirementDisplayIdMap[parentReqUuid]) {
          return {
            ...scenario,
            requirementId: `REQ-${requirementDisplayIdMap[parentReqUuid]}`
          };
        }
        
        // Last resort: keep the original ID
        return scenario;
      }));
      
      // Compare with previous scenarios to find new ones
      const currentScenarioIds = new Set(updatedScenarios.map(s => s.id));
      const newScenarioIds: string[] = [];
      
      updatedScenarios.forEach(scenario => {
        if (!previousScenarioIdsRef.current.has(scenario.id)) {
          newScenarioIds.push(scenario.id);
        }
      });
      
      // Update state
      setScenarios(updatedScenarios);
      
      // Only highlight new scenarios if we've completed initial loading
      if (initialLoadComplete && newScenarioIds.length > 0) {
        setNewlyAddedScenarioIds(newScenarioIds);
        // Remove highlighting after 1 second
        setTimeout(() => {
          setNewlyAddedScenarioIds([]);
        }, 1000);
        
        // Show toast notification for new scenarios
        toast.success(`${newScenarioIds.length} new scenario(s) generated!`, { 
          duration: 1000 
        });
      }
      
      // Update our reference of seen scenarios
      previousScenarioIdsRef.current = currentScenarioIds;
      
      // Check if generation is complete
      const statusResponse = await axios.get(
        `${API_ENDPOINTS.getUseCaseStatus}/${usecaseId}`
      );
      
      if (statusResponse.data.scenario_generation === "Completed") {
        setIsStreaming(false); // Stop streaming when complete
      }
    } catch (error) {
      console.error("Error fetching scenarios:", error);
      if (!initialLoadComplete) {
        setRequirementLoadError("Failed to fetch scenarios. Please try again.");
      }
    } finally {
      if (!initialLoadComplete) {
        setInitialLoadComplete(true);
        setIsLoading(false);
      }
    }
  }, [usecaseId, initialLoadComplete]);

  // Update the generateScenarios function to check workflow status after triggering generation
  const generateScenarios = async () => {
    // console.log("[ScenarioGeneration] Triggering scenario generation for usecase ID:", usecaseId);
    setIsLoading(true);
    try {
      // Make a POST request to the scenario generation endpoint
      const response = await axios.post(API_ENDPOINTS.generateScenarios, {
        usecase_id: usecaseId
      });
      
      // console.log("[ScenarioGeneration] Scenario generation triggered:", response.data);
      
      // Show a toast message
      // toast.success("Scenario generation has been triggered. This may take a few minutes.");
      
      // Keep loading state active
      setIsLoading(true);
    } catch (error) {
      console.error("[ScenarioGeneration] Error triggering scenario generation:", error);
      setRequirementLoadError("Failed to trigger scenario generation. Please try again.");
      setIsLoading(false);
    }
  };

  // Replace the existing checkExistingScenariosAndGenerate function with this
  const checkExistingScenariosAndGenerate = () => {
    fetchScenariosByUsecase();
  };

  const {
    scenarios,
    selectedScenario,
    expandedScenarios,
    showRequirementDialog,
    selectedRequirement,
    selectedScenarios,
    showAddDialog,
    editingScenario,
    setScenarios,
    setShowAddDialog,
    setShowRequirementDialog,
    setSelectedScenarios,
    setEditingScenario,
    handleScenarioClick,
    handleRequirementClick,
    handleSaveNewScenario,
    handleBulkStatusChange
  } = useScenarioState();

  const [showGridDialog, setShowGridDialog] = useState(false);

  const handleEditScenario = (e: React.MouseEvent, scenarioId: string) => {
    e.stopPropagation();
    const scenario = scenarios.find(s => s.id === scenarioId);
    if (scenario) {
      setEditingScenario(scenario);
      setShowAddDialog(true);
    }
  };

  const handleDeleteScenario = (e: React.MouseEvent | null, scenarioId: string) => {
    // Only call stopPropagation if e exists
    if (e) e.stopPropagation();
    
    // Find the scenario to get its backend ID
    const scenario = scenarios.find(s => s.id === scenarioId);
    
    if (!scenario || !scenario.scenario_id) {
      toast.error("Cannot find scenario details");
      return;
    }
    
    // Get the backend scenario ID
    const backendScenarioId = scenario.scenario_id;
    
    console.log("Deleting UI scenario ID:", scenarioId);
    console.log("Mapped to backend scenario ID:", backendScenarioId);
    
    // If this is a direct deletion from the confirmation dialog
    if (!e) {
      // Make API call to delete the scenario on the backend
      try {
        axios.post(`${ENV.API_URL}/scenario-management/delete-by-scenarioid/${backendScenarioId}`)
          .then(() => {
            // Mark the scenario as deleted instead of removing it
            setScenarios(scenarios.map(s => 
              s.id === scenarioId ? { ...s, is_deleted: true } : s
            ));
            
            toast.success("Scenario deleted successfully");
          })
          .catch(error => {
            console.error("Error deleting scenario:", error);
            toast.error("Failed to delete scenario");
          });
      } catch (error) {
        console.error("Error initiating delete request:", error);
        toast.error("Failed to delete scenario");
      }
    } else {
      // This is from the delete button click, just open the confirmation dialog
      setScenarioToDelete(scenarioId);
      setDeleteDialogOpen(true);
    }
  };

  const handleConfirmDelete = async () => {
    if (scenarioToDelete) {
      // Find the scenario to get its backend ID
      const scenario = scenarios.find(s => s.id === scenarioToDelete);
      
      if (scenario && scenario.scenario_id) {
        const backendScenarioId = scenario.scenario_id;
        console.log("Confirming deletion of scenario with backend ID:", backendScenarioId);
        
        // Make API call to delete the scenario on the backend
        try {
          await axios.post(`${ENV.API_URL}/scenario-management/delete-by-scenarioid/${backendScenarioId}`);
          
          // Mark the scenario as deleted
          setScenarios(scenarios.map(s => 
            s.id === scenarioToDelete ? { ...s, is_deleted: true } : s
          ));
          
          // Remove from selected scenarios if it was selected
          setSelectedScenarios(prev => prev.filter(id => id !== scenarioToDelete));
          
          toast.success("Scenario deleted successfully");
        } catch (error) {
          console.error("Error deleting scenario:", error);
          toast.error("Failed to delete scenario");
        }
      } else {
        toast.error("Could not find scenario details");
      }
      
      setDeleteDialogOpen(false);
      setScenarioToDelete(null);
    }
  };

  const handleUpdateScenario = (updatedScenario: TestScenario) => {
    setScenarios(scenarios.map(scenario =>
      scenario.id === updatedScenario.id ? updatedScenario : scenario
    ));
  };

  const handleSelectScenario = (scenarioId: string, checked: boolean) => {
    setSelectedScenarios(prev =>
      checked
        ? [...prev, scenarioId]
        : prev.filter(id => id !== scenarioId)
    );
  };

  const handleSelectAll = (checked: boolean) => {
    setSelectedScenarios(checked ? scenarios.map(s => s.id) : []);
  };

  const handleBulkDelete = () => {
    if (selectedScenarios.length === 0) {
      toast.error("Please select at least one scenario to delete");
      return;
    }
    
    // Map the UI scenario IDs (TS-123) to their actual backend UUIDs
    const backendScenarioIds = selectedScenarios.map(id => {
      // Find the scenario by UI ID to get its backend ID (scenario_id)
      const scenario = scenarios.find(s => s.id === id);
      return scenario?.scenario_id || null;
    }).filter(id => id !== null);
    
    console.log("Selected UI scenario IDs:", selectedScenarios);
    console.log("Mapped backend scenario IDs for deletion:", backendScenarioIds);
    
    // If we have actual backend IDs, show the deletion dialog
    if (backendScenarioIds.length > 0) {
      setBulkDeleteDialogOpen(true);
    } else {
      toast.error("Could not find backend IDs for selected scenarios");
    }
  };

  const handleConfirmBulkDelete = async () => {
    try {
      // Map the UI scenario IDs (TS-123) to their actual backend UUIDs
      const backendScenarioIds = selectedScenarios.map(id => {
        // Find the scenario by UI ID to get its backend ID (scenario_id)
        const scenario = scenarios.find(s => s.id === id);
        return scenario?.scenario_id || null;
      }).filter(id => id !== null) as string[];
      
      console.log("Bulk deleting scenarios with backend IDs:", backendScenarioIds);
      
      let successCount = 0;
      let failureCount = 0;
      
      // Call the backend API to delete each scenario
      for (const scenarioId of backendScenarioIds) {
        try {
          await axios.post(`${ENV.API_URL}/scenario-management/delete-by-scenarioid/${scenarioId}`);
          successCount++;
        } catch (error) {
          console.error(`Error deleting scenario ${scenarioId}:`, error);
          failureCount++;
        }
      }
      
      // Update the UI by marking selected scenarios as deleted
      setScenarios(scenarios.map(scenario => 
        selectedScenarios.includes(scenario.id) 
          ? { ...scenario, is_deleted: true } 
          : scenario
      ));
      
      // Clear selected scenarios
      setSelectedScenarios([]);
      
      // Show appropriate toast messages
      if (successCount > 0) {
        toast.success(`Deleted ${successCount} scenario${successCount !== 1 ? 's' : ''} successfully`);
      }
      
      if (failureCount > 0) {
        toast.error(`Failed to delete ${failureCount} scenario${failureCount !== 1 ? 's' : ''}`);
      }
      
      setBulkDeleteDialogOpen(false);
      
    } catch (error) {
      console.error("Error during bulk delete:", error);
      toast.error("Failed to delete scenarios");
      setBulkDeleteDialogOpen(false);
    }
  };

  const toggleLeftPanel = () => {
    setIsLeftPanelMaximized(!isLeftPanelMaximized);
    setIsRightPanelMaximized(false);
  };

  const toggleRightPanel = () => {
    setIsRightPanelMaximized(!isRightPanelMaximized);
    setIsLeftPanelMaximized(false);
  };

  // Add this function to filter scenarios
  const getFilteredScenarios = (scenarios: TestScenario[]) => {
    return scenarios
      .filter(scenario => !scenario.is_deleted)
      .sort((a, b) => {
        // Extract displayId from scenario.id format "TS-123"
        const aDisplayId = parseInt(a.id.replace('TS-', '')) || 0;
        const bDisplayId = parseInt(b.id.replace('TS-', '')) || 0;
        return aDisplayId - bDisplayId;
      });
  };

  // Update the pagination function to use filtered scenarios
  const getPaginatedScenarios = () => {
    const filteredScenarios = getFilteredScenarios(scenarios);
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return filteredScenarios.slice(startIndex, Math.min(endIndex, filteredScenarios.length));
  };

  // Update total pages calculation based on filtered scenarios
  const totalPages = Math.ceil(getFilteredScenarios(scenarios).length / itemsPerPage);

  // Add a function for pagination display information
  const displayInfo = () => {
    const filteredScenarios = getFilteredScenarios(scenarios);
    const startIndex = (currentPage - 1) * itemsPerPage + 1;
    const endIndex = Math.min(currentPage * itemsPerPage, filteredScenarios.length);
    return {
      start: filteredScenarios.length === 0 ? 0 : startIndex,
      end: endIndex,
      total: filteredScenarios.length
    };
  };

  const goToNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const goToPreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const goToPage = (pageNumber: number) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  const handleItemsPerPageChange = (value: string) => {
    setItemsPerPage(parseInt(value));
    setCurrentPage(1); // Reset to first page when changing items per page
  };

  const handleJumpToPage = (e: React.FormEvent) => {
    e.preventDefault();
    const pageNumber = parseInt(jumpToPageValue);
    
    if (!isNaN(pageNumber) && pageNumber >= 1 && pageNumber <= totalPages) {
      goToPage(pageNumber);
    } else {
      console.warn(`Invalid page number: ${jumpToPageValue}. Must be between 1 and ${totalPages}`);
    }
    
    // Reset the input field after jumping
    setJumpToPageValue('');
  };

  // Render page numbers for pagination
  const renderPageNumbers = () => {
    const pageNumbers = [];
    const maxPageButtons = 5; // Maximum number of page buttons to show
    
    let startPage = Math.max(1, currentPage - Math.floor(maxPageButtons / 2));
    let endPage = Math.min(totalPages, startPage + maxPageButtons - 1);
    
    // Adjust if we're at the end
    if (endPage - startPage + 1 < maxPageButtons) {
      startPage = Math.max(1, endPage - maxPageButtons + 1);
    }
    
    // Always show first page
    if (startPage > 1) {
      pageNumbers.push(
        <Button 
          key={1} 
          variant={currentPage === 1 ? "default" : "outline"} 
          size="sm" 
          onClick={() => goToPage(1)}
          className="h-8 w-8 p-0"
        >
          1
        </Button>
      );
      
      // Add ellipsis if there's a gap
      if (startPage > 2) {
        pageNumbers.push(
          <span key="start-ellipsis" className="px-2">...</span>
        );
      }
    }
    
    // Add page numbers
    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(
        <Button 
          key={i} 
          variant={currentPage === i ? "default" : "outline"} 
          size="sm" 
          onClick={() => goToPage(i)}
          className="h-8 w-8 p-0"
        >
          {i}
        </Button>
      );
    }
    
    // Always show last page
    if (endPage < totalPages) {
      // Add ellipsis if there's a gap
      if (endPage < totalPages - 1) {
        pageNumbers.push(
          <span key="end-ellipsis" className="px-2">...</span>
        );
      }
      
      pageNumbers.push(
        <Button 
          key={totalPages} 
          variant={currentPage === totalPages ? "default" : "outline"} 
          size="sm" 
          onClick={() => goToPage(totalPages)}
          className="h-8 w-8 p-0"
        >
          {totalPages}
        </Button>
      );
    }
    
    return pageNumbers;
  };

  // First, create a scenario ID mapping
  const createScenarioIdMapping = () => {
    const mapping: Record<string, string> = {};
    scenarios.forEach(scenario => {
      if (scenario.scenario_id) {
        mapping[scenario.id] = scenario.scenario_id;
      }
    });
    return mapping;
  };

  if (isLoading) {
    return (
      <div className="flex flex-1 items-center justify-center p-4">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-lg font-medium text-gray-600">
          Please wait, generating the test scenarios...
          </p>
        </div>
      </div>
    );
  }

  if (requirementLoadError) {
    return (
      <div className="flex flex-1 items-center justify-center p-4">
        <div className="flex flex-col items-center gap-4 text-red-500">
          <p className="text-lg font-medium">{requirementLoadError}</p>
          <Button 
            onClick={() => window.location.reload()}
            variant="outline"
          >
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="flex flex-col flex-1 h-full overflow-hidden p-4">
        <UserAssociationInfo 
          product={product} 
          subProduct={subProduct} 
          domain={domain} 
        />
        <BundleInfo bundleName={bundleName} 
        usecaseId={usecaseId?.toString()}
        />
        
        <div className="flex flex-row flex-1">
          <div className={cn(
            "flex flex-col transition-all duration-300",
            isLeftPanelMaximized ? "w-full" : "w-2/3",
            isRightPanelMaximized ? "w-0 hidden" : "flex"
          )}>
            <div className="flex justify-between items-center py-2">
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-semibold">Test Scenarios</h2>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleLeftPanel}
                >
                  {isLeftPanelMaximized ? (
                    <Minimize2 className="h-4 w-4" />
                  ) : (
                    <Maximize2 className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>

            <ScenarioHeader
              selectedScenariosCount={selectedScenarios.length}
              totalScenariosCount={getFilteredScenarios(scenarios).length}
              onSelectAll={handleSelectAll}
              onAddScenario={() => setShowAddDialog(true)}
              onBulkStatusChange={handleBulkStatusChange}
              onBulkDelete={handleBulkDelete}
              onShowGrid={() => setShowGridDialog(true)}
            />

            <ScrollArea className="flex-1">
              <div className="pr-4">
                <ScenarioList
                  scenarios={getPaginatedScenarios()}
                  expandedScenarios={expandedScenarios}
                  selectedScenario={selectedScenario}
                  selectedScenarios={selectedScenarios}
                  onScenarioClick={handleScenarioClick}
                  onEditScenario={handleEditScenario}
                  onDeleteScenario={handleDeleteScenario}
                  onRequirementClick={handleRequirementClick}
                  onToggleSelect={handleSelectScenario}
                  onUpdateScenario={handleUpdateScenario}
                  newlyAddedScenarioIds={newlyAddedScenarioIds}
                />
                {scenarios.length === 0 && !isLoading && (
                  <div className="text-center py-6 text-gray-500">
                    No scenarios available.
                  </div>
                )}
                {isLoading && (
                  <div className="flex justify-center items-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                    <span className="ml-2">Loading scenarios...</span>
                  </div>
                )}
              </div>
            </ScrollArea>

            {/* Pagination Controls */}
            {scenarios.length > 0 && (
              <div className="flex justify-between items-center mt-4 border-t pt-4">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <span>Rows per page:</span>
                  <Select 
                    value={itemsPerPage.toString()} 
                    onValueChange={handleItemsPerPageChange}
                  >
                    <SelectTrigger className="h-8 w-20">
                      <SelectValue placeholder="5" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5</SelectItem>
                      <SelectItem value="10">10</SelectItem>
                      <SelectItem value="20">20</SelectItem>
                      <SelectItem value="50">50</SelectItem>
                    </SelectContent>
                  </Select>
                  <span className="ml-4">
                    {`${displayInfo().start}-${displayInfo().end} of ${displayInfo().total}`}
                  </span>
                </div>
                
                <div className="flex items-center gap-2">
                  {/* Jump to Page Form */}
                  <form onSubmit={handleJumpToPage} className="flex items-center mr-4">
                    <span className="text-sm text-gray-600 mr-2">Jump to:</span>
                    <input
                      type="number"
                      min="1"
                      max={totalPages}
                      value={jumpToPageValue}
                      onChange={(e) => setJumpToPageValue(e.target.value)}
                      className="h-8 w-24 px-2 border rounded-md text-sm"
                      placeholder="Page"
                    />
                    <Button 
                      type="submit" 
                      size="sm" 
                      className="ml-1 h-8 bg-blue-500 hover:bg-blue-600 text-white"
                      disabled={!jumpToPageValue || totalPages <= 1}
                    >
                      Go
                    </Button>
                  </form>
                  
                  <div className="flex items-center">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={goToPreviousPage}
                      disabled={currentPage === 1}
                      className="h-8 w-8 p-0"
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    
                    <div className="flex items-center gap-1 mx-2">
                      {renderPageNumbers()}
                    </div>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={goToNextPage}
                      disabled={currentPage === totalPages}
                      className="h-8 w-8 p-0"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {!isLeftPanelMaximized && (
            <div className={cn(
              "flex flex-col transition-all duration-300",
              isRightPanelMaximized ? "w-full" : "w-1/3",
              isLeftPanelMaximized ? "w-0 hidden" : "flex"
            )}>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold">Requirements Coverage</h2>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleRightPanel}
                >
                  {isRightPanelMaximized ? (
                    <Minimize2 className="h-4 w-4" />
                  ) : (
                    <Maximize2 className="h-4 w-4" />
                  )}
                </Button>
              </div>

              <ScrollArea className="flex-1">
                <RequirementsCoverage 
                  scenarios={getFilteredScenarios(scenarios)}
                  selectedScenario={selectedScenario}
                  onRequirementClick={handleRequirementClick}
                />
              </ScrollArea>
            </div>
          )}
        </div>

        {/* Add streaming indicator */}
        {isStreaming && (
          <div className="flex items-center gap-2 mt-2 p-2 bg-blue-50 border border-blue-200 rounded-md">
            <div className="h-2 w-2 bg-blue-500 rounded-full animate-pulse"></div>
            <span className="text-sm text-blue-700">
              Streaming scenarios as they are generated...
            </span>
          </div>
        )}
      </div>

      {/* Dialogs Section */}
      <AddScenarioDialog
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
        editingScenario={editingScenario}
        onSave={handleSaveNewScenario}
        requirementId={selectedRequirement || ""}
      />

      <RequirementDialog
        open={showRequirementDialog}
        onOpenChange={setShowRequirementDialog}
        selectedRequirement={selectedRequirement}
      />

      <ScenarioGridDialog
        open={showGridDialog}
        onOpenChange={setShowGridDialog}
        scenarios={getFilteredScenarios(scenarios)}
        title="Test Scenarios"
      />

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this scenario? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>Cancel</Button>
            <Button 
              variant="destructive" 
              onClick={handleConfirmDelete}
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Delete Dialog */}
      <Dialog open={bulkDeleteDialogOpen} onOpenChange={setBulkDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Bulk Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete {selectedScenarios.length} scenarios? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBulkDeleteDialogOpen(false)}>Cancel</Button>
            <Button 
              variant="destructive" 
              onClick={handleConfirmBulkDelete}
            >
              Delete {selectedScenarios.length} Scenarios
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}