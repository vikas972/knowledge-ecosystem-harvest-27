export interface TestCase {
  id: string;
  title: string;
  scenarioId: string;
  requirementId: string;
  priority: "high" | "medium" | "low";
  description: string;
  preconditions: string[];
  testData: {
    field: string;
    value: string;
  }[];
  testSteps: {
    step: string;
    input: string;
    expected: string;
  }[];
  expectedResults: string[];
  postconditions: string[];
  status: "completed" | "in_progress" | "needs_review";
  is_deleted?: boolean;
  testcase_id?: string | null;
  flow?: string | null;
  displayId?: number | null;
  scenario_display_id?: string | null;
  requirement_display_id?: string | null;
  actualScenarioId?: string | null;
}

export interface TestCasesProps {
  selectedFile: { id: string; name: string; uploadTime: Date } | null;
  usecaseId?: string | number;
}

export interface CoverageStats {
  scenarioCoverage: number;
  requirementCoverage: number;
  testCaseCount: number;
  scenarioCount: number;
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  steps: {
    id: string;
    description: string;
    expectedResult: string;
  }[];
}
