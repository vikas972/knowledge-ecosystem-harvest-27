import { useState } from "react";
import { ChevronDown, ChevronUp, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { TestCase } from "./types";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import axios from "axios";
import { ENV } from "@/config/env";
import { toast } from "sonner";

interface TestCaseCardProps {
  testCase: TestCase;
  isExpanded: boolean;
  isSelected: boolean;
  checked: boolean;
  onSelect: (checked: boolean) => void;
  onToggle: () => void;
  onClick: () => void;
  onScenarioClick: (scenarioId: string) => void;
  onRequirementClick: (requirementId: string) => void;
  onDelete: (testCaseId: string) => void;
  isNew?: boolean;
}

const getFlowBadgeStyle = (flow: string | null) => {
  const normalizedFlow = flow?.toLowerCase().trim() || '';
  
  switch (normalizedFlow) {
    case 'primary flow':
      return 'bg-[#DCFCE7] text-gray-700 border-[#DCFCE7]';
    case 'alternate flow':
      return 'bg-[#FEF9C3] text-gray-700 border-[#FEF9C3]';
    case 'negative flow':
      return 'bg-[#FEE2E2] text-gray-700 border-[#FEE2E2]';
    case 'exception flow':
      return 'bg-[#F5E8FF] text-gray-700 border-[#F5E8FF]';
    default:
      return 'bg-gray-100 text-gray-700';
  }
};

export const TestCaseCard = ({
  testCase,
  isExpanded,
  isSelected,
  checked,
  onSelect,
  onToggle,
  onClick,
  onScenarioClick,
  onRequirementClick,
  onDelete,
  isNew = false
}: TestCaseCardProps) => {

  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState(testCase.title);
  const [editedPriority, setEditedPriority] = useState<"high" | "medium" | "low">(testCase.priority);
  const [editedStatus, setEditedStatus] = useState<"completed" | "in_progress" | "needs_review">(testCase.status);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleSaveEdit = () => {
    // Here you would typically call a function passed from the parent to update the test case
    // console.log("Saving edited test case:", {
    //   ...testCase,
    //   title: editedTitle,
    //   priority: editedPriority,
    //   status: editedStatus,
    // });
    setIsEditing(false);
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsDeleteDialogOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!testCase.testcase_id) {
      toast.error("No testcase ID available for deletion");
      setIsDeleteDialogOpen(false);
      return;
    }

    setIsDeleting(true);
    try {
      const response = await axios.post(
        `${ENV.API_URL}/testcase-management/delete-by-testcaseid/${testCase.testcase_id}`
      );
      
      if (response.status === 200) {
        toast.success("Test case deleted successfully");
        onDelete(testCase.id);
      } else {
        toast.error("Failed to delete test case");
      }
    } catch (error) {
      console.error("Error deleting test case:", error);
      toast.error("An error occurred while deleting the test case");
    } finally {
      setIsDeleting(false);
      setIsDeleteDialogOpen(false);
    }
  };

  const handleCancelDelete = () => {
    setIsDeleteDialogOpen(false);
  };

  return (
    <Card
      className={cn(
        "mb-4 transition-all cursor-pointer",
        isSelected && "border-primary ring-2 ring-primary",
        isNew ? "animate-pulse bg-blue-50" : "bg-white"
      )}
      onClick={() => onClick()}
    >
      <CardHeader className="p-4">
        <div className="flex items-center gap-3">
          <Checkbox
            checked={checked} 
            onCheckedChange={onSelect}
            onClick={(e) => e.stopPropagation()}
          />
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <span className="font-medium">TC-{testCase.displayId || testCase.id.replace('TC-', '')}</span>
              <span className="text-gray-500">-</span>
              {isEditing ? (
                <Input
                  value={editedTitle}
                  onChange={(e) => setEditedTitle(e.target.value)}
                  className="h-7"
                  onClick={(e) => e.stopPropagation()}
                />
              ) : (
                <span>{testCase.title}</span>
              )}
            </div>
            <p className="text-sm text-gray-600 mb-2">{testCase.description}</p>
            <div className="flex items-center gap-2 text-sm">
              {testCase.flow && (
                <Badge
                  variant="outline"
                  className={cn(
                    "cursor-pointer",
                    getFlowBadgeStyle(testCase.flow)
                  )}
                >
                  {testCase.flow}
                </Badge>
              )}
              <Badge
                variant="outline"
                className="cursor-pointer hover:bg-primary/10"
                onClick={(e) => {
                  e.stopPropagation();
                  onScenarioClick(testCase.scenarioId);
                }}
              >
                {testCase.scenarioId.startsWith('TS-') ? testCase.scenarioId : `TS-${testCase.scenarioId}`}
              </Badge>
              <Badge
                variant="outline"
                className="cursor-pointer hover:bg-primary/10"
                onClick={(e) => {
                  e.stopPropagation();
                  onRequirementClick(testCase.requirementId);
                }}
              >
                {testCase.requirementId.startsWith('REQ-') ? testCase.requirementId : `REQ-${testCase.requirementId}`}
              </Badge>
              {isEditing ? (
                <>
                  <Select 
                    value={editedPriority} 
                    onValueChange={(value: "high" | "medium" | "low") => setEditedPriority(value)}
                  >
                    <SelectTrigger 
                      className="h-7 w-24"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select 
                    value={editedStatus} 
                    onValueChange={(value: "completed" | "in_progress" | "needs_review") => setEditedStatus(value)}
                  >
                    <SelectTrigger 
                      className="h-7 w-32"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="needs_review">Needs Review</SelectItem>
                    </SelectContent>
                  </Select>
                </>
              ) : (
                <>
                  {/* Both priority and status badges removed */}
                </>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2">
            {isEditing ? (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleSaveEdit();
                  }}
                >
                  Save
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsEditing(false);
                  }}
                >
                  Cancel
                </Button>
              </>
            ) : (
              <>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={(e) => {
                    e.stopPropagation();
                    // setIsEditing(true);
                    // Edit functionality disabled
                  }}
                >
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-red-500 hover:text-red-600 hover:bg-red-50"
                  onClick={handleDelete}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggle();
                  }}
                >
                  {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </Button>
              </>
            )}
          </div>
        </div>
      </CardHeader>
      {isExpanded && (
        <CardContent className="px-4 pb-4">
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="preconditions">
              <AccordionTrigger 
                className="text-sm font-medium"
                onClick={(e) => e.stopPropagation()}
              >
                Pre-conditions
              </AccordionTrigger>
              <AccordionContent onClick={(e) => e.stopPropagation()}>
                <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
                  {testCase.preconditions.map((condition, index) => (
                    <li key={index}>{condition}</li>
                  ))}
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="test-data">
              <AccordionTrigger 
                className="text-sm font-medium"
                onClick={(e) => e.stopPropagation()}
              >
                Test Data
              </AccordionTrigger>
              <AccordionContent onClick={(e) => e.stopPropagation()}>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  {testCase.testData.map((data, index) => (
                    <div key={index} className="flex justify-between p-2 bg-gray-50 rounded">
                      <span className="text-gray-600 font-medium">{data.field}:</span>
                      <span>{data.value}</span>
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="test-steps" className="border-b">
              <AccordionTrigger 
                className="text-sm font-medium"
                onClick={(e) => e.stopPropagation()}
              >
                Test Steps
              </AccordionTrigger>
              <AccordionContent onClick={(e) => e.stopPropagation()}>
                <div className="space-y-4">
                  {testCase.testSteps.map((step, index) => (
                    <div key={index} className="p-3 bg-gray-50 rounded">
                      <div className="font-medium text-sm mb-2">Step {index + 1}: {step.step}</div>
                      {/* <div className="text-sm space-y-1 ml-4">
                        <div className="text-gray-600">Input: {step.input}</div>
                        <div className="text-gray-600">Expected: {step.expected}</div>
                      </div> */}
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="expected-results">
              <AccordionTrigger 
                className="text-sm font-medium"
                onClick={(e) => e.stopPropagation()}
              >
                Expected Results
              </AccordionTrigger>
              <AccordionContent onClick={(e) => e.stopPropagation()}>
                <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
                  {testCase.expectedResults.map((result, index) => (
                    <li key={index}>{result}</li>
                  ))}
                </ul>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="postconditions">
              <AccordionTrigger 
                className="text-sm font-medium"
                onClick={(e) => e.stopPropagation()}
              >
                Post-conditions
              </AccordionTrigger>
              <AccordionContent onClick={(e) => e.stopPropagation()}>
                <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
                  {testCase.postconditions.map((condition, index) => (
                    <li key={index}>{condition}</li>
                  ))}
                </ul>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      )}
      
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription asChild>
              <div>
                <div className="mt-2 text-gray-600">
                  You are about to delete the test case "{testCase.title}".
                </div>
                <div className="mt-2 text-gray-600">
                  This action will permanently remove this test case and may affect traceability and coverage metrics.
                </div>
                <div className="mt-4 font-medium text-red-600">
                  Are you sure you want to delete this test case?
                </div>
              </div>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={handleCancelDelete} disabled={isDeleting}>Cancel</Button>
            <Button 
              variant="destructive" 
              onClick={handleConfirmDelete}
              disabled={isDeleting}
            >
              {isDeleting ? "Deleting..." : "Delete Test Case"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
};