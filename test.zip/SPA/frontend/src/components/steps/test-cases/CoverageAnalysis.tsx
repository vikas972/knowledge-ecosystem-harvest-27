import { AlertCircle, CheckCircle, Waves, Network } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { CoverageStats, TestCase, Scenario } from "./types";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RequirementDialog } from "../scenario/dialogs/RequirementDialog";
import { ScenarioDialog } from "../scenario/dialogs/ScenarioDialog";
import { TestScenario } from "../scenario/types";
import { useEffect, useState } from "react";
import axios from "axios";
import { Button } from "@/components/ui/button";

interface CoverageAnalysisProps {
  selectedTestCase?: TestCase | null;
  onCoverageItemClick: (testCase: TestCase) => void;
  testCases: TestCase[];
  usecaseId?: string;
  onShowTraceability?: () => void;
}

export const CoverageAnalysis = ({ 
  selectedTestCase, 
  onCoverageItemClick,
  testCases: initialTestCases,
  usecaseId,
  onShowTraceability 
}: CoverageAnalysisProps) => {
  const [testCases, setTestCases] = useState<TestCase[]>(Array.isArray(initialTestCases) ? initialTestCases : []);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (Array.isArray(initialTestCases)) {
      setTestCases(initialTestCases);
    }
  }, [initialTestCases]);

  useEffect(() => {
    if (usecaseId) {
      fetchTestCases(usecaseId);
    }
  }, [usecaseId]);

  const fetchTestCases = async (usecaseId: string) => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get(`/testcase-management/get-testcases-for-usecase/${usecaseId}`);
      if (Array.isArray(response.data)) {
        setTestCases(response.data);
      } else {
        console.error("API response is not an array:", response.data);
      }
    } catch (err) {
      console.error("Error fetching test cases:", err);
      setError("Failed to load test cases");
    } finally {
      setLoading(false);
    }
  };

  const getScenarioFlowCoverage = (scenarioId: string) => {
    const scenarioTests = Array.isArray(testCases) ? testCases.filter(tc => tc.scenarioId === scenarioId) : [];
    const totalFlows = 7;
    const coveredFlows = 4;
    return {
      percentage: Math.round((coveredFlows / totalFlows) * 100),
      covered: coveredFlows,
      total: totalFlows
    };
  };

  const transformTestCaseToScenario = (testCase: TestCase): TestScenario => {
    return {
      id: testCase.id,
      title: testCase.title,
      description: testCase.description || '',
      requirementId: testCase.requirementId,
      priority: testCase.priority || 'medium',
      status: testCase.status || 'completed',
      flows: [{
        type: "primary",
        description: "Main test flow",
        subflows: testCase.testSteps.map((step, index) => ({
          name: `Step ${index + 1}`,
          coverage: step.step,
          expectedResults: step.expected,
          entries: []
        }))
      }],
      is_deleted: testCase.is_deleted
    };
  };

  const CoverageItem = ({ testCase, isSelected = false }: { testCase: TestCase; isSelected?: boolean }) => {
    const scenarioCoverage = getScenarioFlowCoverage(testCase.scenarioId);
    
    return (
      <Dialog>
        <DialogTrigger asChild>
          <div 
            className={cn(
              "space-y-4 cursor-pointer hover:bg-accent rounded-lg p-4 transition-colors mb-4",
              isSelected && "bg-accent"
            )}
            onClick={() => onCoverageItemClick(testCase)}
          >
            <div className="space-y-3">
              <div className="space-y-1">
                <h4 className="text-sm font-medium">{testCase.title}</h4>
                <p className="text-sm text-muted-foreground">
                  {testCase.description?.substring(0, 100)}
                  {testCase.description && testCase.description.length > 100 ? '...' : ''}
                </p>
              </div>

              <div className="space-y-1">
                <h4 className="text-sm font-medium">Flow Covered</h4>
                <p className="text-sm text-muted-foreground">
                  Primary flow (standard login)
                </p>
              </div>

              <div className="space-y-1">
                <h4 className="text-sm font-medium">Overall Scenario Coverage</h4>
                <div className="flex items-center gap-2">
                  {scenarioCoverage.percentage === 100 ? (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  ) : (
                    <AlertCircle className="h-4 w-4 text-amber-500" />
                  )}
                  <p className="text-sm text-muted-foreground">
                    {scenarioCoverage.percentage}% ({scenarioCoverage.covered} out of {scenarioCoverage.total} flows covered)
                  </p>
                </div>
              </div>
            </div>
          </div>
        </DialogTrigger>

        <DialogContent className="max-w-4xl h-[80vh]">
          <DialogHeader>
            <DialogTitle>Coverage Details</DialogTitle>
          </DialogHeader>
          <Tabs defaultValue="requirement" className="h-full">
            <TabsList>
              <TabsTrigger value="requirement">Requirement</TabsTrigger>
              <TabsTrigger value="scenario">Test Scenario</TabsTrigger>
            </TabsList>
            <TabsContent value="requirement" className="h-[calc(100%-48px)] overflow-y-auto">
              <div className="space-y-4 p-4">
                <div className="flex justify-between items-start">
                  <h3 className="text-lg font-semibold">
                    {testCase.requirementId}
                  </h3>
                  {onShowTraceability && (
                    <Button 
                      size="sm" 
                      className="flex items-center gap-2"
                      onClick={() => {
                        onCoverageItemClick(testCase);
                        onShowTraceability();
                      }}
                    >
                      <Network className="h-4 w-4" />
                      Show Traceability
                    </Button>
                  )}
                </div>
              </div>
            </TabsContent>
            <TabsContent value="scenario" className="h-[calc(100%-48px)] overflow-y-auto">
              <ScenarioDialog
                open={true}
                onOpenChange={() => {}}
                selectedScenario={testCase.scenarioId}
                scenarios={[transformTestCaseToScenario(testCase)]}
              />
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    );
  };

  if (loading) {
    return <div>Loading test cases...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="space-y-4 pr-4">
      <Card>
        <CardContent className="p-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-medium flex items-center gap-2">
              <Waves className="h-4 w-4" />
              Coverage Details
            </h3>
            {onShowTraceability && (
              <Button 
                size="sm" 
                variant="outline"
                className="flex items-center gap-2"
                onClick={onShowTraceability}
              >
                <Network className="h-4 w-4" />
                Show Traceability
              </Button>
            )}
          </div>
          
          <div className="space-y-2">
            {!Array.isArray(testCases) || testCases.length === 0 ? (
              <p>No test cases found for this bundle.</p>
            ) : (
              testCases.map((testCase) => (
                <CoverageItem
                  key={testCase.id}
                  testCase={testCase}
                  isSelected={selectedTestCase?.id === testCase.id}
                />
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
