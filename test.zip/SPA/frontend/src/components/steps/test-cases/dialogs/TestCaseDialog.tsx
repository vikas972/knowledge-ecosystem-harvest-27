import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { TestCase } from "../types";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Network, Activity } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface TestCaseDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedTestCase: string | null;
  testCases: TestCase[];
}

export const TestCaseDialog = ({
  open,
  onOpenChange,
  selectedTestCase,
  testCases = [],
}: TestCaseDialogProps) => {
  // Find the selected test case from the array
  const testCase = testCases.find(tc => tc.id === selectedTestCase) || null;

  if (!testCase) {
    return null;
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>Test Case Details</DialogTitle>
        </DialogHeader>
        <div className="max-h-[70vh] overflow-y-auto">
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-semibold mb-2">{testCase.title}</h3>
              <p className="text-sm text-gray-600 mb-4">{testCase.description}</p>
              <div className="flex items-center gap-2 mb-4">
                <Badge variant="outline">ID: {testCase.id}</Badge>
                <Badge variant="outline">Scenario: {testCase.scenarioId}</Badge>
                <Badge variant="outline">Requirement: {testCase.requirementId}</Badge>
                <Badge variant="secondary">{testCase.status || 'in_progress'}</Badge>
                <Badge>{testCase.priority}</Badge>
              </div>
              
              <Tabs defaultValue="details" className="mt-6">
                <TabsList>
                  <TabsTrigger value="details">Details</TabsTrigger>
                  <TabsTrigger value="traceability" className="flex items-center gap-1">
                    <Network className="h-4 w-4" />
                    Traceability
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="details" className="space-y-6 pt-4">
                  {testCase.preconditions && testCase.preconditions.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-2">Pre-conditions</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        {testCase.preconditions.map((condition, index) => (
                          <li key={index} className="text-sm text-gray-600">
                            {condition}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {testCase.testData && testCase.testData.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-2">Test Data</h4>
                      <div className="border rounded-md overflow-hidden">
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Field</th>
                              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Value</th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            {testCase.testData.map((data, index) => (
                              <tr key={index}>
                                <td className="px-4 py-2 text-sm text-gray-600">{data.field}</td>
                                <td className="px-4 py-2 text-sm text-gray-600">{data.value}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                  
                  {testCase.expectedResults && testCase.expectedResults.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-2">Expected Results</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        {testCase.expectedResults.map((result, index) => (
                          <li key={index} className="text-sm text-gray-600">
                            {result}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {testCase.postconditions && testCase.postconditions.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-2">Postconditions</h4>
                      <ul className="list-disc pl-5 space-y-1">
                        {testCase.postconditions.map((postcondition, index) => (
                          <li key={index} className="text-sm text-gray-600">
                            {postcondition}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="traceability" className="space-y-6 pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    {/* Requirement Card */}
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-center gap-2 mb-3">
                          <Network className="h-5 w-5 text-primary" />
                          <h3 className="font-medium">Requirement</h3>
                        </div>
                        
                        <div className="p-3 bg-gray-50 rounded text-sm">
                          <div className="font-medium mb-1">{testCase.requirementId}</div>
                          <div className="text-gray-600">
                            This test case implements functionality described in requirement {testCase.requirementId}.
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    {/* Scenario Card */}
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-center gap-2 mb-3">
                          <Activity className="h-5 w-5 text-primary" />
                          <h3 className="font-medium">Scenario</h3>
                        </div>
                        
                        <div className="p-3 bg-gray-50 rounded text-sm">
                          <div className="font-medium mb-1">{testCase.scenarioId}</div>
                          <div className="text-gray-600">
                            This test case is derived from scenario {testCase.scenarioId} and covers its main flow.
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-3">Traceability Information</h4>
                    <div className="text-sm text-gray-600 space-y-2">
                      <p>
                        This test case connects requirement {testCase.requirementId} with 
                        scenario {testCase.scenarioId}, ensuring full traceability from
                        requirements through design to testing.
                      </p>
                      <p>
                        The test covers {testCase.testSteps.length} distinct steps
                        and verifies {testCase.expectedResults.length} expected results.
                      </p>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
