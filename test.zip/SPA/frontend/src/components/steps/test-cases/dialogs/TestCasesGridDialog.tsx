import { useState, useRef } from "react";
import { Download, Maximize2, ChevronLeft, ChevronRight } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { TestCase } from "../types";
import * as XLSX from 'xlsx';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface TestCasesGridDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  testCases: TestCase[];
  title?: string;
}

export const TestCasesGridDialog = ({ 
  open, 
  onOpenChange, 
  testCases = [], 
  title = "Test Cases"
}: TestCasesGridDialogProps) => {
  const [isFullScreen, setIsFullScreen] = useState(false);
  
  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const totalPages = Math.ceil(testCases.length / itemsPerPage);
  
  // Jump to page
  const [jumpToPageValue, setJumpToPageValue] = useState<string>('');

  const toggleFullScreen = () => {
    setIsFullScreen(!isFullScreen);
  };

  // Add this helper function to get flow badge style
  const getFlowStyle = (flow: string | null) => {
    const normalizedFlow = flow?.toLowerCase().trim() || '';
    
    switch (normalizedFlow) {
      case 'primary flow':
        return 'bg-[#DCFCE7] text-gray-700';  // Lighter mint green
      case 'alternate flow':
        return 'bg-[#FEF9C3] text-gray-700';  // Lighter amber/gold
      case 'negative flow':
        return 'bg-[#FEE2E2] text-gray-700';  // Lighter coral/salmon
      case 'exception flow':
        return 'bg-[#F5E8FF] text-gray-700';  // Lighter violet/orchid
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  // Modify the export function to include flow field
  const handleExport = () => {
    // Prepare data for export - still export ALL test cases
    const exportData = testCases.map(testCase => ({
      ID: testCase.id,
      Flow: testCase.flow || 'None',
      Title: testCase.title,
      ScenarioID: testCase.scenarioId,
      Requirement: testCase.requirementId,
      Description: testCase.description,
      Preconditions: testCase.preconditions?.join('; ') || 'None',
      TestData: JSON.stringify(testCase.testData) || 'None',
      TestSteps: testCase.testSteps?.map(step => step.step).join('; ') || 'None',
      ExpectedResults: testCase.expectedResults?.join('; ') || 'None',
      Postconditions: testCase.postconditions?.join('; ') || 'None',
    }));

    // Create worksheet
    const ws = XLSX.utils.json_to_sheet(exportData);

    // Create workbook
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Test Cases');

    // Generate Excel file
    // XLSX.writeFile(wb, `${title || 'Test_Cases'}_${new Date().toISOString().split('T')[0]}.xlsx`);
    XLSX.writeFile(wb, 'test_cases.xlsx');
  };

  const dialogClass = isFullScreen 
    ? "w-screen h-screen max-w-none rounded-none" 
    : "w-[95vw] h-[90vh] max-w-[1500px]";

  // Helper function to format lists
  const formatList = (items) => {
    if (!items || items.length === 0) return <span className="text-gray-500 italic text-xs">None</span>;
    return (
      <ul className="list-disc pl-4 text-xs space-y-1">
        {items.map((item, idx) => (
          <li key={idx} className="text-gray-700">{item}</li>
        ))}
      </ul>
    );
  };

  // Helper function to format test data
  const formatTestData = (data) => {
    if (!data || (Array.isArray(data) && data.length === 0) || (typeof data === 'object' && Object.keys(data).length === 0)) {
      return <span className="text-gray-500 italic text-xs">None</span>;
    }
    
    if (Array.isArray(data) && typeof data[0] === 'string') {
      return (
        <ul className="list-disc pl-4 text-xs space-y-1">
          {data.map((item, idx) => (
            <li key={idx} className="text-gray-700">{item}</li>
          ))}
        </ul>
      );
    }
    
    // Case 2: If data is an array of objects with field/value properties
    if (Array.isArray(data) && typeof data[0] === 'object' && 'field' in data[0] && 'value' in data[0]) {
      return (
        <ul className="list-none pl-0 text-xs space-y-2">
          {data.map((item, idx) => (
            <li key={idx} className="text-gray-700">
              <span className="font-medium text-gray-800">{item.field}: </span>
              <span>{String(item.value)}</span>
            </li>
          ))}
        </ul>
      );
    }
    
    // Case 3: If data is an object with key-value pairs
    return (
      <ul className="list-none pl-0 text-xs space-y-2">
        {Object.entries(data).map(([key, value], idx) => (
          <li key={idx} className="text-gray-700">
            <span className="font-medium text-gray-800">{key}: </span>
            <span>{String(value)}</span>
          </li>
        ))}
      </ul>
    );
  };

  // Helper function to format test steps
  const formatTestSteps = (steps) => {
    if (!steps || steps.length === 0) return <span className="text-gray-500 italic text-xs">None</span>;
    return (
      <ol className="list-decimal pl-4 text-xs space-y-1">
        {steps.map((step, idx) => (
          <li key={idx} className="text-gray-700">
            {step.step}
            {step.input && <span className="text-gray-600 italic ml-1">(Input: {String(step.input)})</span>}
            {/* {step.expected && <span className="text-gray-600 italic ml-1">(Expected: {String(step.expected)})</span>} */}
          </li>
        ))}
      </ol>
    );
  };

  // Pagination handlers
  const goToNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const goToPreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const goToPage = (pageNumber: number) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  const handleItemsPerPageChange = (value: string) => {
    setItemsPerPage(parseInt(value));
    setCurrentPage(1); // Reset to first page when changing items per page
  };

  const handleJumpToPage = (e: React.FormEvent) => {
    e.preventDefault();
    const pageNumber = parseInt(jumpToPageValue);
    
    if (!isNaN(pageNumber) && pageNumber >= 1 && pageNumber <= totalPages) {
      goToPage(pageNumber);
    }
    
    // Reset the input field after jumping
    setJumpToPageValue('');
  };

  // Get paginated test cases
  const getPaginatedTestCases = () => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return testCases.slice(startIndex, endIndex);
  };

  // Render page numbers for pagination
  const renderPageNumbers = () => {
    const pageNumbers = [];
    const maxPageButtons = 5; // Maximum number of page buttons to show
    
    let startPage = Math.max(1, currentPage - Math.floor(maxPageButtons / 2));
    let endPage = Math.min(totalPages, startPage + maxPageButtons - 1);
    
    // Adjust if we're at the end
    if (endPage - startPage + 1 < maxPageButtons) {
      startPage = Math.max(1, endPage - maxPageButtons + 1);
    }
    
    // Always show first page
    if (startPage > 1) {
      pageNumbers.push(
        <Button 
          key={1} 
          variant={currentPage === 1 ? "default" : "outline"} 
          size="sm" 
          onClick={() => goToPage(1)}
          className="h-8 w-8 p-0"
        >
          1
        </Button>
      );
      
      // Add ellipsis if there's a gap
      if (startPage > 2) {
        pageNumbers.push(
          <span key="start-ellipsis" className="px-2">...</span>
        );
      }
    }
    
    // Add page numbers
    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(
        <Button 
          key={i} 
          variant={currentPage === i ? "default" : "outline"} 
          size="sm" 
          onClick={() => goToPage(i)}
          className="h-8 w-8 p-0"
        >
          {i}
        </Button>
      );
    }
    
    // Always show last page
    if (endPage < totalPages) {
      // Add ellipsis if there's a gap
      if (endPage < totalPages - 1) {
        pageNumbers.push(
          <span key="end-ellipsis" className="px-2">...</span>
        );
      }
      
      pageNumbers.push(
        <Button 
          key={totalPages} 
          variant={currentPage === totalPages ? "default" : "outline"} 
          size="sm" 
          onClick={() => goToPage(totalPages)}
          className="h-8 w-8 p-0"
        >
          {totalPages}
        </Button>
      );
    }
    
    return pageNumbers;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={dialogClass}>
        <DialogHeader className="flex flex-row items-center justify-between border-b pb-4 px-6">
          <div>
            <DialogTitle className="text-xl font-semibold text-gray-900">{title} Overview</DialogTitle>
            <DialogDescription className="text-sm text-gray-500 mt-1">
              {/* View and export your test cases in a grid format */}
            </DialogDescription>
          </div>
          <div className="flex items-center gap-3">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="outline" 
                    onClick={toggleFullScreen} 
                    className="h-9 w-9 p-0 border-gray-200 hover:bg-gray-100 transition-colors"
                  >
                    <Maximize2 className="h-4 w-4 text-gray-600" />
                  </Button>
                </TooltipTrigger>
                {/* <TooltipContent>
                  <p>Toggle fullscreen</p>
                </TooltipContent> */}
              </Tooltip>
            </TooltipProvider>

            <Button 
              onClick={handleExport} 
              className="bg-blue-600 hover:bg-blue-700 text-white h-9 px-4 shadow-sm transition-colors flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              <span className="font-medium">Export to Excel</span>
            </Button>
          </div>
        </DialogHeader>
        {/* <ScrollArea className="h-[calc(100%-80px)]"> */}
        <ScrollArea className="h-[calc(100%-40px)]">
          {/* <div className="p-4"> */}
          <div className="p-2">
            <div className="overflow-x-auto rounded-md border border-gray-200 shadow-sm">
              <Table className="compact-table">
                <TableHeader className="bg-gray-50 sticky top-0 z-10">
                  <TableRow className="border-b-2 border-gray-200">
                    <TableHead className="w-[120px] whitespace-nowrap px-2 py-2 text-xs font-semibold text-gray-700">Test Case ID</TableHead>
                    <TableHead className="w-[120px] whitespace-nowrap px-2 py-2 text-xs font-semibold text-gray-700">Flow</TableHead>
                    <TableHead className="w-[180px] whitespace-nowrap px-2 py-2 text-xs font-semibold text-gray-700">Test Case Title</TableHead>
                    <TableHead className="w-[150px] whitespace-nowrap px-2 py-2 text-xs font-semibold text-gray-700">Scenario ID</TableHead>
                    <TableHead className="w-[150px] whitespace-nowrap px-2 py-2 text-xs font-semibold text-gray-700">Requirement</TableHead>
                    <TableHead className="min-w-[250px] px-2 py-2 text-xs font-semibold text-gray-700">Description</TableHead>
                    <TableHead className="min-w-[200px] px-2 py-2 text-xs font-semibold text-gray-700">Preconditions</TableHead>
                    <TableHead className="min-w-[200px] px-2 py-2 text-xs font-semibold text-gray-700">Test Data</TableHead>
                    <TableHead className="min-w-[300px] px-2 py-2 text-xs font-semibold text-gray-700">Test Steps</TableHead>
                    <TableHead className="min-w-[250px] px-2 py-2 text-xs font-semibold text-gray-700">Expected Results</TableHead>
                    <TableHead className="min-w-[200px] px-2 py-2 text-xs font-semibold text-gray-700">Postconditions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {getPaginatedTestCases().map((testCase, index) => (
                    <TableRow 
                      key={`${testCase.id}-${index}`}
                      className={`
                        border-b border-gray-200
                        ${index % 2 === 0 ? "bg-white" : "bg-gray-50"}
                        hover:bg-blue-50 transition-colors text-xs
                      `}
                    >
                      <TableCell className="whitespace-nowrap font-medium px-2 py-1.5 border-r border-gray-200 text-xs">
                        {testCase.id || <span className="text-gray-500 italic text-xs">None</span>}
                      </TableCell>
                      <TableCell className="whitespace-nowrap px-2 py-1.5 border-r border-gray-200 text-xs">
                        {testCase.flow ? (
                          <span className={`px-2 py-0.5 rounded-sm ${getFlowStyle(testCase.flow)}`}>
                            {testCase.flow}
                          </span>
                        ) : (
                          <span className="text-gray-500 italic text-xs">None</span>
                        )}
                      </TableCell>
                      <TableCell className="px-2 py-1.5 border-r border-gray-200 text-xs">
                        {testCase.title || <span className="text-gray-500 italic text-xs">None</span>}
                      </TableCell>
                      <TableCell className="whitespace-nowrap px-2 py-1.5 border-r border-gray-200 text-xs">
                        {testCase.scenarioId || <span className="text-gray-500 italic text-xs">None</span>}
                      </TableCell>
                      <TableCell className="whitespace-nowrap px-2 py-1.5 border-r border-gray-200 text-xs">
                        {testCase.requirementId || <span className="text-gray-500 italic text-xs">None</span>}
                      </TableCell>
                      <TableCell className="px-2 py-1.5 border-r border-gray-200 text-xs">
                        {testCase.description || <span className="text-gray-500 italic text-xs">None</span>}
                      </TableCell>
                      <TableCell className="px-2 py-1.5 border-r border-gray-200 text-xs">
                        {formatList(testCase.preconditions)}
                      </TableCell>
                      <TableCell className="px-2 py-1.5 border-r border-gray-200 text-xs">
                        {formatTestData(testCase.testData)}
                      </TableCell>
                      <TableCell className="px-2 py-1.5 border-r border-gray-200 text-xs">
                        {formatTestSteps(testCase.testSteps)}
                      </TableCell>
                      <TableCell className="px-2 py-1.5 border-r border-gray-200 text-xs">
                        {formatList(testCase.expectedResults)}
                      </TableCell>
                      <TableCell className="px-2 py-1.5">
                        {formatList(testCase.postconditions)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {(!testCases || testCases.length === 0) && (
                <div className="text-center py-8 text-gray-500 bg-gray-50">
                  <p className="text-lg">No test cases available</p>
                  <p className="text-sm mt-1">Test cases will appear here as they are generated.</p>
                </div>
              )}
            </div>
          </div>
        </ScrollArea>
        
        {/* Simplified Pagination Controls */}
        {testCases.length > 0 && (
          // <div className="flex justify-between items-center border-t py-2 px-4 bg-gray-50">
          <div className="flex justify-between items-center border-t py-1 px-4 bg-gray-50">
            <div className="flex items-center gap-2 text-xs text-gray-600">
              <Select 
                value={itemsPerPage.toString()} 
                onValueChange={handleItemsPerPageChange}
              >
                <SelectTrigger className="h-7 w-16 text-xs">
                  <SelectValue placeholder="10" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">5</SelectItem>
                  <SelectItem value="10">10</SelectItem>
                  <SelectItem value="20">20</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                </SelectContent>
              </Select>
              <span>per page</span>
              <span className="ml-2">
                {`${(currentPage - 1) * itemsPerPage + 1}-${Math.min(currentPage * itemsPerPage, testCases.length)} of ${testCases.length}`}
              </span>
            </div>
            
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="icon"
                onClick={goToPreviousPage}
                disabled={currentPage === 1}
                className="h-7 w-7"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              
              <div className="flex items-center">
                <input
                  type="number"
                  min="1"
                  max={totalPages}
                  value={currentPage}
                  onChange={(e) => {
                    const page = parseInt(e.target.value);
                    if (page >= 1 && page <= totalPages) {
                      setCurrentPage(page);
                    }
                  }}
                  className="h-7 w-12 px-2 border rounded text-xs text-center"
                />
                <span className="text-xs text-gray-600 mx-1">of {totalPages}</span>
              </div>

              <Button
                variant="outline"
                size="icon"
                onClick={goToNextPage}
                disabled={currentPage === totalPages}
                className="h-7 w-7"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
