import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { TestCase } from "../types";
import { Maximize2, Minimize2, AlertCircle, ArrowUpRight, ChevronDown, PieChart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import axios from "axios";
import { API_ENDPOINTS } from "@/config/api";
import { Badge } from "@/components/ui/badge";
import { ScenarioDialog } from "./ScenarioDialog";

interface TracebilityCoverageProps {
  testCases: TestCase[];
  selectedTestCase: TestCase | null;
  onTestCaseClick: (testCase: TestCase) => void;
  onScenarioClick: (scenarioId: string) => void;
  onRequirementClick: (requirementId: string) => void;
  isVisible: boolean;
  isRightPanelMaximized: boolean;
  isLeftPanelMaximized: boolean;
  onToggleRightPanel: () => void;
}

// Basic traceability interfaces
interface ScenarioTraceability {
  testcase_id: string;
  scenario_id: string;
}

interface RequirementTraceability {
  testcase_id: string;
  requirement_id: string;
}

// Extended interfaces with detailed information
interface RequirementDetails {
  requirementId: string;
  requirementName: string;
  isCompleted: boolean;
  isScenarioGenerated: boolean;
  errorMessage: string | null;
  fileId: string;
  is_deleted: boolean;
}

interface ScenarioDetails {
  scenarioId: string;
  fileId: string;
  requirementId: string;
  isCompleted: boolean;
  errorMessage: string | null;
  outputJson: any;
  createdAt: string;
  updatedAt: string;
  is_deleted: boolean;
}

export const TracebilityCoverage = ({
  testCases,
  selectedTestCase,
  onTestCaseClick,
  onScenarioClick,
  onRequirementClick,
  isVisible,
  isRightPanelMaximized,
  isLeftPanelMaximized,
  onToggleRightPanel
}: TracebilityCoverageProps) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [scenarioData, setScenarioData] = useState<ScenarioTraceability | null>(null);
  const [requirementData, setRequirementData] = useState<RequirementTraceability | null>(null);
  const [scenarioDetails, setScenarioDetails] = useState<ScenarioDetails | null>(null);
  const [requirementDetails, setRequirementDetails] = useState<RequirementDetails | null>(null);
  const [isUpperSectionExpanded, setIsUpperSectionExpanded] = useState(true);
  const [isLowerSectionExpanded, setIsLowerSectionExpanded] = useState(true);
  
  // Add state to control the ScenarioDialog
  const [showScenarioDialog, setShowScenarioDialog] = useState(false);
  const [selectedScenarioId, setSelectedScenarioId] = useState<string | null>(null);

  // Fetch traceability data when selected test case changes
  useEffect(() => {
    if (selectedTestCase?.testcase_id) {
      fetchTraceabilityData(selectedTestCase.testcase_id);
    } else {
      // Clear traceability data when no test case is selected
      setScenarioData(null);
      setRequirementData(null);
      setScenarioDetails(null);
      setRequirementDetails(null);
    }
  }, [selectedTestCase]);

  // Fetch additional scenario details when we get scenario ID
  useEffect(() => {
    if (scenarioData?.scenario_id) {
      fetchScenarioDetails(scenarioData.scenario_id);
    } else {
      setScenarioDetails(null);
    }
  }, [scenarioData]);

  // Fetch additional requirement details when we get requirement ID
  useEffect(() => {
    if (requirementData?.requirement_id) {
      fetchRequirementDetails(requirementData.requirement_id);
    } else {
      setRequirementDetails(null);
    }
  }, [requirementData]);

  // Function to fetch basic traceability data
  const fetchTraceabilityData = async (testcaseId: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Fetch scenario mapping
      const scenarioResponse = await axios.get(
        `${API_ENDPOINTS.getScenarioByTestCase}/${testcaseId}`
      );
      
      // Fetch requirement mapping
      const requirementResponse = await axios.get(
        `${API_ENDPOINTS.getRequirementByTestCase}/${testcaseId}`
      );
      
      console.log("Scenario traceability:", scenarioResponse.data);
      console.log("Requirement traceability:", requirementResponse.data);
      
      // Store the mappings
      setScenarioData(scenarioResponse.data);
      setRequirementData(requirementResponse.data);
    } catch (error) {
      console.error("Error fetching traceability data:", error);
      setError("Failed to load traceability data. Please try again later.");
    } finally {
      setIsLoading(false);
    }
  };

  // Function to fetch detailed scenario information
  const fetchScenarioDetails = async (scenarioId: string) => {
    try {
      const response = await axios.get(`${API_ENDPOINTS.getScenarioById}/${scenarioId}`);
      console.log("Detailed scenario data:", response.data);
      setScenarioDetails(response.data);
    } catch (error) {
      console.error("Error fetching scenario details:", error);
    }
  };

  // Function to fetch detailed requirement information
  const fetchRequirementDetails = async (requirementId: string) => {
    try {
      const response = await axios.get(`${API_ENDPOINTS.getRequirementById}/${requirementId}`);
      console.log("Detailed requirement data:", response.data);
      setRequirementDetails(response.data);
    } catch (error) {
      console.error("Error fetching requirement details:", error);
    }
  };

  // Create a local handler for scenario clicks - FIXED to prevent double modals
  const handleScenarioClick = (id: string) => {
    // Set the selected scenario ID
    setSelectedScenarioId(id);
    // Show the scenario dialog
    setShowScenarioDialog(true);
  };

  // If panel is not visible, don't render anything
  if (!isVisible) {
    return null;
  }

  // Get the scenario name from the outputJson if available
  const getScenarioName = () => {
    if (!scenarioDetails?.outputJson) return "Loading scenario details...";
    
    try {
      if (typeof scenarioDetails.outputJson === 'string') {
        const outputJson = JSON.parse(scenarioDetails.outputJson);
        return outputJson.ScenarioName || "Unnamed Scenario";
      } else {
        return scenarioDetails.outputJson.ScenarioName || "Unnamed Scenario";
      }
    } catch (error) {
      console.error("Error parsing scenario JSON:", error);
      return "Unnamed Scenario";
    }
  };

  return (
    <div
      className={cn(
        "flex flex-col transition-all duration-300 pl-4",
        isRightPanelMaximized ? "w-full" : "w-1/3",
        isLeftPanelMaximized ? "w-0 hidden" : "flex"
      )}
    >
      <div className="flex justify-between items-center py-2">
        <h2 className="text-lg font-semibold">Traceability</h2>
        <Button
          variant="ghost"
          size="sm"
          onClick={onToggleRightPanel}
        >
          {isRightPanelMaximized ? (
            <Minimize2 className="h-4 w-4" />
          ) : (
            <Maximize2 className="h-4 w-4" />
          )}
        </Button>
      </div>

      <ScrollArea className="flex-1 border rounded-md bg-white">
        <div className="p-4">
          {isLoading ? (
            <div className="flex items-center justify-center h-40">
              <div className="flex flex-col items-center gap-2">
                <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full"></div>
                <p className="text-sm text-gray-500">Loading traceability data...</p>
              </div>
            </div>
          ) : error ? (
            <div className="flex items-center justify-center h-40 text-red-500">
              <AlertCircle className="h-4 w-4 mr-2" />
              <p>{error}</p>
            </div>
          ) : !selectedTestCase ? (
            <div className="flex flex-col items-center justify-center h-40 text-gray-500">
              <p className="mb-2">Select a test case to view traceability information</p>
              <p className="text-xs text-gray-400">
                Click on a test case to see its parent scenario and requirement
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Requirement Section - Upper Section */}
              <div className="border rounded-md overflow-hidden">
                <div 
                  className="flex justify-between items-center p-3 bg-gray-50 cursor-pointer"
                  onClick={() => setIsUpperSectionExpanded(!isUpperSectionExpanded)}
                >
                  <h3 className="font-medium text-gray-700">Requirement Traceability</h3>
                  <ChevronDown className={cn(
                    "h-4 w-4 text-gray-500 transition-transform",
                    isUpperSectionExpanded && "transform rotate-180"
                  )} />
                </div>
                
                {isUpperSectionExpanded && (
                  <div className="p-3">
                    {!requirementData ? (
                      <p className="text-sm text-gray-500">No parent requirement found for this test case</p>
                    ) : !requirementDetails ? (
                      <div className="flex items-center justify-center py-4">
                        <div className="animate-spin h-4 w-4 border-2 border-primary border-t-transparent rounded-full mr-2"></div>
                        <p className="text-sm text-gray-500">Loading requirement details...</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <div className="space-y-1">
                            <h4 className="font-medium">{requirementDetails.requirementName}</h4>
                            <div className="flex items-center">
                              <Badge variant="outline" className="mr-2">
                                {requirementDetails.isCompleted ? "Completed" : "In Progress"}
                              </Badge>
                            </div>
                          </div>
                          <div 
                            className="flex items-center gap-2 cursor-pointer"
                            onClick={() => {
                              console.log("View Details clicked with requirement ID:", requirementData.requirement_id);
                              onRequirementClick(requirementData.requirement_id);
                            }}
                          >
                            <Badge 
                              className="bg-blue-100 hover:bg-blue-200 text-blue-800"
                            >
                              View Details
                              <ArrowUpRight className="h-3 w-3 ml-1" />
                            </Badge>
                          </div>
                        </div>
                        
                        <div className="text-sm text-gray-600">
                          <div className="mt-2 p-2 bg-blue-50 rounded border border-blue-200">
                            <div className="flex items-start gap-1 text-blue-600 mb-1">
                              <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                              <div>
                                <span className="text-xs font-medium block">Traceability Information</span>
                                <p className="text-xs text-blue-700 mt-1">
                                  This test case is connected to requirement "{requirementDetails.requirementName}". 
                                  Click on "View Details" to see full requirement specifications.
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
              
              {/* Scenario Section - Lower Section */}
              <div className="border rounded-md overflow-hidden">
                <div 
                  className="flex justify-between items-center p-3 bg-gray-50 cursor-pointer"
                  onClick={() => setIsLowerSectionExpanded(!isLowerSectionExpanded)}
                >
                  <h3 className="font-medium text-gray-700">Scenario Traceability</h3>
                  <ChevronDown className={cn(
                    "h-4 w-4 text-gray-500 transition-transform",
                    isLowerSectionExpanded && "transform rotate-180"
                  )} />
                </div>
                
                {isLowerSectionExpanded && (
                  <div className="p-3">
                    {!scenarioData ? (
                      <p className="text-sm text-gray-500">No parent scenario found for this test case</p>
                    ) : !scenarioDetails ? (
                      <div className="flex items-center justify-center py-4">
                        <div className="animate-spin h-4 w-4 border-2 border-primary border-t-transparent rounded-full mr-2"></div>
                        <p className="text-sm text-gray-500">Loading scenario details...</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <div className="space-y-1">
                            <h4 className="font-medium">{getScenarioName()}</h4>
                            <div className="flex items-center">
                              <Badge variant="outline" className="mr-2">
                                {scenarioDetails.isCompleted ? "Completed" : "In Progress"}
                              </Badge>
                            </div>
                          </div>
                          <div 
                            className="flex items-center gap-2 cursor-pointer"
                            onClick={() => handleScenarioClick(scenarioData.scenario_id)}
                          >
                            <Badge 
                              className="bg-purple-100 hover:bg-purple-200 text-purple-800"
                            >
                              View Scenario
                              <ArrowUpRight className="h-3 w-3 ml-1" />
                            </Badge>
                          </div>
                        </div>
                        
                        <div className="text-sm text-gray-600">
                          <div className="mt-2 p-2 bg-purple-50 rounded border border-purple-200">
                            <div className="flex items-start gap-1 text-purple-600 mb-1">
                              <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                              <div>
                                <span className="text-xs font-medium block">Scenario Information</span>
                                <p className="text-xs text-purple-700 mt-1">
                                  This test case was generated from scenario "{getScenarioName()}". 
                                  Click on "View Scenario" to see full scenario details and flows.
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </ScrollArea>
      
      {/* ScenarioDialog component */}
      <ScenarioDialog
        open={showScenarioDialog}
        onOpenChange={setShowScenarioDialog}
        selectedScenario={selectedScenarioId}
        hideDialog={false}
      />
    </div>
  );
};


