import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useEffect, useState } from "react";
import axios from "axios";
import { API_ENDPOINTS } from "@/config/api";
import { Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface ScenarioDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedScenario: string | null;
  hideDialog?: boolean;
}

// API scenario interface
interface ApiScenario {
  scenarioId: string;
  fileId: string;
  requirementId: string;
  isCompleted: boolean;
  errorMessage: string | null;
  outputJson: {
    ScenarioID: string;
    ScenarioName: string;
    ScenarioDescription: string;
    RequirementID: string;
    Flows: Array<{
      Type: string;
      Description: string;
      Coverage: string;
      ExpectedResults: string;
    }>;
  };
  createdAt: string;
  updatedAt: string;
  is_deleted: boolean;
  displayId: number;
}

// Requirement interface
interface ApiRequirement {
  requirementId: string;
  requirementName: string;
  isCompleted: boolean;
  isScenarioGenerated: boolean;
  errorMessage: string | null;
  requirementJson: any;
  fileId: string;
  is_deleted: boolean;
  displayId: number;
}

// Function to get the badge color for each flow type
const getFlowBadgeStyle = (flowType: string) => {
  const normalizedFlow = flowType.toLowerCase().trim();
  
  if (normalizedFlow.includes('primary')) {
    return 'bg-[#DCFCE7] text-gray-700 border-[#DCFCE7]';
  } else if (normalizedFlow.includes('alternate')) {
    return 'bg-[#FEF9C3] text-gray-700 border-[#FEF9C3]';
  } else if (normalizedFlow.includes('negative')) {
    return 'bg-[#FEE2E2] text-gray-700 border-[#FEE2E2]';
  } else if (normalizedFlow.includes('exception')) {
    return 'bg-[#F5E8FF] text-gray-700 border-[#F5E8FF]';
  } else {
    return 'bg-gray-100 text-gray-700';
  }
};

export const ScenarioDialog = ({
  open,
  onOpenChange,
  selectedScenario,
  hideDialog = false
}: ScenarioDialogProps) => {
  const [loading, setLoading] = useState(false);
  const [apiScenario, setApiScenario] = useState<ApiScenario | null>(null);
  const [requirementDetails, setRequirementDetails] = useState<ApiRequirement | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    if (!selectedScenario || !open) return;
    
    const fetchScenarioDetails = async () => {
      setLoading(true);
      setError(null);
      try {
        console.log(`Fetching scenario details for: ${selectedScenario}`);
        const response = await axios.get(
          `${API_ENDPOINTS.getScenarioById}/${selectedScenario}`
        );
        console.log('API Scenario details:', response.data);
        setApiScenario(response.data);
        
        // Now fetch the requirement details
        if (response.data.requirementId) {
          try {
            const reqResponse = await axios.get(
              `${API_ENDPOINTS.getRequirementById}/${response.data.requirementId}`
            );
            console.log('API Requirement details:', reqResponse.data);
            setRequirementDetails(reqResponse.data);
          } catch (reqError) {
            console.error('Error fetching requirement details:', reqError);
            // Just log the error but don't show error UI if requirement fetch fails
          }
        }
      } catch (error) {
        console.error('Error fetching scenario details:', error);
        setError("Failed to load scenario details. Please try again later.");
      } finally {
        setLoading(false);
      }
    };
    
    fetchScenarioDetails();
  }, [selectedScenario, open]);
  
  if (!selectedScenario) return null;
  
  // Loading UI
  if (loading) {
    const loadingContent = (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2">Loading scenario details...</span>
      </div>
    );
    
    if (hideDialog) return loadingContent;
    
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Scenario Details</DialogTitle>
          </DialogHeader>
          <div className="max-h-[70vh] overflow-y-auto">
            {loadingContent}
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  // Error UI
  if (error) {
    const errorContent = (
      <div className="flex flex-col items-center justify-center py-12 text-red-500">
        <p className="mb-4">{error}</p>
        <p className="text-sm text-gray-500">Scenario ID: {selectedScenario}</p>
      </div>
    );
    
    if (hideDialog) return errorContent;
    
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Scenario Details</DialogTitle>
          </DialogHeader>
          <div className="max-h-[70vh] overflow-y-auto">
            {errorContent}
          </div>
        </DialogContent>
      </Dialog>
    );
  }
  
  // Render API scenario content
  const renderScenarioContent = () => {
    if (!apiScenario) return (
      <div className="text-center text-gray-500 py-12">
        No scenario data available
      </div>
    );
    
    const { outputJson } = apiScenario;
    
    // Format scenario and requirement display IDs
    const formattedScenarioId = apiScenario.displayId ? `TS-${apiScenario.displayId}` : outputJson.ScenarioID || apiScenario.scenarioId;
    const formattedRequirementId = requirementDetails?.displayId 
      ? `REQ-${requirementDetails.displayId}`
      : outputJson.RequirementID || apiScenario.requirementId;
    
    return (
      <div className="space-y-6">
        <div className="flex flex-col gap-2">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-lg font-semibold">
                {outputJson.ScenarioName || outputJson.ScenarioID}
              </h3>
              <p className="text-sm text-gray-500">
                ID: {formattedScenarioId}
              </p>
            </div>
            {/* <div className="text-sm text-muted-foreground flex items-center gap-2">
              <span>Requirement:</span>
              <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">
                {formattedRequirementId}
              </Badge>
            </div> */}
          </div>
          <div className="text-sm text-muted-foreground">
            Status: {apiScenario.isCompleted ? 'Completed' : 'In Progress'}
          </div>
        </div>

        {/* Description */}
        <div>
          <h4 className="font-medium mb-2">Description</h4>
          <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-md">
            {outputJson.ScenarioDescription || "No description available"}
          </p>
        </div>

        {/* Flows */}
        <div>
          <h4 className="font-medium mb-3">Flows</h4>
          <div className="space-y-4">
            {outputJson.Flows && outputJson.Flows.map((flow, index) => (
              <div key={index} className="border rounded-md p-4">
                <div className="flex justify-between items-center mb-3">
                  <Badge
                    variant="outline"
                    className={getFlowBadgeStyle(flow.Type)}
                  >
                    {flow.Type}
                  </Badge>
                  <span className="text-xs text-gray-500">Flow {index + 1}</span>
                </div>
                
                <div className="space-y-2">
                  <div>
                    <span className="text-sm font-medium">Description:</span>
                    <p className="text-sm text-gray-600 ml-4 mt-1">{flow.Description}</p>
                  </div>
                  
                  <div>
                    <span className="text-sm font-medium">Coverage:</span>
                    <p className="text-sm text-gray-600 ml-4 mt-1">{flow.Coverage}</p>
                  </div>
                  
                  <div>
                    <span className="text-sm font-medium">Expected Results:</span>
                    <p className="text-sm text-gray-600 ml-4 mt-1">{flow.ExpectedResults}</p>
                  </div>
                </div>
              </div>
            ))}
            
            {(!outputJson.Flows || outputJson.Flows.length === 0) && (
              <div className="text-sm text-gray-500 italic">
                No flows defined for this scenario
              </div>
            )}
          </div>
        </div>

        {/* Timestamps */}
        <div className="text-xs text-gray-400 flex justify-between pt-4 border-t">
          <div>Created: {new Date(apiScenario.createdAt).toLocaleString()}</div>
          <div>Updated: {new Date(apiScenario.updatedAt).toLocaleString()}</div>
        </div>
      </div>
    );
  };

  const content = renderScenarioContent();

  if (hideDialog) {
    return content;
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>Scenario Details</DialogTitle>
        </DialogHeader>
        <div className="max-h-[70vh] overflow-y-auto p-6">
          {content}
        </div>
      </DialogContent>
    </Dialog>
  );
}; 