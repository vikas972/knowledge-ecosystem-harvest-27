interface TestCaseListProps {
  testCases: TestCase[];
  expandedTestCases: string[];
  selectedTestCases: string[];
  selectedTestCase: TestCase | null;
  onTestCaseClick: (testCase: TestCase) => void;
  onToggleExpand: (id: string) => void;
  onRequirementClick: (requirementId: string) => void;
  onScenarioClick: (scenarioId: string) => void;
  onDelete: (testCaseId: string) => void;
  onSelect: (id: string, checked: boolean) => void;
}

export const TestCaseList = ({
  testCases,
  expandedTestCases,
  selectedTestCases,
  selectedTestCase,
  onTestCaseClick,
  onToggleExpand,
  onRequirementClick,
  onScenarioClick,
  onDelete,
  onSelect,
}: TestCaseListProps) => {
  return (
    <div className="space-y-4">
      {testCases.map((testCase) => (
        <TestCaseCard
          key={testCase.id}
          testCase={testCase}
          isExpanded={expandedTestCases.includes(testCase.id)}
          isSelected={selectedTestCase?.id === testCase.id}
          checked={selectedTestCases.includes(testCase.id)}
          onSelect={(checked) => onSelect(testCase.id, checked)}
          onToggle={() => onToggleExpand(testCase.id)}
          onClick={() => onTestCaseClick(testCase)}
          onScenarioClick={onScenarioClick}
          onRequirementClick={onRequirementClick}
          onDelete={onDelete}
        />
      ))}
      {testCases.length === 0 && (
        <div className="text-center py-6 text-gray-500">
          No test cases available
        </div>
      )}
    </div>
  );
}; 