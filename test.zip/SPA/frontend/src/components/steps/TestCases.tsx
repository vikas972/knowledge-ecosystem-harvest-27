import { useCallback, useEffect, useState, useRef } from "react";
import { Loader2, Maximize2, Minimize2, Plus, RefreshCw, CheckSquare, Trash2, Grid, ChevronLeft, ChevronRight, Activity, AlertCircle, FileQuestion } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import axios from "axios";
import { ENV } from "@/config/env";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { TestCasesGridDialog } from "./test-cases/dialogs/TestCasesGridDialog";
import { ScenarioDialog } from "./scenario/dialogs/ScenarioDialog";
import { RequirementDialog } from "./scenario/dialogs/RequirementDialog";
import { TestCase } from "./test-cases/types";
import { TestCaseCard } from "./test-cases/TestCaseCard";
import { CoverageAnalysis } from "./test-cases/CoverageAnalysis";
import { TestScenario } from "./scenario/types";
import { API_ENDPOINTS } from "@/config/api";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useParams, useLocation } from "react-router-dom";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { UserAssociationInfo } from "../UserAssociationInfo";
import { BundleInfo } from "../BundleInfo";
import { TracebilityCoverage } from "./test-cases/dialogs/TracebilityCoverage";
import { useInterval } from "@/hooks/useInterval";

// Update the interface to match ScenarioGenerationProps
interface TestCasesProps {
  selectedFile: { id: string; name: string; uploadTime: Date } | null;
  usecaseId?: number | string;
  requirementIds: string[];
  product: string;
  subProduct: string;
  domain: string;
  bundleName: string;
}

// Define the dummyScenarioIds variable properly
// const dummyScenarioIds = "0086ed35-81d9-4abc-a173-f557838b21a5";

// Transform API response to TestCase format
const transformApiTestCase = (apiTestCase: any): TestCase => {
  const testJson = apiTestCase.test_json || {};
  
  const transformedTestCase: TestCase = {
    id: `TC-${apiTestCase.displayId || Math.random().toString(36).substring(2, 9)}`,
    title: testJson['test case'] || testJson.title || "",
    scenarioId: testJson.scenarioId || "",
    requirementId: testJson.requirementId || "",
    priority: testJson.priority || "medium",
    description: testJson.description || "",
    preconditions: testJson.preconditions || testJson.preConditions || [],
    testData: Array.isArray(testJson.testData) 
      ? testJson.testData.map((item: string | {field: string, value: string}) => {
          if (typeof item === 'string') {
            // Handle string format like "Card Number: NPKW004202007"
            const parts = item.split(':');
            return {
              field: parts[0]?.trim() || '',
              value: parts[1]?.trim() || item
            };
          }
          return item;
        }) 
      : [],
    testSteps: Array.isArray(testJson.testSteps)
      ? testJson.testSteps.map((step: string | {step: string, input: string, expected: string}, index: number) => {
          if (typeof step === 'string') {
            return {
              step: step,
              input: "",
              expected: testJson.expectedResults?.[0] || ""
            };
          }
          return step;
        })
      : (testJson.flows?.flatMap(flow => 
          flow.subflows?.flatMap(subflow => 
            subflow.entries?.map((entry: string, index: number) => ({
              step: entry,
              input: "",
              expected: subflow.expectedResults || ""
            })) || []
          )
        ) || []),
    expectedResults: Array.isArray(testJson.expectedResults) 
      ? testJson.expectedResults 
      : [testJson.expectedResults || testJson.flows?.[0]?.subflows?.[0]?.expectedResults || ""],
    postconditions: testJson.postconditions || testJson.postConditions || [],
    status: testJson.status || "in_progress",
    is_deleted: apiTestCase.is_deleted || false,
    testcase_id: apiTestCase.testcase_id || null,
    flow: testJson.flow || null,
    displayId: apiTestCase.displayId || null,
    scenario_display_id: apiTestCase.scenario_display_id || null,
    requirement_display_id: apiTestCase.requirement_display_id || null,
    actualScenarioId: null // New field to store the actual UUID
  };
  
  return transformedTestCase;
};

const transformTestCaseToScenario = (testCase: TestCase): TestScenario => {
  return {
    id: testCase.id,
    title: testCase.title,
    description: testCase.description,
    requirementId: testCase.requirementId,
    priority: testCase.priority,
    status: testCase.status,
    flows: [
      {
        type: "primary",
        description: "Main test flow",
        subflows: testCase.testSteps.map((step, index) => ({
          name: `Step ${index + 1}`,
          coverage: step.step,
          expectedResults: step.expected,
          entries: []
        }))
      }
    ]
  };
};

export const TestCases = ({ selectedFile, usecaseId: propUsecaseId, requirementIds = [], product, subProduct, domain, bundleName }: TestCasesProps) => {
  // Get usecaseId from URL params if available
  const params = useParams();
  const location = useLocation();
  
  // Try to extract usecaseId from different sources
  const urlUsecaseId = params.usecaseId || params.id;
  
  // Try to get from URL search params
  const searchParams = new URLSearchParams(location.search);
  const queryUsecaseId = searchParams.get('usecaseId');
  
  // Try to get from localStorage
  const storedUsecaseId = localStorage.getItem('currentUsecaseId');
  
  // Use the first available usecaseId
  const effectiveUsecaseId = propUsecaseId || urlUsecaseId || queryUsecaseId || storedUsecaseId;
  
  // console.log("[TestCases] Component initialized with multiple usecaseId sources:", {
  //   propUsecaseId,
  //   urlUsecaseId,
  //   queryUsecaseId,
  //   storedUsecaseId,
  //   effectiveUsecaseId
  // });
  
  const [isLeftPanelMaximized, setIsLeftPanelMaximized] = useState(false);
  const [isRightPanelMaximized, setIsRightPanelMaximized] = useState(false);
  const [selectedTestCases, setSelectedTestCases] = useState<string[]>([]);
  const [selectedTestCase, setSelectedTestCase] = useState<TestCase | null>(null);
  const [expandedTestCases, setExpandedTestCases] = useState<string[]>([]);
  const [showGridDialog, setShowGridDialog] = useState(false);
  const [showScenarioDialog, setShowScenarioDialog] = useState(false);
  const [showRequirementDialog, setShowRequirementDialog] = useState(false);
  const [selectedScenario, setSelectedScenario] = useState<string | null>(null);
  const [selectedRequirement, setSelectedRequirement] = useState<string | null>(null);
  const [testCases, setTestCases] = useState<TestCase[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isCoverageVisible, setIsCoverageVisible] = useState(false);
  const [isTraceabilityVisible, setIsTraceabilityVisible] = useState(false);
  const [isLeftPanelIconExpanded, setIsLeftPanelIconExpanded] = useState(false);

  // Add new state variables for ID mappings
  const [scenarioDisplayIds, setScenarioDisplayIds] = useState<Map<string, string>>(new Map());
  const [requirementDisplayIds, setRequirementDisplayIds] = useState<Map<string, string>>(new Map());
  // Add these new state variables for storing actual IDs
  const [scenarioActualIds, setScenarioActualIds] = useState<Map<string, string>>(new Map());
  const [requirementActualIds, setRequirementActualIds] = useState<Map<string, string>>(new Map());

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(5);

  // Add these new states for streaming (don't redeclare existing states)
  const [isStreaming, setIsStreaming] = useState(true);
  const previousTestCaseIdsRef = useRef<Set<string>>(new Set());
  const [newlyAddedTestCaseIds, setNewlyAddedTestCaseIds] = useState<string[]>([]);
  const [initialLoadComplete, setInitialLoadComplete] = useState(false);

  // Add this function before it's used
  const getFilteredTestCases = () => {
    return testCases
      .filter(testCase => !testCase.is_deleted)
      .sort((a, b) => {
        // Extract displayId directly or from ID format "TC-123"
        const aDisplayId = a.displayId || parseInt(a.id.replace('TC-', '')) || 0;
        const bDisplayId = b.displayId || parseInt(b.id.replace('TC-', '')) || 0;
        return aDisplayId - bDisplayId;
      });
  };

  const totalPages = Math.ceil(getFilteredTestCases().length / itemsPerPage);

  // Add this new function to handle jumping to a specific page
  const [jumpToPageValue, setJumpToPageValue] = useState<string>('');

  // Add these new state variables for bulk delete
  const [isBulkDeleteDialogOpen, setIsBulkDeleteDialogOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Update the fetchScenarioDisplayId function to use the actual UUID
  const fetchScenarioDisplayId = async (testCaseId: string): Promise<{displayId: string, actualId: string}> => {
    try {
      const response = await axios.get(`${API_ENDPOINTS.getScenarioByTestCase}/${testCaseId}`);
      
      if (response.status === 200 && response.data) {
        const scenarioId = response.data.scenario_id;
        // Fetch scenario details to get the displayId
        const scenarioResponse = await axios.get(`${API_ENDPOINTS.getScenarioById}/${scenarioId}`);
        
        if (scenarioResponse.status === 200 && scenarioResponse.data) {
          const displayId = scenarioResponse.data.displayId || 'Unknown';
          return {
            displayId: `TS-${displayId}`,
            actualId: scenarioId
          };
        }
        return {
          displayId: `TS-${scenarioId.substring(0, 8)}`,
          actualId: scenarioId
        };
      }
      return {
        displayId: 'TS-Unknown',
        actualId: ''
      };
    } catch (error) {
      console.error(`Error fetching scenario for test case ${testCaseId}:`, error);
      return {
        displayId: 'TS-Unknown',
        actualId: ''
      };
    }
  };

  // Update the fetchRequirementByTestCase function to use the test case ID directly
  const fetchRequirementByTestCase = async (testCaseId: string): Promise<{displayId: string, actualId: string}> => {
    try {
      const response = await axios.get(`${API_ENDPOINTS.getRequirementByTestCase}/${testCaseId}`);
      
      if (response.status === 200 && response.data) {
        const requirementId = response.data.requirement_id;
        // Fetch requirement details to get the displayId
        const reqResponse = await axios.get(`${API_ENDPOINTS.getRequirementById}/${requirementId}`);
        
        if (reqResponse.status === 200 && reqResponse.data) {
          const displayId = reqResponse.data.displayId || 'Unknown';
          return {
            displayId: `REQ-${displayId}`,
            actualId: requirementId
          };
        }
        return {
          displayId: `REQ-${requirementId.substring(0, 8)}`,
          actualId: requirementId
        };
      }
      return {
        displayId: 'REQ-Unknown',
        actualId: ''
      };
    } catch (error) {
      console.error(`Error fetching requirement for test case ${testCaseId}:`, error);
      return {
        displayId: 'REQ-Unknown',
        actualId: ''
      };
    }
  };

  // Create a new function to fetch both scenario and requirement IDs for each test case
  const fetchTestCaseParentIds = async (testCases: TestCase[]) => {
    try {
      // Only process test cases that have a testcase_id (needed for API call)
      const testCasesWithIds = testCases.filter(tc => tc.testcase_id);
      
      // Create arrays of promises for parallel execution
      const promises = testCasesWithIds.map(async (testCase) => {
        if (!testCase.testcase_id) return;

        // Fetch scenario ID and display ID
        const scenarioInfo = await fetchScenarioDisplayId(testCase.testcase_id);
        setScenarioDisplayIds(prev => new Map(prev).set(testCase.id, scenarioInfo.displayId));
        setScenarioActualIds(prev => new Map(prev).set(testCase.id, scenarioInfo.actualId));
        
        // Fetch requirement ID and display ID
        const requirementInfo = await fetchRequirementByTestCase(testCase.testcase_id);
        setRequirementDisplayIds(prev => new Map(prev).set(testCase.id, requirementInfo.displayId));
        setRequirementActualIds(prev => new Map(prev).set(testCase.id, requirementInfo.actualId));
      });
      
      // Wait for all promises to resolve
      await Promise.all(promises);
      
    } catch (error) {
      console.error("[TestCases] Error fetching parent IDs:", error);
    }
  };

  // Update the fetchTestCasesForUsecase function to handle the new fields
  const fetchTestCasesForUsecase = useCallback(async (usecaseId: string | number) => {
    try {
      if (!initialLoadComplete) {
        setIsLoading(true);
      }   
      
      // Call the rearrange-testcases API during streaming
      if (isStreaming && usecaseId) {
        try {
          await axios.put(`${ENV.API_URL}/testcase-management/rearrange-testcases/${usecaseId}`);
        } catch (error) {
          console.error("Error rearranging test cases:", error);
          // Continue with fetching even if rearranging fails
        }
      }
      
      // Fetch from API
      const response = await axios.get(`${API_ENDPOINTS.getTestCasesByUsecase}/${usecaseId}`);
      // console.log("[TestCases] Response:", response);

      if (response.status === 200) {
        // Process API response
        let apiTestCases = [];
        
        // Handle different response structures
        if (Array.isArray(response.data)) {
          apiTestCases = response.data;
        } else if (response.data.scenarios && Array.isArray(response.data.scenarios)) {
          // If the response has a scenarios array, extract scenario IDs and flatten all test cases
          response.data.scenarios.forEach((scenario: any) => {
            const testCases = scenario.test_cases || [];
            apiTestCases.push(...testCases);
          });
        } else if (response.data.test_cases && Array.isArray(response.data.test_cases)) {
          apiTestCases = response.data.test_cases;
        } else {
          console.error("[TestCases] Unexpected API response structure:", response.data);
          throw new Error("Unexpected API response structure");
        }
        
        // Transform API test cases to UI format
        const transformedTestCases = apiTestCases.map(transformApiTestCase);
        
        // Store current test case IDs to detect new ones
        const currentTestCaseIds = new Set(transformedTestCases.map(tc => tc.id));
        const newTestCaseIds = [...currentTestCaseIds].filter(id => !previousTestCaseIdsRef.current.has(id));
        
        // Update refs and states
        previousTestCaseIdsRef.current = currentTestCaseIds;
        setNewlyAddedTestCaseIds(newTestCaseIds);
        setTestCases(transformedTestCases);
        
        // Only highlight new test cases if we've completed initial loading
        if (initialLoadComplete && newTestCaseIds.length > 0) {
          setNewlyAddedTestCaseIds(newTestCaseIds);
          // Remove highlighting after 1 seconds
          setTimeout(() => {
            setNewlyAddedTestCaseIds([]);
          }, 1000);
          
          // Show toast notification for new test cases
          toast.success(`${newTestCaseIds.length} new test case(s) generated!`, { 
            duration: 1000 
          });
        }
        
        // Update our reference of seen test cases
        previousTestCaseIdsRef.current = currentTestCaseIds;
        
        // Check if generation is complete
        const statusResponse = await axios.get(
          `${API_ENDPOINTS.getUseCaseStatus}/${usecaseId}`
        );

        // console.log("Check if generation is complete", statusResponse);
        
        if (statusResponse.data.test_case_generation === "Completed") {
          setIsStreaming(false); // Stop streaming when complete
        }

        if (initialLoadComplete) {
          setIsLoading(false);
        } else {
          setInitialLoadComplete(true);
          setIsLoading(false);
        }
      }
    } catch (error) {
      console.error("[TestCases] Error fetching test cases:", error);
      setError("Failed to load test cases. Please try again.");
      setIsLoading(false);
    }
  }, [initialLoadComplete, isStreaming]);

  // Add polling mechanism using custom useInterval hook
  useInterval(
    () => {
      if (effectiveUsecaseId && isStreaming) {
        fetchTestCasesForUsecase(effectiveUsecaseId);
      }
    },
    isStreaming ? 5000 : null // Poll every 5 seconds, or stop if isStreaming is false
  );

  // Initial fetch
  useEffect(() => {
    if (effectiveUsecaseId) {
      fetchTestCasesForUsecase(effectiveUsecaseId);
      
      // Check if we should be streaming
      checkStatus();
    }
  }, [effectiveUsecaseId, fetchTestCasesForUsecase]);

  // Move checkStatus outside the useEffect and make it reusable
  const checkStatus = async () => {
    if (!effectiveUsecaseId) return;
    
    try {
      const statusResponse = await axios.get(
        `${API_ENDPOINTS.getUseCaseStatus}/${effectiveUsecaseId}`
      );
      // console.log("CheckStatus :", statusResponse.data.test_case_generation);
      
      if (statusResponse.data.test_case_generation === "Completed") {
        // console.log("Test case generation completed");
        setIsStreaming(false);
      } else {
        // console.log("Test case generation not completed");
        setIsStreaming(true);
      }
    } catch (error) {
      console.error("Error checking test case generation status:", error);
    }
  };

  // Get paginated test cases
  const getPaginatedTestCases = () => {
    const filteredTestCases = getFilteredTestCases();
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return filteredTestCases.slice(startIndex, endIndex);
  };

  // Pagination handlers
  const goToNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const goToPreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const goToPage = (pageNumber: number) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  const handleItemsPerPageChange = (value: string) => {
    setItemsPerPage(parseInt(value));
    setCurrentPage(1); // Reset to first page when changing items per page
  };

  // const toggleLeftPanel = () => {
  //   setIsLeftPanelMaximized(!isLeftPanelMaximized);
  //   setIsRightPanelMaximized(false);
  // };

  const toggleRightPanel = () => {
    setIsRightPanelMaximized(!isRightPanelMaximized);
    setIsLeftPanelMaximized(false);
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      // Select all non-deleted test cases
      setSelectedTestCases(getFilteredTestCases().map(tc => tc.id));
    } else {
      // Deselect all
      setSelectedTestCases([]);
    }
  };

  // const toggleTestCase = (testCaseId: string) => {
  //   setExpandedTestCases(prev =>
  //     prev.includes(testCaseId)
  //       ? prev.filter(id => id !== testCaseId)
  //       : [...prev, testCaseId]
  //   );
  // };

  const toggleTestCaseExpansion = (testCaseId: string) => {
    setExpandedTestCases(prev => 
      prev.includes(testCaseId) 
        ? prev.filter(id => id !== testCaseId) 
        : [...prev, testCaseId]
    );
    
    // Find the test case and update selection
    const testCase = testCases.find(tc => tc.id === testCaseId);
    if (testCase) {
      if (expandedTestCases.includes(testCaseId)) {
        // If it was expanded and now being collapsed, clear selection
        if (selectedTestCase?.id === testCaseId) {
          setSelectedTestCase(null);
        }
      } else {
        // If it's being expanded, set it as selected
        setSelectedTestCase(testCase);
      }
    }
  };

  const handleScenarioClick = (testCaseId: string) => {
    // Find the test case by ID
    const testCase = testCases.find(tc => tc.id === testCaseId);
    
    if (!testCase || !testCase.testcase_id) {
      toast.error("Cannot find test case details");
      return;
    }
    
    // Fetch the actual scenario UUID using the API
    axios.get(`${API_ENDPOINTS.getScenarioByTestCase}/${testCase.testcase_id}`)
      .then(response => {
        if (response.status === 200 && response.data && response.data.scenario_id) {
          setSelectedScenario(response.data.scenario_id);
          setShowScenarioDialog(true);
        } else {
          toast.error("Cannot find scenario details");
        }
      })
      .catch(error => {
        console.error("Error fetching scenario for test case:", error);
        toast.error("Failed to fetch scenario details");
      });
  };

  const handleRequirementClick = (idParam: string) => {
    // Check if the ID is a UUID (requirement ID) or a test case ID
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(idParam);
    
    if (isUuid) {
      // If it's a UUID, use it directly as the requirement ID
      console.log("Using directly provided requirement UUID:", idParam);
      setSelectedRequirement(idParam);
      setShowRequirementDialog(true);
      return;
    }
    
    // Otherwise, treat it as a test case ID and find the requirement
    // Find the test case by ID
    const testCase = testCases.find(tc => tc.id === idParam);
    
    if (!testCase || !testCase.testcase_id) {
      toast.error("Cannot find test case details");
      return;
    }
    
    // Fetch the actual requirement UUID using the API
    axios.get(`${API_ENDPOINTS.getRequirementByTestCase}/${testCase.testcase_id}`)
      .then(response => {
        if (response.status === 200 && response.data && response.data.requirement_id) {
          setSelectedRequirement(response.data.requirement_id);
          setShowRequirementDialog(true);
        } else {
          toast.error("Cannot find requirement details");
        }
      })
      .catch(error => {
        console.error("Error fetching requirement for test case:", error);
        toast.error("Failed to fetch requirement details");
      });
  };

  const handleStatusChange = (status: "completed" | "in_progress" | "needs_review") => {
    const updatedTestCases = testCases.map(testCase => 
      selectedTestCases.includes(testCase.id) ? { ...testCase, status } : testCase
    );
    setTestCases(updatedTestCases);
    // console.log("[TestCases] Updated test cases with new status:", updatedTestCases);
    // Here you would typically make an API call to update the status on the backend
  };

  const scenariosForGrid = testCases.map(transformTestCaseToScenario);

  const handleTestCaseClick = (testCase: TestCase) => {
    // Toggle selection - if clicking the same test case, deselect it
    if (selectedTestCase?.id === testCase.id) {
      setSelectedTestCase(null);
      // Close any expanded test case
      setExpandedTestCases(prev => prev.filter(id => id !== testCase.id));
    } else {
      // Use the original testCase, not the one with modified IDs
      const originalTestCase = testCases.find(tc => tc.id === testCase.id);
      setSelectedTestCase(originalTestCase || testCase);
      // Expand the selected test case if it's not already expanded
      if (!expandedTestCases.includes(testCase.id)) {
        setExpandedTestCases(prev => [...prev, testCase.id]);
      }
    }
  };

  const handleCoverageItemClick = (testCase: TestCase) => {
    setSelectedTestCase(testCase);
    setSelectedRequirement(testCase.requirementId);
    setShowRequirementDialog(true);
  };

  // Add a handler function for test case deletion
  const handleTestCaseDelete = (testCaseId: string) => {
    // Update the testCases state by filtering out the deleted test case
    setTestCases(prevTestCases => prevTestCases.filter(tc => tc.id !== testCaseId));
    
    // Also clean up any related state, like selected test cases
    setSelectedTestCases(prev => prev.filter(id => id !== testCaseId));
    
    // If the deleted test case was the selected one, clear the selection
    if (selectedTestCase?.id === testCaseId) {
      setSelectedTestCase(null);
    }
    
    // If the deleted test case was expanded, remove it from expanded list
    setExpandedTestCases(prev => prev.filter(id => id !== testCaseId));
  };

  // Add handler to show the bulk delete dialog
  const handleBulkDeleteClick = () => {
    if (selectedTestCases.length === 0) {
      toast.error("Please select at least one test case to delete");
      return;
    }
    setIsBulkDeleteDialogOpen(true);
  };

  // Add handler for bulk delete confirmation
  const handleConfirmBulkDelete = async () => {
    setIsDeleting(true);
    
    try {
      let successCount = 0;
      let failureCount = 0;
      
      for (const testCaseId of selectedTestCases) {
        try {
          // Find the actual test case to get the testcase_id
          const testCase = testCases.find(tc => tc.id === testCaseId);
          
          if (!testCase?.testcase_id) {
            console.error(`No testcase_id found for test case ${testCaseId}`);
            failureCount++;
            continue;
          }
          
          await axios.post(
            `${ENV.API_URL}/testcase-management/delete-by-testcaseid/${testCase.testcase_id}`
          );
          successCount++;
        } catch (error) {
          console.error(`Error deleting test case ${testCaseId}:`, error);
          failureCount++;
        }
      }
      
      setIsBulkDeleteDialogOpen(false);
      
      if (successCount > 0) {
        toast.success(`Successfully deleted ${successCount} test case${successCount !== 1 ? 's' : ''}`);
        
        // Update UI by removing deleted test cases
        setTestCases(prevTestCases => 
          prevTestCases.filter(tc => !selectedTestCases.includes(tc.id))
        );
        
        // Clear selected test cases
        setSelectedTestCases([]);
        
        // Clear selection if it was deleted
        if (selectedTestCase && selectedTestCases.includes(selectedTestCase.id)) {
          setSelectedTestCase(null);
        }
        
        // Update expanded test cases
        setExpandedTestCases(prev => 
          prev.filter(id => !selectedTestCases.includes(id))
        );
      }
      
      if (failureCount > 0) {
        toast.error(`Failed to delete ${failureCount} test case${failureCount !== 1 ? 's' : ''}`);
      }
    } catch (error) {
      console.error("Error performing bulk delete:", error);
      toast.error("An error occurred during bulk deletion");
    } finally {
      setIsDeleting(false);
    }
  };

  // Add handler for canceling bulk delete
  const handleCancelBulkDelete = () => {
    setIsBulkDeleteDialogOpen(false);
  };

  // Render page numbers for pagination
  const renderPageNumbers = () => {
    const pageNumbers = [];
    const maxPageButtons = 5; // Maximum number of page buttons to show
    
    let startPage = Math.max(1, currentPage - Math.floor(maxPageButtons / 2));
    let endPage = Math.min(totalPages, startPage + maxPageButtons - 1);
    
    // Adjust if we're at the end
    if (endPage - startPage + 1 < maxPageButtons) {
      startPage = Math.max(1, endPage - maxPageButtons + 1);
    }
    
    // Always show first page
    if (startPage > 1) {
      pageNumbers.push(
        <Button 
          key={1} 
          variant={currentPage === 1 ? "default" : "outline"} 
          size="sm" 
          onClick={() => goToPage(1)}
          className="h-8 w-8 p-0"
        >
          1
        </Button>
      );
      
      // Add ellipsis if there's a gap
      if (startPage > 2) {
        pageNumbers.push(
          <span key="start-ellipsis" className="px-2">...</span>
        );
      }
    }
    
    // Add page numbers
    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(
        <Button 
          key={i} 
          variant={currentPage === i ? "default" : "outline"} 
          size="sm" 
          onClick={() => goToPage(i)}
          className="h-8 w-8 p-0"
        >
          {i}
        </Button>
      );
    }
    
    // Always show last page
    if (endPage < totalPages) {
      // Add ellipsis if there's a gap
      if (endPage < totalPages - 1) {
        pageNumbers.push(
          <span key="end-ellipsis" className="px-2">...</span>
        );
      }
      
      pageNumbers.push(
        <Button 
          key={totalPages} 
          variant={currentPage === totalPages ? "default" : "outline"} 
          size="sm" 
          onClick={() => goToPage(totalPages)}
          className="h-8 w-8 p-0"
        >
          {totalPages}
        </Button>
      );
    }
    
    return pageNumbers;
  };

  // Add this new function to handle jumping to a specific page
  const handleJumpToPage = (e: React.FormEvent) => {
    e.preventDefault();
    const pageNumber = parseInt(jumpToPageValue);
    
    if (!isNaN(pageNumber) && pageNumber >= 1 && pageNumber <= totalPages) {
      goToPage(pageNumber);
    } else {
      // Could add toast notification here for invalid page number
      console.warn(`Invalid page number: ${jumpToPageValue}. Must be between 1 and ${totalPages}`);
    }
    
    // Reset the input field after jumping
    setJumpToPageValue('');
  };

  // Add a toggle function for traceability panel
  const toggleTraceabilityPanel = () => {
    setIsTraceabilityVisible(!isTraceabilityVisible);
    setIsCoverageVisible(false);
  };

  // Render test cases with proper display IDs
  const renderTestCases = () => {
    const visibleTestCases = getPaginatedTestCases();

    if (isLoading && testCases.length === 0) {
      return (
        <div className="flex justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
    }

    if (error) {
      return (
        <div className="flex flex-col items-center py-20 text-center">
          <AlertCircle className="h-8 w-8 text-red-500 mb-2" />
          <p className="text-gray-600">{error}</p>
          <Button
            variant="outline"
            size="sm"
            className="mt-4"
            onClick={() => {
              setError(null);
              if (effectiveUsecaseId) {
                fetchTestCasesForUsecase(effectiveUsecaseId);
              }
            }}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Retry
          </Button>
        </div>
      );
    }

    if (visibleTestCases.length === 0) {
      return (
        <div className="flex flex-col items-center py-20 text-center">
          <FileQuestion className="h-12 w-12 text-gray-400 mb-2" />
          <p className="text-gray-600 mb-1">No test cases found</p>
          <p className="text-xs text-gray-500">Try generating test cases from your scenarios first</p>
        </div>
      );
    }

    return visibleTestCases.map((testCase) => (
      <TestCaseCard
        key={testCase.id}
        testCase={{
          ...testCase,
          // Use the new display IDs directly from the API response
          scenarioId: testCase.scenario_display_id ? `TS-${testCase.scenario_display_id}` : 
                      (scenarioDisplayIds.get(testCase.id) || testCase.scenarioId),
          requirementId: testCase.requirement_display_id ? `REQ-${testCase.requirement_display_id}` : 
                         (requirementDisplayIds.get(testCase.id) || testCase.requirementId)
        }}
        isExpanded={expandedTestCases.includes(testCase.id)}
        isSelected={selectedTestCase?.id === testCase.id}
        checked={selectedTestCases.includes(testCase.id)} 
        onSelect={(checked) => {
          setSelectedTestCases(prev =>
            checked
              ? [...prev, testCase.id]
              : prev.filter(id => id !== testCase.id)
          );
        }}
        onToggle={() => toggleTestCaseExpansion(testCase.id)}
        onScenarioClick={() => handleScenarioClick(testCase.id)}
        onRequirementClick={() => handleRequirementClick(testCase.id)}
        onClick={() => handleTestCaseClick(testCase)}
        onDelete={handleTestCaseDelete}
        isNew={newlyAddedTestCaseIds.includes(testCase.id)}
      />
    ));
  };

  // Improve the error display to be more user-friendly
  if (error) {
    return (
      <div className="flex flex-1 items-center justify-center p-4">
        <div className="flex flex-col items-center gap-4 max-w-md text-center">
          {/* <div className="text-red-500 text-5xl mb-4">⚠️</div> */}
          <p className="text-lg font-medium text-red-600">
            {error}
          </p>
          <p className="text-gray-600 mt-2">
            {!effectiveUsecaseId ? 
              "To view test cases, you need to select a bundle first. Please go back to the previous step and ensure a bundle is selected." :
              "There was an issue loading the test cases. Please try again"
            }
          </p>
          <Button onClick={() => fetchTestCasesForUsecase(effectiveUsecaseId)} className="mt-4">
            <RefreshCw className="h-4 w-4 mr-2" />
            Retry
          </Button>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex flex-1 items-center justify-center p-4">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-lg font-medium text-gray-600">
          Please wait, generating the test cases...
          </p>
        </div>
      </div>
    );
  }

  return (
    <>
    <div className="flex flex-col flex-1 h-full overflow-hidden">
      {/* User associations with reduced padding */}
      <div className="px-4 pt-4 pb-2">
        <UserAssociationInfo 
          product={product} 
          subProduct={subProduct} 
          domain={domain} 
        />
        <BundleInfo 
          bundleName={bundleName} 
          usecaseId={effectiveUsecaseId?.toString()}
          onStatusChange={(statusData) => {
            // console.log("Bundle status updated:", statusData);
            // Call checkStatus when the bundle status changes
            if (statusData && statusData.test_case_generation) {
              if (statusData.test_case_generation === "Completed") {
                console.log("Test case generation completed via BundleInfo update");
                setIsStreaming(false);
              } else {
                // console.log("Test case generation not completed via BundleInfo update");
                setIsStreaming(true);
              }
            }
          }}
        />
      </div>
      
      {/* Main content area */}
      <div className="flex flex-row flex-1 px-4 pb-4">
        <div
          className={cn(
            "flex flex-col transition-all duration-300",
            isLeftPanelMaximized ? "w-full" : (isCoverageVisible || isTraceabilityVisible) ? "w-2/3" : "w-full",
            isRightPanelMaximized ? "w-0 hidden" : "flex"
          )}
        >
          <div className="flex justify-between items-center py-2">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-semibold">Test Cases</h2>
              {/* <span className="text-sm text-muted-foreground">
                ({getFilteredTestCases().length})
              </span> */}
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleTraceabilityPanel}
            >
              {isLeftPanelIconExpanded ? (
                <Maximize2 className="h-4 w-4" />
              ) : (
                <Minimize2 className="h-4 w-4" />
              )}
            </Button>
          </div>

          {/* <div className="mb-4 border rounded-md overflow-hidden bg-white"> */}
          <div className="mb-1 overflow-hidden">
            {/* <div className="p-3 border-b flex items-center justify-between"> */}
            <div className="p-2  flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Checkbox
                  checked={selectedTestCases.length === getFilteredTestCases().length && getFilteredTestCases().length > 0}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      handleSelectAll(true);
                    } else {
                      handleSelectAll(false);
                    }
                  }}
                />
                <span className="text-sm text-gray-500">
                  Select All ({getFilteredTestCases().length})
                </span>
              </div>
              
              <div className="flex items-center gap-2">
                <Button 
                  className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
                  size="sm"
                  onClick={() => setShowGridDialog(true)}
                >
                  <Grid className="h-4 w-4 mr-2" />
                  Grid
                </Button>
                <Button 
                  className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
                  size="sm"
                  disabled={true}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Test Case
                </Button>
                {/* <Button
                  className={cn(
                    "whitespace-nowrap",
                    isTraceabilityVisible 
                      ? "bg-blue-700 hover:bg-blue-800" 
                      : "bg-blue-500 hover:bg-blue-600"
                  )}
                  size="sm"
                  onClick={toggleTraceabilityPanel}
                >
                  <Activity className="h-4 w-4 mr-2" />
                  Traceability
                </Button> */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
                      size="sm"
                      disabled={selectedTestCases.length === 0}
                    >
                      <CheckSquare className="h-4 w-4 mr-2" />
                      Change Status
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onSelect={() => handleStatusChange("completed")}>
                      Mark as Completed
                    </DropdownMenuItem>
                    <DropdownMenuItem onSelect={() => handleStatusChange("needs_review")}>
                      Mark as Needs Review
                    </DropdownMenuItem>
                    <DropdownMenuItem onSelect={() => handleStatusChange("in_progress")}>
                      Mark as In Progress
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                <Button
                  variant="destructive"
                  size="sm"
                  disabled={selectedTestCases.length === 0}
                  onClick={handleBulkDeleteClick}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Selected
                </Button>
              </div>
            </div>
          </div>

          <ScrollArea className="flex-1 border rounded-md bg-white">
            <div className="p-4">
              {renderTestCases()}
            </div>
          </ScrollArea>
          
          {/* Pagination Controls */}
          {testCases.length > 0 && (
            <div className="flex justify-between items-center mt-4 border-t pt-4">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <span>Rows per page:</span>
                <Select 
                  value={itemsPerPage.toString()} 
                  onValueChange={handleItemsPerPageChange}
                >
                  <SelectTrigger className="h-8 w-20">
                    <SelectValue placeholder="10" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5</SelectItem>
                    <SelectItem value="10">10</SelectItem>
                    <SelectItem value="20">20</SelectItem>
                    <SelectItem value="50">50</SelectItem>
                  </SelectContent>
                </Select>
                <span className="ml-4">
                  {`${(currentPage - 1) * itemsPerPage + 1}-${Math.min(currentPage * itemsPerPage, getFilteredTestCases().length)} of ${getFilteredTestCases().length}`}
                </span>
              </div>
              
              <div className="flex items-center gap-2">
                {/* Jump to Page Form */}
                <form onSubmit={handleJumpToPage} className="flex items-center mr-4">
                  <span className="text-sm text-gray-600 mr-2">Jump to:</span>
                  <input
                    type="number"
                    min="1"
                    max={totalPages}
                    value={jumpToPageValue}
                    onChange={(e) => setJumpToPageValue(e.target.value)}
                    className="h-8 w-24 px-2 border rounded-md text-sm"
                    placeholder="Page"
                  />
                  <Button 
                    type="submit" 
                    size="sm" 
                    className="ml-1 h-8 bg-blue-500 hover:bg-blue-600 text-white"
                    disabled={!jumpToPageValue || totalPages <= 1}
                  >
                    Go
                  </Button>
                </form>
                
                <div className="flex items-center">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={goToPreviousPage}
                    disabled={currentPage === 1}
                    className="h-8 w-8 p-0"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  
                  <div className="flex items-center gap-1 mx-2">
                    {renderPageNumbers()}
                  </div>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={goToNextPage}
                    disabled={currentPage === totalPages}
                    className="h-8 w-8 p-0"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>

        {isCoverageVisible && (
          <div
            className={cn(
              "flex flex-col transition-all duration-300 pl-4",
              isRightPanelMaximized ? "w-full" : "w-1/3",
              isLeftPanelMaximized ? "w-0 hidden" : "flex"
            )}
          >
            <div className="flex justify-between items-center py-2">
              <h2 className="text-lg font-semibold">Coverage Analysis</h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleRightPanel}
              >
                {isRightPanelMaximized ? (
                  <Minimize2 className="h-4 w-4" />
                ) : (
                  <Maximize2 className="h-4 w-4" />
                )}
              </Button>
            </div>

            <ScrollArea className="flex-1 border rounded-md bg-white">
              <div className="p-4">
                <CoverageAnalysis 
                  selectedTestCase={selectedTestCase} 
                  onCoverageItemClick={handleCoverageItemClick}
                  testCases={testCases}
                  usecaseId={effectiveUsecaseId?.toString()}
                />
              </div>
            </ScrollArea>
          </div>
        )}

        {isTraceabilityVisible && (
          <TracebilityCoverage
            testCases={testCases}
            selectedTestCase={selectedTestCase}
            onTestCaseClick={handleTestCaseClick}
            onScenarioClick={handleScenarioClick}
            onRequirementClick={handleRequirementClick}
            isVisible={isTraceabilityVisible}
            isRightPanelMaximized={isRightPanelMaximized}
            isLeftPanelMaximized={isLeftPanelMaximized}
            onToggleRightPanel={toggleRightPanel}
          />
        )}
      </div>

      <TestCasesGridDialog
        open={showGridDialog}
        onOpenChange={setShowGridDialog}
        testCases={getFilteredTestCases()}
        title="Test Cases"  
      />

      
      <ScenarioDialog
        open={showScenarioDialog}
        onOpenChange={setShowScenarioDialog}
        selectedScenario={selectedScenario}
        scenarios={scenariosForGrid}
      />

      <RequirementDialog
        open={showRequirementDialog}
        onOpenChange={setShowRequirementDialog}
        selectedRequirement={selectedRequirement}
      />

      {/* Bulk Delete Dialog */}
      <Dialog open={isBulkDeleteDialogOpen} onOpenChange={setIsBulkDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Bulk Deletion</DialogTitle>
            <DialogDescription asChild>
              <div>
                <div className="mt-2 text-gray-600">
                  You are about to delete {selectedTestCases.length} test case{selectedTestCases.length !== 1 ? 's' : ''}.
                </div>
                <div className="mt-2 text-gray-600">
                  This action will permanently remove these test cases and all related information.
                </div>
                <div className="mt-2 text-gray-600">
                  This will affect traceability and coverage metrics.
                </div>
                <div className="mt-4 font-medium text-red-600">
                  Are you sure you want to delete {selectedTestCases.length} test case{selectedTestCases.length !== 1 ? 's' : ''}?
                </div>
              </div>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={handleCancelBulkDelete} disabled={isDeleting}>Cancel</Button>
            <Button 
              variant="destructive" 
              onClick={handleConfirmBulkDelete}
              disabled={isDeleting}
            >
              {isDeleting ? "Deleting..." : "Delete Test Cases"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add streaming indicator in the UI */}
      {isStreaming && (
        <div className="flex items-center gap-2 mt-2 p-2 bg-blue-50 border border-blue-200 rounded-md">
          <div className="h-2 w-2 bg-blue-500 rounded-full animate-pulse"></div>
          <span className="text-sm text-blue-700">
            Streaming test cases as they are generated...
          </span>
        </div>
      )}
    </div>
    </>
  );
};