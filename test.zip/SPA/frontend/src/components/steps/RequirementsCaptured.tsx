import { toast } from "sonner";
import { RequirementsSection } from "./requirement/components/RequirementsSection";
import { SourceViewer } from "./requirement/components/SourceViewer";
import { useRequirements } from "./requirement/hooks/useRequirements";
import { useRequirementsLayout } from "./requirement/hooks/useRequirementsLayout";
import { createNewRequirement } from "./requirement/requirementUtils";
import { type Requirement } from "./requirement/types";
import { useEffect, useRef, useState } from "react";
import { Loader2, ChevronLeft, ChevronRight } from "lucide-react";
import axios from "axios";
import { ENV } from "@/config/env";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserAssociationInfo } from "../UserAssociationInfo";
import { BundleInfo } from "../BundleInfo";
import { useInterval } from "@/hooks/useInterval";

interface RequirementsCapturedProps {
  selectedFile: {
    id: string;
    name: string;
    uploadTime: Date;
  } | null;
  usecaseId?: string | number;
  onRequirementsGenerated: (requirementIds: string[]) => void;
  product?: string;
  subProduct?: string;
  domain?: string;
  bundleName: string;
}


const transformRequirementData = (backendData: any): Requirement[] => {
  return backendData.map((req: any) => {
    // Handle both cases: when requirementJson is a string or already an object
    const reqJson = typeof req.requirementJson === 'string' 
      ? JSON.parse(req.requirementJson) 
      : req.requirementJson || {};
    
    // Get the first user journey if it exists
    const userJourney = reqJson.user_journeys?.[0] || {};
    
    // Create the base requirement object without hardcoded actors
    const baseRequirement = {
      id: req.requirementId,
      requirementId: `REQ-${req.displayId}`,
      functionalArea: userJourney.name || "Unnamed Journey",
      description: userJourney.description || "No description available",
      userStories: userJourney.user_stories || [],
      status: req.isCompleted ? "completed" : "needs_review" as const,
      confidence: 0.85,
      source: {
        paragraph: 1,
        page: 1,
        text: userJourney.name || "No source text available",
        startIndex: 0,
        endIndex: 100
      },
      is_deleted: req.is_deleted || false
    };
    
    // Create a dynamic object to hold all requirement sections
    const dynamicSections: Record<string, any> = {};
    
    // Process all keys in the requirements object
    if (userJourney.requirements) {
      Object.entries(userJourney.requirements).forEach(([key, value]) => {
        // Convert snake_case to camelCase for the property name
        const camelKey = key.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
        
        if (Array.isArray(value)) {
          // For array values, create a properly formatted array of objects
          dynamicSections[camelKey] = value.map((item, idx) => ({
            id: `${camelKey}${idx + 1}`,
            description: item
          }));
        } 
        else if (typeof value === 'object' && value !== null) {
          // For object values, create an array of name-value pairs
          dynamicSections[camelKey] = Object.entries(value).map(([subKey, subValue], idx) => {
            if (Array.isArray(subValue)) {
              // Handle nested arrays (like in integration_requirements)
              return subValue.map((item, subIdx) => ({
                id: `${camelKey}${idx + 1}_${subIdx + 1}`,
                name: subKey.replace(/_/g, ' '),
                value: item
              }));
            } else {
              // Handle simple key-value pairs
              return {
                id: `${camelKey}${idx + 1}`,
                name: subKey.replace(/_/g, ' '),
                value: subValue
              };
            }
          }).flat();
        }
      });
    }
    
    // Merge the base requirement with dynamic sections only
    return {
      ...baseRequirement,
      ...dynamicSections
    };
  });
};

export const RequirementsCaptured = ({ 
  selectedFile, 
  usecaseId, 
  onRequirementsGenerated,
  product,
  subProduct,
  domain,
  bundleName
}: RequirementsCapturedProps) => {
  const [isLoading, setIsLoading] = useState(true);
  const [requirements, setRequirements] = useState<Requirement[]>([]);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Add pagination state variables
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [jumpToPageValue, setJumpToPageValue] = useState<string>('');

  // Add streaming states
  const [isStreaming, setIsStreaming] = useState(true);
  const previousRequirementIdsRef = useRef<Set<string>>(new Set());
  const [newlyAddedRequirementIds, setNewlyAddedRequirementIds] = useState<string[]>([]);
  const [initialLoadComplete, setInitialLoadComplete] = useState(false);

  // Add console log when component mounts
  useEffect(() => {
    // console.log("[RequirementsCaptured] Component mounted with usecaseId:", usecaseId);
  }, []);

  // Function to check workflow status
  const checkWorkflowStatus = async () => {
    try {
      const response = await axios.get(
        `${ENV.API_URL}/usecase-management/get-usecase-status/${usecaseId}`
      );
      
      if (response.data.requirement_generation === "Completed") {
        fetchRequirements();
        setIsStreaming(false);
      } else if (response.data.requirement_generation === "In Progress") {
        fetchRequirements();
      } else {
        timeoutRef.current = setTimeout(checkWorkflowStatus, 2000);
      }
    } catch (error) {
      console.error("[RequirementsCaptured] Error checking workflow status:", error);
      toast.error("Failed to check workflow status");
      setIsLoading(false);
      setIsStreaming(false);
    }
  };

  // Modified fetchRequirements to handle streaming properly
  const fetchRequirements = async () => {
    try {
      // Call the rearrange-requirements API during streaming
      if (isStreaming && usecaseId) {
        try {
          await axios.put(`${ENV.API_URL}/requirements/rearrange-requirements/${usecaseId}`);
        } catch (error) {
          console.error("Error rearranging requirements:", error);
          // Continue with fetching even if rearranging fails
        }
      }

      const response = await axios.get(
        `${ENV.API_URL}/requirements/get-by-usecaseid/${usecaseId}`
      );
      
      if (response.data.requirements && response.data.requirements.length > 0) {
        const transformedRequirements = transformRequirementData(response.data.requirements);
        
        // Compare with previous requirements to find new ones
        const currentRequirementIds = new Set(transformedRequirements.map(req => req.id));
        const newRequirementIds: string[] = [];
        
        transformedRequirements.forEach(req => {
          if (!previousRequirementIdsRef.current.has(req.id)) {
            newRequirementIds.push(req.id);
          }
        });
        
        // Update state
        setRequirements(transformedRequirements);
        
        // Only highlight new requirements if we've completed initial loading
        if (initialLoadComplete && newRequirementIds.length > 0) {
          setNewlyAddedRequirementIds(newRequirementIds);
          
          // Show toast notification for new requirements
          toast.success(`${newRequirementIds.length} new requirement(s) generated!`, { 
            duration: 1000 
          });
          
          // Remove highlighting after 3 seconds
          setTimeout(() => {
            setNewlyAddedRequirementIds([]);
          }, 3000);
        }
        
        // Update our reference of seen requirement IDs
        previousRequirementIdsRef.current = currentRequirementIds;
        
        // Extract and pass requirement IDs to parent
        const requirementIds = transformedRequirements.map(req => req.id);
        onRequirementsGenerated(requirementIds);

        // Reset to first page when new data is loaded
        if (!initialLoadComplete) {
          setCurrentPage(1);
        }
        
        // Check if generation is complete
        const statusResponse = await axios.get(
          `${ENV.API_URL}/usecase-management/get-usecase-status/${usecaseId}`
        );
        
        if (statusResponse.data.requirement_generation === "Completed") {
          setIsStreaming(false); // Stop streaming when complete
          setIsLoading(false);
        }
        
        if (!initialLoadComplete) {
          setInitialLoadComplete(true);
          setIsLoading(false);
        }
      } 
    } catch (error) {
      console.error("Error fetching requirements:", error);
      toast.error("Failed to fetch requirements");
      setIsLoading(false);
      setIsStreaming(false);
    }
  };

  // This useEffect handles initial loading
  useEffect(() => {
    if (usecaseId) {
      checkWorkflowStatus();
    }
    
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [usecaseId]);

  // Add useInterval for polling during streaming
  useInterval(
    () => {
      if (isStreaming && usecaseId) {
        fetchRequirements();
      }
    },
    isStreaming ? 3000 : null
  );

  // Move the getFilteredRequirements function up before it's used
  const getFilteredRequirements = () => {
    // Check if requirements is properly initialized
    if (!requirements || !Array.isArray(requirements)) {
      return [];
    }

    // Return filtered requirements based on your criteria and sort by displayId
    return requirements
      .filter(req => {
        // Your filtering logic here
        return req && !req.is_deleted; // Example filter condition
      })
      .sort((a, b) => {
        // Extract the numeric part from requirementId (REQ-X) for sorting
        const displayIdA = parseInt(a.requirementId.split('-')[1]);
        const displayIdB = parseInt(b.requirementId.split('-')[1]);
        return displayIdA - displayIdB; // Sort in ascending order
      });
  };

  // Now use getFilteredRequirements in useRequirements
  const {
    editingRequirement,
    selectedRequirements,
    expandedRequirement,
    handleSelectRequirement,
    handleSelectAll,
    handleEditRequirement,
    handleSaveRequirement,
    handleCancelEdit,
    handleDeleteRequirement,
    handleBulkDelete,
    handleBulkStatusChange,
    handleStatusChange,
    handleRequirementClick,
    handleFunctionalAreaChange,
    handleSourceChange,
    handleUserStoriesChange,
  } = useRequirements(getFilteredRequirements(), requirements);

  const {
    isRequirementsMaximized,
    isSourceMaximized,
    toggleRequirementsMaximize,
    toggleSourceMaximize,
  } = useRequirementsLayout();

  // const sourceContent = requirements
  //   .map(req => {
  //     if (req.id === expandedRequirement) {
  //       return `<mark class="bg-yellow-200">${req.source.text}</mark>`;
  //     }
  //     return req.source.text;
  //   })
  //   .join("\n\n");

  const handleAddNewRequirement = () => {
    const newRequirement = createNewRequirement(requirements.length);
    toast.success("New requirement added");
  };

  const handleRegenerateSelected = () => {
    if (selectedRequirements.length === 0) {
      toast.error("Please select at least one requirement to regenerate");
      return;
    }
    // toast.success(`Regenerating ${selectedRequirements.length} requirements`);
  };

  const handleSelectAllRequirements = (checked: boolean) => {
    // console.log("Requirements Captured - handleSelectAll called with:", checked);
    // console.log("RequirementsCaptured - current requirements:", requirements);
    // Call the hook's handleSelectAll method
    handleSelectAll(checked);
  };

  // Make sure handleDeleteRequirement is properly wired up
  const handleDeleteRequirementDirectly = (requirementId: string) => {
    console.log("Deleting requirement:", requirementId);
    
    // Create a new array without the deleted requirement
    const updatedRequirements = requirements.filter(req => req.id !== requirementId);
    
    // Update the state with this filtered array
    setRequirements(updatedRequirements);
    
    handleDeleteRequirement(requirementId);
    
    toast.success("Requirement deleted successfully");
  };

  const handleBulkDeleteDirectly = () => {
    if (selectedRequirements.length === 0) {
      toast.error("Please select at least one requirement to delete");
      return;
    }
    
    console.log("Bulk deleting requirements:", selectedRequirements);
    
    // Create a new array without the selected requirements
    const updatedRequirements = requirements.filter(
      req => !selectedRequirements.includes(req.id)
    );
    
    // Update the state with this filtered array
    setRequirements(updatedRequirements);
    
    // Also update in the hook (which will clear the selection)
    handleBulkDelete();
    
    toast.success(`Deleted ${selectedRequirements.length} requirements`);
  };

  // Then modify the pagination function to use filtered requirements
  const getPaginatedRequirements = () => {
    const filteredReqs = getFilteredRequirements();
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return filteredReqs.slice(startIndex, Math.min(endIndex, filteredReqs.length));
  };

  // Keep only this totalPages calculation
  const totalPages = Math.ceil(getFilteredRequirements().length / itemsPerPage);

  // Update display information
  const displayInfo = () => {
    const filteredReqs = getFilteredRequirements();
    const startIndex = (currentPage - 1) * itemsPerPage + 1;
    const endIndex = Math.min(currentPage * itemsPerPage, filteredReqs.length);
    return {
      start: filteredReqs.length === 0 ? 0 : startIndex,
      end: endIndex,
      total: filteredReqs.length
    };
  };

  // Pagination handlers
  const goToNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const goToPreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const goToPage = (pageNumber: number) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  const handleItemsPerPageChange = (value: string) => {
    setItemsPerPage(parseInt(value));
    setCurrentPage(1); // Reset to first page when changing items per page
  };

  const handleJumpToPage = (e: React.FormEvent) => {
    e.preventDefault();
    const pageNumber = parseInt(jumpToPageValue);
    
    if (!isNaN(pageNumber) && pageNumber >= 1 && pageNumber <= totalPages) {
      goToPage(pageNumber);
    } else {
      console.warn(`Invalid page number: ${jumpToPageValue}. Must be between 1 and ${totalPages}`);
    }
    
    // Reset the input field after jumping
    setJumpToPageValue('');
  };

  // Render page numbers for pagination
  const renderPageNumbers = () => {
    const pageNumbers = [];
    const maxPageButtons = 5; // Maximum number of page buttons to show
    
    let startPage = Math.max(1, currentPage - Math.floor(maxPageButtons / 2));
    let endPage = Math.min(totalPages, startPage + maxPageButtons - 1);
    
    // Adjust if we're at the end
    if (endPage - startPage + 1 < maxPageButtons) {
      startPage = Math.max(1, endPage - maxPageButtons + 1);
    }
    
    // Always show first page
    if (startPage > 1) {
      pageNumbers.push(
        <Button 
          key={1} 
          variant={currentPage === 1 ? "default" : "outline"} 
          size="sm" 
          onClick={() => goToPage(1)}
          className="h-8 w-8 p-0"
        >
          1
        </Button>
      );
      
      // Add ellipsis if there's a gap
      if (startPage > 2) {
        pageNumbers.push(
          <span key="start-ellipsis" className="px-2">...</span>
        );
      }
    }
    
    // Add page numbers
    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(
        <Button 
          key={i} 
          variant={currentPage === i ? "default" : "outline"} 
          size="sm" 
          onClick={() => goToPage(i)}
          className="h-8 w-8 p-0"
        >
          {i}
        </Button>
      );
    }
    
    // Always show last page
    if (endPage < totalPages) {
      // Add ellipsis if there's a gap
      if (endPage < totalPages - 1) {
        pageNumbers.push(
          <span key="end-ellipsis" className="px-2">...</span>
        );
      }
      
      pageNumbers.push(
        <Button 
          key={totalPages} 
          variant={currentPage === totalPages ? "default" : "outline"} 
          size="sm" 
          onClick={() => goToPage(totalPages)}
          className="h-8 w-8 p-0"
        >
          {totalPages}
        </Button>
      );
    }
    
    return pageNumbers;
  };

  if (isLoading) {
    return (
      <div className="flex flex-1 items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-lg font-medium text-gray-600">
            Please wait, generating the requirements...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col flex-1 h-full overflow-hidden">
        <div className="px-4 pt-4 pb-2">
      <UserAssociationInfo 
        product={product} 
        subProduct={subProduct} 
        domain={domain} 
      />
      <BundleInfo bundleName={bundleName} 
      usecaseId={usecaseId?.toString()}/>
      
      </div>
      <div className="flex flex-1 overflow-hidden">
        <RequirementsSection
          fileName={selectedFile?.name}
          isMaximized={isRequirementsMaximized}
          requirements={getPaginatedRequirements()}
          allRequirements={requirements}
          selectedRequirements={selectedRequirements}
          expandedRequirement={expandedRequirement}
          editingRequirement={editingRequirement}
          onEdit={handleEditRequirement}
          onSave={handleSaveRequirement}
          onCancel={handleCancelEdit}
          onSelectAll={handleSelectAllRequirements}
          onAddNew={handleAddNewRequirement}
          onRegenerate={handleRegenerateSelected}
          onBulkStatusChange={handleBulkStatusChange}
          onBulkDelete={handleBulkDeleteDirectly}
          onToggleMaximize={toggleRequirementsMaximize}
          onSelect={handleSelectRequirement}
          onClick={handleRequirementClick}
          onDelete={handleDeleteRequirementDirectly}
          onFunctionalAreaChange={handleFunctionalAreaChange}
          onSourceChange={handleSourceChange}
          onStatusChange={handleStatusChange}
          isSourceMaximized={isSourceMaximized}
          onUserStoriesChange={handleUserStoriesChange}
          displayTotal={displayInfo().total}
          newlyAddedRequirementIds={newlyAddedRequirementIds}
          usecaseId={usecaseId}
          onRequirementAdded={fetchRequirements}
        />

        {/* <SourceViewer
          content={sourceContent}
          isMaximized={isSourceMaximized}
          isHidden={isRequirementsMaximized}
          onToggleMaximize={toggleSourceMaximize}
        /> */}
      </div>

      {/* Pagination Controls */}
      {requirements.length > 0 && (
        <div className="flex justify-between items-center mt-4 border-t pt-4 px-6 pb-4">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <span>Rows per page:</span>
            <Select 
              value={itemsPerPage.toString()} 
              onValueChange={handleItemsPerPageChange}
            >
              <SelectTrigger className="h-8 w-20">
                <SelectValue placeholder="10" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="5">5</SelectItem>
                <SelectItem value="10">10</SelectItem>
                <SelectItem value="20">20</SelectItem>
                <SelectItem value="50">50</SelectItem>
              </SelectContent>
            </Select>
            <span className="ml-4">
              {`${displayInfo().start}-${displayInfo().end} of ${displayInfo().total}`}
            </span>
          </div>
          
          <div className="flex items-center gap-2">
            {/* Jump to Page Form */}
            <form onSubmit={handleJumpToPage} className="flex items-center mr-4">
              <span className="text-sm text-gray-600 mr-2">Jump to:</span>
              <input
                type="number"
                min="1"
                max={totalPages}
                value={jumpToPageValue}
                onChange={(e) => setJumpToPageValue(e.target.value)}
                className="h-8 w-24 px-2 border rounded-md text-sm"
                placeholder="Page"
              />
              <Button 
                type="submit" 
                size="sm" 
                className="ml-1 h-8 bg-blue-500 hover:bg-blue-600 text-white"
                disabled={!jumpToPageValue || totalPages <= 1}
              >
                Go
              </Button>
            </form>
            
            <div className="flex items-center">
              <Button
                variant="outline"
                size="sm"
                onClick={goToPreviousPage}
                disabled={currentPage === 1}
                className="h-8 w-8 p-0"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              
              <div className="flex items-center gap-1 mx-2">
                {renderPageNumbers()}
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={goToNextPage}
                disabled={currentPage === totalPages}
                className="h-8 w-8 p-0"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Add streaming indicator */}
      {isStreaming && (
        <div className="flex items-center gap-2 mt-2 p-2 bg-blue-50 border border-blue-200 rounded-md mx-4 mb-4">
          <div className="h-2 w-2 bg-blue-500 rounded-full animate-pulse"></div>
          <span className="text-sm text-blue-700">
            Streaming requirements as they are generated...
          </span>
        </div>
      )}
    </div>
  );
};
