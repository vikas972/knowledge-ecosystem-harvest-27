import { useEffect, useState, forwardRef, useImperativeHandle, useRef, useCallback } from "react";
import { toast } from "sonner";
import { ImportSourcesGrid } from "./source-selection/ImportSourcesGrid";
import { DocumentContextSection } from "./source-selection/DocumentContextSection";
import { ImportedFilesTable } from "./source-selection/ImportedFilesTable";
import { DocumentContext, SourceSelectionProps, UploadedFile, UserAssociationInfo } from "./source-selection/types";
import { API_ENDPOINTS } from "@/config/api";
import { useUserEmail } from "@/hooks/useUserEmail";
import { UseCaseSelection } from "./source-selection/UseCaseSelection";
import { ExistingUseCaseModal } from "./source-selection/ExistingUseCaseModal";
import { NewUseCaseModal } from "./source-selection/NewUseCaseModal";
import { Plus, File, Trash2, MoreVertical, Upload, FileText, Loader2, CheckCircle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
// import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
// import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Textarea } from "../ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import axios from "axios";
import { ENV } from "@/config/env";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@radix-ui/react-tooltip";

// Replace the existing PRODUCT_OPTIONS and SUB_PRODUCT_OPTIONS constants
const PRODUCT_OPTIONS = [
  { value: "DTB", label: "DTB" },
  { value: "Paycash CX", label: "Paycash CX" },
  { value: "CTX", label: "CTX" },
  { value: "iColumbus", label: "iColumbus" }
];

// Define the mapping of product to sub-products
const PRODUCT_TO_SUBPRODUCTS = {
  "DTB": [
    { value: "CBX", label: "CBX" },
    { value: "CBX BO", label: "CBX BO" },
    { value: "CS", label: "CS" },
    { value: "CIM", label: "CIM" },
    { value: "Mobility", label: "Mobility" },
    { value: "Payments", label: "Payments" },
    { value: "CNR", label: "CNR" },
    { value: "H2H", label: "H2H" }
  ],
  "Paycash CX": [
    { value: "CBOS-ES", label: "CBOS-ES" },
    { value: "CBOS-PG", label: "CBOS-PG" },
    { value: "CIM", label: "CIM" },
    { value: "CS", label: "CS" },
    { value: "CBX", label: "CBX" },
    { value: "DTB-CNR", label: "DTB-CNR" }
  ],
  "CTX": [
    { value: "CBX-LMS (Old)", label: "CBX-LMS (Old)" },
    { value: "CBX-LMS", label: "CBX-LMS" },
    { value: "LMS (Old)- Sweeps", label: "LMS (Old)- Sweeps" },
    { value: "LMS (Old)- Sweeps Notional Pooling", label: "LMS (Old)- Sweeps Notional Pooling" },
    { value: "LMS (New)- Sweeps", label: "LMS (New)- Sweeps" },
    { value: "LMS (New) - Sweeps Notional Pooling", label: "LMS (New) - Sweeps Notional Pooling" },
    { value: "CBX-VAM", label: "CBX-VAM" },
    { value: "VAM", label: "VAM" }
  ],
  "iColumbus": [
    { value: "Escrow", label: "Escrow" },
    { value: "CBX-Trade", label: "CBX-Trade" },
    { value: "Trade Finance", label: "Trade Finance" },
    { value: "SCF", label: "SCF" }
  ]
};

const DOMAIN_OPTIONS = [
  { value: "Payments", label: "Payments" },
  { value: "Trade finance", label: "Trade finance" },
  { value: "Cash management", label: "Cash management" },
  { value: "Supply chain", label: "Supply chain" },
  { value: "Corporate lending", label: "Corporate lending" },
  { value: "Foreign exchange", label: "Foreign exchange" }
];

export const SourceSelection = forwardRef(({ 
  onFileSelect, 
  onNextStep, 
  onUserAssociations,
  onBundleSelect 
}: SourceSelectionProps & { 
  onNextStep?: () => void, 
  onUserAssociations: (associations: UserAssociationInfo) => void,
  onBundleSelect: (bundleName: string, type: "new" | "existing", bundleUsecaseId?: string) => void 
}, ref) => {
  const { email } = useUserEmail();
  const [selectedSource, setSelectedSource] = useState<string | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [isContextExpanded, setIsContextExpanded] = useState(false);
  const [pendingFile, setPendingFile] = useState<File[] | null>(null);
  const [documentContext, setDocumentContext] = useState<DocumentContext>({
    documentName: "",
    documentType: "mainReq",
    documentFormat: "",
    requirementType: "k4",
    customer: "",
    breakRequirementsBy: "",
    businessDomain: "",
    agentContext: "",
    outputPreferences: {
      requirementFormat: "REQ-XXX",
      validationGranularity: "detailed",
      namingConvention: "camelCase",
    },
  });
  
  const [selectedUseCase, setSelectedUseCase] = useState<string | null>(null);
  const [isExistingUseCaseModalOpen, setIsExistingUseCaseModalOpen] = useState(false);
  const [selectedExistingUseCaseName, setSelectedExistingUseCaseName] = useState<string | null>(null);
  const [selectedExistingUseCaseId, setSelectedExistingUseCaseId] = useState<string | null>(null);
  const [isNewUseCaseModalOpen, setIsNewUseCaseModalOpen] = useState(false);
  const [selectedNewUseCaseName, setSelectedNewUseCaseName] = useState<string | null>(null);
  
  const selectedUseCaseObject = selectedUseCase === "existing" && selectedExistingUseCaseName
    ? { id: "existing-case", name: selectedExistingUseCaseName }
    : selectedUseCase === "new" && selectedNewUseCaseName
    ? { id: "new-case", name: selectedNewUseCaseName }
    : null;
  
  // Initialize with default files
  // const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([
  //   {
  //     id: "1",
  //     name: "requirements.pdf",
  //     uploadTime: new Date("2024-01-15T10:00:00"),
  //     status: "completed",
  //   },
  //   {
  //     id: "2",
  //     name: "specifications.docx",
  //     uploadTime: new Date("2024-01-16T14:30:00"),
  //     status: "completed",
  //   },
  //   {
  //     id: "3",
  //     name: "test-cases.xlsx",
  //     uploadTime: new Date("2024-01-17T09:15:00"),
  //     status: "failed",
  //   }
  // ]);

  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);

  // Add state for user associations
  const [selectedProduct, setSelectedProduct] = useState<string>("");
  const [selectedSubProduct, setSelectedSubProduct] = useState<string>("");
  const [selectedDomain, setSelectedDomain] = useState<string>("");

  // Check if all selected files are completed
  const areAllSelectedFilesCompleted = selectedFiles.length > 0 && 
    selectedFiles.every(fileId => {
      const file = uploadedFiles.find(file => file.id === fileId);
      return file && file.status !== "failed"; // Allow both completed and parsing files
    });

  // Next button should be enabled if:
  // - For existing use case: at least one file is selected and all selected files are completed
  // - For new use case: at least one file is selected and all selected files are completed
  const isNextButtonEnabled = selectedUseCaseObject && selectedFiles.length > 0 && areAllSelectedFilesCompleted;

  // Add a new piece of state to track when to auto-select files
  const [autoSelectFilesForUseCaseId, setAutoSelectFilesForUseCaseId] = useState<string | null>(null);

  // Add near your other state declarations (around line 852)
  const [isDeleteBundleDialogOpen, setIsDeleteBundleDialogOpen] = useState(false);

  // Add a new state to track if files have been submitted
  const [filesSubmitted, setFilesSubmitted] = useState(false);

  // Add this with your other state variables around line 153
  const [isUploading, setIsUploading] = useState(false);
  const [customCustomerName, setCustomCustomerName] = useState<string>("");

  const handleSourceFileSelect = (files: File[]) => {
    setPendingFile(files);
    // If opened from modal, keep the modal open, otherwise expand the context section
    if (!isDocumentContextModalOpen) {
      setIsContextExpanded(true);
    }
    
    // Set document context with the files names when selected from source
    // Extract filename without extension for the document name
    const fileName = files.length > 0 ? files[0].name : "";
    const fileNameWithoutExtension = fileName.includes('.') 
      ? fileName.substring(0, fileName.lastIndexOf('.')) 
      : fileName;
    
    setDocumentContext({
      documentName: fileNameWithoutExtension, // Set the document name to the file name without extension
      documentType: documentContext.documentType || "",
      documentFormat: documentContext.documentFormat || "",
      requirementType: documentContext.requirementType || "",
      customer: documentContext.customer || "",
      breakRequirementsBy: documentContext.breakRequirementsBy || "",
      businessDomain: documentContext.businessDomain || "",
      agentContext: `Processing ${files.map(f => f.name).join(', ')}`,
      outputPreferences: {
        requirementFormat: documentContext.outputPreferences?.requirementFormat || "REQ-XXX",
        validationGranularity: documentContext.outputPreferences?.validationGranularity || "detailed",
        namingConvention: documentContext.outputPreferences?.namingConvention || "camelCase",
      },
    });
    
    toast.success(`${files.length} file(s) selected for processing`);
  };

  // const handleFileSelect = (fileId: string, isSelected: boolean) => {
  const handleFileSelect = (fileId: string, isSelected: boolean, silent?: boolean) => {
    // console.log(`Selected file: ${fileId} (Checked: ${isSelected})`);
    setSelectedFiles(prev => {
      if (isSelected) {
        return [...prev, fileId];
      } else {
        return prev.filter(id => id !== fileId);
      }
    });
    
    // If a file is selected, also pass it to the parent component
    // if (isSelected) {
      if (isSelected && !silent) {
      const file = uploadedFiles.find(f => f.id === fileId);
      if (file && file.status !== "failed") {
        onFileSelect?.(file);
      }
    }
  };

  const handleContextUpdate = (field: keyof DocumentContext, value: any) => {
    setDocumentContext(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleRetry = (fileId: string) => {
    setUploadedFiles(files =>
      files.map(file =>
        file.id === fileId ? { ...file, status: "parsing" as const } : file
      )
    );
    toast.success("Retrying file parsing...");
    
    // Simulate completion after a delay
    setTimeout(() => {
      setUploadedFiles(files =>
        files.map(file =>
          file.id === fileId ? { ...file, status: "completed" as const } : file
        )
      );
      toast.success("File parsing completed");
    }, 1000);
  };

  const handleDelete = (fileId: string) => {
    setUploadedFiles(files => files.filter(file => file.id !== fileId));
    setSelectedFiles(prev => prev.filter(id => id !== fileId));
    toast.success("File deleted successfully", {
      duration: 1000
    });
  };

  const handleImport = async (fileIndex?: number) => {
    if (!pendingFile || pendingFile.length === 0) {
      toast.error("No files selected to import");
      return;
    }

    // If a specific file index is provided, import only that file
    if (fileIndex !== undefined && fileIndex >= 0 && fileIndex < pendingFile.length) {
      const file = pendingFile[fileIndex];
      
      // Create new uploaded file entry for the selected file
      // Now include the document context with the file
      const newFile = {
        id: String(Date.now() + Math.random()),
        name: file.name,
        uploadTime: new Date(),
        status: "completed" as const,
        file: file, // Store the actual File object for later upload
        // Store the document context with the file
        documentContext: {
          documentName: documentContext.documentName,
          documentType: documentContext.documentType || "mainReq",
          documentFormat: documentContext.documentFormat,
          requirementType: documentContext.requirementType || "k4",
          customer: documentContext.customer,
          breakRequirementsBy: documentContext.breakRequirementsBy,
          businessDomain: documentContext.businessDomain,
          agentContext: documentContext.agentContext,
          outputPreferences: { ...documentContext.outputPreferences }
        }
      };
      
      setUploadedFiles(prev => [...prev, newFile]);
      toast.success(`File ${file.name} added successfully`, {
        duration: 1000
      });
      
      // If this was the last file in the pending array, clear the pending files
      if (pendingFile.length === 1 || fileIndex === pendingFile.length - 1) {
        setPendingFile(null);
        setIsContextExpanded(false);
        setDocumentContext({
          documentName: "",
          documentType: "",
          documentFormat: "",
          requirementType: "",
          customer: "",
          breakRequirementsBy: "",
          businessDomain: "",
          agentContext: "",
          outputPreferences: {
            requirementFormat: "REQ-XXX",
            validationGranularity: "detailed",
            namingConvention: "camelCase",
          },
        });
      } else {
        // Otherwise, keep the remaining files in the pending state
        // and set agentContext for the next file
        const remainingFiles = [...pendingFile];
        remainingFiles.splice(fileIndex, 1);
        setPendingFile(remainingFiles);
        
        // Update agent context for the next file
        setDocumentContext(prev => ({
          ...prev,
          agentContext: `Processing ${remainingFiles[0].name}`,
        }));
      }
    } else {
      // If no specific file index provided, import all files
      const newFiles = pendingFile.map(file => ({
        id: String(Date.now() + Math.random()),
        name: file.name,
        uploadTime: new Date(),
        status: "completed" as const,
        file: file,
        // Store the current document context with all files
        documentContext: {
          documentName: documentContext.documentName,
          documentType: documentContext.documentType || "mainReq",
          documentFormat: documentContext.documentFormat,
          requirementType: documentContext.requirementType || "k4",
          customer: documentContext.customer,
          breakRequirementsBy: documentContext.breakRequirementsBy,
          businessDomain: documentContext.businessDomain,
          agentContext: documentContext.agentContext,
          outputPreferences: { ...documentContext.outputPreferences }
        }
      }));
      
      setUploadedFiles(prev => [...prev, ...newFiles]);
      toast.success(`Files added to the table successfully`, {
        duration: 500
      });

      // Clear the pending files after adding to table
      setPendingFile(null);
      setIsContextExpanded(false);
      setDocumentContext({
        documentName: "",
        documentType: "",
        documentFormat: "",
        requirementType: "",
        customer: "",
        breakRequirementsBy: "",
        businessDomain: "",
        agentContext: "",
        outputPreferences: {
          requirementFormat: "REQ-XXX",
          validationGranularity: "detailed",
          namingConvention: "camelCase",
        },
      });
    }
  };

  const handleReset = () => {
    if (pendingFile && pendingFile.length > 0) {
    setDocumentContext({
      documentName: "",
      documentType: "",
      documentFormat: "",
      requirementType: "",
      customer: "",
      breakRequirementsBy: "",
      businessDomain: "",
      agentContext: "",
      outputPreferences: {
        requirementFormat: "REQ-XXX",
        validationGranularity: "detailed",
        namingConvention: "camelCase",
      },
    });
    toast.success("Reset to default values");
  }
  };

  const handleUseCaseTypeSelect = (useCaseType: string) => {
    setSelectedUseCase(useCaseType);
    
    if (useCaseType === "existing") {
      setIsExistingUseCaseModalOpen(true);
    } else if (useCaseType === "new") {
      setIsNewUseCaseModalOpen(true);
    }
  };
  
  const handleSelectExistingUseCase = (useCaseId: string, useCaseName: string, product: string, sub_product: string, domain: string) => {
    console.log(`Selected use case: ${useCaseName} (ID: ${useCaseId}) with metadata:`, { product, sub_product, domain });
    setSelectedExistingUseCaseName(useCaseName);
    setSelectedExistingUseCaseId(useCaseId);
    
    // Update the product, sub-product, and domain selections
    if (product) setSelectedProduct(product);
    if (sub_product) setSelectedSubProduct(sub_product);
    if (domain) setSelectedDomain(domain);
    
    // Update the parent component
    onUserAssociations({
      product: product || selectedProduct,
      sub_product: sub_product || selectedSubProduct,
      domain: domain || selectedDomain
    });
    
    // Add this line
    onBundleSelect(useCaseName, "existing", useCaseId);
  };

  const handleCreateNewUseCase = (useCaseName: string, usecaseId: number) => {
    setSelectedNewUseCaseName(useCaseName);
    
    // Reset filesSubmitted when creating a new bundle
    setFilesSubmitted(false);
    
    // Add this line
    onBundleSelect(useCaseName, "new", usecaseId.toString());

    // Store the usecaseId for later use
    setSelectedExistingUseCaseId(usecaseId.toString());
  };

  const fetchFilesForExistingUseCase = async (usecaseId: string) => {
    try {
      // Show loading state, but DON'T use a loading placeholder
      // This prevents auto-selection from selecting "loading"
      setUploadedFiles([]);
      
      // Call the API to get files for the use case
      const response = await fetch(`${API_ENDPOINTS.getFiles}/${usecaseId}`);
      
      if (!response.ok) {
        throw new Error(`Error: ${response.status}`);
      }
      
      // Parse the response
      const files = await response.json();
      
      // Map API response to UploadedFile format
      const mappedFiles: UploadedFile[] = files.map((file: any) => ({
        id: file.fileId,
        name: file.fileName,
        uploadTime: new Date(file.createdAt),
        status: "completed" as const,
        // Map document context info
        documentContext: {
          documentName: file.documentName,
          documentType: file.documentType,
          documentFormat: file.documentFormat,
          requirementType: file.requirementType,
          customer: file.customer,
          breakRequirementsBy: file.breakRequirementsBy,
          businessDomain: file.businessDomain,
          agentContext: file.additionalContext || "",
          outputPreferences: {
            requirementFormat: "REQ-XXX", // Default value
            validationGranularity: "detailed", // Default value
            namingConvention: "camelCase", // Default value
          }
        }
      }));
      
      // Update state with fetched files
      setUploadedFiles(mappedFiles);
      
      // console.log("Files loaded for use case, now selecting them");
      
      // IMPORTANT: Select files HERE after setting uploadedFiles
      const validFiles = mappedFiles
        .filter(file => file.status !== "failed")
        .map(file => file.id);
      
      // Set selected files directly
      // console.log("Setting selectedFiles to:", validFiles);
      setSelectedFiles(validFiles);
      
      // Show success toast
      if (mappedFiles.length === 0) {
        toast.info("No files found for this bundle", { duration: 1000 });
      } else {
        toast.success(`Loaded ${mappedFiles.length} files for bundle`, { duration: 1000 });
      }
      
      return mappedFiles;
    } catch (error) {
      console.error("Error fetching files for bundle:", error);
      // toast.error("Failed to load files for this bundle");
      toast.error(`Failed to load files for this bundle"`, {
        duration: 1000
      });
      
      // Reset to empty state
      setUploadedFiles([]);
      return [];
    }
  };

  const fetchFilesForUseCase = async (useCaseId: string) => {
    try {
      // Set the flag to auto-select files once they're loaded
      setAutoSelectFilesForUseCaseId(useCaseId);
      
      // Fetch the files
      await fetchFilesForExistingUseCase(useCaseId);
      
      // Don't try to set selected files here - the useEffect will handle it
    } catch (error) {
      console.error("Error fetching files for bundle:", error);
      toast.error("Failed to load files for this bundle");
    }
  };

  useEffect(() => {
    if (selectedUseCaseObject) {
      if (selectedUseCase === "existing" && selectedExistingUseCaseId) {
        // Use the actual usecase ID from the selection
        fetchFilesForUseCase(selectedExistingUseCaseId);
      } else if (selectedUseCase === "new") {
        // For new use case, start with empty files list
        setUploadedFiles([]);
      }
    }
  }, [selectedExistingUseCaseName, selectedNewUseCaseName, selectedUseCase, selectedExistingUseCaseId]);

  // Handle file status updates from the table
  const handleFilesStatusChanged = (updatedFiles: UploadedFile[]) => {
    setUploadedFiles(updatedFiles);
    
    // If the status changes for a selected file, notify the parent
    for (const fileId of selectedFiles) {
      const file = updatedFiles.find(f => f.id === fileId);
      if (file && file.status === "completed") {
        onFileSelect(file);
      }
    }
  };

  // Expose the uploadFiles method to the parent component via ref
  useImperativeHandle(ref, () => ({
    uploadFiles: handleUploadFiles,
    getUserAssociations: () => ({
      product: selectedProduct,
      sub_product: selectedSubProduct,
      domain: selectedDomain
    }),
    areFilesSubmitted: () => filesSubmitted,
    isBundleSelected: () => {
      return (selectedUseCase === "existing" && selectedExistingUseCaseId) || 
             (selectedUseCase === "new" && selectedNewUseCaseName);
    },
  }));

  // Update the handleUploadFilesToAPI function
  const handleUploadFilesToAPI = async () => {
    if (uploadedFiles.length === 0 || !selectedUseCaseObject) {
      // toast.error("Please select files and a use case before proceeding");
      toast.error(`Please select files and a bundle before proceeding`, {
        duration: 1000
      });
      return { success: false, usecaseId: null };
    }

    // Get all the selected completed files
    const selectedCompletedFiles = uploadedFiles.filter(
      file => selectedFiles.includes(file.id) && file.status === "completed"
    );
    
    if (selectedCompletedFiles.length === 0) {
      toast.error("No completed files selected");
      return { success: false, usecaseId: null };
    }

    // For existing use case, just return the selected existing usecase ID
    if (selectedUseCase === "existing") {
      console.log("Using existing bundle - skipping file upload");
      
      // Process selected files for the next step
      for (const fileId of selectedFiles) {
        const file = uploadedFiles.find(f => f.id === fileId);
        if (file && file.status === "completed") {
          onFileSelect?.(file);
        }
      }
      
      return { success: true, usecaseId: selectedExistingUseCaseId };
    }
    
    // Only proceed with API call for new use cases
    try {
      // Create a FormData instance
      const formData = new FormData();
      
      // Arrays to store document metadata for each file
      const documentTypes: string[] = [];
      const documentFormats: string[] = [];
      const businessDomains: string[] = [];
      const additionalContexts: string[] = [];
      
      // Add all the selected files to the form data
      for (const fileData of selectedCompletedFiles) {
        // If we have the actual File object stored in the fileData
        if (fileData.file) {
          formData.append('files', fileData.file);
          
          // Use the file-specific document context if available, otherwise use defaults
          if (fileData.documentContext) {
            documentTypes.push(fileData.documentContext.documentType || "srs");
            documentFormats.push(fileData.documentContext.documentFormat || "custom");
            businessDomains.push(fileData.documentContext.businessDomain || "payments");
            additionalContexts.push(fileData.documentContext.agentContext || `Processing ${fileData.name}`);
          } else {
            // Fallback to current global context if no stored context found
            documentTypes.push(documentContext.documentType || "srs");
            documentFormats.push(documentContext.documentFormat || "custom");
            businessDomains.push(documentContext.businessDomain || "payments");
            additionalContexts.push(documentContext.agentContext || `Processing ${fileData.name}`);
          }
        } else {
          // For mock/demo data without actual File objects
          toast.error(`Missing file data for ${fileData.name}. Please re-import the file.`);
          return { success: false, usecaseId: null };
        }
      }
      
      // Add all metadata arrays to the form data
      documentTypes.forEach(type => formData.append('document_types', type));
      documentFormats.forEach(format => formData.append('document_formats', format));
      businessDomains.forEach(domain => formData.append('business_domains', domain));
      additionalContexts.forEach(context => formData.append('additional_contexts', context));
      
      // Add email to the form data
      formData.append('email', email || '');
      
      // Add usecase_id to the form data
      const usecaseId = await (async () => {
        try {
          // For new use cases, we already have the ID from the creation response
          if (selectedUseCase === "new" && selectedExistingUseCaseId) {
            return parseInt(selectedExistingUseCaseId);
          }
          
          // For existing use cases, get the ID from the selection
          if (selectedUseCase === "existing" && selectedExistingUseCaseId) {
            return parseInt(selectedExistingUseCaseId);
          }
          
          throw new Error('No valid usecase ID found');
        } catch (error) {
          console.error('Error getting usecase ID:', error);
          throw error;
        }
      })();
      
      formData.append('usecase_id', usecaseId.toString());
      
      // Make the API call with all selected files
      const url = `${API_ENDPOINTS.fileUpload}`;
      
      // console.log("Uploading files to API:", {
      //   url,
      //   fileCount: selectedCompletedFiles.length,
      //   fileNames: selectedCompletedFiles.map(f => f.name),
      //   usecaseId,
      //   documentTypes,
      //   documentFormats,
      //   businessDomains,
      //   additionalContexts
      // });
      
      const response = await fetch(url, {
        method: 'POST',
        body: formData
      });
      
      if (!response.ok) {
        throw new Error(`Error: ${response.status}`);
      }
      
      const result = await response.json();
      console.log("Files uploaded successfully:", result);
      toast.success("Files uploaded successfully.", {
          duration: 1000
        });
      
      // Process selected files for the next step
      for (const fileId of selectedFiles) {
        const file = uploadedFiles.find(f => f.id === fileId);
        if (file && file.status === "completed") {
          onFileSelect?.(file);
        }
      }
      
      return { success: true, usecaseId: usecaseId };
      
    } catch (error) {
      console.error('Error uploading files:', error);
      toast.error('Failed to upload files. Please try again.');
      return { success: false, usecaseId: null };
    }
  };

  // Update the handleSpecificUseCaseSelect function to properly set all required state variables
  const handleSpecificUseCaseSelect = async (useCaseId: string, useCaseName: string, product?: string, subProduct?: string, domain?: string) => {
    // console.log(`Selected use case from accordion: ${useCaseName} (ID: ${useCaseId})`);
    
    // Set the selection mode to "existing"
    setSelectedUseCase("existing");
    
    // Update the selected existing use case state
    setSelectedExistingUseCaseId(useCaseId);
    setSelectedExistingUseCaseName(useCaseName);
    
    // Fetch files for this bundle
    fetchFilesForUseCase(useCaseId);
    // First, clear existing selections
    setSelectedFiles([]);
    
    // Fetch files and select them in a single operation
    const files = await fetchFilesForExistingUseCase(useCaseId);
    
    // If product, subProduct, and domain were provided directly, use them
    if (product && subProduct && domain) {
      // console.log("Using provided metadata:", { product, subProduct, domain });
      setSelectedProduct(product);
      setSelectedSubProduct(subProduct);
      setSelectedDomain(domain);
      
      onUserAssociations({
        product,
        sub_product: subProduct,
        domain
      });
    }
    
    // Otherwise fetch metadata
    try {
      const response = await axios.get(
        `${ENV.API_URL}/usecase-management/get-usecase-status/${useCaseId}`
      );

      // console.log(response.data.product, response.data.sub_product, response.data.domain, "response.data.product, response.data.subProduct, response.data.domain");
      const product = response.data.product;
      const sub_product = response.data.sub_product;
      const domain = response.data.domain;
      
      // console.log("Fetched metadata:", { product, sub_product, domain });
      
      // Update the product, sub-product, and domain selections
      if (product) setSelectedProduct(product);
      if (sub_product) setSelectedSubProduct(sub_product);
      if (domain) setSelectedDomain(domain);
      
      // Update the parent component
      onUserAssociations({
        product,
        sub_product,
        domain
      });
    } catch (error) {
      console.error("Error fetching use case metadata:", error);
    }
    
    // Add this line
    onBundleSelect(useCaseName, "existing", useCaseId);
  };

  // Add effect to reset sub-product when product changes
  useEffect(() => {
    // Only reset when manually selecting a product from dropdown
    // Don't reset when loading an existing use case
    if (selectedProduct && !selectedExistingUseCaseId) {
      // Reset sub-product when product changes
      setSelectedSubProduct("");
    }
  }, [selectedProduct, selectedExistingUseCaseId]);

  // Update the UserAssociations component
  const UserAssociations = () => {
    // Get the current sub-product options based on selected product
    const currentSubProductOptions = selectedProduct 
      ? PRODUCT_TO_SUBPRODUCTS[selectedProduct as keyof typeof PRODUCT_TO_SUBPRODUCTS] || []
      : [];
      
    return (
      <div className="mb-4">
        <h2 className="text-3xl font-bold text-gray-800 mb-3 ">
          User Associations
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <Label htmlFor="product">Product</Label>
            <Select value={selectedProduct} onValueChange={setSelectedProduct}>
              <SelectTrigger id="product" className="w-full">
                <SelectValue placeholder="Select product" />
              </SelectTrigger>
              <SelectContent>
                {PRODUCT_OPTIONS.map(option => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="sub-product">Sub-Product</Label>
            <Select 
              value={selectedSubProduct} 
              onValueChange={setSelectedSubProduct}
              disabled={!selectedProduct}
            >
              <SelectTrigger id="sub-product" className="w-full">
                <SelectValue placeholder={selectedProduct ? "Select sub-product" : "Select Product first"} />
              </SelectTrigger>
              <SelectContent>
                {currentSubProductOptions.map(option => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="domain">Domain</Label>
            <Select value={selectedDomain} onValueChange={setSelectedDomain}>
              <SelectTrigger id="domain" className="w-full">
                <SelectValue placeholder="Select domain" />
              </SelectTrigger>
              <SelectContent>
                {DOMAIN_OPTIONS.map(option => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    );
  };

  // Debugging useEffect
  useEffect(() => {
    // console.log("SourceSelection: uploadedFiles changed:", uploadedFiles.map(f => f.id));
  }, [uploadedFiles]);

  useEffect(() => {
    // console.log("SourceSelection: selectedFiles changed:", selectedFiles);
  }, [selectedFiles]);

  // Add this state variable near your other state declarations
  const [isDocumentContextModalOpen, setIsDocumentContextModalOpen] = useState(false);

  // Add this function before the return statement
  const handleDeleteBundle = async () => {
    if (!selectedUseCase) {
      toast.error("No bundle selected to delete");
      return;
    }

    try {
      // Close the dialog first
      setIsDeleteBundleDialogOpen(false);
      
      // For new bundles that haven't been saved yet, we can simply clear the selection
      if (selectedUseCase === "new") {
        // Reset the bundle selection
        setSelectedUseCase(null);
        setSelectedNewUseCaseName(null);
        setSelectedFiles([]);
        toast.success("Bundle deleted successfully", {
          duration: 1000
        });
        return;
      }
      
      // For existing bundles, call the API
      if (selectedUseCase === "existing" && selectedExistingUseCaseId) {
        // Make API call to delete the bundle
        const response = await axios.delete(
          `${ENV.API_URL}/usecase-management/delete-usecase/${selectedExistingUseCaseId}`
        );
        
        // Reset selection state
        setSelectedUseCase(null);
        setSelectedExistingUseCaseId(null);
        setSelectedExistingUseCaseName(null);
        setSelectedFiles([]);
        
        toast.success("Bundle deleted successfully", {
          duration: 1000
        });
      }
    } catch (error) {
      console.error("Error deleting bundle:", error);
      toast.error("Failed to delete bundle. Please try again.");
    }
  };

  const anotherElementRef = useRef<HTMLButtonElement>(null);

  // Add this function before your return statement
  const preventAutoFocus = useCallback((node: HTMLDivElement | null) => {
    if (node) {
      // This will execute when the dialog content mounts
      setTimeout(() => {
        // Find any focused element and blur it
        const focusedElement = node.querySelector(':focus') as HTMLElement;
        if (focusedElement) {
          focusedElement.blur();
        }
      }, 0);
    }
  }, []);

  // Add a function to track bundle type
  const handleBundleSelection = (name: string, type: "new" | "existing", usecaseId?: string) => {
    // Update internal state
    // ...
    
    // Pass to parent
    if (onBundleSelect) {
      onBundleSelect(name, type, usecaseId);
    }
  };

  // Add this function implementation to handle file uploads
  const handleUploadFiles = async () => {
    if (uploadedFiles.length === 0 || !selectedUseCaseObject) {
      toast.error(`Please select files and a bundle before proceeding`, {
        duration: 1000
      });
      return { success: false, usecaseId: null };
    }

    // Get all the selected completed files
    const selectedCompletedFiles = uploadedFiles.filter(
      file => selectedFiles.includes(file.id) && file.status === "completed"
    );
    
    if (selectedCompletedFiles.length === 0) {
      toast.error("No completed files selected");
      return { success: false, usecaseId: null };
    }

    // Use your existing handleUploadFilesToAPI function's implementation
    return handleUploadFilesToAPI();
  };

  // Update the handleSubmitFiles function to also hide the bundle panel
  const handleSubmitFiles = async () => {
    setIsUploading(true);
    try {
      const result = await handleUploadFiles();
      if (result.success && result.usecaseId) {
        // Set filesSubmitted flag to true
        setFilesSubmitted(true);
        
        // Clear the uploaded files array to hide the Import Status panel
        setUploadedFiles([]);
        
        // Clear selected files as well
        setSelectedFiles([]);
        
        // Reset the selected use case to hide the bundle panel
        // This will hide the "Requirement Bundles" panel while keeping the bundle name
        // We don't reset selectedNewUseCaseName to keep the bundle name in the success message
        
        toast.success("Files uploaded successfully. Processing started.", {
          duration: 1500
        });
      }
    } catch (error) {
      console.error("Error submitting files:", error);
      toast.error("Failed to submit files");
    } finally {
      setIsUploading(false);
    }
  };

  //added useEffect cleanup
  useEffect(() => {
    return () => {
      // This runs when component unmounts
      setSelectedUseCase(null);
      setSelectedExistingUseCaseName(null);
      setSelectedExistingUseCaseId(null);
      setSelectedNewUseCaseName(null);
    };
  }, []);

  return (
    // <div className="flex flex-col min-h-screen">
      // {/* User Associations as a completely separate section - reduced padding */}


      // {/* Original content in a separate container - reduced top padding */}
      <div className="container mx-auto px-4 py-12">
        <div className="container mx-auto px-4 py-4">
          <div className="max-w-4xl mx-auto bg-white rounded-lg shadow p-6">
            <UserAssociations />
          </div>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-800 mb-3">
            {/* Test Case Selection */}
            Requirement Bundle Creation
          </h2>
          <p className="text-gray-600 mb-8">
            {/* First select your use case type, then choose a source to import requirements. */}
            First select your requirement bundle, then select files to import.
          </p>

        {/* Bundle Selection Section */}
        <div className="mb-10">
          {/* <h3 className="text-2xl font-semibold text-gray-800 mb-4">
            Step 1: Select Bundle Type
          </h3> */}
          <UseCaseSelection 
            selectedUseCase={selectedUseCase}
            onUseCaseSelect={handleUseCaseTypeSelect}
          />
          {selectedUseCase === "existing" && selectedExistingUseCaseName && (
            <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-md">
              <p className="text-sm text-blue-700">
                <span className="font-medium">Selected Bundle:</span> {selectedExistingUseCaseName}
              </p>
            </div>
          )}
          {/* Only show the Requirement Bundles panel if files haven't been submitted yet */}
          {selectedUseCase === "new" && selectedNewUseCaseName && !filesSubmitted && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden mt-6 mb-6">
              <div className="flex justify-between items-center mb-6 p-6 border-b border-gray-200">
                <h3 className="text-xl font-semibold text-gray-800">Requirement Bundles</h3>
              </div>
              
              <div className="bg-[#F8F9FB] p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="text-gray-500">
                      <File className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{selectedNewUseCaseName}</span>
                        <span className="text-sm text-gray-500">•</span>
                        <span className="text-sm text-gray-500">{new Date().toLocaleDateString('en-GB', {
                          day: '2-digit',
                          month: '2-digit',
                          year: 'numeric'
                        }).replace(/\//g, '/')}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <TooltipProvider>
                      <Tooltip delayDuration={200}>
                        <TooltipTrigger asChild>
                          <button 
                            className="p-2 hover:bg-gray-100 rounded-full transition-colors duration-200"
                            onClick={() => setIsDocumentContextModalOpen(true)}
                          >
                            <Plus className="h-5 w-5" />
                          </button>
                        </TooltipTrigger>
                        <TooltipContent 
                          side="bottom"
                          className="bg-slate-800 text-white border-none font-medium px-3 py-2"
                        >
                          Add file to bundle
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                    <button 
                      className="p-2 hover:bg-gray-100 rounded-full text-red-500"
                      onClick={() => setIsDeleteBundleDialogOpen(true)}
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Source Selection Section - Only show for new bundles */}
        {/* {selectedUseCase === "new" && (
          <div className="mb-10">
            <h3 className="text-2xl font-semibold text-gray-800 mb-4">
              Step 2: Select Source
            </h3>
            <p className="text-gray-600 mb-4">
              Choose your preferred source for requirement parsing.
            </p>
            <ImportSourcesGrid
              selectedSource={selectedSource}
              onSourceSelect={setSelectedSource}
              onFileSelect={handleSourceFileSelect}
              isEnabled={!!selectedUseCase}
            />
          </div>
        )} */}

        {/* Document Context Section - Only show for new bundles */}
        {/* {selectedUseCase === "new" && (
          <DocumentContextSection
            isExpanded={isContextExpanded}
            onToggleExpand={() => setIsContextExpanded(!isContextExpanded)}
            selectedFile={selectedFiles[0]}
            uploadedFiles={uploadedFiles}
            documentContext={documentContext}
            onContextUpdate={handleContextUpdate}
            onReset={handleReset}
            onImport={handleImport}
            pendingFile={pendingFile}
          />
        )} */}

          <ImportedFilesTable
            uploadedFiles={uploadedFiles}
            selectedFiles={selectedFiles}
            onFileSelect={handleFileSelect}
            onRetry={handleRetry}
            onDelete={handleDelete}
            selectedUseCase={selectedUseCaseObject}
            selectedUseCaseType={selectedUseCase}
            allowMultiSelect={true}
            onFilesStatusChanged={handleFilesStatusChanged}
            onUseCaseSelect={handleSpecificUseCaseSelect}
            bundleName={selectedNewUseCaseName || selectedExistingUseCaseName || "New Bundle"}
            bundleCreatedAt={new Date()}
            showImportButton={selectedUseCase === "new" && selectedNewUseCaseName && uploadedFiles.length > 0 && !filesSubmitted}
            onImportFiles={handleSubmitFiles}
            isImporting={isUploading}
          />

          <ExistingUseCaseModal
            isOpen={isExistingUseCaseModalOpen}
            onClose={() => setIsExistingUseCaseModalOpen(false)}
            onSelectUseCase={handleSelectExistingUseCase}
          />

          <NewUseCaseModal
            isOpen={isNewUseCaseModalOpen}
            onClose={() => setIsNewUseCaseModalOpen(false)}
            onCreateUseCase={handleCreateNewUseCase}
            product={selectedProduct}
            subProduct={selectedSubProduct}
            domain={selectedDomain}
          />
  
        <Dialog 
          open={isDocumentContextModalOpen} 
          onOpenChange={(open) => {
            setIsDocumentContextModalOpen(open);
            
            // If the dialog is being closed, reset the document name and agent context
            if (!open) {
              setDocumentContext(prev => ({
                ...prev,
                documentName: "",
                agentContext: ""
              }));
            }
          }}
        >
          <DialogContent 
            className="sm:max-w-[500px] max-h-[90vh] flex flex-col p-0 border-0 shadow-lg"
            // ref={preventAutoFocus}
          >
            <DialogHeader className="px-6 py-4 border-b bg-gradient-to-r from-slate-50 to-white">
              <DialogTitle className="text-xl font-semibold text-slate-800">Add File to Bundle</DialogTitle>
            </DialogHeader>
            
            <div className="flex-1 overflow-y-auto">
              <div className="px-6 py-4 space-y-6">
                {/* SELECT SOURCE SECTION */}
                <div className="space-y-3">
                  <Label className="text-sm font-medium text-slate-700">Select Source</Label>
                  <div className="grid grid-cols-2 gap-3">
                    {/* JIRA */}
                    <div 
                      className={`relative flex flex-col items-center justify-center p-4 rounded-lg border transition-all duration-200 shadow-sm hover:shadow-md
                        ${selectedSource === 'jira' 
                          ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500' 
                          : 'border-slate-200 hover:border-slate-300 bg-white'}`}
                        onClick={(e) => {
                        //   e.stopPropagation();
                          setSelectedSource('jira');
                        }}
                    >
                      {selectedSource === 'jira' && (
                        <div className="absolute top-2 right-2 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" className="w-3 h-3">
                            <path fillRule="evenodd" d="M19.916 4.626a.75.75 0 01.208 1.04l-9 13.5a.75.75 0 01-1.154.114l-6-6a.75.75 0 011.06-1.06l5.353 5.353 8.493-12.739a.75.75 0 011.04-.208z" clipRule="evenodd" />
                          </svg>
                        </div>
                      )}
                      <div className="w-10 h-10 flex items-center justify-center rounded-full bg-blue-100 text-blue-600 mb-2">
                        <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                          <path d="M11.53 2.3A1.85 1.85 0 0010 4.05V5H4a2 2 0 00-2 2v3a2 2 0 002 2h6v8.93A1.85 1.85 0 0011.53 22 1.7 1.7 0 0013 21.73l7.79-7.83a1.7 1.7 0 000-2.4l-7.77-7.75A1.7 1.7 0 0011.53 2.3z"/>
                        </svg>
                      </div>
                      <span className="text-sm font-medium text-slate-800">JIRA</span>
                      <span className="text-xs text-slate-500 mt-1">Issue tracking</span>
                    </div>
                    
                    {/* Confluence */}
                    <div 
                      className={`relative flex flex-col items-center justify-center p-4 rounded-lg border transition-all duration-200 shadow-sm hover:shadow-md
                        ${selectedSource === 'confluence' 
                          ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500' 
                          : 'border-slate-200 hover:border-slate-300 bg-white'}`}
                      onClick={(e) => {
                        // e.stopPropagation();
                        setSelectedSource('confluence');
                      }}
                    >
                      {selectedSource === 'confluence' && (
                        <div className="absolute top-2 right-2 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" className="w-3 h-3">
                            <path fillRule="evenodd" d="M19.916 4.626a.75.75 0 01.208 1.04l-9 13.5a.75.75 0 01-1.154.114l-6-6a.75.75 0 011.06-1.06l5.353 5.353 8.493-12.739a.75.75 0 011.04-.208z" clipRule="evenodd" />
                          </svg>
                        </div>
                      )}
                      <div className="w-10 h-10 flex items-center justify-center rounded-full bg-teal-100 text-teal-600 mb-2">
                        <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                          <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                        </svg>
                      </div>
                      <span className="text-sm font-medium text-slate-800">Confluence</span>
                      <span className="text-xs text-slate-500 mt-1">Documentation</span>
                    </div>
                    
                    {/* Local Files */}
                    <div 
                      className={`relative flex flex-col items-center justify-center p-4 rounded-lg border transition-all duration-200 shadow-sm hover:shadow-md
                        ${selectedSource === 'local' 
                          ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500' 
                          : 'border-slate-200 hover:border-slate-300 bg-white'}`}
                      onClick={(e) => {
                      //   e.stopPropagation();
                        setSelectedSource('local');
                      }}
                    >
                      {selectedSource === 'local' && (
                        <div className="absolute top-2 right-2 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" className="w-3 h-3">
                            <path fillRule="evenodd" d="M19.916 4.626a.75.75 0 01.208 1.04l-9 13.5a.75.75 0 01-1.154.114l-6-6a.75.75 0 011.06-1.06l5.353 5.353 8.493-12.739a.75.75 0 011.04-.208z" clipRule="evenodd" />
                          </svg>
                        </div>
                      )}
                      <div className="w-10 h-10 flex items-center justify-center rounded-full bg-amber-100 text-amber-600 mb-2">
                        <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                          <path d="M6 2c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6H6zm7 7V3.5L18.5 9H13z"/>
                        </svg>
                      </div>
                      <span className="text-sm font-medium text-slate-800">Local Files</span>
                      <span className="text-xs text-slate-500 mt-1">From your device</span>
                    </div>
                    
                    {/* Database */}
                    <div 
                      className={`relative flex flex-col items-center justify-center p-4 rounded-lg border transition-all duration-200 shadow-sm hover:shadow-md
                        ${selectedSource === 'database' 
                          ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-500' 
                          : 'border-slate-200 hover:border-slate-300 bg-white'}`}
                      onClick={(e) => {
                      //   e.stopPropagation();
                        setSelectedSource('database');
                      }}
                    >
                      {selectedSource === 'database' && (
                        <div className="absolute top-2 right-2 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" className="w-3 h-3">
                            <path fillRule="evenodd" d="M19.916 4.626a.75.75 0 01.208 1.04l-9 13.5a.75.75 0 01-1.154.114l-6-6a.75.75 0 011.06-1.06l5.353 5.353 8.493-12.739a.75.75 0 011.04-.208z" clipRule="evenodd" />
                          </svg>
                        </div>
                      )}
                      <div className="w-10 h-10 flex items-center justify-center rounded-full bg-purple-100 text-purple-600 mb-2">
                        <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                          <path d="M12 2C6.48 2 2 4.48 2 8v8c0 3.52 4.48 6 10 6s10-2.48 10-6V8c0-3.52-4.48-6-10-6zm0 18c-4.42 0-8-1.79-8-4v-2.81c1.39 1.56 4.38 2.81 8 2.81s6.61-1.25 8-2.81V16c0 2.21-3.58 4-8 4zm0-8c-4.42 0-8-1.79-8-4s3.58-4 8-4 8 1.79 8 4-3.58 4-8 4z"/>
                        </svg>
                      </div>
                      <span className="text-sm font-medium text-slate-800">Database</span>
                      <span className="text-xs text-slate-500 mt-1">Connected data</span>
                    </div>
                  </div>
                </div>
                
                {/* CONDITIONAL DOCUMENT FILE UPLOAD SECTION - Only shown when Local Files is selected */}
                {selectedSource === 'local' && (
                  <div className="space-y-2">
                    <Label htmlFor="modalDocumentFile" className="text-sm font-medium text-slate-700">Document File</Label>
                    <div 
                      className="border-2 border-dashed rounded-lg p-4 flex flex-col items-center justify-center gap-2 py-6 w-full bg-slate-50 hover:bg-slate-100 transition-colors"
                      onDragOver={(e) => e.preventDefault()}
                      onDragLeave={(e) => e.preventDefault()}
                      onDrop={(e) => {
                        e.preventDefault();
                        if (e.dataTransfer.files.length > 0) {
                          // Filter for PDF files only
                          const pdfFiles = Array.from(e.dataTransfer.files).filter(
                            file => file.type === 'application/pdf'
                          );
                          if (pdfFiles.length > 0) {
                            handleSourceFileSelect(pdfFiles);
                          } else {
                            toast.error("Only PDF files are supported");
                          }
                        }
                      }}
                    >
                      <div className="w-12 h-12 rounded-full bg-slate-200 flex items-center justify-center mb-1">
                        <Upload className="h-6 w-6 text-slate-500" />
                      </div>
                      <p className="text-sm text-slate-600 font-medium">
                        Drag and drop your PDF file here, or
                      </p>
                      <Input
                        id="file-upload-modal"
                        type="file"
                        accept=".pdf,application/pdf"
                        className="hidden"
                        onChange={(e) => {
                          if (e.target.files && e.target.files.length > 0) {
                            // Check if selected file is PDF
                            const file = e.target.files[0];
                            if (file.type === 'application/pdf') {
                              handleSourceFileSelect(Array.from(e.target.files));
                            } else {
                              toast.error("Only PDF files are supported");
                              // Reset the input
                              e.target.value = '';
                            }
                          }
                        }}
                      />
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="mt-1 border-slate-300 text-slate-700 hover:bg-slate-200"
                        onClick={() => document.getElementById('file-upload-modal')?.click()}
                      >
                        Browse Files
                      </Button>
                      <p className="text-xs text-slate-400 mt-1">
                        Supports: PDF files only
                      </p>
                    </div>
                    {/* Display selected file name */}
                    {pendingFile && pendingFile.length > 0 && (
                      <div className="mt-3 p-2 bg-blue-50 rounded-md border border-blue-100">
                        <h4 className="text-xs font-medium text-blue-700 mb-1">Selected File:</h4>
                        <div className="flex items-center gap-2">
                          <FileText className="h-4 w-4 text-blue-500" />
                          <span className="text-sm text-blue-700 truncate">
                            {pendingFile[0].name}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                )}
                
                {/* SOURCE-SPECIFIC INPUT FIELDS */}
                {/* {selectedSource === 'jira' && (
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-slate-700">JIRA Issue ID</Label>
                    <Input 
                      placeholder="Enter JIRA issue ID or URL" 
                      className="w-full border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                )} */}
                
                {selectedSource === 'confluence' && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-sm font-medium text-slate-700">Confluence Page Link</Label>
                      <Input 
                        placeholder="Enter Confluence page URL" 
                        className="w-full border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label className="text-sm font-medium text-slate-700">Username</Label>
                        <Input 
                          placeholder="Enter Confluence username" 
                          className="w-full border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label className="text-sm font-medium text-slate-700">Password</Label>
                        <Input 
                          type="password"
                          placeholder="Enter password" 
                          className="w-full border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                        />
                      </div>
                    </div>
                  </div>
                )}
                
                {/* {selectedSource === 'database' && (
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-slate-700">Database Query</Label>
                    <Textarea 
                      placeholder="Enter SQL query or select table" 
                      className="w-full h-20 border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                )} */}
                
                {/* Document Name */}
                <div className="space-y-2">
                  <Label htmlFor="modalDocumentName" className="text-sm font-medium text-slate-700">Document Name</Label>
                  <Input
                    id="modalDocumentName"
                    placeholder="Enter document name"
                    value={documentContext.documentName || ''}
                    onChange={(e) => handleContextUpdate("documentName", e.target.value)}
                    className="w-full border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    autoFocus={false}
                    // ref={(input) => {
                    //   if (input) {
                    //     setTimeout(() => input.blur(), 0);
                    //   }
                    // }}
                  />
                </div>
                
                {/* Keep the rest of the form fields as they were */}
                <div className="space-y-2">
                  <Label htmlFor="modalDocumentType" className="text-sm font-medium text-slate-700">File Category</Label>
                  <div className="text-xs text-red-600 mt-1">
                    * At least one Main Requirement Document is required.
                  </div>
                  <Select
                    value={documentContext.documentType || "mainReq"}
                    onValueChange={(value) => handleContextUpdate("documentType", value)}
                  >
                    <SelectTrigger id="modalDocumentType" className="w-full border-slate-300">
                      <SelectValue placeholder="Main Requirement Document" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mainReq">Main Requirement Document</SelectItem>
                      <SelectItem value="supportingReq">Supporting Requirement Document</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="modalRequirementType" className="text-sm font-medium text-slate-700">Requirement Type</Label>
                  <Select
                    value={documentContext.requirementType || "k4"}
                    onValueChange={(value) => handleContextUpdate("requirementType", value)}
                  >
                    <SelectTrigger id="modalRequirementType" className="w-full border-slate-300">
                      <SelectValue placeholder="Select requirement type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="k1">K1</SelectItem>
                      <SelectItem value="k2">K2</SelectItem>
                      <SelectItem value="k3">K3</SelectItem>
                      <SelectItem value="k4">K4</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="modalCustomer" className="text-sm font-medium text-slate-700">Customer</Label>
                  <Input
                    id="modalCustomer"
                    placeholder="Enter customer name"
                    value={documentContext.customer || ''}
                    onChange={(e) => handleContextUpdate("customer", e.target.value)}
                    className="w-full border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="modalBreakRequirementsBy" className="text-sm font-medium text-slate-700">Break Requirements By</Label>
                  <Select
                    value={documentContext.breakRequirementsBy}
                    onValueChange={(value) => handleContextUpdate("breakRequirementsBy", value)}
                  >
                    <SelectTrigger id="modalBreakRequirementsBy" className="w-full border-slate-300">
                      <SelectValue placeholder="Break Requirements By" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="userJourney">User Journey</SelectItem>
                      <SelectItem value="userStories">User Stories</SelectItem>
                      <SelectItem value="section">Section</SelectItem>
                      <SelectItem value="paragraph">Paragraph</SelectItem>
                      <SelectItem value="page">Page</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                {/* Additional Context textarea */}
                <div className="space-y-2">
                  <Label htmlFor="agentContext" className="text-sm font-medium text-slate-700">Additional Context for SPA Agent</Label>
                  <Textarea 
                    placeholder="Provide any additional context that will help the SPA agent process this document..."
                    value={documentContext.agentContext}
                    onChange={(e) => handleContextUpdate("agentContext", e.target.value)}
                    className="h-24 border-slate-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>
            
            <DialogFooter className="flex-shrink-0 border-t px-6 py-4 bg-slate-50">
              <Button 
                ref={anotherElementRef}
                variant="outline" 
                onClick={() => setIsDocumentContextModalOpen(false)}
                className="border-slate-300 text-slate-700 hover:bg-slate-100"
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  handleImport();
                  setIsDocumentContextModalOpen(false);
                }}
                disabled={false}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                Add File
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Bundle Delete Confirmation Dialog */}
        <Dialog open={isDeleteBundleDialogOpen} onOpenChange={setIsDeleteBundleDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Delete Bundle</DialogTitle>
              <DialogDescription>
                <p className="mt-2 text-gray-600">
                  You are about to delete the bundle "{selectedUseCase === "new" ? selectedNewUseCaseName : selectedExistingUseCaseName}".
                </p>
                <p className="mt-2 text-gray-600">
                  This action will permanently remove the bundle and all its files.
                </p>
                <p className="mt-4 font-medium text-red-600">
                  Are you sure you want to delete this bundle?
                </p>
              </DialogDescription>
            </DialogHeader>
            <DialogFooter className="mt-4">
              <Button 
                variant="outline" 
                onClick={() => setIsDeleteBundleDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button 
                variant="destructive" 
                onClick={handleDeleteBundle}
              >
                Delete Bundle
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Success message */}
        {filesSubmitted && (
          <div className="mt-4 p-3 bg-green-50 border border-green-100 rounded-md">
            <p className="text-green-700 flex items-center">
              <CheckCircle className="h-4 w-4 mr-2" />
              Files submitted successfully. Processing in progress.
            </p>
          </div>
        )}
      </div>
      </div>
    
  );
});
