import { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogDescription
} from "@/components/ui/dialog";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Tooltip, 
  TooltipContent, 
  TooltipProvider, 
  TooltipTrigger 
} from "@/components/ui/tooltip";
import { 
  ChevronLeft, 
  ChevronRight, 
  Download, 
  Maximize2, 
  Minimize2
} from "lucide-react";

export interface TestScript {
  name: string;
  description: string;
  script: string;
}

interface TestScriptsGridDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  testScripts: TestScript[];
  title?: string;
}

export const TestScriptsGridDialog = ({ 
  open, 
  onOpenChange, 
  testScripts = [], 
  title = "Test Scripts"
}: TestScriptsGridDialogProps) => {
  const [isFullScreen, setIsFullScreen] = useState(false);
  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(5);
  const totalPages = Math.ceil(testScripts.length / itemsPerPage);
  
  // Store parsed CSV data
  const [parsedScripts, setParsedScripts] = useState<Array<{
    scriptName: string;
    scriptDescription: string;
    parsedRows: string[][];
  }>>([]);

  // Parse all scripts when component mounts or testScripts changes
  useEffect(() => {
    const newParsedScripts = testScripts.map(script => {
      // Parse CSV into rows
      const rows = script.script.split('\n')
        .map(line => {
          // Process CSV with quotes properly
          const getCSVValues = (line: string): string[] => {
            const values: string[] = [];
            let inQuote = false;
            let currentValue = "";
            
            for (let i = 0; i < line.length; i++) {
              const char = line[i];
              
              if (char === '"') {
                inQuote = !inQuote;
              } else if (char === ',' && !inQuote) {
                values.push(currentValue);
                currentValue = "";
              } else {
                currentValue += char;
              }
            }
            
            values.push(currentValue); // Add the last value
            return values;
          };
          
          return getCSVValues(line);
        });
      
      return {
        scriptName: script.name,
        scriptDescription: script.description,
        parsedRows: rows
      };
    });
    
    setParsedScripts(newParsedScripts);
  }, [testScripts]);

  // Update the getHeaderColumns function to return standardized headers
  const getHeaderColumns = () => {
    // Always return our standardized headers regardless of what's in the data
    return ["Object", "Value", "Extra", "Action", "Description"];
  };

  const toggleFullScreen = () => {
    setIsFullScreen(!isFullScreen);
  };

  const handleItemsPerPageChange = (value: string) => {
    setItemsPerPage(Number(value));
    setCurrentPage(1);
  };

  const goToPreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const goToNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const getPaginatedTestScripts = () => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return parsedScripts.slice(startIndex, endIndex);
  };

  // Function to handle Excel export
  const handleExport = () => {
    // Create a new workbook
    const wb = XLSX.utils.book_new();
    
    // Process each test script as a separate worksheet
    testScripts.forEach((script, index) => {
      try {
        // Parse the CSV data
        const rows = script.script.split('\n')
          .map(line => {
            // Use the same CSV parsing logic as in the component
            const getCSVValues = (line: string): string[] => {
              const values: string[] = [];
              let inQuote = false;
              let currentValue = "";
              
              for (let i = 0; i < line.length; i++) {
                const char = line[i];
                
                if (char === '"') {
                  inQuote = !inQuote;
                } else if (char === ',' && !inQuote) {
                  values.push(currentValue);
                  currentValue = "";
                } else {
                  currentValue += char;
                }
              }
              
              values.push(currentValue); // Add the last value
              return values;
            };
            
            return getCSVValues(line);
          });
        
        // Create worksheet from the parsed rows
        // Use column headers if available
        const headers = ["Object", "Value", "Extra", "Action", "Description"];
        const allRows = [headers, ...rows];
        
        const ws = XLSX.utils.aoa_to_sheet(allRows);
        
        // Clean the script name to be a valid Excel sheet name
        let sheetName = script.name.replace(/[\\/*[\]?:]/g, '_').trim();
        
        // Ensure sheet name is not longer than 31 characters (Excel limitation)
        if (sheetName.length > 31) {
          sheetName = sheetName.substring(0, 28) + '...';
        }
        
        // Use index if sheet name is empty
        if (!sheetName) {
          sheetName = `Script_${index + 1}`;
        }
        
        // Add the worksheet to the workbook
        XLSX.utils.book_append_sheet(wb, ws, sheetName);
      } catch (error) {
        console.error(`Error processing script ${script.name}:`, error);
      }
    });
    
    // Generate Excel file
    const excelFileName = `${title || 'Test_Scripts'}_${new Date().toISOString().split('T')[0]}.xlsx`;
    XLSX.writeFile(wb, excelFileName);
  };

  const dialogClass = isFullScreen 
    ? "w-screen h-screen max-w-none rounded-none" 
    : "w-[95vw] h-[90vh] max-w-[1500px]";

  // Helper for displaying script rows with color coding
  const getActionStyle = (action: string) => {
    const normalizedAction = action.toLowerCase().trim();
    
    switch (normalizedAction) {
      case 'gotocomponent':
        return 'bg-blue-50/50';
      case 'performclick':
        return 'bg-green-50/50';
      case 'wait':
        return 'bg-purple-50/50';
      case 'declare':
        return 'bg-amber-50/50';
      case 'capturescreen':
        return 'bg-indigo-50/50';
      case 'entertext':
        return 'bg-emerald-50/50';
      case 'verifyelementpresent':
      case 'verifyelementtext':
        return 'bg-rose-50/50';
      default:
        return '';
    }
  };

  // Add this helper function for cell styling
  const getCellStyle = (columnIndex: number, value: string) => {
    switch (columnIndex) {
      case 0: // Object column
        return "font-medium text-blue-600";
      case 1: // Value column
        return "text-emerald-600";
      case 2: // Extra column
        return "text-purple-600";
      case 3: // Action column
        return "font-medium text-gray-900";
      case 4: // Description column
        return "text-gray-600";
      default:
        return "text-gray-900";
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={dialogClass}>
        <DialogHeader className="flex flex-row items-center justify-between border-b pb-4 px-6">
          <div>
            <DialogTitle className="text-xl font-semibold text-gray-900">{title} Overview</DialogTitle>
            <DialogDescription className="text-sm text-gray-500 mt-1">
              {/* View all your TestMagic scripts in a grid format */}
            </DialogDescription>
          </div>
          <div className="flex items-center gap-3">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="outline" 
                    onClick={toggleFullScreen} 
                    className="h-9 w-9 p-0 border-gray-200 hover:bg-gray-100 transition-colors"
                  >
                    {isFullScreen ? 
                      <Minimize2 className="h-4 w-4 text-gray-600" /> : 
                      <Maximize2 className="h-4 w-4 text-gray-600" />
                    }
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{isFullScreen ? 'Exit fullscreen' : 'Enter fullscreen'}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <Button 
              onClick={handleExport} 
              className="bg-blue-600 hover:bg-blue-700 text-white h-9 px-4 shadow-sm transition-colors flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              <span className="font-medium">Export to Excel</span>
            </Button>
          </div>
        </DialogHeader>
        <ScrollArea className="h-[calc(100%-40px)]">
          <div className="p-2">
            {getPaginatedTestScripts().map((script, scriptIndex) => (
              <div key={scriptIndex} className="mb-6">
                <div className="bg-gray-100 p-2 rounded-t-md border border-gray-200">
                  <h3 className="font-semibold">{script.scriptName}</h3>
                  <p className="text-xs text-gray-600">{script.scriptDescription}</p>
                </div>
                <div className="overflow-x-auto">
                  <Table className="w-full border-collapse bg-white">
                    <TableHeader className="sticky top-0 z-10">
                      <TableRow>
                        <TableHead className="w-14 bg-gray-50 text-xs font-semibold text-gray-900 border-b border-gray-200 p-2">
                          No
                        </TableHead>
                        <TableHead className="bg-gray-50 text-xs font-semibold text-gray-900 border-b border-gray-200 p-2">
                          Object
                        </TableHead>
                        <TableHead className="bg-gray-50 text-xs font-semibold text-gray-900 border-b border-gray-200 p-2">
                          Value
                        </TableHead>
                        <TableHead className="bg-gray-50 text-xs font-semibold text-gray-900 border-b border-gray-200 p-2">
                          Extra
                        </TableHead>
                        <TableHead className="bg-gray-50 text-xs font-semibold text-gray-900 border-b border-gray-200 p-2">
                          Action
                        </TableHead>
                        <TableHead className="bg-gray-50 text-xs font-semibold text-gray-900 border-b border-gray-200 p-2">
                          Description
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {script.parsedRows.map((row, rowIndex) => {
                        const actionIndex = 3;
                        const action = row[actionIndex] || '';
                        const rowStyle = getActionStyle(action);
                        
                        return (
                          <TableRow 
                            key={rowIndex}
                            className={`
                              border-b border-gray-100
                              ${rowIndex % 2 === 0 ? "bg-white" : "bg-gray-50"}
                              ${rowStyle}
                              hover:bg-blue-50/50 transition-colors
                            `}
                          >
                            <TableCell className="text-xs font-medium text-gray-600 p-2 border-r border-gray-100">
                              {rowIndex + 1}
                            </TableCell>
                            {row.map((cell, cellIndex) => (
                              <TableCell 
                                key={cellIndex}
                                className="text-xs p-2 border-r border-gray-100"
                              >
                                <span className={getCellStyle(cellIndex, cell)}>
                                  {cell ? cell.replace(/^"|"$/g, '') : ''}
                                </span>
                              </TableCell>
                            ))}
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              </div>
            ))}
            
            {(!parsedScripts || parsedScripts.length === 0) && (
              <div className="text-center py-8 text-gray-500 bg-gray-50">
                <p className="text-lg">No test scripts available</p>
                <p className="text-sm mt-1">Test scripts will appear here as they are generated.</p>
              </div>
            )}
          </div>
        </ScrollArea>
        
        {/* Pagination Controls */}
        {testScripts.length > 0 && (
          <div className="flex justify-between items-center border-t py-1 px-4 bg-gray-50">
            <div className="flex items-center gap-2 text-xs text-gray-600">
              <Select 
                value={itemsPerPage.toString()} 
                onValueChange={handleItemsPerPageChange}
              >
                <SelectTrigger className="h-7 w-16 text-xs">
                  <SelectValue placeholder="10" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">5</SelectItem>
                  <SelectItem value="10">10</SelectItem>
                  <SelectItem value="20">20</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                </SelectContent>
              </Select>
              <span>per page</span>
              <span className="ml-2">
                {`${(currentPage - 1) * itemsPerPage + 1}-${Math.min(currentPage * itemsPerPage, testScripts.length)} of ${testScripts.length}`}
              </span>
            </div>
            
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="icon"
                onClick={goToPreviousPage}
                disabled={currentPage === 1}
                className="h-7 w-7"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              
              <div className="flex items-center">
                <input
                  type="number"
                  min="1"
                  max={totalPages}
                  value={currentPage}
                  onChange={(e) => {
                    const page = parseInt(e.target.value);
                    if (page >= 1 && page <= totalPages) {
                      setCurrentPage(page);
                    }
                  }}
                  className="h-7 w-12 px-2 border rounded text-xs text-center"
                />
                <span className="text-xs text-gray-600 mx-1">of {totalPages}</span>
              </div>

              <Button
                variant="outline"
                size="icon"
                onClick={goToNextPage}
                disabled={currentPage === totalPages}
                className="h-7 w-7"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
