// import { cn } from "@/lib/utils";
// import { type TestScenario } from "./types";
// import { AlertCircle, CheckCircle, PieChart } from "lucide-react";
// import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
// import { useEffect, useState } from "react";
// import axios from "axios";
// import { API_ENDPOINTS } from "@/config/api";

// interface RequirementsCoverageProps {
//   scenarios: TestScenario[];
//   selectedScenario: string | null;
//   onRequirementClick: (id: string) => void;
// }

// interface MissingCoverage {
//   type: string;
//   description: string;
// }

// export const RequirementsCoverage = ({
//   scenarios,
//   selectedScenario,
//   onRequirementClick,
// }: RequirementsCoverageProps) => {
//   const [apiRequirementId, setApiRequirementId] = useState<string | null>(null);
//   // Add a map to cache requirement IDs to avoid repeated API calls
//   const [requirementIdMap, setRequirementIdMap] = useState<Record<string, string>>({});

//   useEffect(() => {
//     if (selectedScenario) {
//       // console.log('RequirementsCoverage: Selected scenario ID:', selectedScenario);
      
//       const fullScenario = scenarios.find(s => s.id === selectedScenario);
//       // console.log('Full scenario object found:', fullScenario);
      
//       // Check if the scenario has a scenario_id (database ID) 
//       if (fullScenario?.scenario_id) {
//         // Make API call to get the requirement ID
//         const fetchRequirementId = async () => {
//           try {
//             const response = await axios.get(
//               `${API_ENDPOINTS.getRequirementByScenario}/${fullScenario.scenario_id}`
//             );
            
//             // Log the requirement ID from the API response
//             // console.log('API Requirement ID:', response.data.requirement_id);
            
//             // Store the API requirement ID
//             setApiRequirementId(response.data.requirement_id);
            
//             // Cache this mapping for future use
//             setRequirementIdMap(prev => ({
//               ...prev,
//               [fullScenario.requirementId]: response.data.requirement_id
//             }));
            
//             // You can compare this with the local requirementId
//             // console.log('Local Requirement ID:', fullScenario.requirementId);
            
//             // If they differ, you might want to use the API's requirement ID instead
//             if (response.data.requirement_id !== fullScenario.requirementId) {
//               // console.log('Requirement IDs differ between API and local data');
//             }
//           } catch (error) {
//             console.error('Error fetching requirement ID for scenario:', error);
//           }
//         };
        
//         fetchRequirementId();
//       } else {
//         // console.log('No database scenario_id available for API lookup');
//         // console.log('Using local requirementId:', fullScenario?.requirementId);
//         setApiRequirementId(null);
//       }
//     } else {
//       setApiRequirementId(null);
//     }
//   }, [selectedScenario, scenarios]);
  
//   // Preload all requirements' API IDs when component mounts or scenarios change
//   useEffect(() => {
//     // Extract unique requirement IDs
//     const uniqueRequirementIds = new Set(scenarios.map(s => s.requirementId));
//     // console.log('Unique requirement IDs:', Array.from(uniqueRequirementIds));
    
//     // For each unique requirement, find a scenario with scenario_id and fetch its requirement ID
//     uniqueRequirementIds.forEach(reqId => {
//       // Skip if we already have this mapping
//       if (requirementIdMap[reqId]) return;
      
//       // Find a scenario with this requirement ID that has a scenario_id
//       const scenarioWithId = scenarios.find(s => 
//         s.requirementId === reqId && s.scenario_id
//       );
      
//       if (scenarioWithId?.scenario_id) {
//         const fetchRequirementId = async () => {
//           try {
//             const response = await axios.get(
//               `${API_ENDPOINTS.getRequirementByScenario}/${scenarioWithId.scenario_id}`
//             );
            
//             // Cache the mapping
//             setRequirementIdMap(prev => ({
//               ...prev,
//               [reqId]: response.data.requirement_id
//             }));
            
//             // console.log(`Cached mapping for ${reqId}: ${response.data.requirement_id}`);
//           } catch (error) {
//             console.error(`Error fetching requirement ID for scenario with requirement ${reqId}:`, error);
//           }
//         };
        
//         fetchRequirementId();
//       }
//     });
//   }, [scenarios]);

//   const calculateCoverage = (relatedScenarios: TestScenario[]) => {
//     const totalFlows = relatedScenarios.reduce((acc, scenario) => acc + scenario.flows.length, 0);
//     const totalSubflows = relatedScenarios.reduce((acc, scenario) => 
//       acc + scenario.flows.reduce((flowAcc, flow) => flowAcc + flow.subflows.length, 0), 0);
    
//     const coverage = Math.min(100, Math.round((totalFlows * 20 + totalSubflows * 10) / 3));
//     return coverage;
//   };

//   const getMissingCoverageItems = (coverage: number): MissingCoverage[] => {
//     if (coverage === 100) return [];
    
//     const missingItems: MissingCoverage[] = [];
//     if (coverage < 100) {
//       missingItems.push({
//         type: "flow",
//         description: "Add error handling flows for invalid inputs"
//       });
//     }
//     if (coverage < 80) {
//       missingItems.push({
//         type: "validation",
//         description: "Add validation scenarios for boundary conditions"
//       });
//     }
//     if (coverage < 60) {
//       missingItems.push({
//         type: "edge_case",
//         description: "Consider edge cases for concurrent user actions"
//       });
//     }
//     return missingItems;
//   };

//   const groupedScenarios = scenarios.reduce((acc: { [key: string]: TestScenario[] }, scenario) => {
//     if (!acc[scenario.requirementId]) {
//       acc[scenario.requirementId] = [];
//     }
//     acc[scenario.requirementId].push(scenario);
//     return acc;
//   }, {});

//   const selectedRequirement = selectedScenario 
//     ? Object.entries(groupedScenarios).find(([_, scenarios]) => 
//         scenarios.some(s => s.id === selectedScenario))?.[0]
//     : null;

//   const requirementsToShow = selectedRequirement 
//     ? [[selectedRequirement, groupedScenarios[selectedRequirement]]] as [string, TestScenario[]][]
//     : Object.entries(groupedScenarios) as [string, TestScenario[]][];

//   // Handle requirement click - use API ID if available
//   const handleRequirementClick = (requirementId: string) => {
//     // If we have an API requirement ID for the selected scenario, use that
//     if (apiRequirementId && selectedRequirement === requirementId) {
//       // console.log('Using API requirement ID from selected scenario:', apiRequirementId);
//       onRequirementClick(apiRequirementId);
//     } 
//     // If we have this requirement ID mapped in our cache, use that
//     else if (requirementIdMap[requirementId]) {
//       // console.log('Using cached API requirement ID:', requirementIdMap[requirementId]);
//       onRequirementClick(requirementIdMap[requirementId]);
//     }
//     // Otherwise try to find a scenario with this requirement ID that has scenario_id
//     else {
//       // Look for a scenario with this requirement ID that has a database ID
//       const scenarioWithId = scenarios.find(s => 
//         s.requirementId === requirementId && s.scenario_id
//       );
      
//       if (scenarioWithId?.scenario_id) {
//         // console.log('Found scenario with ID for requirement', requirementId);
        
//         // Make API call to get the requirement ID
//         const fetchAndUseRequirementId = async () => {
//           try {
//             const response = await axios.get(
//               `${API_ENDPOINTS.getRequirementByScenario}/${scenarioWithId.scenario_id}`
//             );
            
//             const apiReqId = response.data.requirement_id;
//             // console.log('Fetched API requirement ID on demand:', apiReqId);
            
//             // Cache this mapping for future use
//             setRequirementIdMap(prev => ({
//               ...prev,
//               [requirementId]: apiReqId
//             }));
            
//             // Use the API ID
//             onRequirementClick(apiReqId);
//           } catch (error) {
//             console.error('Error fetching requirement ID on demand:', error);
//             // Fallback to local ID
//             // console.log('Falling back to local requirement ID:', requirementId);
//             onRequirementClick(requirementId);
//           }
//         };
        
//         fetchAndUseRequirementId();
//         return; // Return early to prevent the fallback below from executing
//       }
      
//       // Fallback to the local requirement ID if we can't get a mapping
//       // console.log('No API mapping available, using local requirement ID:', requirementId);
//       onRequirementClick(requirementId);
//     }
//   };

//   return (
//     <div className="h-full p-4 overflow-hidden">
//       <div className="prose prose-sm max-w-none h-[70vh] overflow-auto pr-2">
//         <div className="space-y-4">
//           {requirementsToShow.map(([requirementId, relatedScenarios]) => {
//             const coverage = calculateCoverage(relatedScenarios);
//             const missingItems = getMissingCoverageItems(coverage);
            
//             return (
//               <div
//                 key={requirementId}
//                 className={cn(
//                   "p-3 border rounded transition-colors cursor-pointer w-full",
//                   selectedScenario && relatedScenarios.some(s => s.id === selectedScenario)
//                     ? "bg-primary/10 border-primary" 
//                     : "hover:bg-gray-50"
//                 )}
//                 onClick={() => handleRequirementClick(requirementId)}
//               >
//                 <div className="flex items-center justify-between mb-2">
//                   <div className="font-medium">{requirementId}</div>
//                   <TooltipProvider>
//                     <Tooltip>
//                       <TooltipTrigger>
//                         <div className="flex items-center gap-2">
//                           <PieChart className={cn(
//                             "h-4 w-4",
//                             coverage === 100 ? "text-green-500" : "text-amber-500"
//                           )} />
//                           <span className="text-sm font-semibold text-gray-700">{coverage}%</span>
//                         </div>
//                       </TooltipTrigger>
//                       <TooltipContent>
//                         <p>Requirement Coverage</p>
//                       </TooltipContent>
//                     </Tooltip>
//                   </TooltipProvider>
//                 </div>
//                 <div className="text-sm text-gray-600">
//                   <div className="flex justify-between items-center mb-1">
//                     <span>Scenarios:</span>
//                     <span className="font-medium">{relatedScenarios.length}</span>
//                   </div>
//                   <div>
//                     Flow Coverage:
//                     <ul className="mt-1 ml-4 list-disc text-xs">
//                         {Object.entries(
//                             relatedScenarios.reduce((acc: any[], s) => acc.concat(s.flows), [])
//                                 .reduce((acc: { [key: string]: number }, flow) => {
//                                     acc[flow.type] = (acc[flow.type] || 0) + flow.subflows.length;
//                                     return acc;
//                                 }, {})
//                         ).map(([type, count]: [string, number]) => (
//                             <li key={type}>
//                                 {type.charAt(0).toUpperCase() + type.slice(1)} Flows: {count}
//                             </li>
//                         ))}
//                     </ul>
//                   </div>
//                   {missingItems.length > 0 && (
//                     <div className="mt-2 p-2 bg-amber-50 rounded border border-amber-200">
//                       <div className="flex items-center gap-1 text-amber-600 mb-1">
//                         <AlertCircle className="h-4 w-4" />
//                         <span className="text-xs font-medium">Missing Coverage</span>
//                       </div>
//                       <ul className="space-y-1">
//                         {missingItems.map((item, index) => (
//                           <li key={index} className="flex items-start gap-2 text-xs text-amber-700">
//                             <span>•</span>
//                             <span>{item.description}</span>
//                           </li>
//                         ))}
//                       </ul>
//                     </div>
//                   )}
//                 </div>
//               </div>
//             );
//           })}
//         </div>
//       </div>
//     </div>
//   );
// };

import { cn } from "@/lib/utils";
import { type TestScenario } from "./types";
import { AlertCircle, CheckCircle, PieChart } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useEffect, useState } from "react";
import axios from "axios";
import { API_ENDPOINTS } from "@/config/api";

interface RequirementsCoverageProps {
  scenarios: TestScenario[];
  selectedScenario: string | null;
  onRequirementClick: (id: string) => void;
}

interface MissingCoverage {
  type: string;
  description: string;
}

export const RequirementsCoverage = ({
  scenarios,
  selectedScenario,
  onRequirementClick,
}: RequirementsCoverageProps) => {
  const [apiRequirementId, setApiRequirementId] = useState<string | null>(null);
  // Add a map to cache requirement IDs to avoid repeated API calls
  const [requirementIdMap, setRequirementIdMap] = useState<Record<string, string>>({});

  useEffect(() => {
    if (selectedScenario) {
      // console.log('RequirementsCoverage: Selected scenario ID:', selectedScenario);
      
      const fullScenario = scenarios.find(s => s.id === selectedScenario);
      // console.log('Full scenario object found:', fullScenario);
      
      // Check if the scenario has a scenario_id (database ID) 
      if (fullScenario?.scenario_id) {
        // Make API call to get the requirement ID
        const fetchRequirementId = async () => {
          try {
            const response = await axios.get(
              `${API_ENDPOINTS.getRequirementByScenario}/${fullScenario.scenario_id}`
            );
            
            // Log the requirement ID from the API response
            // console.log('API Requirement ID:', response.data.requirement_id);
            
            // Store the API requirement ID
            setApiRequirementId(response.data.requirement_id);
            
            // Cache this mapping for future use
            setRequirementIdMap(prev => ({
              ...prev,
              [fullScenario.requirementId]: response.data.requirement_id
            }));
            
            // You can compare this with the local requirementId
            // console.log('Local Requirement ID:', fullScenario.requirementId);
            
            // If they differ, you might want to use the API's requirement ID instead
            if (response.data.requirement_id !== fullScenario.requirementId) {
              // console.log('Requirement IDs differ between API and local data');
            }
          } catch (error) {
            console.error('Error fetching requirement ID for scenario:', error);
          }
        };
        
        fetchRequirementId();
      } else {
        // console.log('No database scenario_id available for API lookup');
        // console.log('Using local requirementId:', fullScenario?.requirementId);
        setApiRequirementId(null);
      }
    } else {
      setApiRequirementId(null);
    }
  }, [selectedScenario, scenarios]);
  
  // Preload all requirements' API IDs when component mounts or scenarios change
  useEffect(() => {
    // Extract unique requirement IDs
    const uniqueRequirementIds = new Set(scenarios.map(s => s.requirementId));
    // console.log('Unique requirement IDs:', Array.from(uniqueRequirementIds));
    
    // For each unique requirement, find a scenario with scenario_id and fetch its requirement ID
    uniqueRequirementIds.forEach(reqId => {
      // Skip if we already have this mapping
      if (requirementIdMap[reqId]) return;
      
      // Find a scenario with this requirement ID that has a scenario_id
      const scenarioWithId = scenarios.find(s => 
        s.requirementId === reqId && s.scenario_id
      );
      
      if (scenarioWithId?.scenario_id) {
        const fetchRequirementId = async () => {
          try {
            const response = await axios.get(
              `${API_ENDPOINTS.getRequirementByScenario}/${scenarioWithId.scenario_id}`
            );
            
            // Cache the mapping
            setRequirementIdMap(prev => ({
              ...prev,
              [reqId]: response.data.requirement_id
            }));
            
            // console.log(`Cached mapping for ${reqId}: ${response.data.requirement_id}`);
          } catch (error) {
            console.error(`Error fetching requirement ID for scenario with requirement ${reqId}:`, error);
          }
        };
        
        fetchRequirementId();
      }
    });
  }, [scenarios]);

  const calculateCoverage = (relatedScenarios: TestScenario[]) => {
    const totalFlows = relatedScenarios.reduce((acc, scenario) => acc + scenario.flows.length, 0);
    const totalSubflows = relatedScenarios.reduce((acc, scenario) => 
      acc + scenario.flows.reduce((flowAcc, flow) => flowAcc + flow.subflows.length, 0), 0);
    
    const coverage = Math.min(100, Math.round((totalFlows * 20 + totalSubflows * 10) / 3));
    return coverage;
  };

  const getMissingCoverageItems = (coverage: number): MissingCoverage[] => {
    if (coverage === 100) return [];
    
    const missingItems: MissingCoverage[] = [];
    if (coverage < 100) {
      missingItems.push({
        type: "flow",
        description: "Add error handling flows for invalid inputs"
      });
    }
    if (coverage < 80) {
      missingItems.push({
        type: "validation",
        description: "Add validation scenarios for boundary conditions"
      });
    }
    if (coverage < 60) {
      missingItems.push({
        type: "edge_case",
        description: "Consider edge cases for concurrent user actions"
      });
    }
    return missingItems;
  };

  const groupedScenarios = scenarios.reduce((acc: { [key: string]: TestScenario[] }, scenario) => {
    if (!acc[scenario.requirementId]) {
      acc[scenario.requirementId] = [];
    }
    acc[scenario.requirementId].push(scenario);
    return acc;
  }, {});

  const selectedRequirement = selectedScenario 
    ? Object.entries(groupedScenarios).find(([_, scenarios]) => 
        scenarios.some(s => s.id === selectedScenario))?.[0]
    : null;

  const requirementsToShow = selectedRequirement 
    ? [[selectedRequirement, groupedScenarios[selectedRequirement]]] as [string, TestScenario[]][]
    : Object.entries(groupedScenarios) as [string, TestScenario[]][];

  // Handle requirement click - use API ID if available
  const handleRequirementClick = (requirementId: string) => {
    // If we have an API requirement ID for the selected scenario, use that
    if (apiRequirementId && selectedRequirement === requirementId) {
      // console.log('Using API requirement ID from selected scenario:', apiRequirementId);
      onRequirementClick(apiRequirementId);
    } 
    // If we have this requirement ID mapped in our cache, use that
    else if (requirementIdMap[requirementId]) {
      // console.log('Using cached API requirement ID:', requirementIdMap[requirementId]);
      onRequirementClick(requirementIdMap[requirementId]);
    }
    // Otherwise try to find a scenario with this requirement ID that has scenario_id
    else {
      // Look for a scenario with this requirement ID that has a database ID
      const scenarioWithId = scenarios.find(s => 
        s.requirementId === requirementId && s.scenario_id
      );
      
      if (scenarioWithId?.scenario_id) {
        // console.log('Found scenario with ID for requirement', requirementId);
        
        // Make API call to get the requirement ID
        const fetchAndUseRequirementId = async () => {
          try {
            const response = await axios.get(
              `${API_ENDPOINTS.getRequirementByScenario}/${scenarioWithId.scenario_id}`
            );
            
            const apiReqId = response.data.requirement_id;
            // console.log('Fetched API requirement ID on demand:', apiReqId);
            
            // Cache this mapping for future use
            setRequirementIdMap(prev => ({
              ...prev,
              [requirementId]: apiReqId
            }));
            
            // Use the API ID
            onRequirementClick(apiReqId);
          } catch (error) {
            console.error('Error fetching requirement ID on demand:', error);
            // Fallback to local ID
            // console.log('Falling back to local requirement ID:', requirementId);
            onRequirementClick(requirementId);
          }
        };
        
        fetchAndUseRequirementId();
        return; // Return early to prevent the fallback below from executing
      }
      
      // Fallback to the local requirement ID if we can't get a mapping
      // console.log('No API mapping available, using local requirement ID:', requirementId);
      onRequirementClick(requirementId);
    }
  };

  return (
    <div className="h-full p-4 overflow-hidden">
      <div className="prose prose-sm max-w-none h-[70vh] overflow-auto pr-2">
        <div className="space-y-4">
          {requirementsToShow.map(([requirementId, relatedScenarios]) => {
            const coverage = calculateCoverage(relatedScenarios);
            const missingItems = getMissingCoverageItems(coverage);
            
            return (
              <div
                key={requirementId}
                className={cn(
                  "p-3 border rounded transition-colors cursor-pointer w-full",
                  selectedScenario && relatedScenarios.some(s => s.id === selectedScenario)
                    ? "bg-primary/10 border-primary" 
                    : "hover:bg-gray-50"
                )}
                onClick={() => handleRequirementClick(requirementId)}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="font-medium">{requirementId}</div>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger>
                        {/* <div className="flex items-center gap-2">
                          <PieChart className={cn(
                            "h-4 w-4",
                            coverage === 100 ? "text-green-500" : "text-amber-500"
                          )} />
                          <span className="text-sm font-semibold text-gray-700">{coverage}%</span>
                        </div> */}
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Requirement Coverage</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <div className="text-sm text-gray-600">
                  <div className="flex justify-between items-center mb-1">
                    <span>Scenarios:</span>
                    <span className="font-medium">{relatedScenarios.length}</span>
                  </div>
                  <div>
                    Flow Coverage:
                    <ul className="mt-1 ml-4 list-disc text-xs">
                        {Object.entries(
                            relatedScenarios.reduce((acc: any[], s) => acc.concat(s.flows), [])
                                .reduce((acc: { [key: string]: number }, flow) => {
                                    acc[flow.type] = (acc[flow.type] || 0) + flow.subflows.length;
                                    return acc;
                                }, {})
                        ).map(([type, count]: [string, number]) => (
                            <li key={type}>
                                {type.charAt(0).toUpperCase() + type.slice(1)} Flows: {count}
                            </li>
                        ))}
                    </ul>
                  </div>
                  {missingItems.length > 0 && (
                    <div className="mt-2 p-2 bg-amber-50 rounded border border-amber-200">
                      <div className="flex items-center gap-1 text-amber-600 mb-1">
                        <AlertCircle className="h-4 w-4" />
                        <span className="text-xs font-medium">Missing Coverage</span>
                      </div>
                      <ul className="space-y-1">
                        {missingItems.map((item, index) => (
                          <li key={index} className="flex items-start gap-2 text-xs text-amber-700">
                            <span>•</span>
                            <span>{item.description}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};