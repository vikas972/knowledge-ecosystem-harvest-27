import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { getRequirementDetails } from "../requirementUtils";
import { useEffect, useState } from "react";
import axios from "axios";
import { API_ENDPOINTS } from "@/config/api";
import { Loader2 } from "lucide-react";

interface RequirementDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedRequirement: string | null;
  hideDialog?: boolean;
}

// API requirement interface
interface ApiRequirement {
  requirementId: string;
  requirementName: string;
  isCompleted: boolean;
  isScenarioGenerated: boolean;
  errorMessage: string | null;
  requirementJson: any;
  fileId: string;
  is_deleted: boolean;
}

export const RequirementDialog = ({
  open,
  onOpenChange,
  selectedRequirement,
  hideDialog = false
}: RequirementDialogProps) => {
  const [loading, setLoading] = useState(false);
  const [apiRequirement, setApiRequirement] = useState<ApiRequirement | null>(null);
  
  useEffect(() => {
    if (!selectedRequirement || !open) return;
    
    const fetchRequirementDetails = async () => {
      setLoading(true);
      try {
        // console.log(`Fetching requirement details for: ${selectedRequirement}`);
        const response = await axios.get(
          `${API_ENDPOINTS.getRequirementById}/${selectedRequirement}`
        );
        // console.log('API Requirement details:', response.data);
        setApiRequirement(response.data);
      } catch (error) {
        console.error('Error fetching requirement details:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchRequirementDetails();
  }, [selectedRequirement, open]);
  
  if (!selectedRequirement) return null;
  
  // Fallback to mock data if API fetch fails
  const mockRequirement = getRequirementDetails(selectedRequirement);
  
  // Loading UI
  if (loading) {
    const loadingContent = (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2">Loading requirement details...</span>
      </div>
    );
    
    if (hideDialog) return loadingContent;
    
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Requirement Details</DialogTitle>
          </DialogHeader>
          <div className="max-h-[70vh] overflow-y-auto">
            {loadingContent}
          </div>
        </DialogContent>
      </Dialog>
    );
  }
  
  // Render API requirement content if available
  const renderApiContent = () => {
    if (!apiRequirement) return null;
    
    const userJourneys = apiRequirement.requirementJson?.user_journeys || [];
    const firstJourney = userJourneys[0] || {};
    const reqs = firstJourney.requirements || {};
    
    // Helper function to render array items with hyphens
    const renderArrayItems = (items: any[]) => {
      return (
        <ul className="space-y-3">
          {items.map((item, index) => {
            // If item is a string, render it directly
            if (typeof item === 'string') {
              return (
                <li key={index} className="text-sm text-gray-600 pl-4 relative">
                  <span className="absolute left-0">-</span>
                  <div className="pl-2">{item}</div>
                </li>
              );
            }
            // If item is an object, render its properties
            else if (typeof item === 'object' && item !== null) {
              return (
                <li key={index} className="text-sm text-gray-600 pl-4 relative">
                  <span className="absolute left-0">-</span>
                  <div className="pl-2">
                    {Object.entries(item)
                      .filter(([key, value]) => key !== 'id' && value !== null && value !== undefined)
                      .map(([key, value], i) => (
                        <div key={i} className="mb-1">
                          <span className="font-medium">{key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}:</span>{' '}
                          {typeof value === 'object' ? JSON.stringify(value) : String(value)}
                        </div>
                      ))}
                  </div>
                </li>
              );
            }
            return null;
          }).filter(Boolean)}
        </ul>
      );
    };
    
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-start">
          <h3 className="text-lg font-semibold">
            {apiRequirement.requirementName || selectedRequirement}
          </h3>
          <div className="text-sm text-muted-foreground">
            Status: {apiRequirement.isCompleted ? 'Completed' : 'In Progress'}
          </div>
        </div>

        <div className="space-y-6">
          {/* Description */}
          <div>
            <h4 className="font-medium mb-2">Description</h4>
            <p className="text-sm text-gray-600">
              {firstJourney.description || "No description available"}
            </p>
          </div>

          {/* User Stories */}
          {firstJourney.user_stories && firstJourney.user_stories.length > 0 && (
            <div>
              <h4 className="font-medium mb-2">User Stories</h4>
              {renderArrayItems(firstJourney.user_stories)}
            </div>
          )}

          {/* Functional Requirements */}
          {reqs.functional_requirements && reqs.functional_requirements.length > 0 && (
            <div>
              <h4 className="font-medium mb-2">Functional Requirements</h4>
              {renderArrayItems(reqs.functional_requirements)}
            </div>
          )}

          {/* Business Rules */}
          {reqs.business_rules && reqs.business_rules.length > 0 && (
            <div>
              <h4 className="font-medium mb-2">Business Rules</h4>
              {renderArrayItems(reqs.business_rules)}
            </div>
          )}

          {/* Data Elements */}
          {reqs.data_elements && reqs.data_elements.length > 0 && (
            <div>
              <h4 className="font-medium mb-2">Data Elements</h4>
              {renderArrayItems(reqs.data_elements)}
            </div>
          )}
          
          {/* Render any additional sections dynamically */}
          {Object.entries(reqs).map(([key, value]) => {
            // Skip already rendered sections
            if (['functional_requirements', 'business_rules', 'data_elements'].includes(key)) {
              return null;
            }
            
            // Format the key for display
            const formattedKey = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
            
            // Handle arrays of strings
            if (Array.isArray(value) && value.length > 0) {
              return (
                <div key={key}>
                  <h4 className="font-medium mb-2">{formattedKey}</h4>
                  {renderArrayItems(value)}
                </div>
              );
            }
            
            // Handle nested objects
            if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
              return (
                <div key={key}>
                  <h4 className="font-medium mb-2">{formattedKey}</h4>
                  <div className="space-y-2">
                    {Object.entries(value).map(([nestedKey, nestedValue]) => {
                      const formattedNestedKey = nestedKey.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
                      
                      if (Array.isArray(nestedValue)) {
                        return (
                          <div key={nestedKey}>
                            <h5 className="text-sm font-medium">{formattedNestedKey}</h5>
                            {renderArrayItems(nestedValue)}
                          </div>
                        );
                      }
                      
                      return (
                        <div key={nestedKey} className="text-sm text-gray-600">
                          <span className="font-medium">{formattedNestedKey}:</span> {nestedValue}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            }
            
            return null;
          }).filter(Boolean)}
        </div>
      </div>
    );
  };
  
  // Use API content if available, otherwise use mock content
  const content = apiRequirement ? renderApiContent() : (
    <div className="space-y-4">
      <div className="flex justify-between items-start">
        <h3 className="text-lg font-semibold">
          {selectedRequirement}
        </h3>
        <div className="text-sm text-muted-foreground">
          Confidence: {Math.round(mockRequirement.confidence * 100)}%
        </div>
      </div>

      <div className="space-y-6">
        {/* Functional Area */}
        <div>
          <h4 className="font-medium mb-2">Functional Area</h4>
          <p className="text-sm text-gray-600">
            {mockRequirement.functionalArea}
          </p>
        </div>

        {/* Description */}
        <div>
          <h4 className="font-medium mb-2">Description</h4>
          <p className="text-sm text-gray-600">
            {mockRequirement.description}
          </p>
        </div>

        {/* Actors */}
        <div>
          <h4 className="font-medium mb-2">Actors</h4>
          <div className="flex gap-2">
            {mockRequirement.actors.map((actor, index) => (
              <span key={index} className="px-2 py-1 bg-gray-100 rounded text-sm">
                {actor}
              </span>
            ))}
          </div>
        </div>

        {/* User Stories */}
        {mockRequirement.userStories && mockRequirement.userStories.length > 0 && (
          <div>
            <h4 className="font-medium mb-2">User Stories</h4>
            <ul className="space-y-2">
              {mockRequirement.userStories.map((story, index) => (
                <li key={index} className="text-sm text-gray-600">
                  {story}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Business Requirements */}
        <div>
          <h4 className="font-medium mb-2">Business Requirements</h4>
          <ul className="space-y-2">
            {mockRequirement.businessRequirements.map((req) => (
              <li key={req.id} className="text-sm text-gray-600">
                {req.description}
              </li>
            ))}
          </ul>
        </div>

        {/* Business Rules */}
        <div>
          <h4 className="font-medium mb-2">Business Rules</h4>
          <ul className="space-y-2">
            {mockRequirement.businessRules.map((rule) => (
              <li key={rule.id} className="text-sm">
                <span className="text-gray-600">{rule.description}</span>
                <span className="ml-2 px-2 py-0.5 bg-gray-100 rounded text-xs">
                  {rule.category}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* Data Elements */}
        <div>
          <h4 className="font-medium mb-2">Data Elements</h4>
          <div className="space-y-3">
            {mockRequirement.dataElements.map((element) => (
              <div key={element.id} className="p-3 border rounded">
                <div className="flex justify-between mb-1">
                  <span className="font-medium">{element.name}</span>
                  <span className="text-sm text-gray-500">{element.type}</span>
                </div>
                <div className="text-sm text-gray-600">
                  {element.specifications.map((spec, index) => (
                    <div key={index}>{spec}</div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  if (hideDialog) {
    return content;
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>Requirement Details</DialogTitle>
        </DialogHeader>
        <div className="max-h-[70vh] overflow-y-auto">
          {content}
        </div>
      </DialogContent>
    </Dialog>
  );
};
