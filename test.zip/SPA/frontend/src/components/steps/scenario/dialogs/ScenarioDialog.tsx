import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { TestScenario } from "../types";
import { useEffect } from "react";

interface ScenarioDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedScenario: string | null;
  scenarios: TestScenario[];
  hideDialog?: boolean; // Optional prop for compatibility with RequirementDialog
}

export const ScenarioDialog = ({
  open,
  onOpenChange,
  selectedScenario,
  scenarios = [],
  hideDialog = false
}: ScenarioDialogProps) => {
  // Add useEffect to log props when they change
  useEffect(() => {
    if (open && selectedScenario) {
      console.log('ScenarioDialog - Props:', { 
        selectedScenario, 
        open,
        scenariosCount: scenarios.length
      });
      
      // Find the scenario in the array and log it
      const scenario = scenarios.find(s => s.id === selectedScenario);
      console.log('ScenarioDialog - Found scenario:', scenario);
      
      if (!scenario) {
        console.warn('ScenarioDialog - No matching scenario found for ID:', selectedScenario);
      }
    }
  }, [open, selectedScenario, scenarios]);

  if (!selectedScenario) return null;
  
  // Find the scenario by ID
  const scenario = scenarios.find(s => s.id === selectedScenario);
  
  // When no matching scenario is found
  if (!scenario) {
    console.log('ScenarioDialog - Rendering not found state for scenario ID:', selectedScenario);
    
    if (hideDialog) {
      return (
        <div className="p-4">
          <p>Scenario ID: {selectedScenario}</p>
          <p className="text-sm text-gray-600 mt-2">
            Scenario details not found. The scenario may have been deleted or is not available.
          </p>
        </div>
      );
    }
    
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Test Scenario Details</DialogTitle>
          </DialogHeader>
          <div className="p-4">
            <p>Scenario ID: {selectedScenario}</p>
            <p className="text-sm text-gray-600 mt-2">
              Scenario details not found. The scenario may have been deleted or is not available.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  console.log('ScenarioDialog - Rendering scenario:', {
    title: scenario.title,
    description: scenario.description,
    requirementId: scenario.requirementId,
    flowsCount: scenario.flows.length
  });

  const content = (
    <div className="max-h-[70vh] overflow-y-auto">
      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-semibold mb-2">{scenario.title}</h3>
          <p className="text-sm text-gray-600 mb-4">{scenario.description}</p>
          
          <div className="flex items-center gap-2 mb-4">
            <Badge variant="outline">ID: {scenario.id}</Badge>
            <Badge variant="outline">Requirement: {scenario.requirementId}</Badge>
            <Badge variant="secondary">{scenario.status || 'in_progress'}</Badge>
            <Badge>{scenario.priority}</Badge>
          </div>
          
          <Accordion type="single" collapsible className="w-full">
            {scenario.flows.map((flow, index) => (
              <AccordionItem key={`${scenario.flows}-${index}`} value={`flow-${index}`}>
                <AccordionTrigger className="text-sm font-medium">
                  {flow.type.charAt(0).toUpperCase() + flow.type.slice(1)} Flow: {flow.description}
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-4 pl-4">
                    {flow.subflows.map((subflow, subIndex) => (
                      <div key={subIndex} className="border-l-2 border-gray-200 pl-4 py-2">
                        <h4 className="text-sm font-medium">{subflow.name}</h4>
                        <p className="text-sm text-gray-600 mt-1">Coverage: {subflow.coverage}</p>
                        <p className="text-sm text-gray-600 mt-1">Expected Results: {subflow.expectedResults}</p>
                        {subflow.entries && subflow.entries.length > 0 && (
                          <div className="mt-2">
                            <h5 className="text-xs font-medium">Entries:</h5>
                            <ul className="list-disc pl-5 text-xs text-gray-600">
                              {subflow.entries.map((entry, entryIndex) => (
                                <li key={entryIndex}>{entry.description}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </div>
  );

  if (hideDialog) {
    return content;
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>Test Scenario Details</DialogTitle>
        </DialogHeader>
        {content}
      </DialogContent>
    </Dialog>
  );
};