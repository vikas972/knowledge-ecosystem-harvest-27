import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, Maximize2, ChevronLeft, ChevronRight } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useState } from "react";
import { TestScenario } from "../types";
import * as XLSX from 'xlsx';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ScenarioGridDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  scenarios: TestScenario[];
  title?: string;
}

export const ScenarioGridDialog = ({ 
  open, 
  onOpenChange, 
  scenarios = [], 
  title = "Scenarios"
}: ScenarioGridDialogProps) => {
  const [isFullScreen, setIsFullScreen] = useState(false);
  
  // Add pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const totalPages = Math.ceil(scenarios.length / itemsPerPage);

  const toggleFullScreen = () => {
    setIsFullScreen(!isFullScreen);
  };

  const handleExport = () => {
    // Prepare data for export with all details
    const exportData = scenarios.map(scenario => {
      // Base scenario data
      const baseData = {
        ScenarioID: scenario.id,
        ScenarioName: scenario.title,
        Requirement: scenario.requirementId,
        // Priority: scenario.priority || 'medium',
        // Status: scenario.status || 'in_progress',
        Description: scenario.description
      };
      
      // Add flow information
      scenario.flows?.forEach((flow, flowIndex) => {
        baseData[`Flow ${flowIndex+1} Type`] = flow.type;
        baseData[`Flow ${flowIndex+1} Description`] = flow.description;
        
        // Add subflow information
        flow.subflows?.forEach((subflow, subflowIndex) => {
          baseData[`Flow ${flowIndex+1} Subflow ${subflowIndex+1} Name`] = subflow.name;
          baseData[`Flow ${flowIndex+1} Subflow ${subflowIndex+1} Coverage`] = subflow.coverage;
          baseData[`Flow ${flowIndex+1} Subflow ${subflowIndex+1} Expected Results`] = subflow.expectedResults;
        });
      });
      
      return baseData;
    });

    // Create worksheet
    const ws = XLSX.utils.json_to_sheet(exportData);

    // Create workbook
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Scenarios');

    // Generate Excel file
    XLSX.writeFile(wb, 'test_scenarios.xlsx');
  };

  const dialogClass = isFullScreen 
    ? "w-screen h-screen max-w-none rounded-none" 
    : "w-[95vw] h-[90vh] max-w-[1500px]";

  // Helper function to format flow information
  const formatFlowInfo = (flow) => {
    if (!flow) return "";
    return `${flow.type.charAt(0).toUpperCase() + flow.type.slice(1)}: ${flow.description}`;
  };

  // Helper function to format subflow information
  const formatSubflowInfo = (subflow) => {
    if (!subflow) return "";
    return (
      <div>
        <div><strong>Name:</strong> {subflow.name}</div>
        <div><strong>Coverage:</strong> {subflow.coverage}</div>
        <div><strong>Expected Results:</strong> {subflow.expectedResults}</div>
      </div>
    );
  };

  // Add pagination handlers
  const goToNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const goToPreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const goToPage = (pageNumber: number) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  const handleItemsPerPageChange = (value: string) => {
    setItemsPerPage(parseInt(value));
    setCurrentPage(1); // Reset to first page when changing items per page
  };

  // Get paginated scenarios
  const getPaginatedScenarios = () => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return scenarios.slice(startIndex, endIndex);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={dialogClass}>
        <DialogHeader className="flex flex-row items-center justify-between border-b pb-4 px-6">
          <div>
            <DialogTitle className="text-xl font-semibold text-gray-900">{title} Overview</DialogTitle>
            {/* <DialogDescription className="text-sm text-gray-500 mt-1">
              View and export your scenarios in a grid format
            </DialogDescription> */}
          </div>
          <div className="flex items-center gap-3">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="outline" 
                    onClick={toggleFullScreen} 
                    className="h-9 w-9 p-0 border-gray-200 hover:bg-gray-100 transition-colors"
                  >
                    <Maximize2 className="h-4 w-4 text-gray-600" />
                  </Button>
                </TooltipTrigger>
                {/* <TooltipContent>
                  <p>Toggle fullscreen</p>
                </TooltipContent> */}
              </Tooltip>
            </TooltipProvider>

            <Button 
              onClick={handleExport} 
              className="bg-blue-600 hover:bg-blue-700 text-white h-9 px-4 shadow-sm transition-colors flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              <span className="font-medium">Export to Excel</span>
            </Button>
          </div>
        </DialogHeader>
        <ScrollArea className="h-[calc(100%-80px)]">
          <div className="p-4">
            <div className="overflow-x-auto rounded-md border border-gray-200 shadow-sm">
              <Table className="compact-table">
                <TableHeader className="bg-gray-50 sticky top-0 z-10">
                  <TableRow className="border-b-2 border-gray-200">
                    <TableHead className="sticky-left z-20 bg-gray-50 w-[100px] whitespace-nowrap px-2 py-2 text-xs font-semibold text-gray-700 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.1)]">ScenarioID</TableHead>
                    <TableHead className="w-[180px] whitespace-nowrap px-2 py-2 text-xs font-semibold text-gray-700">ScenarioName</TableHead>
                    <TableHead className="w-[150px] whitespace-nowrap px-2 py-2 text-xs font-semibold text-gray-700">Requirement</TableHead>
                    <TableHead className="min-w-[250px] px-2 py-2 text-xs font-semibold text-gray-700">Description</TableHead>
                    <TableHead className="min-w-[350px] px-2 py-2 text-xs font-semibold text-gray-700">Primary Flows</TableHead>
                    <TableHead className="min-w-[350px] px-2 py-2 text-xs font-semibold text-gray-700">Alternative Flows</TableHead>
                    <TableHead className="min-w-[350px] px-2 py-2 text-xs font-semibold text-gray-700">Negative Flows</TableHead>
                    <TableHead className="min-w-[350px] px-2 py-2 text-xs font-semibold text-gray-700">Exception Flows</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {getPaginatedScenarios().map((scenario, index) => {
                    // Extract flow information by type
                    const primaryFlows = scenario.flows?.filter(f => f.type === 'primary') || [];
                    const alternativeFlows = scenario.flows?.filter(f => f.type === 'alternate') || [];
                    const negativeFlows = scenario.flows?.filter(f => f.type === 'negative') || [];
                    const exceptionFlows = scenario.flows?.filter(f => f.type === 'exception') || [];
                    
                    return (
                      <TableRow 
                        key={`${scenario.id}-${index}`}
                        className={`
                          border-b border-gray-200
                          ${index % 2 === 0 ? "bg-white" : "bg-gray-50"}
                          hover:bg-blue-50 transition-colors text-xs
                        `}
                      >
                        <TableCell className="sticky-left z-10 bg-inherit whitespace-nowrap font-medium px-2 py-1.5 border-r border-gray-200 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.1)]">
                          {scenario.id || <span className="text-gray-500 italic text-xs">None</span>}
                        </TableCell>
                        <TableCell className="whitespace-nowrap px-2 py-1.5 border-r border-gray-200">
                          {scenario.title || <span className="text-gray-500 italic text-xs">None</span>}
                        </TableCell>
                        <TableCell className="whitespace-nowrap px-2 py-1.5 border-r border-gray-200">
                          {scenario.requirementId || <span className="text-gray-500 italic text-xs">None</span>}
                        </TableCell>
                        <TableCell className="px-2 py-1.5 border-r border-gray-200 text-xs leading-tight">
                          {scenario.description || <span className="text-gray-500 italic text-xs">None</span>}
                        </TableCell>
                        <TableCell className="px-2 py-1.5 border-r border-gray-200">
                          {primaryFlows.length > 0 ? (
                            primaryFlows.map((flow, i) => (
                              <div key={i} className="mb-1.5 pb-1.5 border-b border-dashed border-gray-200 last:border-b-0">
                                <div className="font-medium text-xs text-gray-800 mb-1">{formatFlowInfo(flow)}</div>
                                {flow.subflows?.map((subflow, j) => (
                                  <div key={j} className="ml-2 mt-1 text-xs text-gray-600 leading-tight">
                                    {formatSubflowInfo(subflow)}
                                  </div>
                                ))}
                              </div>
                            ))
                          ) : <span className="text-gray-500 italic text-xs">None</span>}
                        </TableCell>
                        <TableCell className="px-2 py-1.5 border-r border-gray-200">
                          {alternativeFlows.length > 0 ? (
                            alternativeFlows.map((flow, i) => (
                              <div key={i} className="mb-1.5 pb-1.5 border-b border-dashed border-gray-200 last:border-b-0">
                                <div className="font-medium text-xs text-gray-800 mb-1">{formatFlowInfo(flow)}</div>
                                {flow.subflows?.map((subflow, j) => (
                                  <div key={j} className="ml-2 mt-1 text-xs text-gray-600 leading-tight">
                                    {formatSubflowInfo(subflow)}
                                  </div>
                                ))}
                              </div>
                            ))
                          ) : <span className="text-gray-500 italic text-xs">None</span>}
                        </TableCell>
                        <TableCell className="px-2 py-1.5 border-r border-gray-200">
                          {negativeFlows.length > 0 ? (
                            negativeFlows.map((flow, i) => (
                              <div key={i} className="mb-1.5 pb-1.5 border-b border-dashed border-gray-200 last:border-b-0">
                                <div className="font-medium text-xs text-gray-800 mb-1">{formatFlowInfo(flow)}</div>
                                {flow.subflows?.map((subflow, j) => (
                                  <div key={j} className="ml-2 mt-1 text-xs text-gray-600 leading-tight">
                                    {formatSubflowInfo(subflow)}
                                  </div>
                                ))}
                              </div>
                            ))
                          ) : <span className="text-gray-500 italic text-xs">None</span>}
                        </TableCell>
                        <TableCell className="px-2 py-1.5">
                          {exceptionFlows.length > 0 ? (
                            exceptionFlows.map((flow, i) => (
                              <div key={i} className="mb-1.5 pb-1.5 border-b border-dashed border-gray-200 last:border-b-0">
                                <div className="font-medium text-xs text-gray-800 mb-1">{formatFlowInfo(flow)}</div>
                                {flow.subflows?.map((subflow, j) => (
                                  <div key={j} className="ml-2 mt-1 text-xs text-gray-600 leading-tight">
                                    {formatSubflowInfo(subflow)}
                                  </div>
                                ))}
                              </div>
                            ))
                          ) : <span className="text-gray-500 italic text-xs">None</span>}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              {(!scenarios || scenarios.length === 0) && (
                <div className="text-center py-6 text-gray-500 bg-gray-50">
                  <p className="text-base">No scenarios available</p>
                  <p className="text-xs mt-1">Scenarios will appear here once they are added to the project.</p>
                </div>
              )}
            </div>
          </div>
        </ScrollArea>
        
        {/* Add Pagination Controls */}
        {scenarios.length > 0 && (
          <div className="flex justify-between items-center border-t py-1 px-4 bg-gray-50">
            <div className="flex items-center gap-2 text-xs text-gray-600">
              <Select 
                value={itemsPerPage.toString()} 
                onValueChange={handleItemsPerPageChange}
              >
                <SelectTrigger className="h-7 w-16 text-xs">
                  <SelectValue placeholder="10" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">5</SelectItem>
                  <SelectItem value="10">10</SelectItem>
                  <SelectItem value="20">20</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                </SelectContent>
              </Select>
              <span>per page</span>
              <span className="ml-2">
                {`${(currentPage - 1) * itemsPerPage + 1}-${Math.min(currentPage * itemsPerPage, scenarios.length)} of ${scenarios.length}`}
              </span>
            </div>
            
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="icon"
                onClick={goToPreviousPage}
                disabled={currentPage === 1}
                className="h-7 w-7"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              
              <div className="flex items-center">
                <input
                  type="number"
                  min="1"
                  max={totalPages}
                  value={currentPage}
                  onChange={(e) => {
                    const page = parseInt(e.target.value);
                    if (page >= 1 && page <= totalPages) {
                      setCurrentPage(page);
                    }
                  }}
                  className="h-7 w-12 px-2 border rounded text-xs text-center"
                />
                <span className="text-xs text-gray-600 mx-1">of {totalPages}</span>
              </div>

              <Button
                variant="outline"
                size="icon"
                onClick={goToNextPage}
                disabled={currentPage === totalPages}
                className="h-7 w-7"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
