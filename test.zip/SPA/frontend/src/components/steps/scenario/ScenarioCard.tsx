import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Card } from "@/components/ui/card";
import { ScenarioFlows } from "./ScenarioFlows";
import { CheckCircle, XCircle, AlertCircle, PlusCircle, Pencil, Trash2, Save, X, ChevronDown, ChevronUp } from "lucide-react";
import { cn } from "@/lib/utils";
import { type TestScenario, type Priority, type ScenarioStatus } from "./types";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import axios from "axios";
import { toast } from "sonner";
import { ENV } from "@/config/env";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface ScenarioCardProps {
  scenario: TestScenario;
  isSelected: boolean;
  isExpanded: boolean;
  onScenarioClick: (id: string) => void;
  onRequirementClick: (requirementId: string) => void;
  onEdit: (e: React.MouseEvent, id: string) => void;
  onDelete: (e: React.MouseEvent | null, id: string) => void;
  onUpdateScenario: (updatedScenario: TestScenario) => void;
  isChecked: boolean;
  onToggleSelect: (id: string, checked: boolean) => void;
}

export const ScenarioCard = ({
  scenario,
  isSelected,
  isExpanded,
  onScenarioClick,
  onRequirementClick,
  onEdit,
  onDelete,
  onUpdateScenario,
  isChecked,
  onToggleSelect,
}: ScenarioCardProps) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState(scenario.title);
  const [editedDescription, setEditedDescription] = useState(scenario.description);
  const [editedPriority, setEditedPriority] = useState<Priority>(scenario.priority);
  const [editedStatus, setEditedStatus] = useState<ScenarioStatus>(scenario.status || "in_progress");
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  const [suggestions] = useState([
    {
      id: 1,
      description: "Add validation for empty input fields",
      type: "validation"
    },
    {
      id: 2,
      description: "Include error handling for network timeout",
      type: "error_handling"
    }
  ]);

  const [acceptedSuggestions, setAcceptedSuggestions] = useState<number[]>([]);
  const [rejectedSuggestions, setRejectedSuggestions] = useState<number[]>([]);

  const handleAcceptSuggestion = (suggestionId: number) => {
    setAcceptedSuggestions(prev => [...prev, suggestionId]);
  };

  const handleRejectSuggestion = (suggestionId: number) => {
    setRejectedSuggestions(prev => [...prev, suggestionId]);
  };

  const handleUpdateFlows = (newFlows: TestScenario["flows"]) => {
    onUpdateScenario({
      ...scenario,
      flows: newFlows,
    });
  };

  const handleEditClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsEditing(true);
  };

  const handleSaveEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    onUpdateScenario({
      ...scenario,
      title: editedTitle,
      description: editedDescription,
      priority: editedPriority,
      status: editedStatus,
    });
    setIsEditing(false);
  };

  const handleCancelEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditedTitle(scenario.title);
    setEditedDescription(scenario.description);
    setEditedPriority(scenario.priority);
    setEditedStatus(scenario.status || "in_progress");
    setIsEditing(false);
  };

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsDeleteDialogOpen(true);
  };

  const handleConfirmDelete = async () => {
    setIsDeleteDialogOpen(false);
    try {
      const response = await axios.post(
        `${ENV.API_URL}/scenario-management/delete-by-scenarioid/${scenario.scenario_id}`
      );

      // Log the response data
      console.log("Scenario deleted successfully:", response.data);
      
      toast.success(response.data.message || "Scenario successfully deleted");
      
      // Don't pass a fake event object, pass null as the first parameter
      onDelete(null as any, scenario.id);
    } catch (error) {
      console.error("Error deleting scenario:", error);
      toast.error("Failed to delete scenario. Please try again.");
    }
  };

  const handleCancelDelete = () => {
    setIsDeleteDialogOpen(false);
  };

  return (
    <>
      <Card
        className={cn(
          "transition-all",
          isSelected && "ring-2 ring-primary",
          isExpanded && "mb-4"
        )}
      >
        <div
          className="p-4 cursor-pointer hover:bg-gray-50"
          // onClick={() => !isEditing && onScenarioClick(scenario.id)}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4 flex-1">
              <Checkbox
                checked={isChecked}
                onCheckedChange={(checked) => onToggleSelect(scenario.id, checked as boolean)}
                onClick={(e) => e.stopPropagation()}
              />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="font-medium">{scenario.id}</span>
                  <Badge
                    variant="outline"
                    className="cursor-pointer hover:bg-primary/5"
                    // onClick={(e) => {
                    //   e.stopPropagation();
                    //   onRequirementClick(scenario.requirementId);
                    // }}
                  >
                    {scenario.requirementId}
                  </Badge>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    {isEditing ? (
                      <div className="flex items-center gap-4" onClick={(e) => e.stopPropagation()}>
                        <Input
                          value={editedTitle}
                          onChange={(e) => setEditedTitle(e.target.value)}
                          className="text-sm w-48"
                          placeholder="Title"
                        />
                        <Select value={editedStatus} onValueChange={(value: ScenarioStatus) => setEditedStatus(value)}>
                          <SelectTrigger className="h-8 w-32" onClick={(e) => e.stopPropagation()}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="completed">Completed</SelectItem>
                            <SelectItem value="needs_review">Needs Review</SelectItem>
                            <SelectItem value="in_progress">In Progress</SelectItem>
                          </SelectContent>
                        </Select>
                        <Select value={editedPriority} onValueChange={(value: Priority) => setEditedPriority(value)}>
                          <SelectTrigger className="h-8 w-28">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="high">High</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="low">Low</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    ) : (
                      <div className="flex items-center gap-4">
                        <span className="text-sm text-gray-600">{scenario.title}</span>
                        <Badge variant="secondary" className="w-32 justify-center">{scenario.status || 'in_progress'}</Badge>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2 ml-4">
                    {isEditing ? (
                      <>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={handleSaveEdit}
                        >
                          <Save className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={handleCancelEdit}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          disabled={true}
                          onClick={handleEditClick}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          // disabled={true}
                          onClick={handleDeleteClick}
                        >
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            onScenarioClick(scenario.id);
                          }}
                        >
                          {isExpanded ? (
                            <ChevronUp className="h-4 w-4" />
                          ) : (
                            <ChevronDown className="h-4 w-4" />
                          )}
                        </Button>
                      </>
                    )}
                  </div>
                </div>

                <div className="mt-2">
                  {isEditing ? (
                    <div onClick={(e) => e.stopPropagation()}>
                      <Textarea
                        value={editedDescription}
                        onChange={(e) => setEditedDescription(e.target.value)}
                        className="text-sm min-h-[60px]"
                        placeholder="Description"
                      />
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500">{scenario.description}</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          {isExpanded && !isEditing && (
            <>
              <ScenarioFlows
                flows={scenario.flows}
                onUpdateFlows={handleUpdateFlows}
              />
            </>
          )}
        </div>
      </Card>

      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription asChild>
              <div>
                <div className="mt-2 text-gray-600">
                  Deleting this test scenario will permanently remove it and all related information.
                </div>
                <div className="mt-2 text-gray-600">
                  This action cannot be undone. All test cases and execution results associated with this scenario will also be removed.
                </div>
                <div className="mt-4 font-medium text-red-600">
                  Are you sure you want to delete this scenario?
                </div>
              </div>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={handleCancelDelete}>Cancel</Button>
            <Button variant="destructive" onClick={handleConfirmDelete}>Delete Scenario</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};
