import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Grid, Plus, Trash2, CheckSquare } from "lucide-react";
import { useState } from "react";
import axios from "axios";
import { ENV } from "@/config/env";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { type ScenarioStatus } from "../types";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface ScenarioHeaderProps {
  selectedScenariosCount: number;
  totalScenariosCount: number;
  onSelectAll: (checked: boolean) => void;
  onAddScenario: () => void;
  onBulkStatusChange: (status: ScenarioStatus) => void;
  onBulkDelete: () => void;
  onShowGrid: () => void;
  selectedScenarios?: string[];
  scenarioIdMapping?: Record<string, string>; // Mapping from UI id to backend scenario_id
}

export const ScenarioHeader = ({
  selectedScenariosCount,
  totalScenariosCount,
  onSelectAll,
  onAddScenario,
  onBulkStatusChange,
  onBulkDelete,
  onShowGrid,
  selectedScenarios = [],
  scenarioIdMapping = {},
}: ScenarioHeaderProps) => {
  const [isBulkDeleteDialogOpen, setIsBulkDeleteDialogOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDeleteClick = () => {
    if (selectedScenariosCount === 0) {
      toast.error("Please select at least one scenario to delete");
      return;
    }
    setIsBulkDeleteDialogOpen(true);
  };

  const handleConfirmBulkDelete = async () => {
    setIsDeleting(true);
    
    try {
      let successCount = 0;
      let failureCount = 0;
      
      for (const scenarioId of selectedScenarios) {
        try {
          // Use the mapping to get the backend scenario_id, or fall back to the UI id
          const backendScenarioId = scenarioIdMapping[scenarioId] || scenarioId;
          
          await axios.post(
            `${ENV.API_URL}/scenario-management/delete-by-scenarioid/${backendScenarioId}`
          );
          successCount++;
        } catch (error) {
          console.error(`Error deleting scenario ${scenarioId}:`, error);
          failureCount++;
        }
      }
      
      setIsBulkDeleteDialogOpen(false);
      
      if (successCount > 0) {
        toast.success(`Successfully deleted ${successCount} scenario${successCount !== 1 ? 's' : ''}`);
        // Call the onBulkDelete function to update the UI
        onBulkDelete();
      }
      
      if (failureCount > 0) {
        toast.error(`Failed to delete ${failureCount} scenario${failureCount !== 1 ? 's' : ''}`);
      }
    } catch (error) {
      console.error("Error performing bulk delete:", error);
      toast.error("An error occurred during bulk deletion");
    } finally {
      setIsDeleting(false);
    }
  };

  const handleCancelBulkDelete = () => {
    setIsBulkDeleteDialogOpen(false);
  };

  return (
    // <div className="mb-4 border rounded-md overflow-hidden bg-white">
      // <div className="p-3 border-b flex items-center justify-between">
      //  <div className="mb-4 border rounded-md overflow-hidden bg-white"> 
      <div className="mb-1 overflow-hidden">
      {/* </div> <div className="p-3 border-b flex items-center justify-between"> */}
      <div className="p-2  flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Checkbox
            checked={selectedScenariosCount === totalScenariosCount && totalScenariosCount > 0}
            onCheckedChange={onSelectAll}
          />
          <span className="text-sm text-gray-500">
            Select All ({totalScenariosCount})
          </span>
        </div>
        
        <div className="flex items-center gap-2">
          <Button 
            className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
            size="sm"
            onClick={onShowGrid}
          >
            <Grid className="h-4 w-4 mr-2" />
            Grid
          </Button>
          <Button 
            className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
            size="sm"
            disabled={true}
            onClick={onAddScenario}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Test Scenario
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                className="bg-blue-500 hover:bg-blue-600 whitespace-nowrap"
                size="sm"
                disabled={true}
              >
                <CheckSquare className="h-4 w-4 mr-2" />
                Change Status
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onSelect={() => onBulkStatusChange("completed")}>
                Mark as Completed
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => onBulkStatusChange("needs_review")}>
                Mark as Needs Review
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => onBulkStatusChange("in_progress")}>
                Mark as In Progress
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button
            variant="destructive"
            size="sm"
            disabled={selectedScenariosCount === 0}
            onClick={onBulkDelete}
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Delete Selected
          </Button>
        </div>
      </div>

      {/* Bulk Delete Confirmation Dialog */}
      <Dialog open={isBulkDeleteDialogOpen} onOpenChange={setIsBulkDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Bulk Deletion</DialogTitle>
            <DialogDescription asChild>
              <div>
                <div className="mt-2 text-gray-600">
                  You are about to delete {selectedScenariosCount} test scenario{selectedScenariosCount !== 1 ? 's' : ''}.
                </div>
                <div className="mt-2 text-gray-600">
                  This action will permanently remove these scenarios and all related information.
                </div>
                <div className="mt-2 text-gray-600">
                  This will affect test cases, traceability, and coverage metrics that depend on these scenarios.
                </div>
                <div className="mt-4 font-medium text-red-600">
                  Are you sure you want to delete {selectedScenariosCount} test scenario{selectedScenariosCount !== 1 ? 's' : ''}?
                </div>
              </div>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={handleCancelBulkDelete} disabled={isDeleting}>Cancel</Button>
            <Button 
              variant="destructive" 
              onClick={handleConfirmBulkDelete}
              disabled={isDeleting}
            >
              {isDeleting ? "Deleting..." : "Delete Scenarios"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
