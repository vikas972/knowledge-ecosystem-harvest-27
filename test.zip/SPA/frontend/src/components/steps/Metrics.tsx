import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import axios from 'axios';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell
} from "recharts";
import { 
  Download, 
  FileDown, 
  ChartColumnIncreasing, 
  Layers,
  CircleCheckBig,
  GitBranch,
  Clock,
  Users,
  ChevronDown
} from "lucide-react";
import { UserAssociationInfo } from "../UserAssociationInfo";
import { BundleInfo } from "../BundleInfo";
import { API_ENDPOINTS } from "@/config/api";
import { Skeleton } from "@/components/ui/skeleton";
import { useNavigate } from "react-router-dom";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

export interface MetricsProps {
  selectedFile: { id: string; name: string; uploadTime: Date } | null;
  product: string;
  subProduct: string;
  domain: string;
  bundleName: string;
  usecaseId?: string | number;
}

interface MetricsData {
  total_requirements: number;
  total_scenarios: number;
  total_test_cases: number;
}

export const Metrics = ({ selectedFile, product, subProduct, domain, bundleName, usecaseId }: MetricsProps) => {
  const [metricsData, setMetricsData] = useState<MetricsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [confirmUpload, setConfirmUpload] = useState(false);
  const [exportAutomation, setExportAutomation] = useState(false);
  const [showModuleCoverage, setShowModuleCoverage] = useState(false);
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const navigate = useNavigate();
  
  useEffect(() => {
    const fetchMetrics = async () => {
      if (!usecaseId) {
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const response = await axios.get(`${API_ENDPOINTS.getMetricsByUsecase}/${usecaseId}`);
        
        if (response.data && response.data.metrics) {
          setMetricsData(response.data.metrics);
        } else {
          setError("Received invalid metrics data");
        }
      } catch (err) {
        console.error("Error fetching metrics:", err);
        setError("Failed to load metrics data");
      } finally {
        setLoading(false);
      }
    };

    fetchMetrics();
  }, [usecaseId]);

  // Chart data based on actual metrics
  const getChartData = () => {
    if (!metricsData) return [];
    
    return [
      { name: "Requirements", total: metricsData.total_requirements, 
        // covered: Math.floor(metricsData.total_requirements * 0.9) 
      },
      { name: "Scenarios", total: metricsData.total_scenarios, 
        // covered: Math.floor(metricsData.total_scenarios * 0.85) 
      },
      { name: "Test Cases", total: metricsData.total_test_cases, 
        // covered: Math.floor(metricsData.total_test_cases * 0.8) 
      }
    ];
  };

  const handleCompleteGeneration = () => {
    if (!confirmUpload) return;
    setIsConfirmDialogOpen(true);
  };
  
  const handleConfirmUpload = async () => {
    setIsUploading(true);
    
    try {
      // Here you would add the actual API call to upload to KB if needed
      // For example: await axios.post(API_ENDPOINTS.uploadToKB, { usecaseId });
      
      // Simulate a short delay for the upload process
      setTimeout(() => {
        setIsUploading(false);
        setIsConfirmDialogOpen(false);
        
        // Navigate to home page
        navigate('/');
      }, 1000);
    } catch (error) {
      console.error("Error uploading to knowledge base:", error);
      setIsUploading(false);
    }
  };

  return (
    <div className="flex flex-col flex-1 h-full overflow-hidden p-4">
      <UserAssociationInfo 
        product={product} 
        subProduct={subProduct} 
        domain={domain} 
      />
      <BundleInfo 
        bundleName={bundleName} 
        usecaseId={usecaseId?.toString()}
      />
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold">Metrics & Export</h2>
          {/* <Button>
            <FileDown className="mr-2 h-4 w-4" />
            Export Report
          </Button> */}
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="space-y-8">
            {/* Metrics Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {/* Total Requirements */}
              <div className="bg-white rounded-lg p-4 border border-gray-200">
                <div className="flex items-center space-x-3 mb-2">
                  <Layers className="w-6 h-6 text-purple-500" />
                  <h3 className="text-gray-900 font-medium">Requirements Captured</h3>
                </div>
                {loading ? (
                  <Skeleton className="h-8 w-24" />
                ) : (
                  <p className="text-2xl font-bold text-gray-900">
                    {metricsData?.total_requirements || 0}
                  </p>
                )}
                <p className="text-sm text-gray-500">Functional Requirements</p>
              </div>

              {/* Test Scenarios */}
              <div className="bg-white rounded-lg p-4 border border-gray-200">
                <div className="flex items-center space-x-3 mb-2">
                  <ChartColumnIncreasing className="w-6 h-6 text-blue-500" />
                  <h3 className="text-gray-900 font-medium">Test Scenarios</h3>
                </div>
                {loading ? (
                  <Skeleton className="h-8 w-24" />
                ) : (
                  <p className="text-2xl font-bold text-gray-900">
                    {metricsData?.total_scenarios || 0}
                  </p>
                )}
                <p className="text-sm text-gray-500">Total Generated</p>
              </div>

              {/* Test Cases */}
              <div className="bg-white rounded-lg p-4 border border-gray-200">
                <div className="flex items-center space-x-3 mb-2">
                  <GitBranch className="w-6 h-6 text-indigo-500" />
                  <h3 className="text-gray-900 font-medium">Test Cases</h3>
                </div>
                {loading ? (
                  <Skeleton className="h-8 w-24" />
                ) : (
                  <p className="text-2xl font-bold text-gray-900">
                    {metricsData?.total_test_cases || 0}
                  </p>
                )}
                <p className="text-sm text-gray-500">Across All Modules</p>
              </div>

              {/* Coverage */}
              {/* <div className="bg-white rounded-lg p-4 border border-gray-200">
                <div className="flex items-center space-x-3 mb-2">
                  <CircleCheckBig className="w-6 h-6 text-green-500" />
                  <h3 className="text-gray-900 font-medium">Coverage</h3>
                </div>
                <p className="text-2xl font-bold text-gray-900">88%</p>
                <p className="text-sm text-gray-500">Overall Coverage</p>
              </div> */}

              {/* Critical Paths */}
              {/* <div className="bg-white rounded-lg p-4 border border-gray-200">
                <div className="flex items-center space-x-3 mb-2">
                  <GitBranch className="w-6 h-6 text-purple-500" />
                  <h3 className="text-gray-900 font-medium">Critical Paths</h3>
                </div>
                <p className="text-2xl font-bold text-gray-900">41</p>
                <p className="text-sm text-gray-500">Identified & Tested</p>
              </div> */}

              {/* Execution Time */}
              {/* <div className="bg-white rounded-lg p-4 border border-gray-200">
                <div className="flex items-center space-x-3 mb-2">
                  <Clock className="w-6 h-6 text-yellow-500" />
                  <h3 className="text-gray-900 font-medium">Execution Time</h3>
                </div>
                <p className="text-2xl font-bold text-gray-900">2.5 hours</p>
                <p className="text-sm text-gray-500">Estimated</p>
              </div> */}

              {/* Automation Ready */}
              {/* <div className="bg-white rounded-lg p-4 border border-gray-200">
                <div className="flex items-center space-x-3 mb-2">
                  <Users className="w-6 h-6 text-red-500" />
                  <h3 className="text-gray-900 font-medium">Automation Ready</h3>
                </div>
                <p className="text-2xl font-bold text-gray-900">92%</p>
                <p className="text-sm text-gray-500">Of Total Cases</p>
              </div> */}
            </div>

            {/* Chart Section */}
            <div>
              <h3 className="text-lg font-medium mb-4">Analysis</h3>
              <div className="h-72">
                {loading ? (
                  <div className="w-full h-full flex items-center justify-center">
                    <Skeleton className="h-full w-full" />
                  </div>
                ) : error ? (
                  <div className="text-red-500">{error}</div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={getChartData()}
                      margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="total" fill="#8884d8" name="Total" />
                      <Bar dataKey="covered" fill="#82ca9d" name="Covered" />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </div>
            </div>

            {/* Module Coverage Details */}
            {/* <div className="border rounded-lg p-4">
              <button 
                className="flex justify-between items-center w-full"
                onClick={() => setShowModuleCoverage(!showModuleCoverage)}
              >
                <h3 className="text-lg font-medium">Module Coverage Details</h3>
                <ChevronDown className={`w-5 h-5 transform ${showModuleCoverage ? 'rotate-180' : ''} transition-transform`} />
              </button>
              
              {showModuleCoverage && (
                <div className="mt-4 space-y-4">
                  Authentication & Authorization
                  <div className="border rounded-lg p-4">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium">Authentication & Authorization</h4>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-green-600">100% Coverage</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                      <span>32 Test Cases</span>
                      <span>8 Critical Paths</span>
                    </div>
                  </div>
                  
                  Payment Processing
                  <div className="border rounded-lg p-4">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium">Payment Processing</h4>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-yellow-600">92% Coverage</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                      <span>45 Test Cases</span>
                      <span>12 Critical Paths</span>
                    </div>
                    <div className="bg-yellow-50 border border-yellow-100 rounded p-3 mt-2">
                      <p className="text-sm text-yellow-700 font-medium">Uncovered Areas:</p>
                      <ul className="list-disc list-inside text-sm text-yellow-600 mt-1">
                        <li>Refund with International Currency</li>
                        <li>Multi-currency Exchange</li>
                      </ul>
                    </div>
                  </div>
                  
                  Account Management
                  <div className="border rounded-lg p-4">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium">Account Management</h4>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-yellow-600">85% Coverage</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                      <span>28 Test Cases</span>
                      <span>6 Critical Paths</span>
                    </div>
                    <div className="bg-yellow-50 border border-yellow-100 rounded p-3 mt-2">
                      <p className="text-sm text-yellow-700 font-medium">Uncovered Areas:</p>
                      <ul className="list-disc list-inside text-sm text-yellow-600 mt-1">
                        <li>Account Deletion</li>
                        <li>Profile Export</li>
                      </ul>
                    </div>
                  </div>
                  
                  Integration Tests
                  <div className="border rounded-lg p-4">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium">Integration Tests</h4>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-yellow-600">75% Coverage</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                      <span>51 Test Cases</span>
                      <span>15 Critical Paths</span>
                    </div>
                    <div className="bg-yellow-50 border border-yellow-100 rounded p-3 mt-2">
                      <p className="text-sm text-yellow-700 font-medium">Uncovered Areas:</p>
                      <ul className="list-disc list-inside text-sm text-yellow-600 mt-1">
                        <li>Third-party API Failure Scenarios</li>
                        <li>Timeout Handling</li>
                      </ul>
                    </div>
                  </div>
                </div>
              )}
            </div> */}

            {/* Risk Analysis */}
            {/* <div className="border rounded-lg p-4">
              <h3 className="text-lg font-medium mb-4">Risk Analysis</h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="p-3 bg-red-50 rounded-lg">
                  <div className="text-red-700 font-medium">High Risk</div>
                  <div className="text-2xl font-bold text-red-600">12</div>
                  <div className="text-sm text-red-600">Test Cases</div>
                </div>
                <div className="p-3 bg-yellow-50 rounded-lg">
                  <div className="text-yellow-700 font-medium">Medium Risk</div>
                  <div className="text-2xl font-bold text-yellow-600">28</div>
                  <div className="text-sm text-yellow-600">Test Cases</div>
                </div>
                <div className="p-3 bg-green-50 rounded-lg">
                  <div className="text-green-700 font-medium">Low Risk</div>
                  <div className="text-2xl font-bold text-green-600">116</div>
                  <div className="text-sm text-green-600">Test Cases</div>
                </div>
              </div>
            </div> */}
            <div className="border rounded-lg p-4">
              <h3 className="text-lg font-medium mb-4">Risk Analysis</h3>
              <div className="flex flex-row gap-6">
                {/* Left column - Risk cards */}
                <div className="flex flex-col gap-4 w-1/3">
                  <div className="p-3 bg-red-50 rounded-lg">
                    <div className="text-red-700 font-medium">High Risk</div>
                    <div className="text-2xl font-bold text-red-600">29</div>
                    <div className="text-sm text-red-600">Test Cases</div>
                  </div>
                  <div className="p-3 bg-yellow-50 rounded-lg">
                    <div className="text-yellow-700 font-medium">Medium Risk</div>
                    <div className="text-2xl font-bold text-yellow-600">28</div>
                    <div className="text-sm text-yellow-600">Test Cases</div>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <div className="text-green-700 font-medium">Low Risk</div>
                    <div className="text-2xl font-bold text-green-600">116</div>
                    <div className="text-sm text-green-600">Test Cases</div>
                  </div>
                </div>
                
                {/* Right column - Risk graphs */}
                <div className="w-2/3 h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={[
                        { name: "High Risk", value: 29 },
                        { name: "Medium Risk", value: 28 },
                        { name: "Low Risk", value: 116 }
                      ]}
                      margin={{ top: 10, right: 30, left: 0, bottom: 20 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="value" name="Test Cases">
                        <Cell fill="#ef4444" />
                        <Cell fill="#eab308" />
                        <Cell fill="#22c55e" />
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* Confirmation Checkboxes */}
            <div className="space-y-4 border-t pt-4">
              <div className="flex items-center space-x-2">
                <input 
                  type="checkbox" 
                  id="zephyr-upload" 
                  className="h-4 w-4 text-blue-600 rounded border-gray-300"
                  checked={confirmUpload}
                  onChange={(e) => setConfirmUpload(e.target.checked)}
                />
                <label htmlFor="zephyr-upload" className="text-sm text-gray-700">
                  I confirm to upload all the test scenario, test cases and test script to Knowledge Base                </label>
              </div>
              {/* <div className="flex items-center space-x-2">
                <input 
                  type="checkbox" 
                  id="automation-export" 
                  className="h-4 w-4 text-blue-600 rounded border-gray-300"
                  checked={exportAutomation}
                  onChange={(e) => setExportAutomation(e.target.checked)}
                />
                <label htmlFor="automation-export" className="text-sm text-gray-700">
                  Export test cases to selected automation tool
                </label>
              </div> */}
            </div>

            {/* Navigation Buttons */}
            <div className="flex justify-end  pt-4 border-t">
              {/* <Button variant="outline">Previous Step</Button> */}
              <Button 
                disabled={!confirmUpload}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg disabled:bg-gray-300 hover:bg-blue-700 transition-colors"
                onClick={handleCompleteGeneration}
              >
                Complete Generation
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Confirmation Dialog */}
      <Dialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Knowledge Base Upload</DialogTitle>
            <DialogDescription asChild>
              <div>
                <div className="mt-2 text-gray-700">
                  <p className="mb-2">All the test artifacts will be uploaded to the Knowledge Base:</p>
                  <ul className="list-disc pl-5 space-y-1 text-gray-600">
                    <li>Test scenarios and their related flows</li>
                    <li>Test cases with detailed steps and validations</li>
                    <li>Test scripts for all the test cases</li>
                  </ul>
                </div>
                {/* <div className="bg-blue-50 p-3 rounded-md mt-4 border border-blue-100">
                  <p className="text-blue-800 text-sm">
                    This action will make these test assets available for future reference and reuse across projects.
                  </p>
                </div> */}
              </div>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => setIsConfirmDialogOpen(false)} disabled={isUploading}>
              Cancel
            </Button>
            <Button 
              onClick={handleConfirmUpload} 
              disabled={isUploading}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isUploading ? "Uploading..." : "Confirm "}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
