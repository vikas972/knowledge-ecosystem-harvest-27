import { cn } from "@/lib/utils";

interface SourceCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  selected?: boolean;
  onClick?: () => void;
  disabled?: boolean;
}

interface SourceCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  selected?: boolean;
  onClick?: () => void;
  disabled?: boolean; // Add this prop
}

export const SourceCard = ({
  title,
  description,
  icon,
  selected,
  onClick,
  disabled = false, // Add default value
}: SourceCardProps) => {
  return (
    <div
      onClick={disabled ? undefined : onClick}
      className={cn(
        "p-8 rounded-xl border-2 transition-all duration-300",
        "backdrop-blur-sm relative overflow-hidden group",
        selected
          ? "border-primary bg-primary/5 shadow-lg shadow-primary/20"
          : "border-gray-200 bg-white",
        !disabled && "cursor-pointer hover:shadow-xl hover:-translate-y-1 hover:border-primary/50"
      )}
    >
      {/* Background gradient effect */}
      <div className={cn(
        "absolute inset-0 opacity-0 transition-opacity duration-300",
        "bg-gradient-to-br from-primary/5 to-transparent",
        selected ? "opacity-100" : !disabled && "group-hover:opacity-50"
      )} />
      
      <div className="relative flex items-start space-x-4">
        <div className={cn(
          "p-3 rounded-lg transition-all duration-300",
          disabled ? "text-gray-300 bg-gray-50" : selected
            ? "text-primary bg-primary/10"
            : "text-gray-400 bg-gray-50 group-hover:bg-primary/5 group-hover:text-primary"
        )}>
          {icon}
        </div>
        <div>
          <h3 className={cn(
            "font-semibold text-lg mb-1 transition-colors duration-300",
            disabled ? "text-gray-400" : selected ? "text-primary" : "text-gray-700 group-hover:text-primary"
          )}>
            {title}
          </h3>
          <p className={cn(
            "text-sm leading-relaxed",
            disabled ? "text-gray-400" : "text-gray-600"
          )}>
            {description}
          </p>
        </div>
      </div>
    </div>
  );
};