import { LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";
import { ButtonProps } from "@/components/ui/button";

interface LogoutButtonProps extends ButtonProps {
  label?: string;
  showIcon?: boolean;
}

export const LogoutButton = ({
  label = "Logout",
  showIcon = true,
  className,
  variant = "outline",
  size = "sm",
  ...props
}: LogoutButtonProps) => {
  const { logout } = useAuth();

  return (
    <Button
      variant={variant}
      size={size}
      onClick={() => logout()}
      className={cn(
        "flex items-center gap-1.5 transition-all duration-150",
        className
      )}
      {...props}
    >
      {showIcon && <LogOut className="h-4 w-4 mr-1" />}
      {label}
    </Button>
  );
};

export default LogoutButton; 