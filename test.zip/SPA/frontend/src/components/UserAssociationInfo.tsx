import React from 'react';

interface UserAssociationInfoProps {
  product: string;
  subProduct: string;
  domain: string;
}

export const UserAssociationInfo = ({
  product,
  subProduct,
  domain
}: {
  product: string;
  subProduct: string;
  domain: string;
}) => {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 mb-4">
      <div className="p-3">
        <div className="flex flex-wrap justify-between w-full">
          <div className="flex items-center">
            <span className="text-sm font-medium text-gray-600 mr-2">Product:</span>
            <span className="text-sm bg-blue-50 text-blue-700 px-2 py-1 rounded">{product || "Not specified"}</span>
          </div>
          <div className="flex items-center">
            <span className="text-sm font-medium text-gray-600 mr-2">Sub-Product:</span>
            <span className="text-sm bg-blue-50 text-blue-700 px-2 py-1 rounded">{subProduct || "Not specified"}</span>
          </div>
          <div className="flex items-center">
            <span className="text-sm font-medium text-gray-600 mr-2">Domain:</span>
            <span className="text-sm bg-blue-50 text-blue-700 px-2 py-1 rounded">{domain || "Not specified"}</span>
          </div>
        </div>
      </div>
    </div>
  );
}; 