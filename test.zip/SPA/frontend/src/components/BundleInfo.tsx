import React, { useEffect, useState, useRef } from 'react';
import { Badge } from "@/components/ui/badge";
import { API_ENDPOINTS } from "@/config/api";
import { Loader2 } from "lucide-react";

interface BundleInfoProps {
  bundleName: string;
  usecaseId?: string | null;
  onStatusChange?: (status: any) => void;
}

export const BundleInfo = ({
  bundleName,
  usecaseId,
  onStatusChange
}: BundleInfoProps) => {
  const [status, setStatus] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [initialLoadComplete, setInitialLoadComplete] = useState<boolean>(false);

  // Add fetchBundleStatus function outside useEffect for reusability
  const fetchBundleStatus = async () => {
    if (!usecaseId) return;
    
    // Only show loading indicator on initial fetch
    if (!initialLoadComplete) {
      setIsLoading(true);
    }
    
    try {
      const response = await fetch(`${API_ENDPOINTS.getUseCaseStatus}/${usecaseId}`);
      
      if (response.ok) {
        const statusData = await response.json();
        const workflowStatus = {
          text_extraction: statusData.text_extraction,
          requirement_generation: statusData.requirement_generation,
          scenario_generation: statusData.scenario_generation,
          test_case_generation: statusData.test_case_generation,
          test_data_generation: statusData.test_data_generation,
          test_script_generation: statusData.test_script_generation
        };
        
        // Call the onStatusChange callback with the raw status data
        if (onStatusChange) {
          onStatusChange(statusData);
        }
        
        // Determine the new status
        const newStatus = determineWorkflowStatus(workflowStatus);
        
        // Update status with the new value
        setStatus(newStatus);
      }
    } catch (error) {
      console.error("Error fetching bundle status:", error);
    } finally {
      // Mark initial load as complete
      if (!initialLoadComplete) {
        setInitialLoadComplete(true);
        setIsLoading(false);
      }
    }
  };

  useEffect(() => {
    // Reset states when usecaseId changes
    if (usecaseId) {
      setInitialLoadComplete(false);
      setIsLoading(true);
    }
    
    // Initial fetch
    fetchBundleStatus();

    // Set up polling interval
    const intervalId = setInterval(() => {
      fetchBundleStatus();
    }, 10000); // Poll every 10 seconds

    // Cleanup interval on component unmount
    return () => clearInterval(intervalId);
  }, [usecaseId]); // Re-run effect when usecaseId changes

  // Helper function to determine overall workflow status
  const determineWorkflowStatus = (workflowStatus: any) => {
    const stages = [
      { name: "text_extraction", label: "Text Extraction" },
      { name: "requirement_generation", label: "Requirement Generation" },
      { name: "scenario_generation", label: "Scenario Generation" },
      { name: "test_case_generation", label: "Test Case Generation" },
      { name: "test_script_generation", label: "Test Script Generation" },
      // { name: "test_data_generation", label: "Test Data Generation" }
    ];
    
    // Check if all stages are completed
    const allCompleted = stages.every(stage => 
      workflowStatus[stage.name] === "Completed");
    if (allCompleted) return `completed`;
    
    // Find the first stage that's in progress
    const inProgressStage = stages.find(stage => 
      workflowStatus[stage.name] === "In Progress");
    if (inProgressStage) return `${inProgressStage.label} - In Progress`;
    
    // Find the first stage that failed
    const failedStage = stages.find(stage => 
      workflowStatus[stage.name] === "Failed");
    if (failedStage) return `${failedStage.label} - Failed`;
    
    // Check if all stages are in "Not Started" state
    const allNotStarted = stages.every(stage => 
      workflowStatus[stage.name] === "Not Started");
    if (allNotStarted) return "not-started";
    
    // Find the next stage that's "Not Started" after the last completed stage
    let lastCompletedIndex = -1;
    for (let i = stages.length - 1; i >= 0; i--) {
      if (workflowStatus[stages[i].name] === "Completed") {
        lastCompletedIndex = i;
        break;
      }
    }
    
    // Get the next stage after the last completed one
    if (lastCompletedIndex !== -1 && lastCompletedIndex < stages.length - 1) {
      const nextStage = stages[lastCompletedIndex + 1];
      if (workflowStatus[nextStage.name] === "Not Started") {
        return `${nextStage.label} - Not Started`;
      }
    }
    
    // If no specific next stage is found, return generic "Not Started"
    return "not-started";
  };

  // Status badge function
  const getStatusBadge = (status: string) => {
    // Handle workflow-specific statuses
    if (status.includes("In Progress")) {
      return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">{status}</Badge>;
    } else if (status.includes("Failed")) {
      return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">{status}</Badge>;
    } else if (status.includes("Not Started")) {
      return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">{status}</Badge>;
    } else if (status === "not-started") {
      return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">Not Started</Badge>;
    }
    
    // Handle standard statuses
    switch (status) {
      case "completed":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Test Script Generation - Completed</Badge>;
      case "in-progress":
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">In Progress</Badge>;
      case "failed":
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Failed</Badge>;
      case "empty":
        return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">Empty</Badge>;
      default:
        return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">Unknown</Badge>;
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 mb-4 w-fit">
      <div className="p-4">
        <div className="flex items-center gap-4">
          {/* Bundle Name Section */}
          <div className="flex items-center">
            <span className="text-sm font-medium text-gray-600">Selected Requirement Bundle:</span>
            <span className="ml-2 text-sm bg-green-50 text-green-700 px-2.5 py-1 rounded-md">
              {bundleName || "Not specified"}
            </span>
          </div>

          {/* Divider */}
          <div className="h-4 w-px bg-gray-200"></div>
          
          {/* Status Section */}
          <div className="flex items-center">
            <span className="text-sm font-medium text-gray-600">Status:</span>
            <div className="ml-2">
              {/* {isLoading ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin text-gray-500" />
                  <span className="text-sm text-gray-500">Loading...</span>
                </div>
              ) : status ? (
                getStatusBadge(status)
              ) : null} */}
               {status && getStatusBadge(status)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
