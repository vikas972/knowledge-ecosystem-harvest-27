import { BarChart, Check, Database, FileText, List, Settings, Target, TestTube } from "lucide-react";
import { cn } from "@/lib/utils";
import { RiBook2Fill } from "react-icons/ri";
import { FaFilePen } from "react-icons/fa6";
import { AiFillPicture } from "react-icons/ai";
import { TbTestPipe2Filled } from "react-icons/tb";
import { BsDatabaseFillExclamation } from "react-icons/bs";
import { BsFileBarGraphFill } from "react-icons/bs";

interface WizardStepsProps {
  currentStep: number;
  steps: string[];
}

export const WizardSteps = ({ currentStep, steps }: WizardStepsProps) => {
  const stepIcons = [
    <List className="w-6 h-6" />,
    <FileText className="w-6 h-6" />,
    <Target className="w-6 h-6" />,
    <TestTube className="w-6 h-6" />,
    <Database className="w-6 h-6" />,
    <Settings className="w-6 h-6" />,
    <BarChart className="w-6 h-6" />
  ];


  return (
    <div className="w-full py-6 px-8 bg-white">
      <div className="container mx-auto px-8">
        <div className="flex justify-center items-center gap-8 relative">
          {/* Progress bar background */}
          <div className="absolute top-1/2 -translate-y-1/2 left-0 right-0 h-[2px] bg-gray-200 -z-10" />
          
          {/* Active progress bar */}
          <div 
            className="absolute top-1/2 -translate-y-1/2 left-0 h-[2px] bg-gradient-to-r from-primary to-primary/80 transition-all duration-500 ease-in-out -z-10"
            style={{ width: `${(currentStep / (steps.length - 1)) * 100}%` }}
          />
          
          {steps.map((step, index) => (
            <div key={step} className="flex items-center justify-center flex-1 relative z-0 group">
              {/* Progress line between steps */}
              {index < steps.length - 1 && (
                <div className={cn(
                  "absolute h-[6px] w-full left-1/2 top-[28px]",
                  index < currentStep ? "bg-primary" : "bg-gray-200"
                )} />
              )}
              <div className="flex flex-col items-center z-10">
                <div
                  className={cn(
                    "flex items-center justify-center transition-all duration-300 p-3 rounded-lg",
                    index < currentStep
                      ? "text-white bg-primary shadow-lg scale-110"
                      : index === currentStep
                      ? "text-primary bg-white shadow-md animate-pulse ring-2 ring-primary"
                      : "text-gray-400 bg-white shadow-sm hover:scale-105"
                  )}
                >
                  {index < currentStep ? (
                    <Check className="w-6 h-6" />
                  ) : (
                    stepIcons[index]
                  )}
                </div>
                <div className="mt-2 text-center">
                  <div className={cn(
                    "text-sm font-semibold transition-all duration-300",
                    index <= currentStep ? "text-primary" : "text-gray-400"
                  )}>
                    {step.split(' ')[0]}
                  </div>
                  <div className={cn(
                    "text-xs font-medium transition-all duration-300",
                    index <= currentStep ? "text-primary/80" : "text-gray-400"
                  )}>
                    {step.split(' ').slice(1).join(' ')}
                  </div>
                </div>
              </div>
            </div>
          ))}        </div>
      </div>
    </div>
  );
};