
export const KB_CATEGORIES = [
  "Flows/Transactions",
  "Validation Rules",
  "User Interfaces",
  "Operational Flows",
  "Reports and Notifications",
  "Data and Integrations"
] as const
