
export interface KBEntry {
  id: string
  title: string
  description: string
  status: string
  lastModified: Date
  category: string
  documentId: string
}
