#!/usr/bin/env python3
"""
OCR Data Extractor for Supporting Documents

This script extracts OCR data only for supporting documents for a given usecase ID
from the database and stores it in a text file.

The usecase ID and output file are hardcoded in the script.
"""

import os
import sys
import logging
from typing import Tuple, List, Optional
import sqlalchemy
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.exc import SQLAlchemyError
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Database configuration
# These should be updated with your actual database credentials
DB_CONFIG = {
    "user": "postgres",
    "password": "postgres",
    "host": "localhost",
    "port": "5432",
    "database": "spa_automation_ea_v1"
}

def create_db_connection() -> Tuple[sqlalchemy.engine.Engine, sessionmaker]:
    """
    Create a database connection.
    
    Returns:
        Tuple containing:
        - SQLAlchemy engine
        - SQLAlchemy sessionmaker
    """
    try:
        # Create connection string
        connection_string = f"postgresql://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}"
        
        # Create engine
        engine = create_engine(connection_string)
        
        # Create sessionmaker
        Session = sessionmaker(bind=engine)
        
        logger.info("Database connection established successfully")
        return engine, Session
    
    except Exception as e:
        logger.error(f"Error creating database connection: {str(e)}")
        raise

def extract_supporting_docs_ocr_data(usecase_id: int) -> Tuple[List[Tuple[int, str, str]], bool]:
    """
    Extract OCR data only for supporting documents for a usecase.
    
    Args:
        usecase_id: The usecase ID
        
    Returns:
        Tuple containing:
        - List of tuples with (page_number, page_text, file_name)
        - Boolean indicating success
    """
    engine, SessionMaker = create_db_connection()
    
    try:
        with SessionMaker() as session:
            # First, check the structure of the file_metadata table
            table_info_query = text("""
            SELECT column_name 
            FROM information_schema.columns 
            WHERE table_name = 'file_metadata'
            """)
            columns = [row[0] for row in session.execute(table_info_query).fetchall()]
            logger.info(f"Available columns in file_metadata: {columns}")
            
            # Find supporting document files belonging to the usecase - using the same filter as scenario_generator.py
            file_query = text("""
            SELECT fm."fileId", fm."fileName", fm."documentType" 
            FROM file_metadata fm
            WHERE fm."usecaseId" = :usecase_id
            AND fm."documentType" = 'supportingReq'
            AND fm."is_deleted" = FALSE
            """)
            
            files = session.execute(file_query, {"usecase_id": usecase_id}).fetchall()
            
            if not files:
                logger.error(f"No supporting document files found for usecase ID: {usecase_id}")
                return [], False
            
            # Get OCR data for all supporting document files
            all_ocr_data = []
            for file in files:
                file_id = file[0]
                file_name = file[1]
                doc_type = file[2]
                logger.info(f"Processing supporting document file ID: {file_id}, Name: {file_name}, Type: {doc_type}")
                
                # Get OCR data for this file - matching the filter from scenario_generator.py
                ocr_query = text("""
                SELECT "pageNumber", "pageText" 
                FROM ocr_outputs 
                WHERE "fileId" = :file_id 
                AND "isCompleted" = TRUE
                AND "is_deleted" = FALSE
                ORDER BY "pageNumber"
                """)
                
                ocr_outputs = session.execute(ocr_query, {"file_id": file_id}).fetchall()
                
                # Add valid OCR outputs to the result
                for output in ocr_outputs:
                    if output[1]:  # pageText is not empty
                        all_ocr_data.append((output[0], output[1], file_name))
            
            if not all_ocr_data:
                logger.error(f"No OCR data found for supporting documents in usecase ID: {usecase_id}")
                return [], False
            
            # Sort by file name and then page number
            all_ocr_data.sort(key=lambda x: (x[2], x[0]))
            
            logger.info(f"Found {len(all_ocr_data)} total OCR records from supporting documents for usecase ID {usecase_id}")
            return all_ocr_data, True
    
    except Exception as e:
        logger.error(f"Error extracting OCR data for supporting documents in usecase {usecase_id}: {str(e)}")
        return [], False

def save_supporting_docs_ocr_data_to_file(ocr_data: List[Tuple[int, str, str]], usecase_id: int, output_file: str) -> bool:
    """
    Save supporting documents OCR data to a text file.
    
    Args:
        ocr_data: List of tuples with (page_number, page_text, file_name)
        usecase_id: The ID of the usecase
        output_file: Path to the output file
        
    Returns:
        Boolean indicating success
    """
    try:
        with open(output_file, 'w', encoding='utf-8') as f:
            # Write header
            f.write(f"Supporting Documents OCR Data for Usecase ID: {usecase_id}\n")
            f.write(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Total Pages: {len(ocr_data)}\n")
            f.write("=" * 80 + "\n\n")
            
            # Group OCR data by file name
            files_data = {}
            for page_number, page_text, file_name in ocr_data:
                if file_name not in files_data:
                    files_data[file_name] = []
                files_data[file_name].append((page_number, page_text))
            
            # Write OCR data file by file, page by page
            for file_name, pages in files_data.items():
                f.write(f"FILE: {file_name}\n")
                f.write("=" * 80 + "\n\n")
                
                for page_number, page_text in pages:
                    f.write(f"--- Page {page_number} ---\n\n")
                    f.write(page_text)
                    f.write("\n\n")
                    f.write("-" * 80 + "\n\n")
                
                f.write("\n")
            
            # Write combined OCR text at the end
            f.write("=" * 80 + "\n")
            f.write("COMBINED OCR TEXT FROM ALL SUPPORTING DOCUMENTS\n")
            f.write("=" * 80 + "\n\n")
            
            combined_text = "\n\n".join([text for _, text, _ in ocr_data])
            f.write(combined_text)
        
        logger.info(f"Supporting documents OCR data saved to {output_file}")
        return True
    
    except Exception as e:
        logger.error(f"Error saving supporting documents OCR data to file {output_file}: {str(e)}")
        return False

# Main script with hardcoded values
if __name__ == "__main__":
    # Hardcoded configuration values
    USECASE_ID = 5  # Change this to your actual usecase ID
    OUTPUT_FILE = "supporting_docs_ocr_data.txt"  # Change this to your desired output file path
    
    print(f"Starting supporting documents OCR data extraction...")
    print(f"Usecase ID: {USECASE_ID}")
    print(f"Output file: {OUTPUT_FILE}")
    
    try:
        # Extract OCR data for supporting documents
        ocr_data, success = extract_supporting_docs_ocr_data(USECASE_ID)
        
        if not success:
            logger.error(f"Failed to extract supporting documents OCR data for usecase ID {USECASE_ID}")
            sys.exit(1)
        
        logger.info(f"Successfully extracted {len(ocr_data)} pages of supporting documents OCR data")
        
        # Save OCR data to file
        if save_supporting_docs_ocr_data_to_file(ocr_data, USECASE_ID, OUTPUT_FILE):
            logger.info(f"Supporting documents OCR data for usecase ID {USECASE_ID} saved to {OUTPUT_FILE}")
            print(f"Supporting documents OCR data successfully saved to: {os.path.abspath(OUTPUT_FILE)}")
            print(f"Total pages extracted: {len(ocr_data)}")
        else:
            logger.error(f"Failed to save supporting documents OCR data to {OUTPUT_FILE}")
            sys.exit(1)
    except Exception as e:
        print(f"Error during supporting documents OCR data extraction: {str(e)}")
