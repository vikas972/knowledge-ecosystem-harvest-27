import os
import sys
from datetime import datetime
import fitz  # PyMuPDF
from PIL import Image, ImageDraw
import io
import asyncio
import requests
import json

# Add the path to access the AssetInvoker class
sys.path.append('/home/vikasmayura/Desktop/SPA_Automation_Agent/SPA/backend/app/services/llm/pf_image2text_automation')
from asset_invoker import AssetInvoker


class PDFTextExtractor:
    def __init__(self, input_file, output_dir=None, save_images=False, use_asset_invoker=False, 
                 api_key=None, username=None, password=None, asset_id=None, batch_size=10):
        """
        Initialize the PDF text extractor.
        
        Args:
            input_file (str): Path to the input PDF file.
            output_dir (str, optional): Directory to save output files. If None, use current directory.
            save_images (bool, optional): Whether to save page images along with extracted text.
            use_asset_invoker (bool, optional): Whether to use the AssetInvoker for better image text extraction.
            api_key (str, optional): API key for the asset service.
            username (str, optional): Username for the asset service.
            password (str, optional): Password for the asset service.
            asset_id (str, optional): Asset ID for the image-to-text service.
            batch_size (int, optional): Size of batches for parallel processing.
        """
        self.input_file = input_file
        self.output_dir = output_dir or os.path.dirname(input_file) or '.'
        self.save_images = save_images
        self.use_asset_invoker = use_asset_invoker
        self.batch_size = batch_size
        
        if use_asset_invoker:
            self.asset_invoker = AssetInvoker(
                api_key=api_key,
                username=username,
                password=password,
                asset_id=asset_id
            )
        
        # Create output directory if it doesn't exist
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
    
    async def _process_images_with_asset_invoker(self, images_folder):
        """
        Process images with the asset invoker to get better text extraction.
        Uses the actual AssetInvoker from asset_invoker.py
        
        Args:
            images_folder (str): Path to the folder containing the page images.
            
        Returns:
            dict: Dictionary mapping page numbers to extracted text.
        """
        print(f"Processing images in {images_folder} with asset invoker")
        
        # Get sorted list of image files
        image_files = sorted([f for f in os.listdir(images_folder) if f.endswith('.png')])
        image_paths = [os.path.join(images_folder, f) for f in image_files]
        
        # Process images in batches of self.batch_size
        page_texts = {}
        
        print(f"Total images to process: {len(image_paths)}")
        print(f"Processing in batches of {self.batch_size}")
        
        for i in range(0, len(image_paths), self.batch_size):
            batch = image_paths[i:i+self.batch_size]
            batch_num = i//self.batch_size + 1
            total_batches = (len(image_paths) + self.batch_size - 1) // self.batch_size
            
            print(f"Processing batch {batch_num}/{total_batches} with {len(batch)} images")
            try:
                # Use the actual invoke_asset method from the AssetInvoker class
                results = await self.asset_invoker.invoke_asset(batch)
                
                # Process the results
                for j, result in enumerate(results):
                    if i+j < len(image_paths):
                        # Extract page number from filename (format: page_XXX.png)
                        file_basename = os.path.basename(image_paths[i+j])
                        if file_basename.startswith('page_') and file_basename.endswith('.png'):
                            try:
                                page_num = int(file_basename[5:8])
                                print(f"Successfully extracted text for page {page_num}")
                                page_texts[page_num] = result
                            except ValueError:
                                print(f"Could not extract page number from filename: {file_basename}")
                        else:
                            print(f"Unexpected image filename format: {file_basename}")
            except Exception as e:
                print(f"Error processing batch {batch_num}/{total_batches}: {str(e)}")
                # Continue with other batches even if one fails
        
        return page_texts
    
    def extract_text(self):
        """
        Extract text from the PDF file and save it to a text file.
        
        Returns:
            str: Path to the output text file.
        """
        if not os.path.isfile(self.input_file):
            raise FileNotFoundError(f"File not found: {self.input_file}")
            
        base_name = os.path.splitext(os.path.basename(self.input_file))[0]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_text_file = os.path.join(self.output_dir, f"{base_name}_extracted_{timestamp}.txt")
        
        # Create a folder for images if needed
        images_folder = None
        if self.save_images or self.use_asset_invoker:
            images_folder = os.path.join(self.output_dir, f"{base_name}_images_{timestamp}")
            if not os.path.exists(images_folder):
                os.makedirs(images_folder)
        
        try:
            doc = fitz.open(self.input_file)
            print(f"Processing PDF with {doc.page_count} pages")
            
            # Dictionary to store text for each page
            page_texts = {}
            
            # First pass: Extract images and basic text
            for page_number in range(doc.page_count):
                page = doc.load_page(page_number)
                
                # Extract text from the page using PyMuPDF
                page_text = page.get_text()
                page_texts[page_number + 1] = page_text
                
                # Save page as image if requested or if using asset invoker
                if self.save_images or self.use_asset_invoker:
                    try:
                        # Use a safer approach to render the page as an image
                        pix = page.get_pixmap(alpha=False)  # No alpha channel
                        
                        # Method 1: Using PIL directly
                        try:
                            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                            
                            # Add page number to the image
                            draw = ImageDraw.Draw(img)
                            draw.text((10, 10), f"Page {page_number + 1}", fill="red")
                            
                            # Save the image
                            image_filename = f"page_{page_number + 1:03d}.png"
                            image_filepath = os.path.join(images_folder, image_filename)
                            img.save(image_filepath)
                            print(f"Saved image for page {page_number + 1}")
                        except Exception as img_error:
                            print(f"Error converting page {page_number + 1} using PIL: {str(img_error)}")
                            
                            # Method 2 (fallback): Save directly from PyMuPDF
                            try:
                                image_filename = f"page_{page_number + 1:03d}.png"
                                image_filepath = os.path.join(images_folder, image_filename)
                                pix.save(image_filepath)
                                print(f"Saved image for page {page_number + 1} using fallback method")
                            except Exception as fallback_error:
                                print(f"Fallback method also failed for page {page_number + 1}: {str(fallback_error)}")
                                print(f"Skipping image for page {page_number + 1}")
                    except Exception as e:
                        print(f"Error saving image for page {page_number + 1}: {str(e)}")
                        print(f"Continuing with text extraction...")
            
            # Second pass: If using asset invoker, process images to get better text
            if self.use_asset_invoker and images_folder:
                print(f"Using asset invoker for better text extraction")
                asset_page_texts = asyncio.run(self._process_images_with_asset_invoker(images_folder))
                
                # Merge or replace the text
                for page_num, text in asset_page_texts.items():
                    # If PyMuPDF extraction was empty or very short, replace with asset text
                    # Otherwise, append the asset text
                    pymupdf_text = page_texts.get(page_num, "")
                    if len(pymupdf_text.strip()) < 50:  # If PyMuPDF text is very short
                        page_texts[page_num] = text
                    else:
                        page_texts[page_num] = f"{pymupdf_text}\n\n--- Additional text from image analysis ---\n\n{text}"
            
            # Write the final text file
            with open(output_text_file, 'w', encoding='utf-8') as text_output:
                for page_number in range(1, doc.page_count + 1):
                    text_output.write(f"--- Page {page_number} ---\n")
                    text_output.write(page_texts.get(page_number, ""))
                    text_output.write("\n\n")
            
            doc.close()
            print(f"Successfully extracted text to: {output_text_file}")
            if self.save_images:
                print(f"Saved page images to: {images_folder}")
            
            # Clean up the image folder if we don't need to save images
            if not self.save_images and images_folder and os.path.exists(images_folder):
                for file in os.listdir(images_folder):
                    os.remove(os.path.join(images_folder, file))
                os.rmdir(images_folder)
                print(f"Cleaned up temporary image folder: {images_folder}")
            
            return output_text_file
            
        except Exception as e:
            print(f"Error extracting text from PDF: {str(e)}")
            raise
    
    def extract_text_with_ocr(self, ocr_lang="eng"):
        """
        Extract text from the PDF with OCR capabilities.
        This version uses the asset invoker for better image-to-text conversion.
        
        Args:
            ocr_lang (str): Language code for OCR.
            
        Returns:
            str: Path to the output text file.
        """
        # Enable asset invoker for OCR mode
        self.use_asset_invoker = True
        print(f"Extracting text with OCR mode enabled, language: {ocr_lang}")
        return self.extract_text()


# Main script with hardcoded values
if __name__ == "__main__":
    # Hardcoded configuration values
    PDF_FILE_PATH = "/home/vikasmayura/Documents/SPA_Docs/FSD_iGTB Barclays_Inbound Payments_Vol3_v0.7_draft.docx.pdf"  # Change this to your PDF file path
    OUTPUT_DIRECTORY = "/home/vikasmayura/Desktop/SPA_Automation_Agent/SPA/uploads"  # Change this to your desired output directory
    SAVE_IMAGES = False           # Set to False if you don't want to save page images
    USE_OCR = True               # Set to True to use OCR with asset invoker
    BATCH_SIZE = 10              # Number of images to process in each batch
    
    # Asset invoker configuration - now using actual values
    API_KEY = "magicplatform.7881874f7df9423d94b6fFd8ebd6e279"
    USERNAME = "gtb.nikhildusane"
    PASSWORD = "Nikhil@123"
    ASSET_ID = "eac3cc4c-59a9-423e-a10c-cd8690485ec1"
    
    print(f"Starting PDF text extraction...")
    print(f"Input file: {PDF_FILE_PATH}")
    print(f"Output directory: {OUTPUT_DIRECTORY}")
    print(f"Save images: {SAVE_IMAGES}")
    print(f"Use OCR: {USE_OCR}")
    print(f"Batch size: {BATCH_SIZE}")
    
    try:
        # Create the extractor with hardcoded values
        extractor = PDFTextExtractor(
            input_file=PDF_FILE_PATH,
            output_dir=OUTPUT_DIRECTORY,
            save_images=SAVE_IMAGES,
            use_asset_invoker=USE_OCR,
            api_key=API_KEY,
            username=USERNAME,
            password=PASSWORD,
            asset_id=ASSET_ID,
            batch_size=BATCH_SIZE
        )
        
        # Extract text with or without OCR
        if USE_OCR:
            output_file = extractor.extract_text_with_ocr(ocr_lang="eng")
        else:
            output_file = extractor.extract_text()
        
        print(f"Extraction complete. Output saved to: {output_file}")
    except Exception as e:
        print(f"Error during PDF extraction: {str(e)}")
        print("Text extraction may have still succeeded even if image extraction failed.") 