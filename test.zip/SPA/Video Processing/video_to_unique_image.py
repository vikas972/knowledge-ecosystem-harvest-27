"""
Video to Unique Images with Audio Transcription
----------------------------------------------
This script extracts unique frames from a video, timestamps them, 
extracts audio segments between frame changes, and transcribes those 
segments using OpenAI's Whisper.

Note: This script requires numpy<2.0.0 for compatibility with OpenCV.
"""
import cv2
from skimage.metrics import structural_similarity as ssim
import numpy as np
import os
import whisper
from moviepy.editor import VideoFileClip
import time

# Check NumPy version
import numpy as np
numpy_version = np.__version__
if numpy_version.startswith('2'):
    print(f"Warning: Using NumPy {numpy_version}. This may cause compatibility issues with OpenCV.")
    print("Consider downgrading to NumPy<2.0.0 using: pip install numpy<2.0.0")

def extract_unique_frames_with_audio(video_path, output_folder, threshold=0.95, interval=10):
    """
    Extract unique frames from a video with their timestamps and transcribe audio segments between frame changes.
    
    Args:
        video_path: Path to the video file
        output_folder: Folder to save extracted frames and audio transcriptions
        threshold: Similarity threshold for frame comparison (lower means more frames saved)
        interval: Number of frames to skip between comparisons
    """
    # Ensure output directories exist
    os.makedirs(output_folder, exist_ok=True)
    os.makedirs(os.path.join(output_folder, "audio"), exist_ok=True)
    os.makedirs(os.path.join(output_folder, "transcripts"), exist_ok=True)
    output_folder = os.path.abspath(output_folder)
    
    # Load video
    cap = cv2.VideoCapture(video_path)
    success, prev_frame = cap.read()
    if not success:
        print("Failed to read video. Please check the video path.")
        return
    
    # Get video properties
    video_fps = cap.get(cv2.CAP_PROP_FPS)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    video_duration = frame_count / video_fps
    print(f"Video FPS: {video_fps}, Duration: {video_duration:.2f} seconds")
    
    # Load the video for audio extraction
    video_clip = VideoFileClip(video_path)
    
    # Load Whisper model for audio transcription
    print("Loading Whisper model...")
    model = whisper.load_model("base")  # Use "base" for faster processing, "medium" or "large" for higher accuracy
    
    # Save the first frame
    frame_id = 0
    first_frame_time = 0
    first_frame_path = os.path.join(output_folder, f"frame_{first_frame_time:.2f}sec_{format_timestamp(first_frame_time)}.jpg")
    cv2.imwrite(first_frame_path, prev_frame)
    print(f"Saved: {first_frame_path}")
    
    unique_frame_timestamps = [first_frame_time]
    frame_id = 1
    
    current_time = 0
    last_unique_frame_time = 0
    
    while True:
        # Skip frames according to interval
        for _ in range(interval):
            success, _ = cap.read()
            if not success:
                break
            frame_id += 1
            
        # Read the next frame after skipping
        success, curr_frame = cap.read()
        if not success:
            break
            
        # Calculate current time in the video
        current_time = frame_id / video_fps
        
        # Convert frames to grayscale for comparison
        gray_prev = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)
        gray_curr = cv2.cvtColor(curr_frame, cv2.COLOR_BGR2GRAY)
        
        # Calculate SSIM to detect differences
        score, _ = ssim(gray_prev, gray_curr, full=True)
        
        if score < threshold:
            # Save the unique frame with timestamp in seconds in the filename
            frame_path = os.path.join(output_folder, f"frame_{current_time:.2f}sec_{format_timestamp(current_time)}.jpg")
            cv2.imwrite(frame_path, curr_frame)
            print(f"Saved frame at {format_timestamp(current_time)}, ID: {frame_id}, Time: {current_time:.2f} seconds")
            
            # Extract and transcribe audio segment between the last unique frame and this one
            if len(unique_frame_timestamps) > 0:
                extract_and_transcribe_audio_segment(
                    video_clip, 
                    last_unique_frame_time, 
                    current_time, 
                    model,
                    output_folder
                )
            
            # Update variables for next comparison
            prev_frame = curr_frame
            last_unique_frame_time = current_time
            unique_frame_timestamps.append(current_time)
        
        frame_id += 1
    
    # Handle the last audio segment (from the last unique frame to the end)
    if last_unique_frame_time < video_duration:
        extract_and_transcribe_audio_segment(
            video_clip,
            last_unique_frame_time,
            video_duration,
            model,
            output_folder
        )
    
    # Release resources
    cap.release()
    video_clip.close()
    print("Extraction completed.")
    
    # Create a summary report
    create_summary_report(output_folder, unique_frame_timestamps)

def format_timestamp(seconds):
    """Convert seconds to HH:MM:SS.mss format"""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    seconds = seconds % 60
    return f"{hours:02d}_{minutes:02d}_{seconds:06.3f}".replace(".", "_")

def format_readable_timestamp(seconds):
    """Convert seconds to a human-readable HH:MM:SS format"""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = seconds % 60
    return f"{hours:02d}:{minutes:02d}:{secs:06.3f}"

def extract_and_transcribe_audio_segment(video_clip, start_time, end_time, whisper_model, output_folder):
    """Extract audio segment and transcribe it using Whisper"""
    segment_id = format_timestamp(start_time)
    
    # Extract audio segment
    print(f"Extracting audio from {format_timestamp(start_time)} to {format_timestamp(end_time)}")
    segment_duration = end_time - start_time
    # Update audio filename to include time window
    audio_path = os.path.join(output_folder, "audio", f"audio_{start_time:.2f}sec_to_{end_time:.2f}sec_{segment_id}.wav")
    
    try:
        # Extract the audio segment
        audio_segment = video_clip.subclip(start_time, end_time)
        audio_segment.audio.write_audiofile(audio_path, logger=None)
        
        # Transcribe the audio segment
        print(f"Transcribing audio segment {segment_id}...")
        transcript = whisper_model.transcribe(audio_path)
        
        # Add time window information to the transcript content
        timestamp_info = f"[Time window: {format_readable_timestamp(start_time)} to {format_readable_timestamp(end_time)}]\n\n"
        transcript_text = timestamp_info + transcript["text"]
        
        # Save transcription with time window in filename
        transcript_path = os.path.join(output_folder, "transcripts", f"transcript_{start_time:.2f}sec_to_{end_time:.2f}sec_{segment_id}.txt")
        with open(transcript_path, "w") as f:
            f.write(transcript_text)
        
        print(f"Saved transcription for segment {segment_id} ({start_time:.2f}sec to {end_time:.2f}sec)")
        return transcript_text
    except Exception as e:
        print(f"Error processing audio segment {segment_id}: {str(e)}")
        return ""

def create_summary_report(output_folder, timestamps):
    """Create a summary report linking frames with their audio transcripts"""
    report_path = os.path.join(output_folder, "summary_report.html")
    
    with open(report_path, "w") as f:
        f.write("<html><head><title>Video Analysis Report</title>")
        f.write("<style>body{font-family:Arial;margin:20px;}img{max-width:800px;}.timestamp{color:#666;font-size:14px;}</style></head><body>")
        f.write("<h1>Video Analysis Report</h1>")
        
        for i in range(len(timestamps) - 1):
            current_time = timestamps[i]
            next_time = timestamps[i+1]
            
            # Find the corresponding frame and transcript using the time in seconds
            frame_files = [f for f in os.listdir(output_folder) 
                          if f.startswith(f"frame_{current_time:.2f}sec_") and f.endswith(".jpg")]
            
            # Updated transcript file pattern to match new naming convention
            transcript_files = [f for f in os.listdir(os.path.join(output_folder, "transcripts")) 
                              if f.startswith(f"transcript_{current_time:.2f}sec_to_")]
            
            transcript_path = ""
            if transcript_files:
                transcript_path = os.path.join(output_folder, "transcripts", transcript_files[0])
            
            if frame_files and os.path.exists(transcript_path):
                frame_file = frame_files[0]
                
                f.write(f"<h2>Segment {i+1}: <span class='timestamp'>{format_readable_timestamp(current_time)} to {format_readable_timestamp(next_time)}</span></h2>")
                f.write(f"<p class='timestamp'>Time: {current_time:.2f}sec to {next_time:.2f}sec</p>")
                f.write(f"<img src='{frame_file}' alt='Frame at {format_timestamp(current_time)}' /><br>")
                
                # Read and display transcript
                try:
                    with open(transcript_path, "r") as transcript_f:
                        transcript_text = transcript_f.read()
                        f.write(f"<h3>Transcript:</h3><p>{transcript_text}</p>")
                except:
                    f.write("<p>No transcript available for this segment.</p>")
                
                f.write("<hr>")
        
        # Handle the last frame
        if len(timestamps) > 0:
            last_time = timestamps[-1]
            frame_files = [f for f in os.listdir(output_folder) 
                          if f.startswith(f"frame_{last_time:.2f}sec_") and f.endswith(".jpg")]
            
            transcript_files = [f for f in os.listdir(os.path.join(output_folder, "transcripts")) 
                              if f.startswith(f"transcript_{last_time:.2f}sec_to_")]
            
            transcript_path = ""
            if transcript_files:
                transcript_path = os.path.join(output_folder, "transcripts", transcript_files[0])
            
            if frame_files and os.path.exists(transcript_path):
                frame_file = frame_files[0]
                
                f.write(f"<h2>Final Segment: <span class='timestamp'>{format_readable_timestamp(last_time)} to end</span></h2>")
                f.write(f"<p class='timestamp'>Time: {last_time:.2f}sec to end</p>")
                f.write(f"<img src='{frame_file}' alt='Frame at {format_timestamp(last_time)}' /><br>")
                
                # Read and display transcript
                try:
                    with open(transcript_path, "r") as transcript_f:
                        transcript_text = transcript_f.read()
                        f.write(f"<h3>Transcript:</h3><p>{transcript_text}</p>")
                except:
                    f.write("<p>No transcript available for this segment.</p>")
        
        f.write("</body></html>")
    
    print(f"Summary report created at {report_path}")

# Example usage
if __name__ == "__main__":
    video_path = "Screen_Recording_20250314_110441_Chrome.mp4"
    output_folder = "video_analysis_output"
    extract_unique_frames_with_audio(video_path, output_folder, threshold=0.92, interval=15)
