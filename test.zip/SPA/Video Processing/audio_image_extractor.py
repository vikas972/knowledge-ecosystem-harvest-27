import cv2
from skimage.metrics import structural_similarity as ssim
import numpy as np
import os
import speech_recognition as sr
from pydub import AudioSegment
from pydub.silence import split_on_silence
import json
import math

def extract_unique_frames_with_audio(video_path, output_folder, threshold=0.95, interval=10):
    """
    Extract unique frames from a video with their timestamps,
    extract audio segments between unique frames, and convert to text.
    
    Args:
        video_path: Path to input video file
        output_folder: Folder to save extracted frames and audio data
        threshold: Similarity threshold for frames (lower = more frames)
        interval: Frame sampling interval
    """
    # Ensure output directories exist
    frames_folder = os.path.join(output_folder, "frames")
    audio_folder = os.path.join(output_folder, "audio_segments")
    os.makedirs(frames_folder, exist_ok=True)
    os.makedirs(audio_folder, exist_ok=True)
    
    # Initialize video capture
    cap = cv2.VideoCapture(video_path)
    success, prev_frame = cap.read()
    if not success:
        print("Failed to read video. Please check the video path.")
        return
    
    # Get video properties
    fps = cap.get(cv2.CAP_PROP_FPS)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    duration = frame_count / fps
    print(f"Video FPS: {fps}, Duration: {duration:.2f} seconds")
    
    # Extract audio from video
    video_name = os.path.splitext(os.path.basename(video_path))[0]
    audio_path = os.path.join(output_folder, f"{video_name}.wav")
    os.system(f"ffmpeg -i {video_path} -q:a 0 -map a {audio_path} -y")
    
    # List to store frame information
    frame_data = []
    
    # Save the first frame
    first_frame_path = os.path.join(frames_folder, f"frame_0.jpg")
    cv2.imwrite(first_frame_path, prev_frame)
    first_timestamp = 0
    frame_data.append({
        "frame_id": 0,
        "timestamp": first_timestamp,
        "timestamp_str": format_timestamp(first_timestamp),
        "image_path": first_frame_path,
        "text": ""
    })
    
    frame_id = 0
    unique_frame_count = 1
    
    # Process the video frame by frame
    while True:
        success, curr_frame = cap.read()
        if not success:
            break
            
        frame_id += 1
        
        if frame_id % interval == 0:
            # Convert frames to grayscale for comparison
            try:
                gray_prev = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)
                gray_curr = cv2.cvtColor(curr_frame, cv2.COLOR_BGR2GRAY)
                
                # Calculate SSIM to detect differences
                score, _ = ssim(gray_prev, gray_curr, full=True)
                
                # If frames are significantly different, save the current frame
                if score < threshold:
                    timestamp = frame_id / fps
                    frame_path = os.path.join(frames_folder, f"frame_{frame_id}.jpg")
                    cv2.imwrite(frame_path, curr_frame)
                    
                    print(f"Saved: frame_{frame_id}.jpg at time {format_timestamp(timestamp)}")
                    
                    # Add frame info to the list
                    frame_data.append({
                        "frame_id": frame_id,
                        "timestamp": timestamp,
                        "timestamp_str": format_timestamp(timestamp),
                        "image_path": frame_path,
                        "text": ""
                    })
                    
                    unique_frame_count += 1
                    prev_frame = curr_frame
            except Exception as e:
                print(f"Error processing frame {frame_id}: {e}")
                continue
    
    cap.release()
    print(f"Extracted {unique_frame_count} unique frames.")
    
    # Process audio segments between frames
    if len(frame_data) > 1:
        process_audio_segments(audio_path, frame_data, audio_folder)
    
    # Save frame data to JSON file
    data_path = os.path.join(output_folder, "frame_data.json")
    with open(data_path, 'w') as f:
        json.dump(frame_data, f, indent=4)
    
    print(f"Frame data saved to {data_path}")
    print("Processing completed.")

def format_timestamp(seconds):
    """Convert seconds to HH:MM:SS format"""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    msecs = int((seconds - math.floor(seconds)) * 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}.{msecs:03d}"

def process_audio_segments(audio_path, frame_data, audio_folder):
    """Process audio segments between unique frames and convert to text"""
    try:
        # Load the full audio file
        audio = AudioSegment.from_wav(audio_path)
        recognizer = sr.Recognizer()
        
        print("Processing audio segments...")
        
        # Process each segment between consecutive frames
        for i in range(len(frame_data) - 1):
            start_time = frame_data[i]["timestamp"] * 1000  # pydub uses milliseconds
            end_time = frame_data[i + 1]["timestamp"] * 1000
            
            # Extract audio segment
            segment = audio[start_time:end_time]
            
            # Skip very short segments
            if len(segment) < 500:  # Less than 0.5 seconds
                continue
                
            # Save audio segment
            segment_path = os.path.join(audio_folder, f"segment_{i}.wav")
            segment.export(segment_path, format="wav")
            
            # Convert audio to text
            try:
                with sr.AudioFile(segment_path) as source:
                    audio_data = recognizer.record(source)
                    text = recognizer.recognize_google(audio_data)
                    frame_data[i]["text"] = text
                    print(f"Transcribed segment {i}: {text}")
            except Exception as e:
                print(f"Error transcribing segment {i}: {e}")
                frame_data[i]["text"] = ""
    
    except Exception as e:
        print(f"Error processing audio: {e}")

# Example usage
if __name__ == "__main__":
    video_path = "Screen_Recording_20250314_110441_Chrome.mp4"
    output_folder = "video_analysis"
    extract_unique_frames_with_audio(video_path, output_folder)