import os
import asyncio
import sys
import json
from datetime import datetime

# Add the path to the backend directory to import the AssetInvoker
# sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'backend')))
from asset_invoker import AssetInvoker

class FrameTextConverter:
    def __init__(self, api_key, username, password, asset_id, input_folder, output_folder):
        """
        Initialize the FrameTextConverter with necessary credentials and paths.
        
        Args:
            api_key (str): API key for authentication
            username (str): Username for authentication
            password (str): Password for authentication
            asset_id (str): Asset ID for the image-to-text service
            input_folder (str): Folder containing image frames to process
            output_folder (str): Folder to save text output
        """
        self.asset_invoker = AssetInvoker(api_key, username, password, asset_id)
        self.input_folder = input_folder
        self.output_folder = output_folder
        
        # Create output folder if it doesn't exist
        os.makedirs(output_folder, exist_ok=True)
    
    def get_image_files(self, extensions=('.jpg', '.jpeg', '.png')):
        """
        Get all image files from the input folder.
        
        Args:
            extensions (tuple): File extensions to consider as images
            
        Returns:
            list: List of image file paths sorted by name
        """
        image_files = []
        for filename in os.listdir(self.input_folder):
            if filename.lower().endswith(extensions):
                image_files.append(os.path.join(self.input_folder, filename))
        return sorted(image_files)
    
    async def process_images_in_batches(self, batch_size=5):
        """
        Process images in batches to avoid overloading the API.
        
        Args:
            batch_size (int): Number of images to process in each batch
            
        Returns:
            dict: Mapping of image filenames to their text descriptions
        """
        image_files = self.get_image_files()
        results = {}
        
        # Process images in batches
        for i in range(0, len(image_files), batch_size):
            batch = image_files[i:i+batch_size]
            print(f"Processing batch {i//batch_size + 1}/{(len(image_files) + batch_size - 1)//batch_size}: {len(batch)} images")
            
            try:
                responses = await self.asset_invoker.invoke_asset(batch)
                
                # Map responses to their respective files
                for j, response in enumerate(responses):
                    image_path = batch[j]
                    filename = os.path.basename(image_path)
                    results[filename] = response
                    
                print(f"Successfully processed batch {i//batch_size + 1}")
            except Exception as e:
                print(f"Error processing batch starting at index {i}: {str(e)}")
                
            # Add a small delay between batches to avoid rate limiting
            if i + batch_size < len(image_files):
                await asyncio.sleep(2)
                
        return results
    
    def save_results(self, results):
        """
        Save results to individual text files and a combined JSON file.
        
        Args:
            results (dict): Mapping of image filenames to their text descriptions
        """
        # Save individual text files
        for filename, text in results.items():
            base_name = os.path.splitext(filename)[0]
            text_path = os.path.join(self.output_folder, f"{base_name}.txt")
            
            with open(text_path, 'w', encoding='utf-8') as f:
                f.write(text)
        
        # Save combined results to JSON
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        json_path = os.path.join(self.output_folder, f"combined_results_{timestamp}.json")
        
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2)
            
        print(f"Saved {len(results)} text descriptions to {self.output_folder}")
        print(f"Combined results saved to {json_path}")
    
    async def run(self, batch_size=5):
        """
        Run the complete conversion process.
        
        Args:
            batch_size (int): Number of images to process in each batch
        """
        print(f"Starting to process images from {self.input_folder}")
        results = await self.process_images_in_batches(batch_size)
        self.save_results(results)
        print("Processing complete!")

async def main():
    # Configuration - replace with your actual credentials and paths
    API_KEY = "magicplatform.7881874f7df9423d94b6fFd8ebd6e279"
    USERNAME = "igtb.abir"
    PASSWORD = "ASHsussbi@2001"
    # ASSET_ID = "322a7761-9781-48bd-8a09-f05248d501ba"
    ASSET_ID = "951f5446-c525-4f50-929b-9a959137208e"
    
    # Folders
    INPUT_FOLDER = "/home/vikasmayura/Desktop/SPA_Automation_Agent/SPA/Video Processing/unique_frames"  # Folder containing the frame images
    OUTPUT_FOLDER = "/home/vikasmayura/Desktop/SPA_Automation_Agent/SPA/Video Processing/frame_texts"  # Folder to save the text outputs
    
    # Create and run the converter
    converter = FrameTextConverter(
        api_key=API_KEY,
        username=USERNAME,
        password=PASSWORD,
        asset_id=ASSET_ID,
        input_folder=INPUT_FOLDER,
        output_folder=OUTPUT_FOLDER
    )
    
    await converter.run(batch_size=5)

if __name__ == "__main__":
    asyncio.run(main())