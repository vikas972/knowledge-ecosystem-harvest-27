# Advanced Video Processing Pipeline

This system provides a comprehensive video processing pipeline that:
1. Extracts unique frames with timestamps from videos
2. Transcribes audio segments between frame changes using OpenAI's Whisper
3. Converts each frame to text descriptions using PF's image-to-text asset
4. Combines frame descriptions with audio transcripts
5. Sends the combined analysis to PF's conversation asset for further insights

## Important Compatibility Note

**NumPy Version:** This script requires NumPy < 2.0.0 for compatibility with OpenCV. If you see errors like:
```
AttributeError: _ARRAY_API not found
ImportError: numpy.core.multiarray failed to import
```

Run the included fix script:
```
./fix_numpy.sh
```
This will downgrade NumPy to a compatible version.

## Features

### Video Frame Extraction
- Extracts unique frames based on visual differences (using structural similarity)
- Timestamps each extracted frame with precise time information
- Intelligently detects scene changes to minimize redundant frames

### Audio Processing
- Extracts audio segments between frame changes
- Transcribes audio using OpenAI's Whisper model
- Synchronizes audio segments with corresponding visual frames

### Image-to-Text Conversion
- Processes each extracted frame through PF's image-to-text asset
- Generates detailed text descriptions of visual content
- Organizes descriptions with corresponding frame timestamps

### Multimodal Analysis
- Combines visual frame descriptions with audio transcripts
- Creates comprehensive segment-by-segment analysis
- Generates HTML summary reports linking frames with their transcriptions

### AI-Powered Insights
- Sends combined analysis to PF's conversation asset
- Handles large content by processing in segments if needed
- Generates final summary analysis of the entire video content

## Components

The pipeline consists of several script files:

- `video_to_unique_image.py` - Extracts unique frames and transcribes audio
- `pf_asset_img_to_text.py` - Processes images through PF's image-to-text asset
- `invoke_pf_asset_with_text.py` - Interfaces with PF's conversation asset
- `asset_invoker.py` - Provides API integration with PF assets
- `video_analysis_pipeline.py` - Orchestrates the complete processing workflow

## Requirements

- Python 3.8+
- Dependencies listed in `requirements.txt`
- FFmpeg (required for MoviePy to process audio)
- Platform Foundation (PF) API credentials

## Installation

1. For the easiest setup, run the setup script:
   ```
   ./setup.sh
   ```
   
   This will:
   - Install NumPy 1.24.3 (compatible with OpenCV)
   - Install other required packages
   - Check for and install FFmpeg if needed

2. Alternatively, install dependencies manually:

   a. Install FFmpeg:
      ```
      # Ubuntu/Debian
      sudo apt-get install ffmpeg

      # macOS
      brew install ffmpeg

      # Windows
      # Download from https://ffmpeg.org/download.html
      ```

   b. Install Python dependencies:
      ```
      pip install numpy==1.24.3
      pip install -r requirements.txt
      ```

## Configuration

Update the following configuration values in `video_analysis_pipeline.py`:

```python
# Configuration
VIDEO_PATH = "your_video_file.mp4"
OUTPUT_FOLDER = "video_complete_analysis"

# Image-to-text asset configuration
IMG_TO_TEXT_API_KEY = "your_api_key_here"
IMG_TO_TEXT_USERNAME = "your_username_here"
IMG_TO_TEXT_PASSWORD = "your_password_here"
IMG_TO_TEXT_ASSET_ID = "your_image_to_text_asset_id_here"

# Conversation asset configuration
CONVERSATION_ASSET_ID = "your_conversation_asset_id_here"
```

## Usage

### Complete Pipeline

To run the complete analysis pipeline:

```bash
python video_analysis_pipeline.py
```

This will:
1. Extract unique frames from the video and save them with timestamps
2. Transcribe audio segments between frame changes
3. Convert frames to text descriptions using PF
4. Combine frame descriptions with audio transcripts
5. Send the combined analysis to PF for insights

### Individual Components

You can also run individual components separately:

**Extract Frames and Transcribe Audio:**
```bash
python video_to_unique_image.py
```

**Process Images to Text:**
```bash
python pf_asset_img_to_text.py
```

## Output

The script creates a structured output folder with:

- `frames/` - Extracted image frames with timestamps
- `audio/` - Audio segments extracted between frame changes
- `transcripts/` - Text transcriptions of audio segments
- `image_text/` - Text descriptions of extracted frames
- `combined_analysis/` - Combined analysis files including:
  - Individual segment files with frame descriptions and transcripts
  - `complete_analysis.txt` - Master file with all segment analyses
  - `pf_analysis_response.txt` or `final_analysis.txt` - AI-generated insights
- `summary_report.html` - Visual report linking frames with transcriptions

## Customization

You can customize the behavior by modifying these parameters:

- `threshold` (default: 0.92) - SSIM similarity threshold for frame extraction
- `interval` (default: 15) - Number of frames to skip between comparisons
- `batch_size` (default: 5) - Number of images to process in each batch

In `video_analysis_pipeline.py`:
```python
await pipeline.run_pipeline(threshold=0.92, interval=15, batch_size=5)
```

You can also modify the Whisper model size in the code:
- "base" - Faster processing, less accurate
- "small" - Good balance of speed and accuracy
- "medium" - More accurate but slower
- "large" - Most accurate but significantly slower

## Troubleshooting

- **Missing logger module**: If you encounter `ModuleNotFoundError: No module named 'logger'`, the logger references have been replaced with print statements in `invoke_pf_asset_with_text.py`.

- **NumPy compatibility issues**: Make sure to use NumPy < 2.0.0 for compatibility with OpenCV.

- **API connection issues**: Verify your API credentials and internet connection. 