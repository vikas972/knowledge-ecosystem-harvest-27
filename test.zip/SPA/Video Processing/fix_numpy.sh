#!/bin/bash

echo "Fixing NumPy compatibility for OpenCV..."

# Check if pip is installed
if ! command -v pip &> /dev/null; then
    echo "pip could not be found. Please install Python and pip."
    exit 1
fi

# Uninstall current NumPy
echo "Uninstalling current NumPy version..."
pip uninstall -y numpy

# Install compatible NumPy version
echo "Installing NumPy 1.24.3..."
pip install numpy==1.24.3

echo "NumPy fix completed! You should now be able to run the video processing pipeline without errors."
echo "Current NumPy version:"
pip show numpy | grep Version 