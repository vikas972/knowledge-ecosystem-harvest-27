import os
import asyncio
import requests as req
import time

# Credentials for PF agent
class PFImageToTextConfigs:
    api_key = "magicplatform.7881874f7df9423d94b6fFd8ebd6e279"
    username = "igtb.abir"
    password = "ASHsussbi@2001"
    asset_id = "322a7761-9781-48bd-8a09-f05248d501ba"

def get_access_token(headers):
    """
    Retrieve an access token using the provided headers.
    """
    value = ""
    res = req.get("https://api.intellectseecstag.com/accesstoken/idxpigtb", headers=headers)
    if res.status_code == 200:
        data = res.json()
        value = data.get('access_token', '')
    return value

def asset_post(asset_headers, asset_payload, files, asset_id):
    asset_response = req.post(
        "https://api.intellectseecstag.com/magicplatform/v1/invokeasset/" + asset_id + "/genai",
        headers=asset_headers, data=asset_payload, files=files)
    asset_data = asset_response.json()
    trace_id = asset_data["trace_id"]
    return trace_id

def get_chunks(asset_headers, trace_id, asset_id):
    status = ""
    while status != "COMPLETED":
        chunk_get = req.get(
            "https://api.intellectseecstag.com/magicplatform/v1/invokeasset/" + asset_id + "/" + trace_id,
            headers=asset_headers)
        data = chunk_get.json()
        try:
            if data.get('error_code') == "GenaiBaseException":
                raise Exception(data.get('error_description'))
        except Exception:
            pass
        time.sleep(2)
        status = data.get('status', '')
        if status == "COMPLETED":
            return data

def get_audio_transcription(image_path):
    """
    Get the audio transcription from the corresponding text file.
    For example, if image_path is frames/composite_00.jpg, look for frames/composite_00.txt
    """
    # Extract the base name and path
    dir_path = os.path.dirname(image_path)
    base_name = os.path.basename(image_path)
    name_without_ext = os.path.splitext(base_name)[0]
    
    # Construct the path to the text file
    text_file_path = os.path.join(dir_path, f"{name_without_ext}.txt")
    
    # Check if the text file exists
    if os.path.exists(text_file_path):
        try:
            with open(text_file_path, 'r') as file:
                return file.read().strip()
        except Exception as e:
            print(f"Error reading text file {text_file_path}: {e}")
            return ""
    else:
        print(f"Audio transcription file not found: {text_file_path}")
        return ""

def invoke_asset(asset_id, filepath):
    """
    Invoke a conversation asset with the given asset ID and retrieve the response.
    """
    headers_QA = {
        'apikey': PFImageToTextConfigs.api_key,
        'username': PFImageToTextConfigs.username,
        'password': PFImageToTextConfigs.password
    }
    access_token = get_access_token(headers_QA)
    asset_headers = {
        'Accept': 'application/json',
        'apikey': PFImageToTextConfigs.api_key,
        'Authorization': 'Bearer ' + access_token,
    }
    asset_payload = {}
    
    # Get audio transcription text for this image
    audio_text = get_audio_transcription(filepath)
    print(audio_text)
    
    files = [
        ('Image', ('document.png', open(filepath, 'rb'), 'image/jpeg')),
        ('Audio', ('audio.txt', audio_text, 'text/plain'))    # the agent has both audio and image input fields
    ]
    
    trace_id = asset_post(asset_headers, asset_payload, files, asset_id)
    output = get_chunks(asset_headers, trace_id, asset_id)
    return output["response"]["output"][0]["debug_logs"][0]["raw_response"]

async def process_frames():
    frames_folder = "unique_frames"
    if not os.path.isdir(frames_folder):
        print("Frames folder not found.")
        return ""
    
    # Filter and sort common image files (e.g. png, jpg, jpeg)
    image_files = sorted([f for f in os.listdir(frames_folder) if f.lower().endswith(('.png', '.jpg', '.jpeg'))])
    if not image_files:
        print("No image files found in frames folder.")
        return ""
    
    # Create absolute file paths instead of just file names
    image_paths = [os.path.abspath(os.path.join(frames_folder, f)) for f in image_files]
    
    descriptions = []
    for image_path in image_paths:
        try:
            if not os.path.exists(image_path):
                print(f"Warning: File does not exist: {image_path}")
                continue
                
            print(f"Processing: {image_path}")
            # Call the synchronous invoke_asset function in a separate thread to avoid blocking
            description = await asyncio.to_thread(invoke_asset, PFImageToTextConfigs.asset_id, image_path)
            print(f"Finished processing {os.path.basename(image_path)}")
            descriptions.append(description)
        except Exception as e:
            print(f"Error invoking PF asset for {os.path.basename(image_path)}: {e}")
            import traceback
            traceback.print_exc()
    
    combined_text = "\n".join(descriptions)
    return combined_text

if __name__ == "__main__":
    final_description = asyncio.run(process_frames())
    print(final_description)