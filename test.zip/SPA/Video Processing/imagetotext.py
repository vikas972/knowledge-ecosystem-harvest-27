import moviepy.editor as mp
import cv2
import pytesseract
from vosk import Model, KaldiRecognizer, SetLogLevel
import wave
import json

# Step 1: Extract audio from video (16kHz WAV for Vosk)
video = mp.VideoFileClip("input_video.mp4")
audio = video.audio
audio.write_audiofile("audio.wav", fps=16000)  # Save as 16kHz WAV

# Step 2: Transcribe audio using Vosk
SetLogLevel(0)
# Specify the path to your Vosk model (download from https://alphacephei.com/vosk/models)
model = Model("path/to/vosk-model")  # e.g., "vosk-model-small-en-us-0.15"
with wave.open("audio.wav", "rb") as wf:
    rec = KaldiRecognizer(model, wf.getframerate())
    rec.set_words(True)  # Enable word-level timestamps
    while True:
        data = wf.readframes(4000)
        if len(data) == 0:
            break
        rec.AcceptWaveform(data)
    result = json.loads(rec.FinalResult())
    words = result.get('result', [])  # List of words with 'start', 'end', 'word'

# Step 3: Group words into segments based on timing gaps
segments = []
if words:
    current_segment = {'start': words[0]['start'], 'end': words[0]['end'], 'text': words[0]['word']}
    for i in range(1, len(words)):
        if words[i]['start'] - words[i-1]['end'] > 0.5:  # 0.5-second threshold
            segments.append(current_segment)
            current_segment = {'start': words[i]['start'], 'end': words[i]['end'], 'text': words[i]['word']}
        else:
            current_segment['text'] += " " + words[i]['word']
            current_segment['end'] = words[i]['end']
    segments.append(current_segment)

# Step 4: Process video to extract UI elements for each segment
video_capture = cv2.VideoCapture("input_video.mp4")
fps = video_capture.get(cv2.CAP_PROP_FPS)
for segment in segments:
    midpoint_time = (segment['start'] + segment['end']) / 2
    frame_index = int(midpoint_time * fps)
    video_capture.set(cv2.CAP_PROP_POS_FRAMES, frame_index)
    ret, frame = video_capture.read()
    if ret:
        # Convert frame to grayscale for better OCR
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # Extract text using OCR
        text = pytesseract.image_to_string(gray)
        # Split text into unique words/elements (remove duplicates)
        ui_elements = set(text.split())
        segment['ui_elements'] = ui_elements
    else:
        segment['ui_elements'] = set()
video_capture.release()

# Step 5: Create structured description
description = ""
for segment in segments:
    step_description = segment['text']
    ui_elements = ", ".join(segment['ui_elements']) if 'ui_elements' in segment else "N/A"
    description += f"Step: {step_description}\nUI elements: {ui_elements}\n\n"

# Step 6: Output the description (print or save for LLM)
print(description)

# Optional: Save to a file
# with open("application_flow.txt", "w") as f:
#     f.write(description)