"""
This file is the common module to invoke Conversation Asset of PF.

PF is a Gen AI framework used to get LLM responses.
"""

import requests as req
import time


api_key = 'magicplatform.7881874f7df9423d94b6fFd8ebd6e279'

headers_QA = {'apikey': api_key,
              'username': 'gtb.rohitghule',
              'password': 'Intellect@2023'
              }


def get_access_token(headers):
    """
    Retrieve an access token using the provided headers.

    Args:
        headers (dict): The headers containing authentication details.

    Returns:
        str: The access token or an empty string if the token retrieval fails.
    """
    value = ""
    res = req.get("https://api.intellectseecstag.com/accesstoken/idxpigtb", headers=headers)
    if res.status_code == 200:
        data = res.json()
        value = data['access_token']
    else:
        print("Unable to create Access token")
    return value


def create_chat(asset_headers, payload):
    """
    Create a new chat conversation.

    Args:
        asset_headers (dict): The headers for the API request.
        payload (dict): The payload containing the conversation details.

    Returns:
        str: The conversation ID of the created chat.
    """
    response = req.post(
        "https://api.intellectseecstag.com/magicplatform/v1/genai/conversation/create",
        headers=asset_headers, json=payload).json()
    
    conversation_id = response['conversation_details']['conversation_id']
    return conversation_id


def asset_post(asset_headers, asset_payload):
    """
    Post a message to an existing chat conversation.

    Args:
        asset_headers (dict): The headers for the API request.
        asset_payload (dict): The payload containing the message details.

    Returns:
        str: The message ID of the posted message.
    """
    asset_post = req.post(
        "https://api.intellectseecstag.com/magicplatform/v1/genai/conversation/addmessage",
        headers=asset_headers, json=asset_payload)
    
    message_id = asset_post.json()['message_id']
    return message_id


def get_response(asset_headers, conversation_id, message_id):
    """
    Retrieve the response for a posted message in a chat conversation.

    Args:
        asset_headers (dict): The headers for the API request.
        conversation_id (str): The conversation ID.
        message_id (str): The message ID.

    Returns:
        tuple: A tuple containing the response text and the total cost of the response.
    """
    while True:
        try:
            response = req.get(
                f"https://api.intellectseecstag.com/magicplatform/v1/genai/conversation/response/{conversation_id}/{message_id}",
                headers=asset_headers)
        except Exception as e:
            access_token = get_access_token(headers_QA)
            asset_headers = {
                'Content-Type': 'application/json',
                'apikey': api_key,
                'Authorization': 'Bearer ' + access_token,
            }
            
        try:
            response_ = response.json()
            if response_['error_code'] == "GenaiBaseException":
                print(f"PF Error: Failed with {response_['error_description']}")
                raise Exception(response_['error_description'])
        except:
            pass
        

        try:
            res = response.json()['message_content'][0]['response']
            cost = response.json()['message_content'][0]['metrics']['total_cost']
            return res, cost
        except:
            print("Waiting for response from PF...")
            time.sleep(4)


def invoke_asset(asset_id, query):
    """
    Invoke a conversation asset with the given query and retrieve the response.

    Args:
        asset_id (str): The asset ID to be invoked.
        query (str): The query to be sent to the asset.

    Returns:
        tuple: A tuple containing the response text and the total cost of the response.
    """
    print("Getting access token")
    access_token = get_access_token(headers_QA)
    asset_headers = {
        'Content-Type': 'application/json',
        'apikey': api_key,
        'Authorization': 'Bearer ' + access_token,
    }

    # Create conversation
    print("Creating conversation")
    create_payload = {"conversation_name": "hi", "asset_version_id": asset_id, "mode": "EXPERIMENT"}
    conversation_id = create_chat(asset_headers, create_payload)
    print(f"Conversation id is: {conversation_id}")

    # Invoke asset
    print("Invoking asset")
    asset_payload = {"conversation_id": conversation_id, "query": query, "KB_Types": []}
    message_id = asset_post(asset_headers, asset_payload)
    print(f"Message id is: {message_id}")

    # Get response
    output = get_response(asset_headers, conversation_id, message_id)
    print(f"Response from the PF: {output}")
    
    return output

# asset_id = "abe88ecb-c101-4fff-b044-80b4fea30c39"
# query = """VIDEO ANALYSIS COMPLETE REPORT
# ================================================================================

# SEGMENT: 00:00:00.000 to 00:01:11.899
# TIME: 0.00 seconds to 71.90 seconds

# IMAGE DESCRIPTION:
# Here is the extracted text from the presentation slides in markdown format:

# # The CBX Application

# - Broadly, CBX is divided into the CBX Back Office (CBX BO) & the CBX Front Office (CBX FO)

# ## CBX Back Office (Accessed by bank users)
# - Corporate user administration by bank or corporate admin
# - Facilitates corporate & user setup & maintenance 
# - User activity audit reports for better control
# - Enables secured password management features

# ## CBX Front Office (Accessed by corporate users)
# - Role based authorization workflow & function based entitlements
# - File uploads & imports
# - User setup can be done by corporate user w/o recourse to the bank
# - Facility for transaction servicing, inquiries & reports

# # Back Office Functions

# Typically, the Back Office performs functions such as:

# - Registering of corporates for CBX using customer profile
# - Defining the criteria to entitle corporate users for accessing products or sub-products
# - Defining user roles as appropriate to titles in the corporate
# - Defining transaction workflow rules
# - Creating corporate admin users etc.

# *Note: The presentation appears to be a training or overview document about a CBX (Corporate Banking Experience) system's structure and functionality.*

# AUDIO TRANSCRIPT:
# [Time window: 00:00:00.000 to 00:01:11.899]

#  solution that offers corporates a consistent and individualized experience. Essentially, the CBX has broken down transaction banking processes into a set of more than 300 apps, each of which delivers a specific banking function. The solution allows segmentation, creation of roles and personas, personalized themes, targeted campaigns, branding and so on. Through CBX, banks can offer their corporate clients a uniform, only channel experience across diverse touchpoints such as the internet, tablets, mobile phones and so on. Without any additional coding. The application has two components, the back office and the front office. In the current presentation, you will learn about the back office application of the CBX. There are separate videos which cover the front office. So let us take a deep dive into what is the CBX back office.

# --------------------------------------------------------------------------------

# SEGMENT: 00:01:11.899 to 00:02:29.163
# TIME: 71.90 seconds to 149.16 seconds

# IMAGE DESCRIPTION:


# AUDIO TRANSCRIPT:
# [Time window: 00:01:11.899 to 00:02:29.163]

#  Let us first understand these terms back office and front office. The back office is essentially an application that is installed at the implementing bank and is used by the bank users to administer the CBX functionality. Essential functions such as creation of administrative users, grant of access rights, monitoring and control functions besides registration of corporate customers, linkage to business products, modules and functionalities, workflow rules etc are done in the back office application. On the other hand, the front office application is used by the corporate users, that is by the customers of the implementing bank. It allows corporate users to initiate and authorize business transactions, perform queries, generate reports and monitor the status of their business banking activities with the bank. The back office setup is required to make the front office work. In this video, we will learn about how this setup is created by the implementing bank.

# --------------------------------------------------------------------------------

# SEGMENT: 00:02:29.163 to 00:02:32.383
# TIME: 149.16 seconds to 152.38 seconds

# IMAGE DESCRIPTION:


# AUDIO TRANSCRIPT:
# [Time window: 00:02:29.163 to 00:02:32.383]

#  Typically, these are the type of functions

# --------------------------------------------------------------------------------

# SEGMENT: 00:02:32.383 to 00:03:24.966
# TIME: 152.38 seconds to 204.97 seconds

# IMAGE DESCRIPTION:


# AUDIO TRANSCRIPT:
# [Time window: 00:02:32.383 to 00:03:24.966]

#  that the back office performs. Actions such as registering of corporates for using CBX, defining the entitlement criteria, the user rules, the transaction workflow rules, creation of admin users and so on. All of this would be configured in the back office application initially when the CBX is implemented by the bank or when a new customer is enrolled for CBX access. Besides, the back office also performs validations when users initiate transactions from the front office. We will take a detailed look at how these configurations are done in the subsequent slides. So let us now take a deeper look at the CBX back office.

# --------------------------------------------------------------------------------

# SEGMENT: 00:03:24.966 to end
# TIME: 204.97 seconds to end

# IMAGE DESCRIPTION:


# AUDIO TRANSCRIPT:
# [Time window: 00:03:24.966 to 00:03:25.234]



# --------------------------------------------------------------------------------
# """
# invoke_asset(asset_id, query)