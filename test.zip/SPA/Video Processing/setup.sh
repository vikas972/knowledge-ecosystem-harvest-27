#!/bin/bash

echo "Setting up Video Processing Pipeline..."

# Check if pip is installed
if ! command -v pip &> /dev/null; then
    echo "pip could not be found. Please install Python and pip."
    exit 1
fi

# Check for FFmpeg
if ! command -v ffmpeg &> /dev/null; then
    echo "FFmpeg not found. Attempting to install..."
    
    # Check the OS
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux
        echo "Detected Linux system"
        sudo apt-get update
        sudo apt-get install -y ffmpeg
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        echo "Detected macOS system"
        if command -v brew &> /dev/null; then
            brew install ffmpeg
        else
            echo "Homebrew not found. Please install Homebrew or FFmpeg manually."
            echo "Visit: https://brew.sh/ or https://ffmpeg.org/download.html"
        fi
    else
        # Windows or other
        echo "Detected Windows or unsupported system"
        echo "Please install FFmpeg manually from: https://ffmpeg.org/download.html"
    fi
else
    echo "FFmpeg is already installed."
fi

# Install compatible NumPy version
echo "Installing NumPy 1.24.3 for compatibility with OpenCV..."
pip install numpy==1.24.3

# Install other dependencies
echo "Installing Python dependencies..."
pip install -r requirements.txt

echo "Setup completed! You can now run the video processing pipeline."
echo "To analyze a video, update the configuration in video_analysis_pipeline.py and run:"
echo "python video_analysis_pipeline.py" 