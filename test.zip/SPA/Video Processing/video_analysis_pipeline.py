"""
Video Analysis Pipeline
----------------------
This script combines:
1. Extracting unique frames with timestamps from videos
2. Converting those frames to text descriptions using PF's image-to-text asset
3. Combining frame descriptions with audio transcripts
4. Sending the combined data to PF's conversation asset
"""

import os
import asyncio
import sys
import json
from datetime import datetime
import cv2
from skimage.metrics import structural_similarity as ssim
import numpy as np
import whisper
from moviepy.editor import VideoFileClip
import time

# Import the necessary modules
from asset_invoker import AssetInvoker
import invoke_pf_asset_with_text as conversation_invoker

class VideoAnalysisPipeline:
    def __init__(self, video_path, output_folder, 
                 img_to_text_api_key, img_to_text_username, img_to_text_password, img_to_text_asset_id,
                 conversation_asset_id):
        """
        Initialize the video analysis pipeline.
        
        Args:
            video_path: Path to the video file
            output_folder: Base folder for all outputs
            img_to_text_api_key: API key for image-to-text service
            img_to_text_username: Username for image-to-text service
            img_to_text_password: Password for image-to-text service
            img_to_text_asset_id: Asset ID for image-to-text service
            conversation_asset_id: Asset ID for conversation service
        """
        self.video_path = video_path
        self.base_output_folder = output_folder
        self.frames_folder = os.path.join(output_folder, "frames")
        self.audio_folder = os.path.join(output_folder, "audio")
        self.transcripts_folder = os.path.join(output_folder, "transcripts")
        self.image_text_folder = os.path.join(output_folder, "image_text")
        self.combined_folder = os.path.join(output_folder, "combined_analysis")
        
        # Ensure all output directories exist
        for folder in [self.frames_folder, self.audio_folder, self.transcripts_folder, 
                      self.image_text_folder, self.combined_folder]:
            os.makedirs(folder, exist_ok=True)
        
        # Image-to-text asset configuration
        self.img_to_text_api_key = img_to_text_api_key
        self.img_to_text_username = img_to_text_username
        self.img_to_text_password = img_to_text_password
        self.img_to_text_asset_id = img_to_text_asset_id
        
        # Conversation asset configuration
        self.conversation_asset_id = conversation_asset_id
        
        # Initialize frame timestamps list
        self.frame_timestamps = []
        
    async def run_pipeline(self, threshold=0.92, interval=15, batch_size=5):
        """
        Run the complete analysis pipeline.
        
        Args:
            threshold: Similarity threshold for frame comparison (lower means more frames saved)
            interval: Number of frames to skip between comparisons
            batch_size: Number of images to process in each batch for image-to-text
        """
        print("STEP 1: Extracting unique frames and transcribing audio...")
        # Extract frames and transcribe audio
        self.extract_unique_frames_with_audio(threshold, interval)
        
        print("\nSTEP 2: Converting frames to text descriptions...")
        # Convert frames to text
        img_to_text_results = await self.process_frames_to_text(batch_size)
        
        print("\nSTEP 3: Combining frame descriptions with audio transcripts...")
        # Combine image descriptions with audio transcripts
        combined_results = self.combine_image_and_audio()
        
        print("\nSTEP 4: Sending combined analysis to conversation asset...")
        # Send combined analysis to conversation asset
        self.send_to_conversation_asset(combined_results)
        
        print("\nAnalysis pipeline completed successfully!")
        
    def extract_unique_frames_with_audio(self, threshold=0.92, interval=15):
        """Extract unique frames and transcribe audio segments between frame changes."""
        # Load video
        cap = cv2.VideoCapture(self.video_path)
        success, prev_frame = cap.read()
        if not success:
            print("Failed to read video. Please check the video path.")
            return
        
        # Get video properties
        video_fps = cap.get(cv2.CAP_PROP_FPS)
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        video_duration = frame_count / video_fps
        print(f"Video FPS: {video_fps}, Duration: {video_duration:.2f} seconds")
        
        # Load the video for audio extraction
        video_clip = VideoFileClip(self.video_path)
        
        # Load Whisper model for audio transcription
        print("Loading Whisper model...")
        model = whisper.load_model("base")  # Use "base" for faster processing
        
        # Save the first frame
        frame_id = 0
        first_frame_time = 0
        first_frame_path = os.path.join(self.frames_folder, f"frame_{first_frame_time:.2f}sec_{self.format_timestamp(first_frame_time)}.jpg")
        cv2.imwrite(first_frame_path, prev_frame)
        print(f"Saved: {first_frame_path}")
        
        self.frame_timestamps = [first_frame_time]
        frame_id = 1
        
        current_time = 0
        last_unique_frame_time = 0
        
        while True:
            # Skip frames according to interval
            for _ in range(interval):
                success, _ = cap.read()
                if not success:
                    break
                frame_id += 1
                
            # Read the next frame after skipping
            success, curr_frame = cap.read()
            if not success:
                break
                
            # Calculate current time in the video
            current_time = frame_id / video_fps
            
            # Convert frames to grayscale for comparison
            gray_prev = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)
            gray_curr = cv2.cvtColor(curr_frame, cv2.COLOR_BGR2GRAY)
            
            # Calculate SSIM to detect differences
            score, _ = ssim(gray_prev, gray_curr, full=True)
            
            if score < threshold:
                # Save the unique frame with timestamp in seconds in the filename
                frame_path = os.path.join(self.frames_folder, f"frame_{current_time:.2f}sec_{self.format_timestamp(current_time)}.jpg")
                cv2.imwrite(frame_path, curr_frame)
                print(f"Saved frame at {self.format_timestamp(current_time)}, ID: {frame_id}, Time: {current_time:.2f} seconds")
                
                # Extract and transcribe audio segment between the last unique frame and this one
                if len(self.frame_timestamps) > 0:
                    self.extract_and_transcribe_audio_segment(
                        video_clip, 
                        last_unique_frame_time, 
                        current_time, 
                        model
                    )
                
                # Update variables for next comparison
                prev_frame = curr_frame
                last_unique_frame_time = current_time
                self.frame_timestamps.append(current_time)
            
            frame_id += 1
        
        # Handle the last audio segment (from the last unique frame to the end)
        if last_unique_frame_time < video_duration:
            self.extract_and_transcribe_audio_segment(
                video_clip,
                last_unique_frame_time,
                video_duration,
                model
            )
        
        # Release resources
        cap.release()
        video_clip.close()
        print("Frame extraction and audio transcription completed.")
        
    def format_timestamp(self, seconds):
        """Convert seconds to HH:MM:SS.mss format"""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        seconds = seconds % 60
        return f"{hours:02d}_{minutes:02d}_{seconds:06.3f}".replace(".", "_")
    
    def format_readable_timestamp(self, seconds):
        """Convert seconds to a human-readable HH:MM:SS format"""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = seconds % 60
        return f"{hours:02d}:{minutes:02d}:{secs:06.3f}"
    
    def extract_and_transcribe_audio_segment(self, video_clip, start_time, end_time, whisper_model):
        """Extract audio segment and transcribe it using Whisper"""
        segment_id = self.format_timestamp(start_time)
        
        # Extract audio segment
        print(f"Extracting audio from {self.format_timestamp(start_time)} to {self.format_timestamp(end_time)}")
        segment_duration = end_time - start_time
        # Update audio filename to include time window
        audio_path = os.path.join(self.audio_folder, f"audio_{start_time:.2f}sec_to_{end_time:.2f}sec_{segment_id}.wav")
        
        try:
            # Extract the audio segment
            audio_segment = video_clip.subclip(start_time, end_time)
            audio_segment.audio.write_audiofile(audio_path, logger=None)
            
            # Transcribe the audio segment
            print(f"Transcribing audio segment {segment_id}...")
            transcript = whisper_model.transcribe(audio_path)
            
            # Add time window information to the transcript content
            timestamp_info = f"[Time window: {self.format_readable_timestamp(start_time)} to {self.format_readable_timestamp(end_time)}]\n\n"
            transcript_text = timestamp_info + transcript["text"]
            
            # Save transcription with time window in filename
            transcript_path = os.path.join(self.transcripts_folder, f"transcript_{start_time:.2f}sec_to_{end_time:.2f}sec_{segment_id}.txt")
            with open(transcript_path, "w") as f:
                f.write(transcript_text)
            
            print(f"Saved transcription for segment {segment_id} ({start_time:.2f}sec to {end_time:.2f}sec)")
            return transcript_text
        except Exception as e:
            print(f"Error processing audio segment {segment_id}: {str(e)}")
            return ""
        
    async def process_frames_to_text(self, batch_size=5):
        """Process extracted frames using image-to-text asset."""
        # Initialize the AssetInvoker
        asset_invoker = AssetInvoker(
            self.img_to_text_api_key,
            self.img_to_text_username,
            self.img_to_text_password,
            self.img_to_text_asset_id
        )
        
        # Get all image files
        image_files = []
        for filename in os.listdir(self.frames_folder):
            if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
                image_files.append(os.path.join(self.frames_folder, filename))
        
        image_files = sorted(image_files)
        results = {}
        
        # Process images in batches
        for i in range(0, len(image_files), batch_size):
            batch = image_files[i:i+batch_size]
            print(f"Processing batch {i//batch_size + 1}/{(len(image_files) + batch_size - 1)//batch_size}: {len(batch)} images")
            
            try:
                responses = await asset_invoker.invoke_asset(batch)
                
                # Map responses to their respective files
                for j, response in enumerate(responses):
                    image_path = batch[j]
                    filename = os.path.basename(image_path)
                    results[filename] = response
                    
                    # Save individual text description
                    text_path = os.path.join(self.image_text_folder, f"{os.path.splitext(filename)[0]}_description.txt")
                    with open(text_path, 'w', encoding='utf-8') as f:
                        f.write(response)
                    
                print(f"Successfully processed batch {i//batch_size + 1}")
            except Exception as e:
                print(f"Error processing batch starting at index {i}: {str(e)}")
                
            # Add a small delay between batches to avoid rate limiting
            if i + batch_size < len(image_files):
                await asyncio.sleep(2)
        
        # Save combined results to JSON
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        json_path = os.path.join(self.image_text_folder, f"image_descriptions_{timestamp}.json")
        
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2)
            
        print(f"Saved {len(results)} image descriptions to {self.image_text_folder}")
        print(f"Combined results saved to {json_path}")
        
        return results
    
    def combine_image_and_audio(self):
        """Combine image descriptions with audio transcripts."""
        combined_results = []
        
        for i in range(len(self.frame_timestamps) - 1):
            start_time = self.frame_timestamps[i]
            end_time = self.frame_timestamps[i+1]
            
            # Find the corresponding frame file
            frame_files = [f for f in os.listdir(self.frames_folder) 
                         if f.startswith(f"frame_{start_time:.2f}sec_") and f.endswith(".jpg")]
            
            if not frame_files:
                continue
                
            frame_file = frame_files[0]
            
            # Find the corresponding image text description
            image_text_file = os.path.join(self.image_text_folder, f"{os.path.splitext(frame_file)[0]}_description.txt")
            image_description = ""
            if os.path.exists(image_text_file):
                with open(image_text_file, 'r', encoding='utf-8') as f:
                    image_description = f.read()
            
            # Find the corresponding transcript
            transcript_files = [f for f in os.listdir(self.transcripts_folder) 
                              if f.startswith(f"transcript_{start_time:.2f}sec_to_")]
            
            transcript_text = ""
            if transcript_files:
                transcript_path = os.path.join(self.transcripts_folder, transcript_files[0])
                if os.path.exists(transcript_path):
                    with open(transcript_path, 'r', encoding='utf-8') as f:
                        transcript_text = f.read()
            
            # Combine the image description and transcript
            segment_info = f"SEGMENT: {self.format_readable_timestamp(start_time)} to {self.format_readable_timestamp(end_time)}\n"
            segment_info += f"TIME: {start_time:.2f} seconds to {end_time:.2f} seconds\n\n"
            
            combined_text = f"{segment_info}IMAGE DESCRIPTION:\n{image_description}\n\nAUDIO TRANSCRIPT:\n{transcript_text}\n\n"
            combined_text += "-" * 80 + "\n\n"
            
            # Save the combined text
            combined_file = os.path.join(self.combined_folder, f"segment_{start_time:.2f}sec_to_{end_time:.2f}sec_combined.txt")
            with open(combined_file, 'w', encoding='utf-8') as f:
                f.write(combined_text)
            
            combined_results.append({
                "segment": f"{start_time:.2f}sec_to_{end_time:.2f}sec",
                "start_time": start_time,
                "end_time": end_time,
                "image_file": frame_file,
                "image_description": image_description,
                "audio_transcript": transcript_text,
                "combined_text": combined_text
            })
        
        # Handle the last frame
        if len(self.frame_timestamps) > 0:
            last_time = self.frame_timestamps[-1]
            
            # Find the corresponding frame file
            frame_files = [f for f in os.listdir(self.frames_folder) 
                         if f.startswith(f"frame_{last_time:.2f}sec_") and f.endswith(".jpg")]
            
            if frame_files:
                frame_file = frame_files[0]
                
                # Find the corresponding image text description
                image_text_file = os.path.join(self.image_text_folder, f"{os.path.splitext(frame_file)[0]}_description.txt")
                image_description = ""
                if os.path.exists(image_text_file):
                    with open(image_text_file, 'r', encoding='utf-8') as f:
                        image_description = f.read()
                
                # Find the corresponding transcript
                transcript_files = [f for f in os.listdir(self.transcripts_folder) 
                                  if f.startswith(f"transcript_{last_time:.2f}sec_to_")]
                
                transcript_text = ""
                if transcript_files:
                    transcript_path = os.path.join(self.transcripts_folder, transcript_files[0])
                    if os.path.exists(transcript_path):
                        with open(transcript_path, 'r', encoding='utf-8') as f:
                            transcript_text = f.read()
                
                # Combine the image description and transcript
                segment_info = f"SEGMENT: {self.format_readable_timestamp(last_time)} to end\n"
                segment_info += f"TIME: {last_time:.2f} seconds to end\n\n"
                
                combined_text = f"{segment_info}IMAGE DESCRIPTION:\n{image_description}\n\nAUDIO TRANSCRIPT:\n{transcript_text}\n\n"
                combined_text += "-" * 80 + "\n\n"
                
                # Save the combined text
                combined_file = os.path.join(self.combined_folder, f"segment_{last_time:.2f}sec_to_end_combined.txt")
                with open(combined_file, 'w', encoding='utf-8') as f:
                    f.write(combined_text)
                
                combined_results.append({
                    "segment": f"{last_time:.2f}sec_to_end",
                    "start_time": last_time,
                    "end_time": None,
                    "image_file": frame_file,
                    "image_description": image_description,
                    "audio_transcript": transcript_text,
                    "combined_text": combined_text
                })
        
        # Create a master combined file with all segments
        all_combined_text = "VIDEO ANALYSIS COMPLETE REPORT\n"
        all_combined_text += "=" * 80 + "\n\n"
        
        for segment in combined_results:
            all_combined_text += segment["combined_text"]
        
        # Save the master combined file
        master_file = os.path.join(self.combined_folder, "complete_analysis.txt")
        with open(master_file, 'w', encoding='utf-8') as f:
            f.write(all_combined_text)
        
        print(f"Created {len(combined_results)} combined segment files")
        print(f"Master combined file saved to {master_file}")
        
        return combined_results
    
    def send_to_conversation_asset(self, combined_results):
        """Send combined analysis to conversation asset for further processing."""
        # Read the complete analysis file
        master_file = os.path.join(self.combined_folder, "complete_analysis.txt")
        with open(master_file, 'r', encoding='utf-8') as f:
            complete_analysis = f.read()
        
        # Prepare the query for the conversation asset
        query = f"Analyze the following video content which includes image descriptions and audio transcripts:\n\n{complete_analysis}"
        
        # Check if content is too long, and if so, process segment by segment
        if len(query) > 32000:  # Assuming a token limit
            print("Complete analysis too long, processing segment by segment...")
            
            # Process each segment individually
            segment_responses = []
            for i, segment in enumerate(combined_results):
                segment_query = f"Analyze this segment of video content (segment {i+1}/{len(combined_results)}):\n\n{segment['combined_text']}"
                
                print(f"Sending segment {i+1}/{len(combined_results)} to conversation asset...")
                try:
                    response, cost = conversation_invoker.invoke_asset(self.conversation_asset_id, segment_query)
                    segment_responses.append(response)
                    print(f"Response received for segment {i+1}. Cost: {cost}")
                except Exception as e:
                    print(f"Error processing segment {i+1}: {str(e)}")
                
                # Save individual segment responses
                segment_response_file = os.path.join(self.combined_folder, f"segment_{i+1}_response.txt")
                with open(segment_response_file, 'w', encoding='utf-8') as f:
                    f.write(response)
                
                # Add a small delay between requests
                time.sleep(2)
            
            # Combine all segment responses
            all_responses = "\n\n".join([f"SEGMENT {i+1} ANALYSIS:\n{resp}" for i, resp in enumerate(segment_responses)])
            
            # Send a summary request
            summary_query = f"Create a summary analysis of the following segment analyses from a video:\n\n{all_responses}"
            
            print("Sending summary request to conversation asset...")
            try:
                final_response, cost = conversation_invoker.invoke_asset(self.conversation_asset_id, summary_query)
                print(f"Final summary response received. Cost: {cost}")
            except Exception as e:
                print(f"Error processing summary: {str(e)}")
                final_response = "Error generating summary."
            
            # Save the final response
            final_response_file = os.path.join(self.combined_folder, "final_analysis.txt")
            with open(final_response_file, 'w', encoding='utf-8') as f:
                f.write(final_response)
            
            print(f"Final analysis saved to {final_response_file}")
            
        else:
            # Send the complete analysis in one request
            print("Sending complete analysis to conversation asset...")
            try:
                response, cost = conversation_invoker.invoke_asset(self.conversation_asset_id, query)
                print(f"Response received. Cost: {cost}")
                
                # Save the response
                response_file = os.path.join(self.combined_folder, "pf_analysis_response.txt")
                with open(response_file, 'w', encoding='utf-8') as f:
                    f.write(response)
                
                print(f"Analysis response saved to {response_file}")
            except Exception as e:
                print(f"Error processing with conversation asset: {str(e)}")

async def main():
    # Configuration
    VIDEO_PATH = "/home/vikasmayura/Downloads/SPA_design.mp4"
    OUTPUT_FOLDER = "video_complete_analysis"
    
    # Image-to-text asset configuration
    IMG_TO_TEXT_API_KEY = "magicplatform.7881874f7df9423d94b6fFd8ebd6e279"
    IMG_TO_TEXT_USERNAME = "igtb.abir"
    IMG_TO_TEXT_PASSWORD = "ASHsussbi@2001"
    IMG_TO_TEXT_ASSET_ID = "951f5446-c525-4f50-929b-9a959137208e"
    
    # Conversation asset configuration
    CONVERSATION_ASSET_ID = "abe88ecb-c101-4fff-b044-80b4fea30c39"
    
    # Create and run the pipeline
    pipeline = VideoAnalysisPipeline(
        video_path=VIDEO_PATH,
        output_folder=OUTPUT_FOLDER,
        img_to_text_api_key=IMG_TO_TEXT_API_KEY,
        img_to_text_username=IMG_TO_TEXT_USERNAME,
        img_to_text_password=IMG_TO_TEXT_PASSWORD,
        img_to_text_asset_id=IMG_TO_TEXT_ASSET_ID,
        conversation_asset_id=CONVERSATION_ASSET_ID
    )
    
    await pipeline.run_pipeline(threshold=0.92, interval=15, batch_size=5)

if __name__ == "__main__":
    asyncio.run(main()) 