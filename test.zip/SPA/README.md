# SPA Automation Agent

## Project Structure

```
backend/
├── app/
│   ├── main.py
│   ├── api/
│   │   ├── v1/
│   │   │   ├── endpoints/
│   │   │   │   ├── generator/
│   │   │   │   │   ├── requirements.py    
│   │   │   │   │   ├── scenarios.py      
│   │   │   │   │   ├── test_cases.py      
│   │   │   │   │   ├── test_data.py      
│   │   │   │   │   └── ...
│   │   │   │   ├── file_processing/
│   │   │   │   │   ├── file_upload.py        # e.g. upload, download
│   │   │   │   │   ├── file_convert.py       # e.g. doc-to-text, PDF parsing
│   │   │   │   │   └── ...
│   │   │   │   ├── llm/
│   │   │   │   │   ├── completion.py         # GPT completions
│   │   │   │   │   ├── embeddings.py         # embeddings, semantic search
│   │   │   │   │   └── ...
│   │   │   │   └── user.py                   # user management (optional)
│   │   │   └── api_router.py                 # aggregator of sub-routers
│   │   └── deps.py                           # common dependencies (DB, security, etc.)
│   ├── core/
│   │   ├── config.py                         # environment variables, secrets, DB URLs
│   │   ├── security.py                       # JWT, password hashing
│   │   ├── celery_app.py                     # Celery or RQ for background tasks
│   │   └── logging_config.py                 # optional unified logging setup
│   ├── db/
│   │   ├── base.py                           # SQLAlchemy Base
│   │   ├── session.py                        # SessionLocal, engine
│   │   └── migrations/                       # Alembic/DB migrations
│   ├── models/
│   │   ├── generator/
│   │   │   ├── requirement.py
│   │   │   ├── scenario.py
│   │   │   ├── test_case.py
│   │   │   └── test_data.py
│   │   ├── file_processing/
│   │   │   └── file_record.py                # store metadata if you want DB records
│   │   ├── llm/
│   │   │   └── llm_usage.py                  # optional - track usage logs?
│   │   └── user.py                           # user model (if relevant)
│   ├── schemas/
│   │   ├── generator/
│   │   │   ├── requirement.py
│   │   │   ├── scenario.py
│   │   │   ├── test_case.py
│   │   │   └── test_data.py
│   │   ├── file_processing/
│   │   │   └── file.py
│   │   ├── llm/
│   │   │   └── completion.py
│   │   └── user.py
│   ├── services/
│   │   ├── generator/
│   │   │   ├── requirement_parser.py       # Stage 1
│   │   │   ├── scenario_generator.py       # Stage 2
│   │   │   ├── test_case_generator.py      # Stage 3
│   │   │   ├── test_data_generator.py      # Stage 4
│   │   │   ├── generator_workflow.py       # Orchestrating the generator steps
│   │   ├── file_processing/
│   │   │   ├── file_service.py            # saving, retrieving files
│   │   │   ├── file_conversion_service.py # doc2text, PDF parse, etc.
│   │   │   └── ...
│   │   ├── llm/
│   │   │   ├── llm_service.py             # GPT completions, embeddings, etc.
│   │   │   └── ...
│   │   ├── user_service.py                # register, login, user ops
│   │   └── ...
│   ├── utils/
│   │   ├── integration/
│   │   │   ├── jira_client.py
│   │   │   ├── zephyr_client.py
│   │   │   └── ...
│   │   ├── background_tasks.py            # Celery or RQ tasks
│   │   ├── file_storage.py                # read/write to disk or cloud
│   │   ├── gpt_utils.py                   # specialized GPT calls if needed
│   │   └── common.py                      # shared helpers
│   └── tests/
│       ├── test_generator/
│       │   └── ...
│       ├── test_file_processing/
│       │   └── ...
│       ├── test_llm/
│       │   └── ...
│       ├── test_users.py
│       └── ...
├── uploads/                               # local storage if needed
├── Dockerfile
├── docker-compose.yml
├── pyproject.toml / requirements.txt
├── .env
└── README.md
```

## Data Migration

To migrate the database to a server, follow these steps:

1. **Ensure Database Server is Running**: Make sure that the PostgreSQL server is installed and running on your server.

2. **Set Up Environment Variables**: Ensure that your environment variables (like database URL, user, password) are correctly set on the server. You can use a `.env` file or set them directly in the server's environment.

3. **Install Dependencies**: Make sure all the necessary Python packages are installed on the server. You can do this by running:
   ```bash
   pip install -r requirements.txt
   ```

4. **Create the Database**: If the database does not exist, create it using a command like:
   ```bash
   createdb spa_automation_ea
   ```
   You might need to use `sudo -u postgres` or the appropriate user with permissions to create databases.

5. **Run Alembic Migrations**: Use Alembic to apply the migrations and create the tables in the database. Run the following command:
   ```bash
   alembic upgrade head
   ```
   This command will apply all the migrations and set up your database schema as defined in your migration scripts.

6. **Verify the Setup**: Check if the tables are created correctly and the application can connect to the database without issues.

### Summary of Commands to Run on the Server:

```bash
# Install dependencies
pip install -r requirements.txt

# Create the database (if not already created)
sudo -u postgres createdb spa_automation_ea

# uncomment this line in db/base.py
from app.models.user import User

# Run migrations
alembic upgrade head

# recomment this line in db/base.py
from app.models.user import User
```

## Node.js Setup and Running Instructions

To set up and run the Node.js environment, follow these steps:

1. **Install Node.js and npm**: Make sure Node.js and npm (Node Package Manager) are installed on your system. You can download them from [nodejs.org](https://nodejs.org/).

2. **Verify Installation**: Check if Node.js and npm are installed correctly by running the following commands:
   ```bash
   node -v
   npm -v
   ```
   These commands should display the installed versions of Node.js and npm.

3. **Install Project Dependencies**: Navigate to the project directory and install the necessary Node.js packages by running:
   ```bash
   npm install
   ```
   This command will install all the dependencies listed in the `package.json` file.

4. **Run the Application**: Start the Node.js application by executing:
   ```bash
   npm start
   ```
   This command will run the application as defined in the `package.json` scripts.

5. **Verify the Application**: Ensure the application is running correctly by accessing it through the specified port or endpoint.

Make sure you have the necessary permissions and that your environment is configured to accept connections from your application. If you encounter any issues, check the logs for more details.

## Background Task Management

### Task Limiting Implementation

To prevent excessive load on the PF Asset Agent and system resources when multiple users access the application concurrently, we've implemented a task limiting mechanism for background tasks. This ensures that only a configurable maximum number of tasks can run simultaneously, with any additional tasks being queued for later execution.

### Configuration

The task limiting configuration is defined in the `backend/app/core/config.py` file under the `PFAssetServiceConfigs` class:

```python
class PFAssetServiceConfigs:
    MAX_CONCURRENT_TASKS = int(os.getenv("PF_MAX_CONCURRENT_TASKS", "10"))
    TASK_QUEUE_TIMEOUT = int(os.getenv("PF_TASK_QUEUE_TIMEOUT", "60"))  # seconds
```

You can configure these values through environment variables:
- `PF_MAX_CONCURRENT_TASKS`: Maximum number of concurrent background tasks (default: 10)
- `PF_TASK_QUEUE_TIMEOUT`: Maximum time to wait for a task slot in seconds (default: 60)

### Implementation Details

1. **Synchronous Task Limiting (pf_asset.py)**:
   - Uses a ThreadPoolExecutor with a fixed number of workers
   - Employs a BoundedSemaphore for concurrency control
   - Tracks active task count for monitoring

2. **Asynchronous Task Limiting (asset_invoker.py)**:
   - Uses asyncio.Semaphore for concurrent API calls
   - Implements a global semaphore shared across all AssetInvoker instances

3. **FastAPI Background Tasks (background_tasks.py)**:
   - Provides utilities to limit FastAPI background tasks
   - Offers both synchronous and asynchronous task limiting

### Usage

To use the task limiting utilities in API endpoints:

```python
from app.utils.background_tasks import add_limited_task

@router.post("/endpoint")
async def my_endpoint(background_tasks: BackgroundTasks):
    # Add a task with concurrency limiting
    add_limited_task(
        background_tasks,
        my_background_function,
        arg1=value1,
        arg2=value2
    )
    return {"message": "Task started"}
```

### Monitoring

The implementation includes logging of task execution, which helps in monitoring:
- Current number of active tasks
- Tasks waiting in the queue
- Task execution time and completion status

This task limiting system helps ensure application stability and prevents resource exhaustion when many users are logged in simultaneously.