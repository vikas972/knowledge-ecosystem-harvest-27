"""
    All global variable that are going to be used in multiple functions
    in different files will be declared in this file.
"""

__import__('pysqlite3')
import sys
import os
sys.modules['sqlite3'] = sys.modules.pop('pysqlite3')

from dotenv import load_dotenv
from langchain.chat_models import AzureChatOpenAI
from langchain.embeddings import AzureOpenAIEmbeddings
from langchain.vectorstores import Chroma

import logging
import os

# Load env file to get variables
load_dotenv()

# # # Set the environment variables for Azure OpenAI
os.environ["OPENAI_API_TYPE"] = os.getenv("ORGANIZATION")
os.environ["OPENAI_API_BASE"] = "https://aoaijapeast.openai.azure.com/"
os.environ["OPENAI_API_KEY"] = os.getenv("Embeddings_GPT_4_API_KEY")
os.environ["OPENAI_API_VERSION"] = os.getenv("Embeddings_GPT_4_API_VERSION")
os.environ["AZURE_OPENAI_API_KEY"] = os.getenv("GPT_4_API_KEY")

# Create an instance of AzureOpenAIEmbeddings
embeddings = AzureOpenAIEmbeddings(
    deployment=os.getenv("TEXT_EMBEDDING_002_DEPLOYMENT_NAME"),
    model="text-embedding-ada-002-us",
    openai_api_base= "https://igtb-openai.openai.azure.com/", #"https://aoaijapeast.openai.azure.com/",
    openai_api_key= os.getenv("Embeddings_GPT_4_API_KEY"),
    openai_api_version = os.getenv("Embeddings_GPT_4_API_VERSION"),
    openai_api_type=os.getenv("ORGANIZATION"),
    chunk_size=1024 
)


#Creates an instance of the AzureChatOpenAI language model for use in the application.
model = AzureChatOpenAI(
        openai_api_base=os.getenv("GPT_4_API_BASE"),
        openai_api_version=os.getenv("GPT_4_API_VERSION"),
        deployment_name=os.getenv("GPT_4_ID"),
        openai_api_key=os.getenv("GPT_4_API_KEY"),
        openai_api_type=os.getenv("ORGANIZATION"),
        temperature = 0.5,
        seed = 21
    )

global_initial_message = [{
    'role': 'system',
    'content': 'You are a helpful assistant.Your name is Lisa.'
}]



# PF assets id's
# Note that commented commented id's are before changing response format
Asset_id_Chat2doc =  "a1efb972-089e-4e26-86e3-df4b2839b2e2"
Asset_id_classification = "ea28ddc3-08ce-455b-8952-36674f96a0e3"
# only latest asset id is from staging
Asset_id_AS = "d8c83342-730a-450a-91f5-7f8d7f304e64" #"e5ab3ed3-7203-4853-b4b1-72b2de1a462d"#"74c086ae-def9-46d7-bee6-cc864565079c"
# only latest asset id is from staging
Asset_id_AM = "72ca1d6c-eb73-409a-961e-8516d5a975a7" #"9025c9fd-7c55-40f6-b841-371dc9206351"#"15c113a5-70d8-45ad-ae60-1735a80151d9"
# only latest asset id is from staging
Asset_id_RFF = "4ea6b125-f801-4c06-be10-cb57382a00bc" #"9df38a4a-a625-4030-9751-c0f02d51cc0e"#"caee5bda-e9d3-4522-8353-95a53b8c0897"#"53c45599-8b08-4f93-b7f4-fb27f3bd003d"#"c7994d8b-7029-46ed-ab94-fd47c6129e61"
# only latest asset id is from staging
Asset_id_UFF = "4b70a6ab-0801-412c-a494-b87830469a87" #"eb99c4db-eea6-4d7d-9077-a1a295068721"#"84abf77f-4f3e-40ee-aa06-e12640c4df0b"#"09f56c64-3218-438b-9de6-ba6d87e8c3d8" #"a0c9bebc-8b84-4e10-9614-67515edfa74f" This is the previous one
Asset_id_completion = "9a904900-2f0e-4fd7-8731-71a497071bd5"
# only latest asset id is from staging
Asset_for_payments_iso_mapping = "d7a1ffb2-5460-45b6-ba27-3cbf9a97535b from staging"#"0cb89087-56e0-4323-9f55-4fbd51b9f090"#"d8154486-288f-42d0-9b81-ebc8646fb3c5"#"9540b0d6-a47e-49ca-9c63-cc04613d893f"#"bca33f29-b301-42c2-8310-a064e8c20efc"
Asset_for_bg_classification_with_pdf_input = "b82b939b-2461-4b55-9235-fb90de268689"#"96d0c9ba-9df5-4b00-a707-469587be3dfd"
Asset_for_bg_fields_extractor = "c0bfd234-7749-40fb-a0da-415ded86499a"# OLD Extractor "db31c6a2-4d61-44db-b975-4c3536da5e7d" 
Asset_for_bg_extracted_fields_validation = "e74990f6-8e58-4ef7-a9fd-75391f29fbdc"# OLD Validator"5bf66960-cffc-4425-9e2f-014b20f6e2d7"# New Valid_v1"1aa93f39-241b-4723-b131-648c7972da22"
# Asset_for_bg_TnC_cassification = "9d306db6-3303-4708-9861-677af78f6fb6"
Asset_for_mixed_doc_cassification = "ca666920-dabc-481b-b1ae-f132ed7592d7" #"7a811b29-78d5-4d4d-b271-3bbc466c76ac"

# New Asset for Mixed Class Document
Asset_for_purchase_order = "93f54b94-497c-42f9-9edc-3018e33ec139"
Asset_for_invoice = "aac5dd88-6be2-41c4-be1e-4bf759e0c767"
Asset_for_airway_bill = "9f90a83c-0605-42d4-9d98-0190f31f65cf"
Asset_for_bill_of_lading = "7f54ff04-91dd-4321-861e-905e3612a466"
Asset_for_bill_of_exchange = "61cc30f6-0d1e-4e93-877d-8dc2ebf962cc"

Asset_for_hdfc_extraction = "d6fcf696-1043-4b70-b7b8-21332d41514c"
Asset_for_Payments_Onboarding_Physical_Form_Extractor = "f8c056e9-3db0-4d93-9319-98c7d0d6720c"
Asset_for_iso_mapping_fields_validation = "af5d8f24-26b3-42d7-9e7e-68d14fefa62a"
Asset_for_html_to_json_converted = "152703cc-e86a-4e61-a184-40059a4a1aa5"


# New Asset for Cutomer and Account Creation
Asset_for_customer_creation = "be980c95-8cb9-4123-86ea-7e66178ec8f3" #"6070d7d6-98df-4896-bb83-47d711283a1c"#"97d52d24-ca14-4555-b40a-d2f98cdb9615"#"8ca360d8-14c3-42b3-ba96-dd7b2ad8e263"
Asset_for_account_creation = "f3f38352-cd17-485a-b154-c0790f8d974b"#"9a9b0f48-5018-40b4-a13d-845bbb3f2819"


# Asset for JSON key value generation from PDF and Confidence Score
Asset_for_json_key_value_generation = "710b9444-ad28-4b8a-86f0-b675a47afe54"#"97d9e450-d7e0-4b25-8cce-42606dfbbb46"
CONFIDENCE_SCORE_API_URL = "http://172.172.194.217:8095/get_confidence_score/"
Asset_for_json_to_html_generation = "27a62349-3f3c-43f6-aaf0-c31b0e14b80b"#"97d9e450-d7e0-4b25-8cce-42606dfbbb46"


# vectordb connection
vectordb = Chroma(persist_directory="./chroma_storage",
                        embedding_function=embeddings,
                        collection_name='cops')


# azure blob storage
connection_string = 'DefaultEndpointsProtocol=https;AccountName=onboardingdocstorage;AccountKey=AqVza1d6695oHDl7pnCTtI3pMSn4RtvA2ZXfE6hennFKw+c+WFDpVseUam3YG7AaLeCClaKOnIWY+AStVs7Zsw==;EndpointSuffix=core.windows.net'
container_name = 'onboardingdocstorage'
bucket_url = 'https://onboardingdocstorage.blob.core.windows.net/onboardingdocstorage/'


# Define the external URL for customer creation
customer_creation_url = "https://igtb-liq-bo-lbpcg17.intellectproduct.com/cim20/static/v2/cim/customer/create"


server_url = "http://127.0.0.1:5000"
### Config Change at Jul22 2024 at 16:00 by VIKAS

PURPLE_FABRIC_ENV="stg"
PURPLE_FABRIC_TENANT="idx"

if(PURPLE_FABRIC_ENV=="qa") and PURPLE_FABRIC_TENANT =="idx":
    PURPLE_FABRIC_ENDPOINT="api.intellectqacloud.com"
    PURPLE_FABRIC_API_KEY="magicplatform.6e985612C96b454Ea46b95068EE3C8cb"
    PURPLE_FABRIC_USERNAME="idx.trinanjan"
    PURPLE_FABRIC_PASSWORD="Test12!@"
    PURPLE_FABRIC_CLASSIFIER_ID="0a86b8fc-10e6-4b27-b088-a8fe328470be"
elif (PURPLE_FABRIC_ENV=="qa") and PURPLE_FABRIC_TENANT =="aisandbox":
    PURPLE_FABRIC_ENDPOINT="api.intellectqacloud.com"
    PURPLE_FABRIC_API_KEY="magicplatform.5694abf3199d4c54b7a3b374e94eB1ee"
    PURPLE_FABRIC_USERNAME="aisandbox.trinanjan"
    PURPLE_FABRIC_PASSWORD="Test12!@#"
    PURPLE_FABRIC_CLASSIFIER_ID="92caec03-c810-439e-8129-ac09f3216607"
elif (PURPLE_FABRIC_ENV=="stg") and PURPLE_FABRIC_TENANT =="idx":
    PURPLE_FABRIC_ENDPOINT="api.intellectseecstag.com"
    PURPLE_FABRIC_API_KEY="magicplatform.e013B95FB9454CE7a14BadEF301e98D2"
    PURPLE_FABRIC_USERNAME="idx.trinanjansaha"
    PURPLE_FABRIC_PASSWORD="tEST12!@"
    PURPLE_FABRIC_CLASSIFIER_ID="e99f61aa-d84b-4e06-acfa-7c2dd8480195"
    # PURPLE_FABRIC_EXTRACTOR_PO_ASSET_ID="d81fcf5e-b7d9-4d62-8efa-bc2ebf1ef4a3"
    PURPLE_FABRIC_EXTRACTOR_PO_ASSET_ID="87c78c94-8e59-4b20-8ec3-d8cc71831bbe"
    PURPLE_FABRIC_EXTRACTOR_BOL_ASSET_ID="073e804b-50f3-4b3f-b48e-0c28e2bae927"
    PURPLE_FABRIC_EXTRACTOR_AWB_ASSET_ID="998008da-2744-498a-b2a9-1cd07eded14e"
    # PURPLE_FABRIC_EXTRACTOR_BOE_ASSET_ID="7af33704-a046-45a2-b4fc-8f32f502e27d"
    PURPLE_FABRIC_EXTRACTOR_BOE_ASSET_ID="a8908236-23b5-4399-9884-582e3418c177"
    # PURPLE_FABRIC_EXTRACTOR_INV_ASSET_ID="f2e5b1e3-4786-4d7a-a9d3-975f2ab24f14"
    PURPLE_FABRIC_EXTRACTOR_INV_ASSET_ID="aeb11e84-7865-4aa6-bf20-4fec38e05c1a"
