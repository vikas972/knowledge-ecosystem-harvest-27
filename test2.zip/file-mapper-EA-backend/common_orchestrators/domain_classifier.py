__import__('pysqlite3')
import sys
import os
sys.modules['sqlite3'] = sys.modules.pop('pysqlite3')

# Add the project root directory to the sys.path as this file run as subprocess
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import json

# Custom modules
from prompts import *
from configs import *
from utils.utility_functions import *
from db_script.db_operations import *
from domain_orchestrators.payments_orchestrator import payments_orchestrator_module
from domain_orchestrators.tf_orchestrator import  tf_orchestrator_module
from logger import logger
from prompts.common_prompts import domain_classification_prompt
from pf_asset_calling.invoke_azure_gpt4o import call_azure_gpt4o
from utils.pdf_to_images import split_pdf_into_images, delete_all_images

    
    
def domain_classifier(filename, file_id, corp_id, mapping_id, temp_file_path):
    """
    This function will use to classify domain of in putted document

    Args:
        filename: Name of the file
        file_id: Id of file
        corp_id: Id of organisation
    """

    # Below code is commented for now as we are sending images instead of text to LLM
    # try:
    #     # Read the contents of the temporary file
    #     with open(temp_file_path, 'r', encoding='utf-8') as temp_file:
    #         extracted_text = temp_file.read()
    #     logger.info("File exist here",temp_file_path)
    #     # os.remove(temp_file_path)
    #     temp_file.close()
    # except Exception as e:
    #     logger.info(f"An error occurred while processing the temp file: {e}")
    #     return  

    # Below code is commented for now as we are sending images instead of text to Azure gpt4o
    # LLM call to get type of doc from payments. (onboarding or board resolution) 
    # domain_classifier_prompt = get_domain_template() + "Below is context for generating response: ```\n" + extracted_text + "\n```"
    # domain_classifier_call = invoke_asset(Asset_id_Chat2doc, domain_classifier_prompt)
    # domain_classifier_call = domain_classifier_call[0]

    logger.info("In Domain Classifier...")

    # Call gpt4o with image as input till we have sonnet3.5 on PF
    img_paths = split_pdf_into_images(filename)
    logger.info(f"Image path in domain classifier: {img_paths}")
    llm_response = call_azure_gpt4o(img_paths, domain_classification_prompt)
    delete_all_images()

    # Extract data inside tags from llm response.
    tagstoextract = ['type', 'summary', 'options']
    extractedtags = extractValuesFromTag(tagstoextract, llm_response)
    
    document_type_code = extractedtags['type']
    summary = extractedtags['summary']
    summary_action_buttons = extractedtags['options']
    
    document_type_code = extractedtags['type']
    
    logger.info(f"Domain of input document is: {document_type_code}.")
    
    flag,msg = update_document_domain_name(file_id,document_type_code)
    if flag:
        logger.info(f"Document domain name updated successfully for corp_file_id: {file_id}")
    else:
        logger.error(f"Document domain name updation failed for corp_file_id: {file_id}")
        


    if document_type_code == "Payments":
        logger.info("Calling Payment orchestrator...")
        _ = payments_orchestrator_module(filename, file_id ,corp_id, mapping_id, temp_file_path)
    elif document_type_code == "TF":
        logger.info("Calling TF orchestrator...")
        _ = tf_orchestrator_module(filename, file_id ,corp_id, mapping_id, temp_file_path)
    else:
        db_update_result, msg = update_database_mapping_details(mapping_id,document_type_code,summary,summary_action_buttons)
        if not db_update_result:
            logger.error(f"Uploaded file {filename} with file_id {file_id} failed to\
                        complete processing because of error: {msg}")
            return

    
if __name__ == "__main__":
    filename, file_id, corp_id , mapping_id, temp_file_path = \
        sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5]
    logger.info(f"filename : {filename}")
    logger.info(f"file_id : {file_id}")
    logger.info(f"corp_id : {corp_id}")
    domain_classifier(filename, file_id,  corp_id, mapping_id, temp_file_path)
