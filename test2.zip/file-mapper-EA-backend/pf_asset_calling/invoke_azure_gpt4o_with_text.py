import openai
from logger import logger

# Setting the API key and endpoint for Azure OpenAI service
openai.api_type = "azure"
openai.api_base = "https://igtb-openai.openai.azure.com/"
openai.api_version = "2024-08-01-preview"
openai.api_key = "25rt1k9D0mp1KvUrYPvW0pfNVTa8HJCJxBFiJIVtb8NjctvjYbsDJQQJ99BBACYeBjFXJ3w3AAABACOG2lBv"



def call_azure_gpt4o(query, prompt: str) -> str:
    """ This function will take a single text input and pass it to GPT4o.
    It will return the generated response as a string."""

    # Prepare the message content with the prompt
    messages = [
        { "role": "system", "content": prompt },
        { "role": "user", "content": query }
    ]

    # Call the OpenAI API
    response = openai.ChatCompletion.create(
        engine="gpt-4o-us",
        messages=messages,
        max_tokens=4096,
        temperature=0
    )

    return response["choices"][0]["message"]["content"]

# Example usage
# prompt = "Explain the process of photosynthesis in plants."
# response = call_azure_gpt4o(prompt)
# logger.info(response)
