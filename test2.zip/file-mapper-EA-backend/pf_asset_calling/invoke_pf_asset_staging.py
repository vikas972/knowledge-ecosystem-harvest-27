"""
This file is the common module to invoke Conversation Asset of PF.

PF is a Gen AI framework used to get LLM responses.
"""

import requests as req
import time
from logger import logger


api_key = 'magicplatform.7881874f7df9423d94b6fFd8ebd6e279'

headers_QA = {'apikey': api_key,
              'username': 'gtb.rohitghule',
              'password': 'Intellect@2023'
              }


def get_access_token(headers):
    """
    Retrieve an access token using the provided headers.

    Args:
        headers (dict): The headers containing authentication details.

    Returns:
        str: The access token or an empty string if the token retrieval fails.
    """
    value = ""
    res = req.get("https://api.intellectseecstag.com/accesstoken/idxpigtb", headers=headers)
    if res.status_code == 200:
        data = res.json()
        value = data['access_token']
    else:
        logger.info("Unable to create Access token")
    return value


def create_chat(asset_headers, payload):
    """
    Create a new chat conversation.

    Args:
        asset_headers (dict): The headers for the API request.
        payload (dict): The payload containing the conversation details.

    Returns:
        str: The conversation ID of the created chat.
    """
    response = req.post(
        "https://api.intellectseecstag.com/magicplatform/v1/genai/conversation/create",
        headers=asset_headers, json=payload).json()
    
    conversation_id = response['conversation_details']['conversation_id']
    return conversation_id


def asset_post(asset_headers, asset_payload):
    """
    Post a message to an existing chat conversation.

    Args:
        asset_headers (dict): The headers for the API request.
        asset_payload (dict): The payload containing the message details.

    Returns:
        str: The message ID of the posted message.
    """
    asset_post = req.post(
        "https://api.intellectseecstag.com/magicplatform/v1/genai/conversation/addmessage",
        headers=asset_headers, json=asset_payload)
    
    message_id = asset_post.json()['message_id']
    return message_id


def get_response(asset_headers, conversation_id, message_id):
    """
    Retrieve the response for a posted message in a chat conversation.

    Args:
        asset_headers (dict): The headers for the API request.
        conversation_id (str): The conversation ID.
        message_id (str): The message ID.

    Returns:
        tuple: A tuple containing the response text and the total cost of the response.
    """
    while True:
        try:
            response = req.get(
                f"https://api.intellectseecstag.com/magicplatform/v1/genai/conversation/response/{conversation_id}/{message_id}",
                headers=asset_headers)
        except Exception as e:
            access_token = get_access_token(headers_QA)
            asset_headers = {
                'Content-Type': 'application/json',
                'apikey': api_key,
                'Authorization': 'Bearer ' + access_token,
            }
            
        try:
            response_ = response.json()
            if response_['error_code'] == "GenaiBaseException":
                logger.info(f"PF Error: Failed with {response_['error_description']}")
                raise Exception(response_['error_description'])
        except:
            pass
        

        try:
            res = response.json()['message_content'][0]['response']
            cost = response.json()['message_content'][0]['metrics']['total_cost']
            return res, cost
        except:
            logger.info("Waiting for response from PF...")
            time.sleep(4)


def invoke_asset(asset_id, query):
    """
    Invoke a conversation asset with the given query and retrieve the response.

    Args:
        asset_id (str): The asset ID to be invoked.
        query (str): The query to be sent to the asset.

    Returns:
        tuple: A tuple containing the response text and the total cost of the response.
    """
    logger.info("Getting access token")
    access_token = get_access_token(headers_QA)
    asset_headers = {
        'Content-Type': 'application/json',
        'apikey': api_key,
        'Authorization': 'Bearer ' + access_token,
    }

    # Create conversation
    logger.info("creating conversation")
    create_payload = {"conversation_name": "hi", "asset_version_id": asset_id, "mode": "EXPERIMENT"}
    conversation_id = create_chat(asset_headers, create_payload)
    logger.info(f"Conversation id is: {conversation_id}")

    # Invoke asset
    logger.info("Invoking asset")
    asset_payload = {"conversation_id": conversation_id, "query": query, "KB_Types": []}
    message_id = asset_post(asset_headers, asset_payload)
    logger.info(f"Message id is: {message_id}")

    # Get response
    output = get_response(asset_headers, conversation_id, message_id)
    logger.info(f"Response from the PF: {output}")
    
    return output

# asset_id = "4f91a2c4-01e8-48b3-8ac5-eff1a2ed3af3"
# query = "What is the count of failed instructions?"
# invoke_asset(asset_id, query)
