from helper_for_calling_pf_and_processing_pdf import *
import hashlib
import shutil
from pathlib import Path
from glob import glob as glob
import sys
from logger import logger

def make_base_path(_id):
    base_path = Path(f"asset/{_id}")
    shutil.rmtree(base_path, ignore_errors=True)
    base_path.mkdir(exist_ok=True)
    return base_path

def save_file(path, content, mode='wb'):
    with open(path, mode) as f:
        f.write(content if mode == 'wb' else json.dumps(content))

def start_orchestrator(org_file_bytes, org_file_name, clean_output=False):
    _id = hashlib.sha256(org_file_bytes).hexdigest()
    base_path = make_base_path(_id)
    file_extension = org_file_name.split(".")[-1].lower()
    org_data_local_path = f"{base_path}/org_file.{file_extension}"

    # Step 1: Save input files locally
    logger.info("----------------- step 1 is going on ----------------------")
    save_file(org_data_local_path, org_file_bytes)
    extracted_text = read_input_file(org_file_bytes, org_file_name)
    logger.info("step 1 is completed ---------------------------------------")

    # Step 2: Deduplication
    logger.info("----------------- step 2 is going on ----------------------")
    dedup_doc, pages_2_del = dedup_file_level(extracted_text, org_file_bytes)
    dedup_data_local_path = f"{base_path}/dedup_file.{file_extension}"
    save_file(dedup_data_local_path, dedup_doc.write())
    logger.info("step 2 is completed ---------------------------------------")

    # Step 3: Split dedup doc by pages
    logger.info("----------------- step 3 is going on ----------------------")
    page_level_dedup_data_local_path = f"{base_path}/dedup_file_pages/"
    split_save_doc_by_page(dedup_doc, page_level_dedup_data_local_path, file_extension)
    logger.info("step 3 is completed ---------------------------------------")

    return {
        "file_id": _id,
        "file_name": org_file_name,
        "dedup_pages": pages_2_del,
        "base_path": base_path,
        "page_level_dedup_data_local_path": page_level_dedup_data_local_path
    }


def classify_document_pages(base_path, page_level_dedup_data_local_path):
    logger.info("----------------- step 4 is going on ----------------------")
    trace_id_file_classifier, access_token = get_all_trace_ids_classifier(page_level_dedup_data_local_path)
    classifier_raw_response = get_classifier_raw_response(trace_id_file_classifier, access_token)
    classifier_full_response = process_classifier_response(classifier_raw_response)
    classifier_response_local_path = f"{base_path}/classifier_response.json"
    save_file(classifier_response_local_path, classifier_full_response, mode='w')
    logger.info("step 4 is completed ---------------------------------------")
    return classifier_full_response

def extract_document_data(base_path, page_level_dedup_data_local_path, classifier_full_response):
    logger.info("----------------- step 5 is going on ----------------------")
    page_2_class = {item["file_page_name"]: get_doc_class(item["classifier_raw_response"]["output"]) for item in classifier_full_response}
    trace_id_file_extractor, access_token = get_all_trace_ids_extractor(page_level_dedup_data_local_path, page_2_class)
    extractor_raw_response = get_extractor_raw_response(trace_id_file_extractor, access_token, page_2_class)
    extractor_full_response = process_extractor_response(extractor_raw_response)
    extractor_response_local_path = f"{base_path}/extractor_response.json"
    save_file(extractor_response_local_path, extractor_full_response, mode='w')
    logger.info("step 5 is completed ---------------------------------------")
    return extractor_full_response


def read_pdf(file_path):
    try:
        # Open the PDF file
        with open(file_path, "rb") as f:
            file_bytes = f.read()
        
        # Call the start_daemon function with the file bytes and file name
        # Initial processing
        orchestrator_response = start_orchestrator(file_bytes, file_path, clean_output=False)

        # Classification
        classifier_full_response = classify_document_pages(
            orchestrator_response["base_path"],
            orchestrator_response["page_level_dedup_data_local_path"]
        )

        # If classification is successful, proceed with extraction
        if classifier_full_response:
            extractor_full_response = extract_document_data(
                orchestrator_response["base_path"],
                orchestrator_response["page_level_dedup_data_local_path"],
                classifier_full_response
            )
            final_output = {
                "file_id": orchestrator_response["file_id"],
                "file_name": orchestrator_response["file_name"],
                "dedup_pages": orchestrator_response["dedup_pages"],
                "classifier_full_response": [
                    {
                        "file_page_name": i["file_page_name"],
                        "classifier_processed_response": i["classifier_processed_response"],
                    }
                    for i in classifier_full_response
                ],
                "extractor_raw_response": [
                    {
                        "file_page_name": i["file_page_name"],
                        "extractor_processed_response": i["extractor_processed_response"],
                    }
                    for i in extractor_full_response
                ],
            }
        else:
            final_output = {
                "file_id": orchestrator_response["file_id"],
                "file_name": orchestrator_response["file_name"],
                "dedup_pages": orchestrator_response["dedup_pages"],
                "classifier_full_response": [],
                "extractor_raw_response": [],
            }

        # final_output will now contain the complete processed data
        
        # Display the result
        logger.info(final_output)
        
    except Exception as e:
        logger.info(f"Error reading PDF file: {e}")
        sys.exit(1)


# if __name__ == "__main__":
#     # Specify the path to the PDF file
#     pdf_file_path = "PerformanceGuarantee.pdf"  # Replace with your PDF file path
    
#     # Read the PDF file and call start_daemon
#     read_pdf(pdf_file_path)


