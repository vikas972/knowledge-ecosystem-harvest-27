# import json
# import os

# import requests
# import time
# import pandas as pd


# def get_access_token(end_point,api_key):

#     url = f"https://{end_point}/accesstoken/idxpigtb"

#     payload = {}
#     headers = {
#         'apikey': api_key,
#         'username': username,
#         'password': password
#     }

#     response = requests.request("GET", url, headers=headers, data=payload)

#     return response.json().get("access_token")


# def get_trace_id(access_token,file,asset_version_id,end_point,api_key):
#     url = f"https://{end_point}/magicplatform/v1/invokeasset/{asset_version_id}/genai?add_additional_model_output=true"


#     payload = {}
#     files = [
#         ('document', (file,
#                         open(os.path.join(location,file), 'rb'),
#                         'application/pdf'))
#     ]
#     headers = {
#         'apikey': api_key,
#         'Accept': 'application/json',
#         'Authorization': f'Bearer {access_token}'
#     }

#     response = requests.request("POST", url, headers=headers, data=payload, files=files)

#     response=response.json()

#     trace_id_file[response.get("trace_id")]=file
#     return response.get("trace_id")



# def get_response(trace_id,access_token,asset_version_id,end_point,api_key):

#     url = f"https://{end_point}/magicplatform/v1/invokeasset/{asset_version_id}/{trace_id}"


#     payload = {}
#     headers = {
#         'apikey': api_key,
#         'Accept': 'application/json',
#         'Authorization': f'Bearer {access_token}'
#     }

#     response = requests.request("GET", url, headers=headers, data=payload)
#     return response.json()


# asset_version_id="c45c6366-6201-4ea6-965b-0935bab212d8"
# location="/home/vikasmayura/Downloads/test_logprob"
# all_files=os.listdir(location)
# # all_files = ["/home/trinanjansaha/Desktop/work_intellect/confidence_score_implementation/data/awb_pdfs/png2pdf.pdf"]
# env="qa"
# if(env=="qa"):
#     end_point="api.intellectseecstag.com"
#     api_key="magicplatform.7881874f7df9423d94b6fFd8ebd6e279"
#     username="gtb.rohitghule"
#     password="Intellect@2023"
# print(all_files)
# all_trace_ids=list()
# trace_id_file=dict()
# access_token=get_access_token(end_point,api_key)
# print(access_token)
# for file in all_files:
#     print(file)
#     trace_id=get_trace_id(access_token,file,asset_version_id,end_point,api_key)
#     all_trace_ids.append(trace_id)

# df=pd.DataFrame()
# try:
#     for trace_id,file  in trace_id_file.items():
#         response = get_response(trace_id, access_token,asset_version_id,end_point,api_key)
#         while(response.get("status","")=="IN_QUEUE" or response.get("status","")=="IN_PROGRESS" or response.get("message","")=="Unable to process the request. Please try again."):
#             response = get_response(trace_id, access_token,asset_version_id,end_point,api_key)
#             print(f"The file {file} response is {response}")
#             time.sleep(5)
#         # print(f"The file {file} response is {response}")
#         response=response.get("response").get('output')[0]
#         # parsed_output=response.get("output")

#         ##############################
#         # parsed_output=response.get("raw_model_response")
#         response = json.dumps(response)
#         parsed_output=response.replace("```json\n", "").replace("\n```", "").replace("\n", "")
#         parsed_output=json.loads(parsed_output)
#         print(parsed_output)


#         ############################

#         df1=pd.DataFrame([parsed_output])
#         df1.fillna("NA")


#         df1["document"]=file
#         if(len(df)==0):
#             df=df1
#         else:
#             df=pd.concat([df,df1],ignore_index=True)
#         print(parsed_output)
# #     df.to_excel("test_pro_exec_third.xlsx")
# except Exception as ex:
#     print("Exception occured as : ",ex)
# #     df.to_excel("test_pro_exec_third.xlsx")



import json

# Confidence scores JSON (as a Python dictionary)
confidence_json = {
    "Application Details": {
        "Application Date": 99.68,
        "Branch Name": 0,
        "Company/Customer Name": 100.0,
        "Company/Customer Address": 99.96
    },
    "Contact Details": {
        "Primary Contact Name": 100.0,
        "Primary Contact Mobile": 100.0,
        "Primary Contact Email": 99.88,
        "Secondary Contact Name": 0,
        "Secondary Contact Mobile": 0,
        "Secondary Contact Email": 0
    },
    "Account Information": {
        "Account Numbers": 100.0,
        "Account Type": 0,
        "Daily Transaction Limit": 0
    },
    "User Information": {
        "User Name": 98.82,
        "User Role": 99.98,
        "Email IDs": 99.91,
        "Mobile Numbers": 100.0
    },
    "Banking Services": {
        "Enabled Services": 98.99,
        "Special Instructions": 97.75
    },
    "Beneficiary Information": {
        "Beneficiary Name": 93.27,
        "Beneficiary Account Number": 100.0,
        "IFSC Code": 100.0,
        "Email Address": 100.0
    },
    "Declaration and Authorizations": {
        "Signatory Name(s)": 0,
        "Designations": 0,
        "Signatures": 0
    }
}

# Extracted data JSON (as a Python dictionary)
extracted_data = {
    "Application Details": {
        "Application Date": "09082024",
        "Branch Name": "",
        "Company/Customer Name": "ABC LIMITED.",
        "Company/Customer Address": "KANJURMARG-EAST MUMBAI."
    },
    "Contact Details": {
        "Primary Contact Name": "MR. XYZ.",
        "Primary Contact Mobile": "9999999999",
        "Primary Contact Email": "abcdcgmain.com",
        "Secondary Contact Name": "",
        "Secondary Contact Mobile": "",
        "Secondary Contact Email": ""
    },
    "Account Information": {
        "Account Numbers": "123456789",
        "Account Type": "",
        "Daily Transaction Limit": ""
    },
    "User Information": {
        "User Name": "ABC PLEASE, XY2",
        "User Role": "MAREAR, CHECKER",
        "Email IDs": "SEPADATE ANNEXDREQ Another DESIGN, add e guag COM PUNE",
        "Mobile Numbers": "0999999999, 8888888888"
    },
    "Banking Services": {
        "Enabled Services": "RTGS, NEFT, A2A, IMPS, Cheque, DD, ECMS",
        "Special Instructions": "Mobile App, Trade on Net, Trade on Mobile"
    },
    "Beneficiary Information": {
        "Beneficiary Name": "My Beneficiary PLEASE ATTACH",
        "Beneficiary Account Number": "A12345",
        "IFSC Code": "ETT00005",
        "Email Address": "beneficiary@gmail.com"
    },
    "Declaration and Authorizations": {
        "Signatory Name(s)": "",
        "Designations": "",
        "Signatures": ""
    }
}

def merge_confidences(confidence_dict, extracted_dict):
    """
    Merges two dictionaries: one with confidence scores
    and one with extracted field values.
    
    Returns a dictionary where each field is an object:
      { "value": <extracted_value>, "confidence": <score> }
    """
    merged_dict = {}
    
    # Loop through all top-level keys (e.g. "Application Details", "Contact Details")
    for section_key, section_value in extracted_dict.items():
        merged_section = {}
        
        # Loop through fields in that section
        for field_key, field_value in section_value.items():
            confidence_score = 0.0
            if (section_key in confidence_dict and
                field_key in confidence_dict[section_key]):
                confidence_score = confidence_dict[section_key][field_key]
            
            merged_section[field_key] = {
                "value": field_value,
                "confidence": confidence_score
            }
        
        merged_dict[section_key] = merged_section
    
    return merged_dict

merged_output = merge_confidences(confidence_json, extracted_data)

# Convert to JSON string with pretty-printing (indent=2)
merged_json_str = json.dumps(merged_output, indent=2)
print(merged_json_str)
