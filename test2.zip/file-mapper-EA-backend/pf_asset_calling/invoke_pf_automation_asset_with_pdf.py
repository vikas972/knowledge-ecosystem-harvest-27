"""
This file is the common module to invoke Conversation Asset of PF.

PF is a Gen AI framework used to get LLM responses.
"""

import requests as req
import time
from logger import logger


api_key = 'magicplatform.0Eb0AA478da8432595309ea105bCac09'

headers_QA = {
    'apikey': api_key,
    'username': 'igtbqa.rohitghule',
    'password': 'Intellect@2023'
}


def get_access_token(headers):
    """
    Retrieve an access token using the provided headers.

    Args:
        headers (dict): The headers containing authentication details.

    Returns:
        str: The access token or an empty string if the token retrieval fails.
    """
    value = ""
    res = req.get("https://api.intellectqacloud.com/accesstoken/igtb", headers=headers)
    if res.status_code == 200:
        data = res.json()
        value = data['access_token']
    else:
        logger.info("Unable to create Access token")
    return value



def asset_post(asset_headers, asset_payload, files, asset_id):
    asset_response = req.post(
        "https://api.intellectqacloud.com/magicplatform/v1/invokeasset/" + asset_id + "/genai",
        headers=asset_headers, data=asset_payload, files=files)
    asset_data = asset_response.json()
    trace_id = asset_data["trace_id"]
    return trace_id



def get_chunks(asset_headers, trace_id, asset_id):
    status = ""
    while status != "COMPLETED":
        chunk_get = req.get(
            "https://api.intellectqacloud.com/magicplatform/v1/invokeasset/" + asset_id + "/" + trace_id,
            headers=asset_headers)
        data = chunk_get.json()
        try:
            if data['error_code'] == "GenaiBaseException":
                logger.info(f"PF Error: Failed with {data['error_description']}")
                raise Exception(data['error_description'])
        except:
            pass
        
        logger.info(data)
        time.sleep(2)
        status = data['status']
        status = status
        if status == "COMPLETED":
            return data


def invoke_asset(asset_id, query, filepath):
    """
    Invoke a conversation asset with the given query and retrieve the response.

    Args:
        asset_id (str): The asset ID to be invoked.
        query (str): The query to be sent to the asset.

    Returns:
        tuple: A tuple containing the response text and the total cost of the response.
    """
    access_token = get_access_token(headers_QA)
    
    asset_headers = {
            # 'Content-Type': 'application/json',
            'Accept': 'application/json',
            'apikey': api_key,
            'Authorization': 'Bearer ' +
                            access_token,
        }
    # Invoke asset
    asset_payload = {}
    logger.info(f"Path of pdf file is: {filepath}")
    files=[
    ('document',('document.pdf',
                    open(filepath,'rb'),
                    'application/pdf'))
    ]
    logger.info(f"Payload for classification: {asset_payload}")
    trace_id = asset_post(asset_headers, asset_payload, files, asset_id)
    # Get response
    output = get_chunks(asset_headers, trace_id, asset_id)
    logger.info(output["response"]["output"][0]["output_parameters"])
    return output

# invoke_asset("96d0c9ba-9df5-4b00-a707-469587be3dfd", "", "static/uploads/Sample_4_DBZ-20240721220850.pdf")