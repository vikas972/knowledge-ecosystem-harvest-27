"""
This file is the common module to invoke Conversation Asset of PF.

PF is a Gen AI framework used to get LLM responses.
"""

import requests as req
import time
from logger import logger
from utils.utility_functions import format_json


api_key = 'magicplatform.7881874f7df9423d94b6fFd8ebd6e279'

headers_QA = {'apikey': api_key,
              'username': 'gtb.rohitghule',
              'password': 'Intellect@2023'
              }


def get_access_token(headers):
    """
    Retrieve an access token using the provided headers.

    Args:
        headers (dict): The headers containing authentication details.

    Returns:
        str: The access token or an empty string if the token retrieval fails.
    """
    value = ""
    res = req.get("https://api.intellectseecstag.com/accesstoken/idxpigtb", headers=headers)
    if res.status_code == 200:
        data = res.json()
        value = data['access_token']
    else:
        logger.info("Unable to create Access token")
    return value


def asset_post(asset_headers, asset_payload, asset_id):
    asset_response = req.post(
        "https://api.intellectseecstag.com/magicplatform/v1/invokeasset/" + asset_id + "/genai",
        headers=asset_headers, json=asset_payload)
    asset_data = asset_response.json()
    logger.info(f">> {asset_data}")
    trace_id = asset_data["trace_id"]
    return trace_id



def get_chunks(asset_headers, trace_id, asset_id):
    status = ""
    while status != "COMPLETED":
        chunk_get = req.get(
            "https://api.intellectseecstag.com/magicplatform/v1/invokeasset/" + asset_id + "/" + trace_id,
            headers=asset_headers)
        data = chunk_get.json()
        try:
            if data['error_code'] == "GenaiBaseException":
                logger.info(f"PF Error: Failed with {data['error_description']}")
                raise Exception(data['error_description'])
        except:
            pass
        
        logger.info(data)
        time.sleep(2)
        status = data['status']
        status = status
        if status == "COMPLETED":
            return data


def invoke_asset(asset_id, query):
    """
    Invoke a conversation asset with the given query and retrieve the response.

    Args:
        asset_id (str): The asset ID to be invoked.
        query (str): The query to be sent to the asset.

    Returns:
        tuple: A tuple containing the response text and the total cost of the response.
    """
    access_token = get_access_token(headers_QA)
    
    asset_headers = {
            'Content-Type': 'application/json',
            'apikey': api_key,
            'Authorization': 'Bearer ' +
                            access_token,
        }
    # Invoke asset
    asset_payload = {"party_terms_and_conditions":query["party_terms_and_conditions"],
                     "bg_extractor_output":query["bg_extractor_output"]}
    

    #create input as a string
    query["Undertaking_Terms_and_Conditions"] = query["party_terms_and_conditions"]
    asset_payload = {"bg_ext_op_and_party_tnc": f"""{query}"""}
    logger.info(f"Payload for validator asset: {asset_payload}")

    trace_id = asset_post(asset_headers, asset_payload, asset_id)

    # Get response
    output = get_chunks(asset_headers, trace_id, asset_id)
    output_json = output["response"]["output"][0]["output_parameters"]["validation_output"]
    formatted_output = format_json(output_json)
    logger.info(formatted_output[0])

    return formatted_output
    


# ptnc = open("party_tnc.txt","r").read()
# json_response = """
# {'Governing_Law_Jurisdiction': '', 'Advising_Bank_Name': '', 'Undertaking_Amount': '670,000', 'Claim_Period': '', 'Document_and_Presentation_Instructions': '', 'Undertaking_Terms_and_Conditions': '', 'Form_of_Undertaking': '', 'Issuer_BIC': '', 'Supplementary_Information_About_Amount': '', 'Date_Of_Issue': 'Date of Issue', 'Beneficiary_Name': 'BIOMARIN PHARMACEUTICAL INC.', 'Issue_Type': '', 'Beneficiary_Address_2': '38 GLOUCESTER RD Van Cliln', 'Beneficiary_Telephone_No': '+1 (415) 455-7558', 'Delivery_of_Original_Undertaking': '', 'Obligor_Instructing Party_Address': '', 'Issuer_Name': 'DBS Bank Ltd., Australia Branch', 'Effective_Date': 'As per format attached', 'Applicant_Contact_Person': 'MASARO UESHIMA', 'Beneficiary_Contact_Person': 'ELIZABETH MC KEE ANDERSON', 'Debit_Account_No': '', 'Beneficiary_Address_1': '105 DIGITAL DRIVE', 'Expiry_Type': 'Specific Date', 'Applicant_Fax_No': '+61-0801 321267', 'Applicant_Name': 'ICC PHARMA AUSTRALIA LIMITED', 'Application_Type': 'ISSUE as per FORMAT ENCLOSED initialed on each page by the authorised signatories of the Company with such amendments satisfactory to you (which is deemed to be our authorised format, hereinafter called the "Format")', 'Applicant_Telephone_No': '+61-0800 423267', 'Advising_Bank_Address': '', 'Claim_Date': '01-10-2020', 'Applicant_Address_1': 'UNIT 1, 1 SLOUGH BUSINESS PARK', 'Requested_Local_Undertaking_Terms_and_Conditions': '', 'Expiry_Condition': 'As per format attached', 'Available_With': '', 'Applicant_Address_2': '', 'Applicable_Rules': '', 'Demand_Indicator': '', 'Obligor_Instructing Party_Name': '', 'Applicant_Address_3': 'NEW SOUTH WALES, 2137', 'Underlying_Transaction_Details': '', 'Confirmation_Instruction': '', 'Beneficiary_Address_3': 'Hong Kong', 'Delivery_To_Collection_By': 'Please courier back to Applicant at Address for attention of Contact Person as indicated above. We are aware of the additional transit time of 3-5 working days.', 'Application_Sub_Type': '', 'Beneficiary_Fax_No': '+1 (415) 532-1457', 'Advising_Bank_BIC': '', 'Date_of_Expiry': '28-08-2020', 'Charges': '', 'Undertaking_Amount_CCY': 'USD United States Dollar'}
# """
# query = {"party_terms_and_conditions":f"Terms and conditions for party are as follows\n: ```{ptnc}```",
#          "bg_extractor_output":f"The extracted fields are as follows\n:```{json_response}```"}

# invoke_asset("1aa93f39-241b-4723-b131-648c7972da22",#"96d0c9ba-9df5-4b00-a707-469587be3dfd", 
#              query)