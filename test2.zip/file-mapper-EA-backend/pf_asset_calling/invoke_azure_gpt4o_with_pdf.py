from typing import List
import base64
import openai
from pdf2image import convert_from_path
from io import BytesIO
from logger import logger

# Setting the API key and endpoint for Azure OpenAI service
openai.api_type = "azure"
openai.api_base = "https://igtb-openai.openai.azure.com/"
openai.api_version = "2024-08-01-preview"
openai.api_key = "25rt1k9D0mp1KvUrYPvW0pfNVTa8HJCJxBFiJIVtb8NjctvjYbsDJQQJ99BBACYeBjFXJ3w3AAABACOG2lBv"


def call_azure_gpt4o_with_pdf(pdf_path: str, prompt: str) -> str:
    """
    Converts PDF to images, encodes them to base64, and sends them to Azure GPT-4o.
    """

    logger.info("Converting PDF to images...")
    images = convert_from_path(pdf_path)
    logger.info(f"Converted {len(images)} pages from PDF to images.")

    # Encode images to base64
    encoded_images = []
    for i, image in enumerate(images):
        logger.info(f"Encoding page {i + 1} to base64...")
        buffer = BytesIO()
        image.save(buffer, format="JPEG")
        buffer.seek(0)
        encoded_images.append(base64.b64encode(buffer.read()).decode('utf-8'))
        buffer.close()
        logger.info(f"Page {i + 1} successfully encoded.")

    # Prepare the message content
    messages = [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": [{"type": "text", "text": prompt}]},
    ]

    for i, encoded_image in enumerate(encoded_images):
        messages[1]["content"].append({
            "type": "image_url",
            "image_url": {"url": f"data:image/jpeg;base64,{encoded_image}"}
        })

    logger.info("Calling the OpenAI API with encoded images...")
    try:
        response = openai.ChatCompletion.create(
            engine="gpt-4o-us",
            messages=messages,
            max_tokens=4096,
            temperature=0
        )
        logger.info(f"Response from the API: {response['choices'][0]['message']['content']}")
        return response["choices"][0]["message"]["content"]

    except openai.error.InvalidRequestError as e:
        logger.error(f"Invalid image data: {e}")
        raise e



# # Example usage
# image_paths = "/home/vikasmayura/Downloads/TF Testing Files-20240919T095931Z-001/Testing_Doc/ENet_Onboarding-20240814173800.pdf"


# json_information_extraction_prompt = '''

# You are tasked with generating precise JSON output for the document content provided from the image input.

# ### Critical Instructions:
# - Input Format: The input will be an image of a form or document. Extract all relevant fields and interactive elements.
# - Output Format: Provide the extracted data in structured JSON format. The JSON should reflect the document's content, separating each section and grouping related fields together. Include only the data that requires user input or relevant information from the form.
# - Sections and Fields: Ensure each section of the form is represented as a key in the JSON, with corresponding fields as nested keys. Fields that include checkboxes, text inputs, radio buttons, and tables should be captured accurately.
  
# ### Guidelines:

# 1. Field Extraction: 
#    - For each section of the form, identify and extract content that requires user interaction or input, such as text fields, checkboxes, radio buttons, and tables.
#    - Ignore static content like labels, headings, or signature fields that do not require user input.

# 2. Data Structure:
#    - Sections: Each section in the form should be represented as a distinct JSON object, with the section name as the key.
#    - Fields: Fields within a section should be captured as key-value pairs. For example, text fields will be represented as `"field_name": "field_value"`. Checkboxes or radio buttons should use Boolean values (`true` or `false`) to indicate whether they are checked or selected.
#    - Tables: If the form contains tables (for example, user access rights or payment modules), represent each row as a JSON object. Ensure all table data is aligned and categorized under appropriate keys.

# 3. Completeness:
#    - Do not omit any interactive elements like input fields or checkboxes. Every input field that appears in the form must be represented in the JSON output, even if its value is empty or unchecked.
#    - Ensure that data is captured exactly as it appears in the image.

# 4. Special Handling:
#    - Date Fields: Convert date fields into a standard ISO date format (`YYYY-MM-DD`).
#    - Phone Numbers: For fields containing phone numbers, extract them as strings to preserve any leading zeros.
#    - Email Fields: Extract email fields as strings.
#    - Checkboxes: Represent checkboxes and radio buttons as Boolean values (`true` if checked, `false` if unchecked).

# 5. Sections and Example Fields:
#    - Client Information: Includes fields like "Company Name," "Address," "Date of Application," "Contact Person Details" (Full Name, Phone Number, Email).
#    - Accounts Mapping Information: Fields like "Bank Account Number," "Bank Account Name as per Bank’s Record."
#    - Payment Module: Includes "Business Product/Purpose" and corresponding payment products like "RTGS," "NEFT," etc., with each option's status (checked or unchecked).
#    - User Information: Fields like "User Full Name," "User Role," "User Email," and "Mobile Number."
#    - Other Sections: Identify and extract fields from additional sections as they appear.

# ### Sample JSON Output:
# ```json
# {
#   "client_information": {
#     "existing_enet_setup": "yes",
#     "enet_setup_test_value": "TEST",
#     "date_of_application": "2024-08-09",
#     "company_name": "ABC LIMITED.",
#     "company_address": "KANJURMARG-EAST, MUMBAI.",
#     "full_name": "MR. XYZ",
#     "telephone_mobile_no": "9999999999",
#     "email_id": "abcd@gmail.com"
#   },
#   "accounts_mapping_information": {
#     "bank_account_details": [
#       {
#         "bank_account_number": "123456789",
#         "bank_account_name": "ABC LIMITED"
#       }
#     ]
#   },
#   "payment_module": {
#     "options": ["On Screen", "Bulk Upload"],
#     "business_product_purpose": [
#       {
#         "product": "Vendor",
#         "payment_products": {
#           "RTGS": true,
#           "NEFT": true,
#           "A2A": true,
#           "IMPS": true,
#           "Cheque": false,
#           "DD": false,
#           "ECMS": false
#         }
#       },
#       {
#         "product": "Salary",
#         "payment_products": {
#           "RTGS": true,
#           "NEFT": true,
#           "A2A": true,
#           "IMPS": true,
#           "Cheque": false,
#           "DD": false,
#           "ECMS": false
#         }
#       }
#     ],
#     "special_instructions": "",
#     "access_required": ["Mobile App", "Trade on Net"],
#     "expiry_days": "4 DAYS",
#     "beneficiary_validation": {
#       "on_screen": false,
#       "bulk": false
#     }
#   },
#   "user_information": [
#     {
#       "user_full_name": "ABC",
#       "user_role": "Maker",
#       "user_email_id": "abcde@gmail.com",
#       "mobile_number": "9999999999"
#     },
#     {
#       "user_full_name": "XYZ",
#       "user_role": "Checker",
#       "user_email_id": "dddde@gmail.com",
#       "mobile_number": "8888888888"
#     }
#   ]
# }
# ```

# ### Validation:
# Before concluding, ensure the extracted JSON is properly structured and validated for accuracy, without missing any interactive elements or sections. Double-check for alignment and consistency across different sections of the form.

# '''
# response = call_azure_gpt4o_with_pdf(image_paths, json_information_extraction_prompt)
# logger.info(response["choices"][0]["message"]["content"])
