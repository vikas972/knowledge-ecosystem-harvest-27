"""
This file is the common module to invoke Conversation Asset of PF.

PF is a Gen AI framework used to get LLM responses.
"""

import requests as req
import time
from logger import logger


api_key = 'magicplatform.7881874f7df9423d94b6fFd8ebd6e279'

headers_QA = {'apikey': api_key,
              'username': 'vikas.maurya',
              'password': 'Vikas@123'
              }


def get_access_token(headers):
    """
    Retrieve an access token using the provided headers.

    Args:
        headers (dict): The headers containing authentication details.

    Returns:
        str: The access token or an empty string if the token retrieval fails.
    """
    value = ""
    res = req.get("https://api.intellectseecstag.com/accesstoken/idxpigtb", headers=headers)
    if res.status_code == 200:
        data = res.json()
        value = data['access_token']
    else:
        logger.info("Unable to create Access token")
    return value


def asset_post(asset_headers, asset_payload, files, asset_id):
    # logger.info(asset_headers, asset_payload, files, asset_id)
    asset_response = req.post(
        "https://api.intellectseecstag.com/magicplatform/v1/invokeasset/" + asset_id + "/genai?add_additional_model_output=true",
        headers=asset_headers, data=asset_payload, files=files)
    logger.info(f"Asset response for extraction request: {asset_response.json()}")
    asset_data = asset_response.json()
    trace_id = asset_data["trace_id"]
    return trace_id



def get_chunks(asset_headers, trace_id, asset_id):
    status = ""
    while status != "COMPLETED":
        chunk_get = req.get(
            "https://api.intellectseecstag.com/magicplatform/v1/invokeasset/" + asset_id + "/" + trace_id,
            headers=asset_headers)
        data = chunk_get.json()
        
        try:
            if data['error_code'] == "GenaiBaseException":
                logger.info(f"PF Error: Failed with {data['error_description']}")
                raise Exception(data['error_description'])
        except:
            pass
        
        logger.info(data)
        time.sleep(2)
        status = data['status']
        status = status
        if status == "COMPLETED":
            return data


def invoke_asset(asset_id, query, filepath, field_name):
    """
    Invoke a conversation asset with the given query and retrieve the response.

    Args:
        asset_id (str): The asset ID to be invoked.
        query (str): The query to be sent to the asset.

    Returns:
        tuple: A tuple containing the response text and the total cost of the response.
    """
    access_token = get_access_token(headers_QA)
    logger.info(f">>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<{filepath}")
    
    asset_headers = {
            # 'Content-Type': 'application/json',
            'Accept': 'application/json',
            'apikey': api_key,
            'Authorization': 'Bearer ' +
                            access_token,
        }
    # Invoke asset
    asset_payload = {}
    files=[
    (field_name,('document.pdf',
                    open(filepath,'rb'),
                    'application/pdf'))
    ]
    trace_id = asset_post(asset_headers, asset_payload, files, asset_id)
    # Get response
    output = get_chunks(asset_headers, trace_id, asset_id)
    # logger.info(output["response"])
    return output


# import json
# result = invoke_asset("d6fcf696-1043-4b70-b7b8-21332d41514c",#"96d0c9ba-9df5-4b00-a707-469587be3dfd", 
#              "", 
#              "/home/vikasmayura/Downloads/TF Testing Files-20240919T095931Z-001/Testing_Doc/ARCHR406_91111105_1251.pdf",
#              'document')
# logger.info(json.loads(result["response"]["output"][0]["debug_logs"][0]["raw_response"]))


# import requests as req
# import json
# from logger import logger

# CONFIDENCE_SCORE_API_URL = "http://172.172.194.217:8095/get_confidence_score/"

# def call_confidence_score_api(raw_output):
#     """
#     Call the Confidence Score API with the raw output of the PF extractor.

#     Args:
#         raw_output (str): The raw PF extractor output in string format.

#     Returns:
#         dict: The response from the Confidence Score API.
#     """
#     headers = {
#         "Content-Type": "application/json"
#     }
    
#     payload = {
#         "query": raw_output
#     }

#     try:
#         response = req.post(CONFIDENCE_SCORE_API_URL, headers=headers, json=payload)
#         if response.status_code == 200:
#             return response.json()
#         else:
#             logger.error(f"Confidence Score API call failed with status code {response.status_code}: {response.text}")
#             return {"error": "Failed to fetch confidence score."}
#     except Exception as e:
#         logger.error(f"Exception occurred while calling Confidence Score API: {str(e)}")
#         return {"error": "Exception occurred."}

# # Invoke the asset to get the outputc45c6366-6201-4ea6-965b-0935bab212d8
# result = invoke_asset(
#     "97d9e450-d7e0-4b25-8cce-42606dfbbb46",
#     "", 
#     "/home/vikasmayura/Downloads/test_logprob/enet.pdf",
#     'document'
# )

# # Extract raw response from the output
# raw_response = result["response"]["output"][0]
# response = json.dumps(raw_response)
# parsed_output=response.replace("```json\n", "").replace("\n```", "").replace("\n", "")
# print(raw_response)
# # Call the Confidence Score API
# confidence_score_response = call_confidence_score_api(parsed_output)
# # print(confidence_score_response)
# # Log the confidence score response
# logger.info(f"Confidence Score Response: {json.dumps(confidence_score_response, indent=4)}")