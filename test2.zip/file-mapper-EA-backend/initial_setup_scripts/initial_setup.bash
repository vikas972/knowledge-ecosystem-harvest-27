# Setting up environment variables to access PostgreSQL from the local system
echo "[INFO] Updating .env file with host IP address..."
# Get the system's IP address
for /f "tokens=1" %%i in ('ipconfig ^| findstr IPv4') do set HOST_IP=%%i
# Specify the path to the .env file
set "ENV_FILE_PATH=.env"
# Check if .env file exists
if not exist "%ENV_FILE_PATH%" (
    echo "ERROR: .env file not found. Please enter the correct path:"
    set /p ENV_FILE_PATH="Enter the path to the .env file: "
    if not exist "%ENV_FILE_PATH%" (
        echo "ERROR: Invalid path. Exiting."
        exit /b 1
    )
)
# Specify the variable to update
set "TARGET_VARIABLE=POSTGRES_HOST"
# Update the value of the specified variable in the .env file
powershell -Command "(Get-Content \"%ENV_FILE_PATH%\") -replace \"^%TARGET_VARIABLE%=.*\", \"%TARGET_VARIABLE%=%HOST_IP%\" | Set-Content \"%ENV_FILE_PATH%\""
echo "Host IP from Local PostgreSQL is: %HOST_IP%."
echo "[INFO] Updated .env file."

echo.

echo "[INFO] Updating PostgreSQL configuration files..."
# Specify the path to the pg_hba.conf file
set "PG_HBA_CONF=C:\Program Files\PostgreSQL\12\data\pg_hba.conf"
# Check if pg_hba.conf exists
if not exist "%PG_HBA_CONF%" (
    echo "ERROR: pg_hba.conf not found. Please enter the correct path:"
    set /p PG_HBA_CONF="Enter the path to the pg_hba.conf file: "
    if not exist "%PG_HBA_CONF%" (
        echo "ERROR: Invalid path. Exiting."
        exit /b 1
    )
)
# Lines to add to pg_hba.conf
set "LINES_TO_ADD=# TYPE  DATABASE        USER            ADDRESS                 METHOD`r`nhost    all             all             172.16.0.0/12           md5"
# Check if the lines already exist
findstr /C:"%LINES_TO_ADD%" "%PG_HBA_CONF%" >nul
if %errorlevel% equ 0 (
    echo "%PG_HBA_CONF% is already updated. No changes made."
) else (
    echo %LINES_TO_ADD% >> "%PG_HBA_CONF%"
    echo "%PG_HBA_CONF% file is updated now."
)

echo.

echo "[INFO] Restarting PostgreSQL server..."
# Restart PostgreSQL service
net stop postgresql-x64-12
net start postgresql-x64-12
echo "PostgreSQL server restarted."

echo.

echo "[INFO] Allowing ports using Windows Firewall..."
# Allow ports using Windows Firewall
netsh advfirewall firewall add rule name="PostgreSQL Port" dir=in action=allow protocol=TCP localport=5432
netsh advfirewall firewall add rule name="PostgreSQL Alternate Port" dir=in action=allow protocol=TCP localport=5433

echo "[INFO] Windows setup completed."
