import json





def transform_json(json_obj, root_title=""):
    """
    Transforms a JSON object into a list of field-value pairs, preserving the structure of the original JSON.

    Args:
        json_obj (dict): The JSON object to be transformed.
        root_title (str, optional): The title of the root section. Defaults to an empty string.

    Returns:
        dict: A dictionary where the keys are section titles and the values are lists of field-value pairs.
    """

    logger.info(f"JSON received in transform function: {json_obj}")
    result = {}
    if root_title:
        root_title = root_title.replace('_', ' ').title()

    # if type(json_obj) == list:
        # json_obj = json_obj[0]

    for key, value in json_obj.items():
        key = key.replace('_', ' ').title()
        if isinstance(value, dict):
            # Create a new section for this dictionary
            section_title = f"{root_title}/{key}" if root_title else key
            result[section_title] = []
            # Process the dictionary and add its key-value pairs
            for sub_key, sub_value in value.items():
                result[section_title].append({
                    'field': sub_key.replace('_', ' '),
                    'value': sub_value.replace('_', ' ')
                })
        elif isinstance(value, list):
            # Handle list items similarly but ensure indices are reflected
            for idx, item in enumerate(value):
                list_title = f"{root_title}/{key}/{idx+1}" if root_title else f"{key}[{idx}]"
                result[list_title] = []
                if isinstance(item, dict):
                    for sub_key, sub_value in item.items():
                        result[list_title].append({
                            'field': sub_key.replace('_', ' '),
                            'value': sub_value.replace('_', ' ')
                        })
                else:
                    result[list_title].append({
                        'field': key.replace('_', ' '),
                        'value': item.replace('_', ' ')
                    })
        else:
            # For non-dictionary and non-list values, just add them as-is
            if root_title not in result:
                result[root_title] = []
            result[root_title].append({
                'field': key.replace('_', ' '),
                'value': value.replace('_', ' ')
            })

    return result


def flatten_json(input_json):
    flat_result = {}

    # Traverse only the first-level keys (e.g., "Purchase Order")
    for root_key, root_value in input_json.items():
        # Pass each first-level object to be processed and add it to the final result
        try:
            transformed = transform_json(root_value, root_key)
        except Exception as e: #for now catch all the errors and just skip to next element
            continue
        flat_result.update(transformed)

    return flat_result




a = flatten_json({'mt_700_copy':{'mt_700_copy': {'27_sequence_of_total': '', '40a_form_of_documentary_credit': 'IRREVOCABLE', '20_documentary_credit_number': '12345678', '23_reference_to_pre_advice': '', '31c_date_of_issue': '240716', '40e_applicable_rules': 'AS PER UCPURR LATEST VERSION', '31d_date_and_place_of_expiry': '240805 HONGKONG', '51a_applicant_bank': '', '50_applicant': 'XYZ, HO CHI MINH CITY, VIETNAM', '59_beneficiary': 'ABC, GARDENA, USA', '32b_currency_code_amount': 'USD 61607.70', '39a_percentage_credit_amount_tolerance': '03/03', '39c_additional_amounts_covered': '', '41a_available_with_by': 'ANY BANK BY NEGOTIATION.', '42c_drafts_at': '60 DAYS AFTER BL DATE.', '42a_drawee': 'MNC BANK, HO CHI MINH CITY, VIETNAM', '42m_mixed_payment_details': '', '42p_negotiation_deferred_payment_details': '', '43p_partial_shipments': 'ALLOWED', '43t_transhipment': 'ALLOWED', '44a_place_of_taking_in_charge_dispatch_from_place_of_receipt': '', '44e_port_of_loading_airport_of_departure': 'QINGDAO PORT', '44f_port_of_discharge_airport_of_destination': 'ANY PORT IN VIETNAM', '44b_place_of_final_destination_for_transportation_to_place_of_delivery': '', '44c_latest_date_of_shipment': '', '44d_shipment_period': '', '45a_description_of_goods_and_or_services': 'MAIN FABRIC, UNIT PRICE USD ORIGIN : CHINA, FOB QINGDAO SERVICES 2.772/YARDS, QUANTITY 22,225 YARDS PORT, INCOTERMS 2010', '46a_documents_required': "1. Beneficiary's Draft drawn on Opening Bank. 2. Beneficiary's in one original plus two signed copies covering materials shipped. 3. Bill of Lading in full set marked freight collect consigned to and notify to the applicant. 4. Beneficiary's packing list in 3 copies.", '47a_additional_conditions': '1. All apparent spelling mistakes/ typographical errors in the LC Documents which do not alter the meaning/ description/ specification/ quality of the goods are acceptable and do not count as discrepancy. 2. All apparent spelling mistakes/mistakes in LC documents, which do not alter meaning/ specification/ description/ Quantity/ value of goods are acceptable and will not count as a discrepancy. 3. Tolerance of +/-03 % is allowed on the total quantity and value as well as tolerance of +/- 03 % is allowed on quantity and value of each size is acceptable. 4. Any amendment to the letter of credit without the prior written consent of the beneficiary shall not be taken cognizance of, under this letter of credit. 5. TT Reimbursement is allowed at the cost of applicant.', '49g_special_payment_conditions_for_beneficiary': '', '49h_special_payment_conditions_for_bank_only': '', '71d_charges': "All Bank charges outside Vietnam are for beneficiary's account.", '48_period_for_presentation_in_days': '7', '49_confirmation_instructions': 'WITHOUT', '58a_requested_confirmation_party': '', '53a_reimbursing_bank': '', '78_instructions_to_the_paying_accepting_negotiating_bank': '', '57a_advise_through_bank': '', '72z_sender_to_receiver_information': ''}}}
)


print(a)
