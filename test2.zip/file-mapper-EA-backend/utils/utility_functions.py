"""
All common utility functions used in the application.
"""

import sys
import os

# Add the project root directory to the sys.path as this file run as subprocess
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))


import tiktoken
import re

from prompts import *
from prompts_templates import *
from rag import store_text_in_vecdb
from utils.document_handler import extract_text
from utils.store_file_to_blob_storage import upload_file_to_blob
from db_script.db_operations import update_ocr_needed

import json
from logger import logger
import subprocess
import tempfile
from bs4 import BeautifulSoup



def get_chat_history_from_session(user_msg, session, global_initial_message):
    """
    Retrieve chat history from the session and append the user's message.

    Args:
        user_msg (str): The user's message.
        session (dict): The session dictionary containing chat history.
        global_initial_message (str): The initial message to start the chat.

    Returns:
        list: The updated chat history including the user's message.
    """
    initial_assistant_msg = """Hi I'm Lisa, your Onboarding Copilot, I can help you with the following :
            1. Analyze Payments Onboarding files and generate ISO mappings for various payment file formats
            2. Analyze Board Resolution documents and extract and compile a list of authorized signatories and their approval matrix.
            I can send the extracted information to the respective systems."""

    if 'global_messages' not in session:
        session['global_messages'] = []
        session['global_messages'].append(
                {'role': 'assistant', 'content': initial_assistant_msg}
            )
    if len(session['global_messages']) > 6:
        msg_to_send = session['global_messages'][-6:]
    else:
        msg_to_send = session['global_messages']

    chat_history = global_initial_message + msg_to_send + [{'role': 'user', 'content': user_msg}]
    return chat_history


def parse_chat_history(chat_history):
    """
    Parse chat history into a formatted string.

    Args:
        chat_history (list): The chat history containing messages.

    Returns:
        str: The formatted chat history.
    """
    formatted_history = []
    for entry in chat_history:
        role = entry.get('role', 'unknown')
        content = entry.get('content', '')
        formatted_history.append(f"role: {role}\ncontent: {content}")
    return "\n".join(formatted_history)


def extractValuesFromTag(tags_to_extract, responseFromGPT):
    """
    Extract values from specific tags in the GPT response.

    Args:
        tags_to_extract (list): List of tags to extract values from.
        responseFromGPT (str): The response from GPT.

    Returns:
        dict: A dictionary containing the extracted values.
    """
    extractedTextFromTag = {}
    for tag in tags_to_extract:
        pattern = f"<{tag}>(.*?)</{tag}>"
        matches = re.findall(pattern, responseFromGPT, re.DOTALL)
        if matches:
            extractedTextFromTag[tag] = '||'.join(matches)
        else:
            extractedTextFromTag[tag] = None
    logger.info("Extraction Completed")
    logger.info(extractedTextFromTag)
    return extractedTextFromTag


def remove_hidden_characters(input_string):
    """
    Remove hidden non-logger.infoable characters from a string.

    Args:
        input_string (str): The input string.

    Returns:
        str: The cleaned string.
    """
    input_string = re.sub(r'\s+', ' ', input_string)
    input_string = input_string.replace("\n", "")
    regex = re.compile(r'[\x00-\x1F\x7F-\x9F]')
    cleaned_string = regex.sub('', input_string)
    return cleaned_string


def clean_text(input_text):
    """
    Clean the input text by removing unnecessary characters.

    Args:
        input_text (str): The input text.

    Returns:
        str: The cleaned text.
    """
    cleaned_text = input_text.replace("\n", " ")
    cleaned_text = cleaned_text.replace("\\", " ")
    cleaned_text = re.sub(r'\s+', ' ', cleaned_text)
    return cleaned_text


def getDocumentFormat(docType):
    """
    Get the document format based on the document type.

    Args:
        docType (str): The document type.

    Returns:
        str: The document format.
    """
    if docType in ("CPO","CPO_WithHeaders","CPO_Template","CPO_WithoutHeaders"):
        return "Corporate Payments Onboarding"
    elif docType == "BR":
        return "Board Resolution"
    elif docType == "TFBGApplication":
        return "Bank Guarantee Form"
    elif docType == "TFBGCounterGuarantee":
        return "Counter Guarantee"
    elif docType == "CIB_OnboardingForm" or docType == "outOfDomain": #tmp or part added
        return "channel onboarding"
    else:
        return "Unknown Type"


def validate_json(json_obj):
    """
    Validate if the given object is a valid JSON.

    Args:
        json_obj (dict): The JSON object to validate.

    Returns:
        bool: True if valid, False otherwise.
    """
    for key, value in json_obj.items():
        if not isinstance(key, str):
            return False
        if not isinstance(value, list):
            return False
        for element in value:
            if not isinstance(element, dict):
                return False
    return True


def format_json(json_string):
    """
    Format a JSON string.

    Args:
        json_string (str): The JSON string.

    Returns:
        tuple: A tuple containing the formatted JSON object and a boolean indicating success.
    """
    start_idx = json_string.find('[')
    end_idx = json_string.rfind(']')
    json_data = json_string[start_idx:end_idx + 1]
    try:
        json_object = json.loads(json_data)
        return json_object, True
    except Exception as e:
        logger.error(f"Error in loading JSON: {e}")
        return json_data, False


def count_tokens(text, model_name='gpt-4'):
    """
    Count the number of tokens in the given text using the specified model's tokenizer.

    Args:
        text (str): The input text.
        model_name (str): The name of the model.

    Returns:
        int: The number of tokens in the text.
    """
    tokenizer = tiktoken.encoding_for_model(model_name)
    tokens = tokenizer.encode(text)
    num_tokens = len(tokens)
    return num_tokens


def cut_string_from_last_brace(string):
    """
    Cut the string from the last occurrence of '{' or '['.

    Args:
        string (str): The input string.

    Returns:
        str: The cut string.
    """
    last_curly_brace_index = string.rfind('{')
    last_square_brace_index = string.rfind('[')
    cut_index = last_curly_brace_index
    if cut_index == -1:
        return string
    return string[:cut_index]


def extract_json_content(text):
    """
    Extract JSON content from the given text.

    Args:
        text (str): The input text.

    Returns:
        str: The extracted JSON content.
    """
    pattern = r'```json(.*?)```'
    matches = re.findall(pattern, text, re.DOTALL)
    if matches:
        return matches[0].strip()
    else:
        return text


def remove_dots_from_keys(data):
    """
    Remove dots from keys in the given data.

    Args:
        data (list): The list of dictionaries with keys to be cleaned.

    Returns:
        list: The cleaned list of dictionaries.
    """
    new_list = []
    if isinstance(data, list):
        for item in data:
            new_dict = {}
            for key, value in item.items():
                new_key = key.replace('.', ' ').replace(',', ' ')
                new_dict[new_key] = value
            new_list.append(new_dict)
    return new_list


def run_subprocess(filepath, file_id, corp_id, mapping_id, filename):
    """
    Run a subprocess to handle file operations and upload to Azure Blob Storage.

    Args:
        filepath (str): The path to the file.
        file_id (str): The file ID.
        corp_id (str): The corporate ID.
        mapping_id (str): The mapping ID.
        filename (str): The name of the file.

    Returns:
        tuple: A tuple containing a boolean indicating success and a message.
    """
    flag, msg = upload_file_to_blob(filepath, filename)
    if not flag:
        logger.debug(f"An error occurred while storing file to file storage: {msg}")
        return False, "File is not uploaded properly. Please try after some time."
    
    # if not ".pdf" in filepath:
    extracted_text = extract_text(filepath)
    if not extracted_text and not ".pdf" in filepath: #temp condition to avoid scaned pdf errors
        logger.debug(f"An error occurred while extracting text from file: ",filepath)
        return False, "An error occurred while extracting text from file"
    
    if not extract_text and  ".pdf" in filepath:
        db_update, msg = update_ocr_needed(file_id)
        logger.info(f"[DB Info] ocr_needed is update as no extracted text from pdf\
                    . Response of update: {db_update} , msg: {msg}")
    
    
    #Create a temporary text file with the extracted text from the uploaded file.
    if extracted_text == None:
        extracted_text = ""
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix='.txt') as temp_file:
            temp_file.write(extracted_text.encode('utf-8'))
            temp_file_path = temp_file.name
    except Exception as e:
        logger.error(f"Error while storing text equivalent file of uploaded file: {e}")
        return False, e

    # Store the text in the vector database
    status, msg = store_text_in_vecdb(int(mapping_id), extracted_text)
    if not status:
        logger.error("There is some error while storing text in vectordb")
        return False, msg
    
    logger.info(f"File ID: {file_id}")
    logger.info(f"Corp ID: {corp_id}")

    ### Code Change 29th July 2024. Previous code commented temporarily.
    command1 = f"python common_orchestrators/domain_classifier.py {filepath} {file_id} {corp_id} {mapping_id} {temp_file_path}"
            # Asynchronously run the subprocess task
    # command2 = f"python domain_orchestrators/tf_subprocesses/bg_form_extractor_subprocess.py \
    #     {file_id}"

    try:
        _ = subprocess.Popen(command1, shell=True)
        # _ = subprocess.Popen(command2, shell=True)
        return True, "Started processing on your file. Classification and Extraction started together"    
    except Exception as e:
        logger.debug(f"An error occurred while starting the subprocess: {e}")
        return False, e


def transform_data(input_data):
    """
    Transform LLM response JSON into a new format.

    Args:
        input_data (list): The input data from LLM response.

    Returns:
        dict: The transformed data.
    """
    transformed_data = {}
    for item in input_data:
        try:
            title = item.pop("title")
        except KeyError:
            logger.error("Error in fetching title key from response")
            title = "Table:"
        if type(title) == list:
            title = title[0]
        if title not in transformed_data:
            transformed_data[title] = []
        transformed_data[title].append(item)
    return transformed_data


def get_response_text_sectionwise(section_code):
    """
    Get the response text based on the provided section code.
    
    Args:
        section_code (str): The code for the section.
    
    Returns:
        str: The response text for the given section code, or a default response if the section code is not found.
    """
    section_codes_responses = {
        'UFF': "Content extracted for Upload File Format section and ISO Mappings\
              for the same generated successfully.",
        'RFF': "Content extracted for Reverse File Format section and ISO Mappings\
              for the same generated successfully.",
        'AM': "Data extracted for Approval Matrix section.",
        'AS': "Data extracted for Authorized Signatory section."
    }
    default_response = "JSON Mapping generated successfully !!!"

    return section_codes_responses.get(section_code, default_response)


def manipulate_file_status(status):
    """
    Manipulates the file status based on the provided status.
    
    Args:
        status (str): The current status of the file.
    
    Returns:
        str: The manipulated file status.
    """
    if status == "not_started" or status == "inprogress":
        return "pending"
    elif status == "done":
        return "done"
    else:
        return status
    

def get_current_file_status(classification_status,
                            classification_is_approved,
                            classification_rejected,
                            extraction_status,
                            extraction_is_approved,
                            extraction_rejected):
    
    """
    Determines the current file status based on the provided classification and extraction status.
    
    Args:
        classification_rejected (bool): Indicates if the classification was rejected.
        classification_status (str): The current status of the classification.
        classification_is_approved (bool): Indicates if the classification was approved.
        extraction_status (str): The current status of the extraction.
        extraction_is_approved (bool): Indicates if the extraction was approved.
        extraction_rejected (bool): Indicates if the extraction was rejected.
    
    Returns:
        str: The current file status.
    """
    if classification_rejected:
        return "Classification Rejected"
    if classification_status == "pending":
        return "Classification Pending"
    if classification_status == "done" and not classification_is_approved and not classification_rejected:
        return "Classification Approval pending"
    if classification_is_approved and extraction_status == "pending":
        return "Classification Approved and Extraction Pending"
    if classification_is_approved and extraction_status == "done" and not extraction_is_approved and not extraction_rejected:
        return "Extraction Approval Pending"
    if classification_is_approved and extraction_status == "done" and extraction_is_approved and not extraction_rejected:
        return "Extraction Approved."
    if extraction_status=="failed":
        return "Extraction Failed"
    

def get_current_file_status_for_validator(
                            classification_rejected,
                            validation_rejected):
    """
    Determines the current file status based on the provided classification and validation status.
    
    Args:
        classification_rejected (bool): Indicates if the classification was rejected.
        validation_rejected (bool): Indicates if the validation was rejected.
    
    Returns:
        str: The current file status.
    """
    if classification_rejected:
        return "Classification Rejected"
    if validation_rejected:
        return "Validation Rejected"


def make_html_editable(inner_html):
    """
    Converts the provided HTML content into an editable format by adding edit icons 
    and making the text content editable for relevant HTML tags. 
    It also adds controls for adding new rows to tables and delete buttons for each row.
    
    Args:
        inner_html (str): The HTML content to be made editable.
    
    Returns:
        str: The modified HTML content with the added editable functionality.
    """
        
    soup = BeautifulSoup(inner_html, 'html.parser')

    # Add edit icon and make text content editable for all relevant tags
    for tag in soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'th', 'td', 'label']):
        # Handle text-only tags (e.g., th, td) that don't contain inputs
        if not tag.find(['input', 'textarea', 'select']):
            # Create a unique ID for each editable element if needed
            element_id = f"{tag.name}-{tag.get_text(strip=True).lower().replace(' ', '-')}-label"
            
            # Wrap the tag content in a div with contenteditable attribute set to false initially
            editable_div = soup.new_tag('div', id=element_id, contenteditable="false", **{'class': 'editable'})
            editable_div.string = tag.get_text(strip=True)
            tag.clear()
            tag.append(editable_div)

            # Add edit icon after the tag
            edit_icon = soup.new_tag('span', **{'class': 'edit-icon', 'onclick': f"makeEditable('{element_id}')"})
            # edit_icon.string = '✏️'  # Pencil icon for edit
            edit_icon.string = '' 
            tag.append(edit_icon)
    
    # Ensure input elements are editable without altering their values
    for input_tag in soup.find_all(['input', 'textarea', 'select']):
        input_tag['class'] = input_tag.get('class', []) + ['editable']

    # Add controls for adding new rows to tables and add delete buttons
    for index, table in enumerate(soup.find_all('table')):
        # Assign a unique ID to each table
        table_id = f"table-{index + 1}"
        table['id'] = table_id
        
        # Create a div for control buttons
        control_div = soup.new_tag('div', **{'class': 'controls'})
        
        # Add an "Add Row" button before each table
        add_row_button = soup.new_tag('button', onclick=f"addRow('{table_id}')")
        add_row_button.string = 'Add Row'
        add_row_button['class'] = 'add-row'
        control_div.append(add_row_button)
        
        table.insert_before(control_div)

        # Ensure the delete button is correctly placed in its own column for each row
        for row in table.find_all('tr')[1:]:
            # Get the number of columns in the header row
            expected_col_count = len(table.find('tr').find_all('th'))
            current_col_count = len(row.find_all('td'))
            
            # If the row has any <td> elements, check and modify it
            if current_col_count > 0:
                # Check if the last column is a delete button, and remove it if necessary
                last_td = row.find_all('td')[-1]
                if last_td.find('button', {'class': 'delete-row'}):
                    last_td.decompose()
                
                # Add the delete button in its own new column
                delete_cell = soup.new_tag('td')
                delete_button = soup.new_tag('button', **{'class': 'delete-row', 'onclick': 'deleteRow(this)'})
                delete_button.string = 'Delete'
                delete_cell.append(delete_button)
                row.append(delete_cell)

    # Return the modified HTML as a string
    return str(soup)



# Add this function somewhere appropriate in the file
def generate_unique_customer_id():
    """Generate a unique customer ID with a timestamp prefix and UUID suffix, total length < 20"""
    import uuid
    import datetime
    # Using shorter date format YYMMDD (6 chars)
    timestamp = datetime.datetime.now().strftime("%y%m%d")
    # Using only 6 characters of UUID
    uuid_part = str(uuid.uuid4()).replace('-', '')[:6]
    # Total: CUS (3) + date (6) + uuid (6) = 15 characters
    return f"CUS{timestamp}{uuid_part}"