# Custom modules
import asyncio
import json
from prompts import *
from configs import *
from utils.utility_functions import *
from db_script.db_operations import *
from pf_asset_calling.invoke_azure_gpt4o import call_azure_gpt4o
from pf_asset_calling.invoke_pf_asset_staging import invoke_asset as invoke_asset_staging
from utils.pdf_to_images import split_pdf_into_images
from logger import logger
from prompts.common_prompts import json_information_extraction_prompt


# Convert existing blocking function to async
async def async_call_azure_gpt4o(image_path, prompt):
    return await asyncio.to_thread(call_azure_gpt4o, image_path, prompt)

async def async_invoke_asset_staging(asset, html_data):
    return await asyncio.to_thread(invoke_asset_staging, asset, html_data)

# Process a single page asynchronously
async def process_page(image_path, page_number, hdfc_information_extraction_prompt):
    logger.info(f"Processing page {page_number} with image path: {image_path}")
    
    # Get HTML generated with extraction data for the current page
    hdfc_fields = await async_call_azure_gpt4o(image_path, hdfc_information_extraction_prompt)
    hdfc_fields = hdfc_fields.replace("```html", "").replace("```", "")
    logger.info(f"Response from extractor for page {page_number}: {hdfc_fields}")
    
    # Check if hdfc_fields is empty
    if not hdfc_fields.strip():  # If empty, assign a default HTML message inside a <div>
        logger.warning(f"No data extracted for page {page_number}. Assigning default HTML message.")
        hdfc_fields = f'<div>No HTML is generated for page {page_number}.</div>'  # Default message inside div

    
    # Convert HTML to JSON for the current page
    completion_response = await async_invoke_asset_staging(Asset_for_html_to_json_converted, str(hdfc_fields))
    completion_response = extract_json_content(completion_response[0])
    completion_response = json.loads(completion_response)
    # completion_response = await async_call_azure_gpt4o(image_path, json_information_extraction_prompt)
    # completion_response = extract_json_content(completion_response)
    # completion_response = json.loads(completion_response)
    
    return page_number, hdfc_fields, completion_response

# Function to process all pages asynchronously
async def process_all_pages(file_id,image_paths, hdfc_information_extraction_prompt):
    tasks = []
    
    # Create a task for each page
    for page_number, image_path in enumerate(image_paths, start=1):
        task = process_page([image_path], page_number, hdfc_information_extraction_prompt)
        tasks.append(task)
    
    # Wait for all tasks to complete
    results = await asyncio.gather(*tasks)
    
    # Sort the results by page number to ensure correct sequence
    sorted_results = sorted(results, key=lambda x: x[0])  # Sort by page_number
    
    # Concatenate HTML and JSON results
    concatenated_hdfc_fields = "".join(result[1] for result in sorted_results)  # Concatenate HTML
    concatenated_completion_response = [result[2] for result in sorted_results]  # Concatenate JSON
    
    
    # After concatenating the HTML and JSON results
    for result in sorted_results:
        page_number = result[0]  # Page number from the result
        html_content = result[1]  # Page-wise HTML content
        json_content = result[2]  # Page-wise JSON content

        html_content = make_html_editable(html_content)

        # Save the data into the database using correct functions
        success_html, message_html = insert_page_html_content(file_id, page_number, html_content)
        success_json, message_json = insert_page_json_content(file_id, page_number, json_content)
        
        if success_html and success_json:
            logger.info(f"Page {page_number} data saved successfully")
        else:
            logger.error(f"Error saving page {page_number} data: HTML: {message_html}, JSON: {message_json}")

    
    return concatenated_hdfc_fields, concatenated_completion_response

# Main async function
async def main_calling_func(file_id,filepath, hdfc_information_extraction_prompt):
    logger.info("In channel onboarding Form section...")

    # Split pdf into images to send it to vision model
    image_paths = split_pdf_into_images(filepath)
    logger.info(f"Image paths: {image_paths}")
    
    # Process all pages asynchronously
    concatenated_hdfc_fields, concatenated_completion_response = await process_all_pages(
       file_id, image_paths, hdfc_information_extraction_prompt
    )
    
    # Log the concatenated result for all pages
    logger.info(f"Concatenated HTML from all pages: {concatenated_hdfc_fields}")
    logger.info(f"Concatenated JSON from all pages: {concatenated_completion_response}")
    return concatenated_hdfc_fields, concatenated_completion_response

