"""
This file contains functions to disable input and textarea elements in HTML.

The main function `disable_input_tags` takes an HTML string as input and returns
a modified version of the HTML with all input and textarea elements disabled.

It uses BeautifulSoup to parse and modify the HTML, which is a more robust
approach than using regular expressions for HTML manipulation.

There's also a commented-out version of the function that uses regular
expressions, which is left for reference or potential future use.

Usage:
    html_string = "<html>...<input type='text'>...</html>"
    disabled_html = disable_input_tags(html_string)
"""


from bs4 import BeautifulSoup

def disable_input_tags(inner_html):
    """
    Disables all input and textarea elements within the provided HTML string.
    
    Args:
        inner_html (str): The HTML string to be processed.
    
    Returns:
        str: The updated HTML string with all input and textarea elements disabled.
    """
    soup = BeautifulSoup(inner_html, 'html.parser')
    
    # Disable all input elements
    for input_tag in soup.find_all('input'):
        input_tag['disabled'] = 'disabled'
    
    # Disable all textarea elements
    for textarea_tag in soup.find_all('textarea'):
        textarea_tag['disabled'] = 'disabled'
    
    return str(soup)


# Example usage
# html_string = '''
# <form>
#     <input type="text" name="name" value="John">
#     <input type="email" name="email" value="john@example.com">
#     <input type="submit" value="Submit">
# </form>
# '''

# disabled_html = disable_input_tags(html_string)
# print(disabled_html)