"""
Converts an HTML content to a JSON representation.

The `html_to_json` function takes an HTML content string as input and returns a dictionary representing the structure of the HTML document. 
The function extracts the content from various HTML elements, such as headings, divs, and tables, and organizes them into a hierarchical structure.

The function processes the HTML content using the BeautifulSoup library and performs the following steps:

1. Parses the HTML content and creates a BeautifulSoup object.
2. Iterates through the HTML elements, identifying headings (h1-h6) and using them to create a hierarchical structure in the resulting JSON.
3. For each section, processes the content of div and table elements, extracting the relevant data and storing it in the JSON structure.
4. The `process_div` function handles the processing of div elements, extracting the label and input values and storing them in the JSON.
5. The `process_table` function handles the processing of table elements, extracting the table headers and data and storing them in the JSON.
6. The `get_input_value` function is used to extract the value of an input element based on its type (checkbox, radio, or text).

The resulting JSON structure is a dictionary, where the keys represent the section names and the values are dictionaries containing the data for each section.
"""

from bs4 import BeautifulSoup


def html_to_json(html_content):
    """
    Converts an HTML content to a JSON representation.
    
    The `html_to_json` function takes an HTML content string as input and returns a dictionary representing the structure of the HTML document. The function extracts the content from various HTML elements, such as headings, divs, and tables, and organizes them into a hierarchical structure.
    """
    soup = BeautifulSoup(html_content, 'html.parser')
    result = {}
    current_section = None

    for element in soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div', 'table']):
        if element.name.startswith('h'):
            current_section = f"Section Name: {element.text.strip().split('. ', 1)[-1]}"
            result[current_section] = {}
        elif current_section:
            section_data = result[current_section]
            if element.name == 'div':
                process_div(element, section_data)
            elif element.name == 'table':
                process_table(element, section_data, current_section)

    return result

def process_div(div, section_data):
    for child in div.children:
        if child.name in ['label', 'input']:
            process_input(child, section_data)

def process_input(element, section_data):
    if element.name == 'label':
        key = element.text.strip()
        input_elem = element.find('input')
        if input_elem:
            value = get_input_value(input_elem)
            section_data[key] = value
    elif element.name == 'input':
        key = element.get('name', '').strip() or element.get('id', '').strip()
        if key:
            value = get_input_value(element)
            section_data[key] = value

def get_input_value(input_elem):
    input_type = input_elem.get('type', '')
    if input_type == 'checkbox':
        return 'Checked' if input_elem.get('checked') is not None else 'Unchecked'
    elif input_type == 'radio':
        return 'Yes' if input_elem.get('checked') is not None else 'No'
    else:
        return input_elem.get('value', '')

def process_table(table, section_data, current_section):
    """
    Processes the table data in the HTML content and adds it to the section data.
    
    If the table has no headers, it processes each row and adds the key-value pairs to the section data.
    
    If the table has headers, it processes each row and creates a dictionary for each row, using the headers as the keys and the cell values as the values. It then adds the row data to the 'Table Data' list in the section data.
    
    For the 'PAYMENT MODULE' section, it handles the 'Business Product / Purpose' column differently, extracting only the first word as the value.
    """
    headers = [th.text.strip() for th in table.find_all('th')]
    
    if not headers:
        # For tables without headers (like in the first section)
        for row in table.find_all('tr'):
            cells = row.find_all('td')
            if len(cells) >= 2:
                key = cells[0].text.strip()
                value = process_cell(cells[1])
                section_data[key] = value
    else:
        table_data = []
        if current_section == "Section Name: PAYMENT MODULE":
            headers = [h for h in headers if h != "Payment Product"]
            for row in table.find_all('tr'):
                cells = row.find_all(['td', 'th'])
                if cells and cells[0].name == 'td':
                    row_data = {}
                    for i, cell in enumerate(cells):
                        if i < len(headers):
                            key = headers[i]
                            if key == "Business Product / Purpose":
                                value = cell.text.strip().split()[0]  # Get the first word (e.g., "Vendor", "Salary")
                            else:
                                value = 'Checked' if cell.find('input', {'type': 'checkbox', 'checked': True}) else 'Unchecked'
                            row_data[key] = value
                    if row_data:
                        table_data.append(row_data)
        else:
            for row in table.find_all('tr'):
                cells = row.find_all(['td', 'th'])
                if cells and cells[0].name == 'td':
                    row_data = {}
                    for i, cell in enumerate(cells):
                        if i < len(headers):
                            key = headers[i]
                            value = process_cell(cell)
                            row_data[key] = value
                    if row_data:
                        table_data.append(row_data)

        if table_data:
            if 'Table Data' not in section_data:
                section_data['Table Data'] = []
            section_data['Table Data'].extend(table_data)

def process_cell(cell):
    input_elem = cell.find('input')
    if input_elem:
        return get_input_value(input_elem)
    else:
        return cell.text.strip()
    

