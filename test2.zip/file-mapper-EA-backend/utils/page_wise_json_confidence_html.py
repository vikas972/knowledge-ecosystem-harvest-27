import sys
import os
# Add the project root directory to the sys.path as this file runs as subprocess
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import asyncio
from concurrent.futures import ThreadPoolExecutor
import json
import requests
from prompts.common_prompts import prompt_for_html_generation
from PyPDF2 import PdfReader, PdfWriter
from pf_asset_calling.invoke_pf_automation_asset_with_pdf_staging import invoke_asset as invoke_asset_staging
from pf_asset_calling.invoke_azure_gpt4o_with_pdf import call_azure_gpt4o_with_pdf
from logger import logger
from configs import *
from utils.utility_functions import *
from db_script.db_operations import (
    insert_page_json_content,
    insert_page_html_content
)


def split_pdf_into_pages(filepath):
    page_paths = []
    try:
        reader = PdfReader(filepath)
        for page_number in range(len(reader.pages)):
            page_path = f"{filepath}_page_{page_number + 1}.pdf"
            with open(page_path, "wb") as f:
                writer = PdfWriter()
                writer.add_page(reader.pages[page_number])
                writer.write(f)
            page_paths.append(page_path)
    except Exception as e:
        logger.error(f"Error splitting PDF into pages: {str(e)}")
        raise
    
    return page_paths


def merge_confidences(confidence_dict, extracted_dict):
    merged_dict = {}
    for section_key, section_value in extracted_dict.items():
        merged_section = {}

        # If the "section_value" is a list, handle as you do below
        if isinstance(section_value, list):
            merged_section = []
            for item in section_value:
                if isinstance(item, dict):
                    temp_item = {}
                    for field_key, field_value in item.items():
                        # The error would occur here if confidence_dict[section_key] is not a dict
                        confidence_score = confidence_dict.get(section_key, {}).get(field_key, 0.0)
                        temp_item[field_key] = {
                            "value": field_value,
                            "confidence": confidence_score
                        }
                    merged_section.append(temp_item)
                else:
                    merged_section.append({
                        "value": item,
                        "confidence": confidence_dict.get(section_key, 0.0)
                    })
        else:
            # Normal dict structure
            for field_key, field_value in section_value.items():
                # Potential error here if confidence_dict[section_key] is a string
                confidence_score = confidence_dict.get(section_key, {}).get(field_key, 0.0)
                merged_section[field_key] = {
                    "value": field_value,
                    "confidence": confidence_score
                }

        merged_dict[section_key] = merged_section
    return merged_dict


def call_confidence_score_api(raw_output):
    headers = {
        "Content-Type": "application/json"
    }

    payload = {
        "query": raw_output
    }

    try:
        response = requests.post(CONFIDENCE_SCORE_API_URL, headers=headers, json=payload)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        logger.error(f"Confidence Score API call failed: {str(e)}")
        return {"error": "Failed to fetch confidence score."}


def process_page(file_id,filepath, page_number, asset_id):
    logger.info(f"Processing page {page_number} from PDF: {filepath}")

    try:
        response = invoke_asset_staging(asset_id, "", filepath, 'document')
        extraction_result = json.loads(response["response"]["output"][0]["debug_logs"][0]["raw_response"])
        json_fields = response["response"]["output"][0]

        parsed_json_str = json.dumps(json_fields).replace("```json", "").replace("```", "")
        confidence_score_response = call_confidence_score_api(parsed_json_str)
        # logger.info(f"Response from extractor for page {page_number}: {parsed_json_str}")

        if not parsed_json_str.strip():
            logger.warning(f"No data extracted for page {page_number}. Assigning default message.")
            parsed_json_str = f'No JSON is generated for page {page_number}'
        confidence_dict = json.loads(confidence_score_response['response'])

        merged_data = merge_confidences(confidence_dict,extraction_result)
        combined_prompt = f"{prompt_for_html_generation}\n\nJSON Data:\n{json.dumps(merged_data, indent=2)}"
        
        # Call additional asset with merged data to get HTML
        # html_response = invoke_asset_staging(Asset_for_json_to_html_generation, json.dumps(merged_data), filepath, 'document')
        html_response = call_azure_gpt4o_with_pdf(filepath, combined_prompt)
        # html_content = html_response["response"]["output"][0]["debug_logs"][0]["raw_response"]
        html_content = html_response.replace("```html", "").replace("```", "")
        html_content = make_html_editable(html_content)
        # Save HTML content
        success_html, message_html = insert_page_html_content(file_id, page_number, html_content)
        if not success_html:
            logger.error(f"Failed to save HTML content for page {page_number}: {message_html}")

        # Insert page-level JSON data
        success_json, message_json = insert_page_json_content(file_id, page_number, json_content=merged_data)
        if success_json:
            logger.info(message_json)
        else:
            logger.error(message_json)
            
        return page_number, html_content, merged_data

    except Exception as e:
        logger.error(f"Error processing page {page_number}: {str(e)}")
        return page_number, "<div>Error processing page</div>", {"error": "Page processing failed."}


async def process_all_pages(file_id,filepath, information_extraction_asset_id):
    loop = asyncio.get_event_loop()
    results = []
    
    try:
        page_paths = split_pdf_into_pages(filepath)
        with ThreadPoolExecutor() as executor:
            tasks = [loop.run_in_executor(executor, process_page, file_id, page_path, page_number, information_extraction_asset_id)
                     for page_number, page_path in enumerate(page_paths, start=1)]
            completed, _ = await asyncio.wait(tasks)
            results = [task.result() for task in completed]

        # Sort results by page number
        sorted_results = sorted(results, key=lambda x: x[0])
        
        # Separate HTML and JSON content
        concatenated_html = "".join(result[1] for result in sorted_results)
        concatenated_json = [result[2] for result in sorted_results]
        
        return concatenated_html, concatenated_json

    except Exception as e:
        logger.error(f"Error splitting PDF: {str(e)}")
        return "", []


async def main_calling_func_for_confidence_score(file_id, filepath):
    logger.info("Starting PDF processing with page-wise splitting...")

    results = await process_all_pages(
        file_id,filepath, Asset_for_json_key_value_generation
    )

    logger.info(f"Concatenated JSON from all pages: {results}")
    return results


if __name__ == "__main__":
    asyncio.run(main_calling_func_for_confidence_score("3", "/home/vikasmayura/Downloads/test_logprob/enet.pdf"))
