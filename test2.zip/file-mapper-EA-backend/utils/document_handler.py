"""
This file has different types of files reading functionalities like pdf, doc, txt, json, and xlsx.
"""

import PyPDF2
from docx import Document
import os
import logging
import json
import pandas as pd
from typing import Optional


logger = logging.getLogger(__name__)


def clean_text(text):
    """
    Clean the input text by stripping leading and trailing whitespace.

    Args:
        text (str): The text to be cleaned.

    Returns:
        str: The cleaned text.
    """
    return text.strip()


def extract_text(filename: str) -> Optional[str]:
    """
    Extract text from a given file based on its extension.

    Args:
        filename (str): The path to the file from which text needs to be extracted.

    Returns:
        str or None: The extracted text or None if an error occurs or the file extension is unsupported.
    """    
    logger.info("Extracting text from input file")
    try:
        # Check file extension
        ext = os.path.splitext(filename)[1].lower()
        
        EXTENSION_HANDLERS = {
                '.pdf': extract_text_from_pdf,
                '.doc': extract_text_from_doc,
                '.docx': extract_text_from_doc,
                '.txt': extract_text_from_txt,
                '.json': extract_text_from_json,
                '.xlsx': extract_text_from_xlsx,
                '.xls': extract_text_from_xlsx
            }
    
        handler = EXTENSION_HANDLERS.get(ext)
        if handler:
            return handler(filename)
        else:
            logger.error(f"Unsupported file extension: {ext}")
            return None
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        return None

def extract_text_from_pdf(file):
    """
    Extract text from a PDF file.

    Args:
        file (str): The path to the PDF file.

    Returns:
        str or None: The extracted text or None if an error occurs.
    """
    try:
        pdf_reader = PyPDF2.PdfReader(file)
        text = ""
        for page in range(len(pdf_reader.pages)):
            new_page = clean_text(pdf_reader.pages[page].extract_text())
            text += new_page
        
        return text if text else None
    except Exception as e:
        logger.error(f"An error occurred while reading PDF: {e}")
        return None

def extract_text_from_doc(file):
    """
    Extract text from a DOC or DOCX file.

    Args:
        file (str): The path to the DOC or DOCX file.

    Returns:
        str or None: The extracted text or None if an error occurs.
    """
    try:
        ext = os.path.splitext(file)[1].lower()
        if ext == '.docx':
            return extract_text_from_docx(file)
        elif ext == '.doc':
            return extract_text_from_doc_legacy(file)
    except Exception as e:
        logger.error(f"An error occurred while reading DOC: {e}")
        return None

def extract_text_from_docx(file):
    """
    Extract text from a DOCX file.

    Args:
        file (str): The path to the DOCX file.

    Returns:
        str or None: The extracted text or None if an error occurs.
    """
    try:
        doc = Document(file)
        text = ""
        for paragraph in doc.paragraphs:
            text += clean_text(paragraph.text) + "\n"
        
        return text if text else None
    except Exception as e:
        logger.error(f"An error occurred while reading DOCX: {e}")
        return None

def extract_text_from_doc_legacy(file):
    """
    Extract text from a legacy DOC file.

    Args:
        file (str): The path to the legacy DOC file.

    Returns:
        str or None: The extracted text or None if an error occurs.
    """
    try:
        # Implement legacy .doc file handling (if necessary)
        import subprocess
        result = subprocess.run(['antiword', file], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if result.returncode == 0:
            return clean_text(result.stdout.decode('utf-8'))
        else:
            logger.error(f"An error occurred while reading DOC: {result.stderr.decode('utf-8')}")
            return None
    except Exception as e:
        logger.error(f"An error occurred while reading DOC: {e}")
        return None

def extract_text_from_txt(file):
    """
    Extract text from a TXT file.

    Args:
        file (str): The path to the TXT file.

    Returns:
        str or None: The extracted text or None if an error occurs.
    """
    try:
        with open(file, 'r', encoding='utf-8') as f:
            text = f.read()
            return clean_text(text)
    except Exception as e:
        logger.error(f"An error occurred while reading TXT: {e}")
        return None

def extract_text_from_json(file):
    """
    Extract text from a JSON file.

    Args:
        file (str): The path to the JSON file.

    Returns:
        str or None: The extracted text or None if an error occurs.
    """
    try:
        with open(file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return json.dumps(data, indent=4)
    except Exception as e:
        logger.error(f"An error occurred while reading JSON: {e}")
        return None

def extract_text_from_xlsx(file):
    """
    Extract text from an XLSX file.

    Args:
        file (str): The path to the XLSX file.

    Returns:
        str or None: The extracted text or None if an error occurs.
    """
    try:
        df = pd.read_excel(file)
        text = df.to_string(index=False)
        return text if text else None
    except Exception as e:
        logger.error(f"An error occurred while reading XLSX: {e}")
        return None
