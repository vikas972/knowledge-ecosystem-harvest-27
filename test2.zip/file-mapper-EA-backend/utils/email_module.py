# import smtplib
# import ssl
# from email.mime.multipart import MIMEMultipart
# from email.mime.text import MIMEText
# from email.mime.application import MIMEApplication

# def send_email(sender_email, receiver_email, subject, body, attachment_path, smtp_server, port, password):
#     """
#     Sends an email with an attachment.

#     Parameters:
#     - sender_email (str): Sender's email address.
#     - receiver_email (str): Recipient's email address.
#     - subject (str): Subject of the email.
#     - body (str): Body text of the email.
#     - attachment_path (str): Path to the attachment file.
#     - smtp_server (str): SMTP server address.
#     - port (int): Port number for the SMTP server.
#     - password (str): Password for the sender's email account.
#     """
#     # Create a multipart message
#     message = MIMEMultipart()
#     message["From"] = sender_email
#     message["To"] = receiver_email
#     message["Subject"] = subject

#     # Attach the email body
#     message.attach(MIMEText(body, "plain"))

#     # Attach the file
#     try:
#         with open(attachment_path, "rb") as attachment_file:
#             # Read the attachment file
#             attachment = MIMEApplication(attachment_file.read(), _subtype="html")
#             attachment.add_header(
#                 "Content-Disposition",
#                 "attachment",
#                 filename=attachment_path.split('/')[-1]  # Extract the file name
#             )
#             message.attach(attachment)
#     except Exception as e:
#         print(f"Error reading attachment file: {e}")
#         return

#     # Send the email via SMTP server
#     try:
#         context = ssl.create_default_context()
#         with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
#             server.login(sender_email, password)
#             server.sendmail(sender_email, receiver_email, message.as_string())
#         print("Email sent successfully.")
#     except Exception as e:
#         print(f"Error sending email: {e}")


# # Email configuration
# sender_email = "vikas.maurya@intellectdesign.com"
# receiver_email = "vikasmaurya9732@gmail.com"
# subject = "Automated Test Report"
# body = """Dear Client,

# Please find attached the latest test report.

# Best regards,
# Your Name
# """


# import pdfkit

# # Specify the path to your HTML report
# html_report = '/home/vikasmayura/Desktop/Onboarding_with_Trade_Finance/igtb-copilot-workspace/file-mapper-EA/file-mapper-EA-backend/reportnov112024.html'
# pdf_report = '/home/vikasmayura/Desktop/Onboarding_with_Trade_Finance/igtb-copilot-workspace/file-mapper-EA/file-mapper-EA-backend/reportnov112024.pdf'

# # Convert HTML to PDF
# pdfkit.from_file(html_report, pdf_report)

# print("Report converted to PDF successfully.")

# attachment_path = "/home/vikasmayura/Desktop/Onboarding_with_Trade_Finance/igtb-copilot-workspace/file-mapper-EA/file-mapper-EA-backend/reportnov112024.pdf"  # Path to your test report
# smtp_server = "smtp.gmail.com"  # Your SMTP server
# port = 465  # SSL port for SMTP server
# password = "mjxt rnjf kpje mnyg"  # Your email account password


# # Send the email
# send_email(
#     sender_email=sender_email,
#     receiver_email=receiver_email,
#     subject=subject,
#     body=body,
#     attachment_path=attachment_path,
#     smtp_server=smtp_server,
#     port=port,
#     password=password
# )


# import smtplib
# # creates SMTP session
# s = smtplib.SMTP('smtp.gmail.com', 587)
# # start TLS for security
# s.starttls()
# # Authentication
# s.login("vikas.maurya@intellectdesign.com", "mjxt rnjf kpje mnyg")
# # message to be sent
# message = "Message_you_need_to_send"
# # sending the mail
# s.sendmail("vikasmaurya9732@gmail.com", "vikas.maurya@intellectdesign.com", message)
# # terminating the session
# s.quit()

import smtplib
import ssl
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import pdfkit
from premailer import transform
import os

def convert_html_to_pdf(html_file_path, pdf_file_path):
    """
    Convert an HTML file to a PDF using pdfkit with proper handling for tables.
    """
    options = {
        'enable-local-file-access': None,  # Enable local file access for styles and images
        'page-size': 'A4',
        'encoding': 'UTF-8',
        'no-outline': None,  # Disable PDF outline
        'print-media-type': None,  # Use print CSS media
    }
    try:
        pdfkit.from_file(html_file_path, pdf_file_path, options=options)
        print(f"PDF generated successfully: {pdf_file_path}")
    except Exception as e:
        print(f"Error converting HTML to PDF: {e}")
        return None

def send_email_with_attachment(sender_email, receiver_email, subject, body, pdf_file_path, smtp_server, port, password):
    """
    Send an email with a PDF attachment.
    """
    # Create a multipart message
    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = receiver_email
    message["Subject"] = subject

    # Add email body
    message.attach(MIMEText(body, "plain"))

    # Attach the PDF file
    try:
        with open(pdf_file_path, "rb") as pdf_file:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(pdf_file.read())
            encoders.encode_base64(part)
            part.add_header(
                "Content-Disposition",
                f"attachment; filename={os.path.basename(pdf_file_path)}",
            )
            message.attach(part)
    except FileNotFoundError:
        print("PDF file not found.")
        return

    # Send the email
    try:
        context = ssl.create_default_context()
        with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, message.as_string())
        print("Email sent successfully.")
    except Exception as e:
        print(f"Error sending email: {e}")

# File paths
html_file_path = "reportnov112024.html"  # Path to the HTML file
pdf_file_path = "reportnov112024.pdf"    # Path to save the generated PDF

# Email configuration
sender_email = "igtbcopilot@intellectdesign.com"
receiver_email = "vikas.maurya@intellectdesign.com"
subject = "Automated Test Report"
body = "Please find the attached PDF report."
smtp_server = "smtp.gmail.com"
port = 465
password = "iGTBCopilot@2023"  # Use an App Password for security

# Step 1: Preprocess HTML (Transform external CSS to inline CSS)
try:
    with open(html_file_path, "r", encoding="utf-8") as file:
        html_content = file.read()
    html_content = transform(html_content)

    # Save the transformed HTML back to the file
    with open(html_file_path, "w", encoding="utf-8") as file:
        file.write(html_content)
except FileNotFoundError:
    print("HTML file not found. Please check the file path.")
    exit()

# Step 2: Convert HTML to PDF
convert_html_to_pdf(html_file_path, pdf_file_path)

# Step 3: Check if the PDF file is generated successfully
if not os.path.exists(pdf_file_path) or os.path.getsize(pdf_file_path) == 0:
    print("PDF generation failed or resulted in an empty file.")
    exit()

# Step 4: Send the email with the PDF attachment
send_email_with_attachment(
    sender_email=sender_email,
    receiver_email=receiver_email,
    subject=subject,
    body=body,
    pdf_file_path=pdf_file_path,
    smtp_server=smtp_server,
    port=port,
    password=password,
)
