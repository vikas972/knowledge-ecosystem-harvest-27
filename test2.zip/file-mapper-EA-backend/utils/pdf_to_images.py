"""
Utility functions for splitting a PDF file into individual image files.

The `split_pdf_into_images` function takes a PDF file path and an optional output folder path,
and converts each page of the PDF into a JPEG image file. The function returns a list of the
paths to the generated image files.

The `delete_all_images` function deletes all JPEG image files in the specified output folder.
"""

import os
import glob
from pdf2image import convert_from_path
from logger import logger

def split_pdf_into_images(pdf_path, output_folder='static/output_images'):
    # Create the output folder if it doesn't exist
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    
    # Extract the filename without extension from the pdf_path
    filename = os.path.splitext(os.path.basename(pdf_path))[0]
    
    # Convert PDF pages to images
    pages = convert_from_path(pdf_path)
    image_paths = []

    for i, page in enumerate(pages):
        image_path = os.path.join(output_folder, f"{filename}_page{i + 1}.jpg")
        page.save(image_path, 'JPEG')
        image_paths.append(image_path)
    
    return image_paths

def delete_all_images(folder_path='static/output_images'):
    # Use glob to find all jpg files in the folder
    image_files = glob.glob(os.path.join(folder_path, "*.jpg"))
    
    # Iterate through the list and delete each file
    for image_file in image_files:
        try:
            os.remove(image_file)
            logger.info(f"Deleted: {image_file}")
        except Exception as e:
            logger.info(f"Error deleting file {image_file}: {e}")


# if __name__ == "__main__":
#     pdf_path = '/home/rohitghule/Downloads/ENet Onboarding-bsp.pdf'
#     image_paths = split_pdf_into_images(pdf_path)
    
#     # logger.info or return the list of image paths
#     for image_path in image_paths:
#         logger.info(image_path)
