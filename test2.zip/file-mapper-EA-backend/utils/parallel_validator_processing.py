import asyncio
import json
import logging
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, Tuple, Any

from configs import (
    Asset_for_customer_creation,
    Asset_for_account_creation
)
from db_script.db_operations import insert_third_party_data
from pf_asset_calling.invoke_pf_asset_staging import invoke_asset
from logger import logger

async def process_api_response(asset_id: str, input_query: str) -> Tuple[bool, Dict[str, Any]]:
    """
    Process a single API response asynchronously.
    
    Args:
        asset_id (str): The asset ID for the API call
        input_query (str): The input query for the API
        
    Returns:
        Tuple[bool, Dict]: Success status and response data
    """
    try:
        with ThreadPoolExecutor() as executor:
            # Run the synchronous invoke_asset in a thread pool
            llm_response = await asyncio.get_event_loop().run_in_executor(
                executor,
                lambda: invoke_asset(asset_id, input_query)
            )
            
            if not llm_response or not llm_response[0]:
                return False, {}
                
            # Clean and parse the response
            cleaned_response = llm_response[0].replace("```json", "").replace("```", "")
            return True, json.loads(cleaned_response)
            
    except Exception as e:
        logger.error(f"Error processing API response: {e}")
        return False, {}

async def process_db_update(file_id: int, api_url: str, data: Dict[str, Any]) -> Tuple[bool, str]:
    """
    Process database update asynchronously.
    
    Args:
        file_id (int): The file ID
        api_url (str): The API URL
        data (Dict): The data to insert
        
    Returns:
        Tuple[bool, str]: Success status and message
    """
    try:
        with ThreadPoolExecutor() as executor:
            # Run the synchronous db operation in a thread pool
            return await asyncio.get_event_loop().run_in_executor(
                executor,
                lambda: insert_third_party_data(file_id, api_url, data)
            )
    except Exception as e:
        logger.error(f"Error updating database: {e}")
        return False, str(e)

async def parallel_validator_processing(file_id: int, extracted_fields: str) -> Tuple[bool, str]:
    """
    Process validator APIs and database updates in parallel.
    
    Args:
        file_id (int): The file ID
        extracted_fields (str): The extracted fields data
        
    Returns:
        Tuple[bool, str]: Overall success status and message
    """
    try:
        # Process both API calls in parallel
        api_tasks = [
            process_api_response(Asset_for_customer_creation, extracted_fields),
            process_api_response(Asset_for_account_creation, extracted_fields)
        ]
        api_results = await asyncio.gather(*api_tasks)
        
        # Check if both API calls were successful
        if not all(result[0] for result in api_results):
            return False, "One or more API calls failed"
            
        # Extract the response data
        customer_data = api_results[0][1]
        account_data = api_results[1][1]
        
        # Process both database updates in parallel
        db_tasks = [
            process_db_update(
                file_id,
                "https://igtb-liq-bo-lbpcg17.intellectproduct.com/cim20/static/v2/cim/customer/create",
                customer_data
            ),
            process_db_update(
                file_id,
                "https://igtb-liq-bo-lbpcg17.intellectproduct.com/cim20/static/v2/cim/account/create",
                account_data
            )
        ]
        db_results = await asyncio.gather(*db_tasks)
        
        # Check if both database updates were successful
        if not all(result[0] for result in db_results):
            return False, "One or more database updates failed"
            
        return True, "All operations completed successfully"
        
    except Exception as e:
        logger.error(f"Error in parallel validator processing: {e}")
        return False, str(e)

def run_parallel_validator_processing(file_id: int, extracted_fields: str) -> Tuple[bool, str]:
    """
    Wrapper function to run the async parallel processing in a synchronous context.
    
    Args:
        file_id (int): The file ID
        extracted_fields (str): The extracted fields data
        
    Returns:
        Tuple[bool, str]: Overall success status and message
    """
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(parallel_validator_processing(file_id, extracted_fields))
        loop.close()
        return result
    except Exception as e:
        logger.error(f"Error running parallel validator processing: {e}")
        return False, str(e) 