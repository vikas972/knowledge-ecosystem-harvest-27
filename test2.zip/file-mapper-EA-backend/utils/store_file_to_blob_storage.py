"""
This module provides functionality to upload files to Azure Blob Storage.

Uploads a file to Azure Blob Storage.

Args:
    local_file_path (str): Path to the local file to be uploaded.
    blob_name (str): Name of the blob in Azure Blob Storage.

Returns:
    tuple: A tuple containing a boolean flag indicating success or failure, and a message.

Example:
    local_file_path_to_upload = "/path/to/your/file.jpg"
    blob_name_to_upload = "file.jpg"
    success, message = upload_file_to_blob(local_file_path_to_upload, blob_name_to_upload)
"""


from azure.storage.blob import BlobServiceClient
from azure.core.exceptions import ResourceNotFoundError

from configs import connection_string, container_name
from logger import logger

def upload_file_to_blob(local_file_path, blob_name):
    """
    Uploads a file to Azure Blob Storage.

    Args:
        local_file_path (str): Path to the local file to be uploaded.
        blob_name (str): Name of the blob in Azure Blob Storage.

    Returns:
        tuple: A tuple containing a boolean flag indicating success or failure, and a message.

    Example:
        local_file_path_to_upload = "/path/to/your/file.jpg"
        blob_name_to_upload = "file.jpg"
        success, message = upload_file_to_blob(local_file_path_to_upload, blob_name_to_upload)
    """
    try:
        # Create the BlobServiceClient object
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)

        # Create a container if it does not already exist
        try:
            container_client = blob_service_client.create_container(container_name)
        except Exception as e:
            container_client = blob_service_client.get_container_client(container_name)
            logger.info(f"Container {container_name} already exists or could not be created. Error: {e}")

        # Create a BlobClient
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)
        
        # Upload the file
        with open(local_file_path, "rb") as data:
            blob_client.upload_blob(data, overwrite=True)
            logger.info(f"File {blob_name} uploaded to container {container_name}.")
        
        return True, "Uploaded to storage."
    except ResourceNotFoundError as e:
        logger.error(f"Blob storage error occurred: {e}")
        return False, e
    except Exception as e:
        logger.error(f"An unexpected error occurred: {e}")
        return False, e

def download_file_from_blob(connection_string, container_name, blob_name, download_file_path):
    """
    Downloads a file from Azure Blob Storage to local storage.

    Args:
        connection_string (str): Azure storage account connection string.
        container_name (str): Name of the container in Azure Blob Storage.
        blob_name (str): Name of the blob in Azure Blob Storage.
        download_file_path (str): Path to store the downloaded file.

    Returns:
        None

    Example:
        blob_name_to_download = "file.jpg"
        local_file_path_to_download = "/path/to/store/downloaded/file.jpg"
        download_file_from_blob(connection_string, container_name, blob_name_to_download, local_file_path_to_download)
    """
    try:
        # Create the BlobServiceClient object
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)

        # Create a BlobClient
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)

        # Download the blob to a local file
        with open(download_file_path, "wb") as download_file:
            data = blob_client.download_blob()
            download_file.write(data.readall())
            logger.info(f"File {blob_name} downloaded to {download_file_path}.")
    
    except ResourceNotFoundError as e:
        logger.info(f"Blob storage error occurred: {e}")
    except Exception as e:
        logger.info(f"An unexpected error occurred: {e}")


# Upload example
# local_file_path_to_upload = "/home/abhijeetmore/Desktop/GIT_CLONE/igtb-copilot-workspace/onboarding-copilot/onboarding-copilot-backend/static/images/iGTB-Copilot_2-01.jpg"
# blob_name_to_upload = "iGTB-Copilot_2-01.jpg"
# upload_file_to_blob(local_file_path_to_upload, blob_name_to_upload)

# Download example
# blob_name_to_download = "iGTB-Copilot_2-01.jpg"
# local_file_path_to_download = "/home/abhijeetmore/Desktop/GIT_CLONE/igtb-copilot-workspace/onboarding-copilot/onboarding-copilot-backend/static/images/iGTB-Copilot.jpg"
# download_file_from_blob(connection_string, container_name, blob_name_to_download, local_file_path_to_download)
