import subprocess
import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dotenv import load_dotenv
import os

# Load environment variables from .env file
load_dotenv()

def run_tests_and_generate_report():
    """
    Run the test suite and generate an HTML report.
    """
    html_report = "/home/vikasmayura/Desktop/Onboarding_with_Trade_Finance/igtb-copilot-workspace/file-mapper-EA/file-mapper-EA-backend/DocCheckreport.html"
    test_command = f"pytest test_cases/test_api_with_mock_data_v1.py --html={html_report} --self-contained-html"

    print("Running tests...")
    try:
        # Run the test command and capture the return code
        result = subprocess.run(test_command, shell=True, check=False)
        print(f"HTML report generated: {html_report}")
    except Exception as e:
        print(f"Error running tests: {e}")
        return None
    return html_report

def send_email(sender_email, receiver_email, subject, html_report, smtp_server, port, password):
    """
    Send the HTML report via email with instructions.
    """
    try:
        # Create email message
        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = receiver_email
        message["Subject"] = subject

        # Add email body
        body = """
        Hello Team,

        The latest automated test report has been generated. Please download the attached HTML file and open it in a browser to view the detailed results.

        Note: Some test cases may have failed. Please review the report for details.

        Best Regards,
        Automated Test Suite
        """
        message.attach(MIMEText(body, "plain"))

        # Attach the HTML report
        with open(html_report, "r", encoding="utf-8") as file:  # Open in text mode
            html_content = file.read()  # Read content as string
        part = MIMEText(html_content, "html")  # Pass string content
        part.add_header(
            "Content-Disposition",
            f"attachment; filename={html_report}"
        )
        message.attach(part)

        # Send email
        context = ssl.create_default_context()
        with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, message.as_string())

        print("Email sent successfully.")
    except Exception as e:
        print(f"Error sending email: {e}")


def main():
    # Step 1: Run the tests and generate HTML report
    html_report = run_tests_and_generate_report()
    if not html_report:
        print("Test execution failed to generate report. Email not sent.")
        return

    # Step 2: Read email configuration from .env file
    sender_email = os.getenv("EMAIL")
    receiver_email = os.getenv("RECEIVER_EMAIL")
    subject = "Daily Automated Test Report"
    smtp_server = os.getenv("SMTP_SERVER")
    port = int(os.getenv("SMTP_PORT"))
    password = os.getenv("EMAIL_PASSWORD")

    # Validate environment variables
    if not all([sender_email, receiver_email, smtp_server, port, password]):
        print("Error: Missing required email configurations in .env file.")
        return

    # Step 3: Send the HTML report via email
    send_email(
        sender_email=sender_email,
        receiver_email=receiver_email,
        subject=subject,
        html_report=html_report,
        smtp_server=smtp_server,
        port=port,
        password=password,
    )

if __name__ == "__main__":
    main()
