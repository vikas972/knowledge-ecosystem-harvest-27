
## Prerequisite:
- Install PostgreSQL (Version 16.1) (Make username and password both as "postgres")
- Python (3.8)
- Docker (24.0.7)
- Docker-compose (2.24.6)


# Installation Steps:
## 1. Clone the Repository

    Begin by cloning the project repository to your local machine. Open a terminal and run the following commands:
    For ubuntu:
        ```in terminal:
            - git clone https://igit.intellectdesign.com/presale/igtb-copilot-workspace.git
            - cd igtb-copilot-workspace
        ```

## 2. Checkout Feature Branch

    Switch to the relevant feature branch using the following command:

        - "git checkout feature-dev/merged-tf-and-onboarding"
   

## 3. Initial setup
    For ubuntu based systems run the following command in terminal:
        - chmod +x initial_setup_scripts/initial_setup.sh
        - ./initial_setup_scripts/initial_setup.sh


## 4. Database Dump (Needed only first time installation)
    - Create virtualenv with above python version.
    
    For onboarding-copilot:
        - run "pip install -r requirements/requirements_db.txt"
        - run "python db_script/create_database.py"
        - run "python db_script/update_db.py"
    For lbg-copilot:
        - run "pip install -r requirements_db.txt"
        - run "python lbgpostgres/dump.py"
    For rm-copilot:
        - run "pip install -r requirements_db.txt"
        - run "python restoredb/dbrestore.py"

    - deactivate virtualenv


## ## ## Running the application from container
    For ubuntu based systems run below commands in terminal:
       sudo docker-compose build
       sudo docker-compose up
        

## ## ## Running the application without container
    For onboarding-copilot:
        Run the following commands in ubuntu terminal:
            -  sudo apt-get install antiword
            - "pip install requirements/requirements_without_container.txt"
            - "python app.py"







## Project Structure

```
file-mapper-EA-backend/

    ├── README.md
    ├── .env
    ├── app.py
    ├── Dockerfile
    ├── docker-compose.yaml
    ├── configs.py
    ├── prompts_templates.py
    ├── logger.py
    ├── party_tnc.txt
    ├── helper_for_calling_pf_and_processing_pdf.py
    ├── rag.py
    │
    ├── domain_orchestrators/
    │   ├── tf_subprocesses/
    |            ├── bg_form_extractor_subprocess.py
    |            ├── bg_form_validator_subprocess.py
    │   ├── tf_orchestrator.py
    │   ├── payments_orchestrator.py
    │   ├── payments_subprocess
    |            ├── payments_extractor_subprocess.py
    |            ├── payments_validator_subprocess.py
    │
    ├── requirements/
    │   ├── requirements_container.txt
    │   ├── requirements_without_container.txt
    │   ├── requirements_db.txt
    │   └── requirements_container_base.txt
    │
    ├── templates/
    │   ├── index.html
    │   ├── extractor.html
    │   ├── new_extractor.html
    │   ├── hdfc_render_extractor.html
    │   ├── temp.html
    │   ├── classification.html
    │   ├── hdfc_render_validator.html
    │   ├── uploadfile.html
    │   ├── validator.html
    │   ├── iso_extractor.html
    │   ├── extractor_render.html
    │   └── iso_validator.html
    │
    ├── static/
    │   ├── pdf/
    │   ├── uploads/
    │   ├── Extracted_pdf/
    │   ├── forms/
    │   ├── img/
    │   ├── assets/
    │   ├── output_images/
    │   └── css/
    │
    ├── asset/
    │
    ├── logs_files/
    │   ├── db_logs.log
    │   └── cops_logs.log
    │
    ├── test_cases/
    │   ├── test_extract_text.py
    │   ├── test.doc
    │   ├── test_submit_selection.py
    │   ├── test_upload_file.py
    │   ├── test_fetch_corp_file_mapping.py
    │   ├── test_save_mappings_json.py
    │   ├── test_get_corporates.py
    │   ├── test.txt
    │   ├── app_unittest.py
    │   └── test.pdf
    │
    ├── initial_setup_scripts/
    │   ├── initial_setup_zsh.zsh
    │   ├── initial_setup.bash
    │   └── initial_setup.sh
    │
    ├── pf_asset_calling/
    │   ├── invoke_pf_asset.py
    │   ├── invoke_trade_finance_orchestrator.py
    │   ├── invoke_pf_automation_asset_with_pdf.py
    │   ├── invoke_pf_automation_asset_with_pdf_staging.py
    │   ├── invoke_pf_asset_staging.py
    │   ├── invoke_pf_automation_asset_with_query_staging.py
    │   └── invoke_azure_gpt4o.py
    │
    ├── db_script/
    │   ├── db_logger.py
    │   ├── db_operations.py
    │   ├── create_database.py
    │   └── update_db.py
    │
    ├── source/
    │   ├── index.rst
    │   ├── conf.py
    │   ├── _templates/
    │   ├── modules.rst
    │   ├── Makefile
    │   ├── _build/
    │   ├── _static/
    │   ├── chroma_storage/
    │   └── make.bat
    │
    ├── common_orchestrators/
    │   └── domain_classifier.py
    │
    ├── prompts/
    │   ├── PF_prompts_back.py
    │   ├── common_prompts.py
    │   ├── PF_prompts.py
    │   ├── file_mapper.py
    │   ├── board_resolution.py
    │   └── __init__.py
    │
    ├── build/
    │   ├── singlehtml/
    │   ├── html/
    │   └── doctrees/
    │
    |└── chroma_storage/
    |    ├── chroma.sqlite3
    |    └── 89dcad0d-e1d9-4644-9975-09e5b0b2c9f1/
    |
    |── utils
            ├── disable_text_fields_of_html.py
            ├── document_handler.py
            ├── html_to_json_conversion.py
            ├── pdf_to_images.py
            ├── store_file_to_blob_storage.py
            └── utility_functions.py


## Directory Structure Description:
    domain_orchestrators/: Contains orchestrators for different domains (e.g., TF, payments).
    requirements/: Contains different requirement files for various environments.
    templates/: HTML templates for the web interface.
    static/: Static files including PDFs, images, and CSS.
    asset/: Asset-related files.
    logs_files/: Log files for database and COPS.
    test_cases/: Unit tests and test files.
    initial_setup_scripts/: Scripts for initial setup in different shells.
    pf_asset_calling/: Scripts for invoking PF assets and orchestrators.
    db_script/: Database-related scripts including operations and logging.
    source/: Documentation source files.
    common_orchestrators/: Common orchestrator files.
    prompts/: Prompt templates for different functionalities.
    build/: Build files for documentation.
    chroma_storage/: Storage for Chroma database.

## Key Files:
    app.py: Main application file.
    Dockerfile and docker-compose.yaml: Docker configuration files.
    conf.py: Configuration file.
    html_to_json_conversion.py: HTML to JSON converter.
    document_handler.py: Handles document processing.
    configs.py: Configuration settings.
    prompts_templates.py: Templates for prompts.
    utility_functions.py: Utility functions.
    logger.py: Logging configuration.
    rag.py: Retrieval-Augmented Generation implementation.












## Contributing
Abhijeet More
Vikas Maurya
Nikhil Dusane
Rohit Ghule
Vimlendu Mishra
