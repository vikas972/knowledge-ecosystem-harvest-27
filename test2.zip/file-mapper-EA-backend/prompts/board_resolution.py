prompt_auth_sig = f"""
            You are corporate banking expert.
            This is the context for answering the question. Output should be just JSON.
            {{context}}
            
            Analyze the attached Board Resolution document and provide a JSON structure listing only the authorized signatories along with their functions. If sections related to banking operations like account opening, account operations, internet banking, etc., are present, extract names and designations of the signatories. If no data is found in these sections, include this in the JSON structure. Omit transaction limits or approval processes. Adapt the JSON to the document's content and format, capturing specific roles and names as presented or noting the absence of data.
            Output Format: The standard format of output json is:
                    dict(
                            "[table heading](Understand from context around table. please dont include any special characters)":
                            [dict(
                            "column_name" : ["column_value"],
                            all the rest of the values of that row
                            ),
                            dict(
                            Same process to be repeated for every row in that table
                            )],         
                    )
            Very Important: 
                a) The same output format should be followed for all values.
                b) Do not include any column as a whole with the "approved by" or "approval matrix" as it is different from authorized signatories.
            Critical:
                a) There might me some data or table whose officials dont come under any particular category, in this case i want you to make a separeate table called "Other Banking Facilities" and add those officials in that table and add it at the end of the json.
                b) The name of the official had to be present in every table.
                c) Make sure to print the tables in the exact same order as they appear in the document starting from the first page.
            
            Note: You will get a tip of 10000$ if you give correct output in proper expected output format.
            """  

prompt_app_matrix = f"""
            You are corporate banking expert.
            This is the context for answering the question. Output should be just JSON.
            {{context}}
            Analyze the attached Board Resolution document and provide a JSON structure listing the approval matrix, if present. Focus on identifying transaction limits, approval authorities, and specific conditions for financial operations like account operations, internet banking, etc. If the document does not contain this information or sections are empty, include this in the JSON structure. Ensure the JSON captures the approval process details or the absence of such data, adapting to the document's format and content.
            Output Format: The standard output format of json is:
                    dict(
                            "[table heading](Generate accoding to table context. please dont include any special characters)":
                            [dict(
                            "column_name" : ["column_value"],
                            all the rest of the values of that row
                            ),
                            dict(
                            Same process to be repeated for every row in that table
                            )],         
                    )
            Very Important: 
                a) The same format should be followed for all values.

            Critical:
                a) There might me some data or table whose officials dont come under any particular category, in this case i want you to make a separeate table called "Other Banking Facilities" and add those officials in that table and add it at the end of the json.
                b) The name of the official had to be present in every table.
                c) Make sure to print the tables in the exact same order as they appear in the document starting from the first page.
            
            Note: You will get a tip of 10000$ if you give correct output in proper expected output format.
            """