
prompt_for_html_generation = """You are tasked with generating precise HTML code for the document type provided, using both a JSON input and an accompanying image. If a value is present in the JSON with high confidence, use it directly in the HTML. If any key-value is missing (or has empty / zero confidence), then refer to the provided image’s visible text or checkboxes. The final HTML must match the exact layout of the original ENet Corporate Internet Banking Services Application Form, including only the interactive elements (text fields, checkboxes, etc.) that users would fill in or select.

Critical Instructions:

Output Format:

Only produce the inner content that would go inside the <body> tag.
Do not include <html>, <head>, or <body> tags.
Do not add any extra text, comments, or explanations. Output only the required HTML.
Editable Elements Only:

Include only interactive user-input fields: <input> (text, checkbox, radio, date, email, etc.), <textarea>, etc.
Omit any static text, paragraphs, instructions, notes, or signature fields that do not require user input.
Skip Signature and Notes:

Do not include signature sections or fields used only for signing/remarks.
Form Sections:

Identify and structure each section with HTML headings (e.g., <h3 class="section-header">1. CLIENT INFORMATION</h3>).
Preserve multi-row and multi-column tables by using <table>, <tr>, and <td> tags.
Maintain the alignment and order of all interactive fields exactly as in the original form.
Handling Missing Data:

If a JSON field is empty or has zero confidence, fallback to the provided image’s visible text or checkboxes.
If the image shows a certain date format or a pre-filled text, replicate that in the HTML.
For checkboxes, check them if indicated by the JSON or visible in the image. Otherwise, leave them unchecked.
Maintain Section Numbering and Layout:

Keep the original numbering of sections (e.g., "1. CLIENT INFORMATION", "2. ACCOUNTS MAPPING INFORMATION", etc.).
Within each section, ensure the table structure, columns, and rows match the source form layout.
HTML Tag Usage and CSS Classes:

Use <h3 class="section-header"> for section titles.
Use <table class="table"> for tables.
For each input field:
Text fields: <input type="text" class="input-text">
Email fields: <input type="email" class="input-email">
Date fields: <input type="date" class="input-date">
Checkboxes: <input type="checkbox" class="checkbox">
For text areas: <textarea class="textarea"></textarea>
Data Integrity:

Where JSON data is available, pre-fill the <input> or <textarea> fields with value="...".
If a checkbox is indicated as checked (by the JSON or the image), include checked in the <input type="checkbox">.
If a field is blank in JSON but visible on the image, you might leave it blank or confirm from the image if it’s indeed empty.
Example:
(See below for an example input JSON + image reference and how the output HTML should look.)
No additional clarifications or descriptive text should be included in your response. Generate only the final HTML that would appear inside the <body>.

## **Example Input**

1. **JSON**  
{
  "Client Information": {
    "Date of Application": {
      "value": "09082024",
      "confidence": 99.8
    },
    "Company Name": {
      "value": "ABC LIMITED.",
      "confidence": 98.75
    },
    "Company Address": {
      "value": "KANJURMARG-EAST MUMBAI.",
      "confidence": 99.29
    },
    "Primary Contact Name": {
      "value": "MR. XYZ.",
      "confidence": 96.31
    },
    "Primary Contact Mobile": {
      "value": "9999999999",
      "confidence": 100
    },
    "Primary Contact Email": {
      "value": "abcdcgmain.com",
      "confidence": 99.91
    },
    "Branch Name": {
      "value": "PUNE",
      "confidence": 99.94
    }
  },
  "Accounts Mapping Information": {
    "Account Numbers": {
      "value": "123456789",
      "confidence": 100
    },
    "Account Type": {
      "value": "",
      "confidence": 0
    },
    "Daily Transaction Limit": {
      "value": "",
      "confidence": 0
    }
  },
  "Payment Module": {
    "Enabled Services": {
      "value": "RTGS, NEFT, A2A, IMPS, Cheque, DD, ECMS",
      "confidence": 95.76
    },
    "Special Instructions": {
      "value": "Access Required Mobile App Trade on Net Trade on Mobile Expiry Days & DAYS Beneficiary Validation On Screen Bulk",
      "confidence": 92.94
    }
  },
  "User Information": {
    "User Name": {
      "value": "ABC PLEASE, XY2",
      "confidence": 99.41
    },
    "User Role": {
      "value": "TAREA, CHECKER",
      "confidence": 99.73
    },
    "Email IDs": {
      "value": "SEPADATE POESIGN, dadd e gual PUNE COM and",
      "confidence": 99.65
    },
    "Mobile Numbers": {
      "value": "999999999, 888888888",
      "confidence": 100
    }
  },
  "Signatory Information": {
    "Signatory Name(s)": {
      "value": "",
      "confidence": 0
    },
    "Designations": {
      "value": "",
      "confidence": 0
    },
    "Signatures": {
      "value": "",
      "confidence": 0
    }
  }
}

Image
(Assume the image is the original HDFC Bank ENet Corporate Internet Banking Services - Application Form, showing data like “Existing eNet Setup? Yes | Domain/Group ID: TEST,” “Date of Application: 09/08/2024,” “Company Name: ABC LIMITED.,” etc.)
Example Output
Below is illustrative HTML that might result from the above input. Notice that:

We only include interactive fields (no static text).
We replicate the structure shown in the image.
We fill data from JSON where available; otherwise, we use the form image as fallback.
<h3 class="section-header">1. CLIENT INFORMATION</h3>
<div class="enet-setup-wrapper">
  <label>Existing eNet Setup?</label>
  <input type="radio" name="enet_setup" value="yes" checked> Yes
  <input type="text" value="TEST" style="width: 120px; margin-left: 5px; margin-right: 10px;">
  <input type="radio" name="enet_setup" value="no"> No
</div>

<table class="table">
  <tr>
    <td class="label">Date of Application:</td>
    <td class="input-field">
      <input type="date" 
             value="2024-08-09" 
             class="input-date" 
             data-confidence="99.8"
             title="Confidence: 99.8%">
      <span class="confidence-indicator">99.8%</span>
    </td>
  </tr>
  <tr>
    <td class="label">Company Name:</td>
    <td class="input-field">
      <input type="text" 
             class="input-text" 
             value="ABC LIMITED." 
             data-confidence="98.75"
             title="Confidence: 98.75%">
      <span class="confidence-indicator">98.75%</span>
    </td>
  </tr>
  <tr>
    <td class="label">Company Address:</td>
    <td class="input-field">
      <textarea class="textarea" 
                data-confidence="99.29"
                title="Confidence: 99.29%">KANJURMARG-EAST MUMBAI.</textarea>
      <span class="confidence-indicator">99.29%</span>
    </td>
  </tr>
  <tr>
    <td class="label">Full Name:</td>
    <td class="input-field">
      <input type="text" 
             class="input-text" 
             value="MR. XYZ." 
             data-confidence="96.31"
             title="Confidence: 96.31%">
      <span class="confidence-indicator">96.31%</span>
    </td>
  </tr>
  <tr>
    <td class="label">Telephone/Mobile No.:</td>
    <td class="input-field">
      <input type="text" 
             class="input-text" 
             value="9999999999" 
             data-confidence="100"
             title="Confidence: 100%">
      <span class="confidence-indicator">100%</span>
    </td>
  </tr>
  <tr>
    <td class="label">E-mail ID:</td>
    <td class="input-field">
      <input type="email" 
             class="input-email" 
             value="abcdcgmain.com" 
             data-confidence="99.91"
             title="Confidence: 99.91%">
      <span class="confidence-indicator">99.91%</span>
    </td>
  </tr>
</table>

<h3 class="section-header">2. ACCOUNTS MAPPING INFORMATION</h3>
<table class="table">
  <tr>
    <th>Bank Account Number</th>
    <th>Bank Account Name as per Bank's record</th>
  </tr>
  <tr>
    <td>
      <input type="text" 
             class="input-text" 
             value="123456789" 
             data-confidence="100"
             title="Confidence: 100%">
      <span class="confidence-indicator">100%</span>
    </td>
    <td>
      <input type="text" 
             class="input-text" 
             value="ABC LIMITED." 
             data-confidence="0"
             title="Confidence: 0%">
      <span class="confidence-indicator low-confidence">0%</span>
    </td>
  </tr>
</table>

<h3 class="section-header">3. PAYMENT MODULE</h3>
<div class="module-options">
  <label>
    <input type="checkbox" checked data-confidence="95.76" title="Confidence: 95.76%"> On Screen
    <span class="confidence-indicator">95.76%</span>
  </label>
  <label>
    <input type="checkbox" checked data-confidence="95.76" title="Confidence: 95.76%"> Bulk Upload
    <span class="confidence-indicator">95.76%</span>
  </label>
</div>

<table class="table payment-matrix">
  <tr>
    <th>Business Product / Purpose</th>
    <th>RTGS</th>
    <th>NEFT</th>
    <th>A2A</th>
    <th>IMPS</th>
    <th>Cheque</th>
    <th>DD</th>
    <th>ECMS</th>
  </tr>
  <tr>
    <td>
      <label>Vendor
        <input type="checkbox" checked data-confidence="95.76" title="Confidence: 95.76%">
        <span class="confidence-indicator">95.76%</span>
      </label>
    </td>
    <td>
      <input type="checkbox" checked data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" checked data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" checked data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" checked data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
  </tr>
  <tr>
    <td>
      <label>Salary
        <input type="checkbox" checked data-confidence="95.76" title="Confidence: 95.76%">
        <span class="confidence-indicator">95.76%</span>
      </label>
    </td>
    <td>
      <input type="checkbox" checked data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" checked data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" checked data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" checked data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
  </tr>
  <tr>
    <td>
      <label>Tax
        <input type="checkbox" checked data-confidence="95.76" title="Confidence: 95.76%">
        <span class="confidence-indicator">95.76%</span>
      </label>
    </td>
    <td>
      <input type="checkbox" checked data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" checked data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" checked data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" checked data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
  </tr>
  <tr>
    <td>
      <label>Reimbursements
        <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
        <span class="confidence-indicator">95.76%</span>
      </label>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
  </tr>
  <tr>
    <td>
      <label>Redemption
        <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
        <span class="confidence-indicator">95.76%</span>
      </label>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
  </tr>
  <tr>
    <td>
      <label>Loan Disbursement
        <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
        <span class="confidence-indicator">95.76%</span>
      </label>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
  </tr>
  <tr>
    <td>
      <label>OAT
        <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
        <span class="confidence-indicator">95.76%</span>
      </label>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
    <td>
      <input type="checkbox" data-confidence="95.76" title="Confidence: 95.76%">
      <span class="confidence-indicator">95.76%</span>
    </td>
  </tr>
</table>

<div class="additional-options">
  <div class="special-instructions">
    <label>Special Instructions (if any)</label>
    <textarea data-confidence="92.94" title="Confidence: 92.94%"></textarea>
    <span class="confidence-indicator">92.94%</span>
  </div>
  
  <div class="access-required">
    <label>Access Required</label>
    <div class="options">
      <label>
        <input type="checkbox" checked data-confidence="92.94" title="Confidence: 92.94%"> Mobile App
        <span class="confidence-indicator">92.94%</span>
      </label>
      <label>
        <input type="checkbox" checked data-confidence="92.94" title="Confidence: 92.94%"> Trade on Net
        <span class="confidence-indicator">92.94%</span>
      </label>
      <label>
        <input type="checkbox" data-confidence="92.94" title="Confidence: 92.94%"> Trade on Mobile
        <span class="confidence-indicator">92.94%</span>
      </label>
    </div>
  </div>
  
  <div class="expiry-validation">
    <div class="expiry-days">
      <label>Expiry Days</label>
      <input type="text" value="4 DAYS" data-confidence="92.94" title="Confidence: 92.94%">
      <span class="confidence-indicator">92.94%</span>
    </div>
    <div class="beneficiary-validation">
      <label>Beneficiary Validation</label>
      <label>
        <input type="checkbox" data-confidence="92.94" title="Confidence: 92.94%"> On Screen
        <span class="confidence-indicator">92.94%</span>
      </label>
      <label>
        <input type="checkbox" data-confidence="92.94" title="Confidence: 92.94%"> Bulk
        <span class="confidence-indicator">92.94%</span>
      </label>
    </div>
  </div>
</div>
<h3 class="section-header">4. USER INFORMATION</h3>
<table class="table">
  <tr>
    <th>User Full Name</th>
    <th>User Role</th>
    <th>User Email ID</th>
    <th>Mobile Numbers</th>
  </tr>
  <tr>
    <td>
      <input type="text" 
             class="input-text" 
             value="ABC PLEASE" 
             data-confidence="99.41"
             title="Confidence: 99.41%">
      <span class="confidence-indicator">99.41%</span>
    </td>
    <td>
      <input type="text" 
             class="input-text" 
             value="TAREA" 
             data-confidence="99.73"
             title="Confidence: 99.73%">
      <span class="confidence-indicator">99.73%</span>
    </td>
    <td>
      <input type="email" 
             class="input-email" 
             value="SEPADATE POESIGN" 
             data-confidence="99.65"
             title="Confidence: 99.65%">
      <span class="confidence-indicator">99.65%</span>
    </td>
    <td>
      <input type="text" 
             class="input-text" 
             value="999999999" 
             data-confidence="100"
             title="Confidence: 100%">
      <span class="confidence-indicator">100%</span>
    </td>
  </tr>
  <tr>
    <td>
      <input type="text" 
             class="input-text" 
             value="XY2" 
             data-confidence="99.41"
             title="Confidence: 99.41%">
      <span class="confidence-indicator">99.41%</span>
    </td>
    <td>
      <input type="text" 
             class="input-text" 
             value="CHECKER" 
             data-confidence="99.73"
             title="Confidence: 99.73%">
      <span class="confidence-indicator">99.73%</span>
    </td>
    <td>
      <input type="email" 
             class="input-email" 
             value="dadd e gual PUNE COM and" 
             data-confidence="99.65"
             title="Confidence: 99.65%">
      <span class="confidence-indicator">99.65%</span>
    </td>
    <td>
      <input type="text" 
             class="input-text" 
             value="888888888" 
             data-confidence="100"
             title="Confidence: 100%">
      <span class="confidence-indicator">100%</span>
    </td>
  </tr>
</table>

"""

hdfc_information_extraction_prompt = """
You are tasked with generating precise HTML code for the document type provided.

Critical Instructions:
  -Output Format: Only the inner content that would go inside the <body> tag is required; do not include the outer <html>, <head>, or <body> tags. Provide the HTML content exactly as it should appear within the <body> tag, without any surrounding HTML document structure. The output should not include any summaries, explanations, or descriptions—only the needed inner body HTML code.
  -Content Structure: Ensure the HTML maintains the integrity of the original form's layout, including all interactive elements such as text fields, checkboxes, and tables.
  -Follow Guidelines: Use proper HTML tags for structure and CSS classes for styling as outlined in the guidelines provided below.
  -No Additional Text: The response should only include inner body HTML code. Any attempt to provide additional context or explanation should be avoided.
 
Follow these guidelines to ensure that the HTML output is accurate, complete, and adaptable to any form, regardless of its complexity.

General Instructions:
1. Editable Elements Only:
-Focus: Extract and include only content that requires user interaction, such as text fields (<input>), checkboxes (<input type="checkbox">), radio buttons (<input type="radio">), and editable tables. Do not include static text, notes, instructions, or signature sections that do not require user input.
2. Ignore Static Content:
- Skip over any paragraphs (<p>), notes, or other static content that is not tied to an interactive element. Only extract sections where users input information.
3. Skip Signature and Notes Sections:
- Explicitly avoid extracting or including sections like "For Intellect," signature fields, or any non-editable notes.
4. Form Sections:
-Presence of Various Sections: The form may include various sections such as 'Client Information', 'Accounts Mapping Information', 'Payment Module', 'User Information', 'User Access Rights Information', 'Beneficiary Information For Mapping', 'Bulk Tax Registration Format For Direct Taxes(CBDT)' etc. While these sections are commonly present in ENet Corporate Internet Banking Services- Application forms, the existence of each section is not guaranteed.
-Identify and Title Each Section: Clearly identify and title each section of the form using appropriate HTML tags such as <h3> for section titles. For example, if the form contains a section for "5. User Access Rights Information," this should be reflected with a title like <h3>5. User Access Rights Information</h3>.
-Multi-Row and Multi-Column Table Structure:
-For any section that contains multiple fields arranged in rows and columns, especially when rows contain distinct elements (e.g., one row for labels and another for input fields), use HTML <table>, <tr>, and <td> tags to accurately maintain alignment and structure. Ensure that each row and column in the form is correctly represented in the HTML.
-For the "User Access Rights Information" section, ensure that the "Business Products Array" is structured with a broader column that spans multiple sub-columns (e.g., "Only View," "Vendor," "Salary," "Tax," "Reimbursement," "Investment," "Redemption," "Loan Disbursement," and "OAT"). Each sub-column should contain individual checkboxes, and the alignment must reflect the hierarchical structure with the broader "Business Products Array" at the top.
-Handling Split Cells Across Rows: If a column contains data split across multiple rows (e.g., "User Full Name" with "123456789" in one row and "Corp User" in the next row), represent this by using multiple <tr> tags within the same <td>. Ensure that the data is not combined into a single cell unless it appears that way in the original form.
5. Fields within Sections:
-Only extract content related to editable elements like text fields, radio buttons, checkboxes, and tables. Skip over any static text, instructions, notes, or signature sections that do not require user input. These fields may or may not be present depending on the specific form you are processing. Expected Sections and the field listing within each section has been provided below in Section-Specific Instructions. However, please be advised that this should only serve as a reference and not a mandation.
6. Element Types and Editability:
-Comprehensive Input Types: Include all relevant input types such as text fields, checkboxes, radio buttons, dropdowns, etc., ensuring each input field is editable. Use tags like <input type="text">, <input type="checkbox">, <textarea>, etc., as appropriate.
-Precision in Alignment and Positioning: Maintain the relative alignment of all labels, input fields, and other elements as per the original form. Use CSS to control spacing and alignment, ensuring that labels and fields are consistently aligned both horizontally and vertically.
-Consistent Input Field Sizing: Ensure that input fields (e.g., text boxes, email fields) are sized consistently within their designated sections. Avoid any overflow or excessive spacing by setting appropriate width and padding for these fields.
-Editable Table Fields: For sections with tables, each cell should contain editable fields where applicable. Ensure that input fields within tables are centered and aligned with their respective headers, and that table rows and columns maintain consistent sizing.
7. Handling Complex Structures:
-Tables with Multiple Rows and Columns: For any table in the form that contains multiple rows and columns, ensure that each row is accurately represented with a <tr> tag and each column with a <td> tag. For example, a "User Access Rights Information" section may have rows and columns representing different users and their access rights.
-Ensure Data Integrity Across Multiple Columns:
-When working with data that spans multiple columns, ensure that data in one column does not accidentally shift to another column, particularly when there is no data present in an adjacent cell. This can be managed by carefully structuring each <tr> and <td> tag to maintain the intended layout.
-Only include fields and structures where users provide input. Ignore any static text or non-interactive sections, including notes, terms, and signature areas

-Independent Selections for Interactive Elements: Ensure that interactive elements such as checkboxes, radio buttons, and dropdowns allow for independent selections. For example, if the form has multiple checkboxes under the same label, they should be treated as independent, allowing the user to select any combination without interference.
8. Layout, Spacing, and Consistency:
-Overall Layout Integrity: Pay close attention to the overall layout of the form. Use CSS (such as Flexbox or Grid layouts) to ensure that the form maintains its structural integrity, especially in complex sections like tables.
-Balanced Spacing: Ensure consistent margins and padding between form sections to maintain a visually balanced and user-friendly layout. Avoid excessive padding or margins that might disrupt the flow of the form.
-Alignment in Complex Forms: For complex forms, use grid or flexbox layouts to manage alignment, particularly in multi-column sections or nested tables. Ensure that all elements, including those in tables, are positioned correctly relative to each other.
9. Completeness and Accuracy:
-No Omissions:  No Omissions in the interactive elements. Skip sections such as notes, terms, and signature lines unless they contain editable fields. Every field, particularly those in tables or aligned in non-standard ways, should be correctly represented and editable.
-Correct Data Reflection: Ensure that pre-filled data (e.g., checked checkboxes, filled text fields) is accurately reflected in the HTML. Validate that each field's content matches the original form's data without discrepancies.
-Multi-Line Text Fields: Ensure that any multi-line text fields or special instructions are correctly captured and formatted within their designated areas, using <textarea> tags where applicable.
10. Adaptation for Any Form:
-Universally Applicable HTML: The generated HTML should be adaptable to any form, regardless of complexity. All elements, fields, and sections should be included, ensuring the form is comprehensive and functional.
-Editable and Functional Elements: Ensure that all interactive elements (text fields, checkboxes, radio buttons, dropdowns) are editable and correctly positioned. This includes elements within tables, lists, or other complex structures.
11. Applying Styles:
-Section Headers: Apply the section-header class to all section titles. Example: <h3 class="section-header">Section Title</h3>.
-Tables: Apply the table class to all <table> elements. Example: <table class="table">.
-Table Headers and Data Cells: Ensure <th> and <td> elements within tables are consistently styled using the table class applied to the <table> element.
-Input Text Fields: Apply the input-text class to all <input type="text"> fields. Example: <input type="text" class="input-text">.
-Input Email Fields: Apply the input-email class to all <input type="email"> fields. Example: <input type="email" class="input-email">.
-Input Date Fields: Apply the input-date class to all <input type="date"> fields. Example: <input type="date" class="input-date">.
-Textareas: Apply the textarea class to all <textarea> elements. Example: <textarea class="textarea"></textarea>.
-Checkboxes: Apply the checkbox class to all <input type="checkbox"> elements. Example: <input type="checkbox" class="checkbox">.
12. Validation and Data Consistency:
-Preview and Validation: Include a validation step to preview the HTML output and ensure all elements are correctly aligned and editable. Adjust CSS as needed to correct any misalignments or inconsistencies.
-Consistency Across Sections: Ensure that data is consistently represented across different sections of the form. Cross-verify that fields, especially in sections like user information or financial details, are accurately reflected and editable.

Additional Changes:
-Add the section numbers before each section title, like 5. User Access Rights Information, 6. Beneficiary Information for Mapping, etc.
-Move any text note that is present at the end of the form to be positioned correctly as it is in the original form.

Section-Specific Instructions:
1. For each section, do not miss on any information. No omissions please. But include only the interactive elements, such as fields where users provide information. Do not include any static or non-interactive text.

2. Client Information Section
Possible Fields:
-Existing eNet Setup: This field may include radio buttons for "Yes" and "No," accompanied by a text field for entering a "Domain/Group ID."
-Date of Application: A date input field that might look like <input type="date" value="09/08/2024">.
-Company Name: A text input field with the company name pre-filled, e.g., <input type="text" value="ABC LIMITED.">.
-Company Address: This could be a text area or a text input field for entering the address.
-Contact Person Details: This field might include sub-fields for "Full Name," "Telephone/Mobile No.," and "E-mail ID," each represented by their respective input fields.
Example Layout:
A possible layout could include a table with the above fields organized into rows. However, the actual layout may vary depending on the form's design. Here's an example HTML structure for this section:
<div class="section-title-wrapper">
<h3 class="section-header">1. CLIENT INFORMATION</h3>
<div class="enet-setup-wrapper">
<label>Existing eNet Setup?</label>
<input type="radio" name="enet_setup" value="yes" checked> Yes
<input type="text" value="TEST" style="width: 120px; margin-left: 5px; margin-right: 10px;">
<input type="radio" name="enet_setup" value="no"> No
</div>
</div>

<table class="table">
<tr>
<td class="label">Date of Application:</td>
<td class="input-field"><input type="date" value="2024-08-09"></td>
</tr>
<tr>
<td class="label">Company Name:</td>
<td class="input-field"><input type="text" value="ABC LIMITED."></td>
</tr>
<tr>
<td class="label">Company Address:</td>
<td class="input-field"><textarea>KANJURMARG-EAST, MUMBAI.</textarea></td>
</tr>
<tr>
<td class="label">Full Name:</td>
<td class="input-field"><input type="text" value="MR. XYZ"></td>
</tr>
<tr>
<td class="label">Telephone/Mobile No.:</td>
<td class="input-field"><input type="text" value="9999999999"></td>
</tr>
<tr>
<td class="label">E-mail ID:</td>
<td class="input-field"><input type="email" value="abcd@gmail.com"></td>
</tr>
</table>
3. Accounts Mapping Information Section
Possible Fields:
-Bank Account Number: This field should be represented as a text input field within a table structure. The expected format could be similar to <input type="text" value="123456789">.
-Bank Account Name as per Bank's record: This field should also be a text input field and aligned in the same row as "Bank Account Number" within the table structure. An example format might be <input type="text" value="ABC LIMITED">.
Example Layout:
A possible layout could include a table with two columns: one for "Bank Account Number" and another for "Bank Account Name as per Bank's record." Both fields should be in the same row to maintain the original structure's integrity. Here’s an example HTML structure for this section:

<h3 class="section-header">2. ACCOUNTS MAPPING INFORMATION</h3>
<table class="table">
<tr>
<th>Bank Account Number</th>
<th>Bank Account Name as per Bank's record</th>
</tr>
<tr>
<td><input type="text" value="123456789"></td>
<td><input type="text" value="ABC LIMITED"></td>
</tr>
</table>

4. Payment Module Section
Possible Fields:
-Business Product / Purpose: A list of products with associated checkboxes. Each product (e.g., Vendor, Salary, Tax, etc.) will have a checkbox on the right side that may be checked or unchecked.
-Payment Product: A set of checkboxes across columns for various payment methods (RTGS, NEFT, A2A, IMPS, Cheque, DD, ECMS) for each business product/purpose. These checkboxes should accurately reflect their checked or unchecked status.
-Special Instructions (If any): This is a label without a checkbox, placed within the first column but spanning the width of the table for special instructions.
-Access Required: A set of checkboxes for access options like "Mobile App," "Trade on Net," and "Trade on Mobile." All checkboxes should be placed in a single row within the second column.
-Expiry Days: A text field that appears in the first column labeled "Expiry Days" with a value entered (e.g., "4 DAYS").
-Beneficiary Validation: A set of checkboxes for validation options like "On Screen" and "Bulk," placed in the second column adjacent to "Expiry Days." These checkboxes may be unchecked.
Example Layout:
-The "Payment Module" section should be represented as a table where each business product/purpose is listed in the first column, and payment products are listed across the top as column headers. The cells beneath each column header contain checkboxes. Ensure that the alignment of checkboxes is consistent and that the special instructions are correctly placed in the first column.
-The "Payment Module" section title (<h3 class="section-header">) must include the right-aligned options for "On Screen" and "Bulk Upload" within the <h3> tag itself. The complete structure should look like this:
<h3 class="section-header">3. PAYMENT MODULE
<div class="right-aligned-options">
<label><input type="checkbox" checked> On Screen</label>
<label><input type="checkbox" checked> Bulk Upload</label>
</div>
</h3>
-Access options and expiry days should be placed in subsequent rows, ensuring that all checkboxes and text fields are correctly aligned with their labels. Here's an example HTML structure for this section:

<h3 class="section-header">3. PAYMENT MODULE
<div class="right-aligned-options">
<label><input type="checkbox" checked> On Screen</label>
<label><input type="checkbox" checked> Bulk Upload</label>
</div>
</h3>

<table class="table">
<tr>
<th rowspan="2">Business Product / Purpose</th>
<th colspan="7">Payment Product</th>
</tr>
<tr>
<th>RTGS</th>
<th>NEFT</th>
<th>A2A</th>
<th>IMPS</th>
<th>Cheque</th>
<th>DD</th>
<th>ECMS</th>
</tr>
<tr>
<td class="product">Vendor<input type="checkbox" checked style="float: right;"></td>
<td><input type="checkbox" checked></td>
<td><input type="checkbox" checked></td>
<td><input type="checkbox" checked></td>
<td><input type="checkbox" checked></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
</tr>
<tr>
<td class="product">Salary<input type="checkbox" checked style="float: right;"></td>
<td><input type="checkbox" checked></td>
<td><input type="checkbox" checked></td>
<td><input type="checkbox" checked></td>
<td><input type="checkbox" checked></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
</tr>
<tr>
<td class="product">Tax<input type="checkbox" checked style="float: right;"></td>
<td><input type="checkbox" checked></td>
<td><input type="checkbox" checked></td>
<td><input type="checkbox" checked></td>
<td><input type="checkbox" checked></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
</tr>
<tr>
<td class="product">Reimbursements<input type="checkbox" style="float: right;"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
</tr>
<tr>
<td class="product">Redemption<input type="checkbox" style="float: right;"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
</tr>
<tr>
<td class="product">Loan Disbursement<input type="checkbox" style="float: right;"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
</tr>
<tr>
<td class="product">OAT<input type="checkbox" style="float: right;"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
</tr>
<tr>
<td class="product">Special Instructions (If any):</td>
<td colspan="7"></td>
</tr>
<tr>
<td class="product">Access Required</td>
<td colspan="7">
<label><input type="checkbox" checked> Mobile App</label>
<label><input type="checkbox" checked> Trade on Net</label>
<label><input type="checkbox"> Trade on Mobile</label>
</td>
</tr>
<tr>
<td class="product">
Expiry Days <input type="text" value="4 DAYS" style="width: 100px; margin-left: 10px;">
</td>
<td colspan="7">
<label>Beneficiary Validation</label>
<label><input type="checkbox"> On Screen</label>
<label><input type="checkbox"> Bulk</label>
</td>
</tr>
</table>
5. User Information Section
Possible Fields:
-User Full Name: This field is represented as a text input field, where the full name of the user will be entered. An example format might be <input type="text" value="User's Name">.
-User Role: This field indicates the role of the user (e.g., Maker, Checker) and is represented as a text input field. The expected format could be <input type="text" value="User's Role">.
-User Email ID: This field is represented as an email input field, where the user's email address will be entered. The format might look like <input type="email" value="user@example.com">.
-Mobile Number: This field captures the user's mobile number and is represented as a text input field. The expected format could be <input type="text" value="9999999999">.
Example Layout:
-The "User Information" section should be structured as a table with four columns: "User Full Name," "User Role," "User Email ID," and "Mobile Number." Each row corresponds to a separate user, and the fields should be organized as follows. Here's an example HTML structure for this section:

<h3 class="section-header">4. USER INFORMATION</h3>
<table class="table">
<tr>
<th>User Full Name</th>
<th>User Role</th>
<th>User Email ID</th>
<th>Mobile Number</th>
</tr>
<tr>
<td><input type="text" class="input-text" value="ABC"></td>
<td><input type="text" class="input-text" value="Maker"></td>
<td><input type="email" class="input-email" value="abcde@gmail.com"></td>
<td><input type="text" class="input-text" value="9999999999"></td>
</tr>
<tr>
<td><input type="text" class="input-text" value="XYZ"></td>
<td><input type="text" class="input-text" value="Checker"></td>
<td><input type="email" class="input-email" value="dddde@gmail.com"></td>
<td><input type="text" class="input-text" value="8888888888"></td>
</tr>
</table>
6. User Access Rights Information Section
Possible Fields:
-User Full Name: This field should be represented as a text input field where the user's full name is entered. An example format might be <input type="text" value="User's Full Name">.
-Account No for Access: This field should be a text input field, which could be empty depending on the form. Example: <input type="text">.
-Business Products Array: This section includes various business product options such as "Only View," "Vendor," "Salary," "Tax," "Reimbursement," "Investment," "Redemption," "Loan Disbursement," and "OAT." Each of these should be represented as checkboxes, with the layout reflecting the hierarchy under a broader column named "Business Products Array."
-Others (Please Specify): A text input field for any other specifications, placed at the end of the row. Example: <input type="text" placeholder="Please specify">.
Example Layout:
<h3 class="section-header">5. User Access Rights Information</h3>
<table class="table">
 <tr>
<th rowspan="2">User Full Name</th>
<th rowspan="2">Account No for Access</th>
<th colspan="9">Business Products Array (Please TICK to enable below options for each user)</th>
<th rowspan="2">Others (Please Specify)</th>
 </tr>
 <tr>
<th>Only View</th>
<th>Vendor</th>
<th>Salary</th>
<th>Tax</th>
<th>Reimbursement</th>
<th>Investment</th>
<th>Redemption</th>
<th>Loan Disbursement</th>
<th>OAT</th>
 </tr>
 <tr>
<td>123456789</td>
<td></td> <!-- This field is empty as it should be -->
<td><input type="checkbox"></td>
<td><input type="checkbox" checked></td>
<td><input type="checkbox" checked></td>
<td><input type="checkbox" checked></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="text" placeholder="Please specify"></td>
 </tr>
 <tr>
<td>Corp User</td>
<td></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="checkbox"></td>
<td><input type="text"></td>
 </tr>
</table>
7. Beneficiary Information For Mapping
Possible Fields:
-Beneficiary Code: This field is represented as a text input field for entering the beneficiary code. Example: <input type="text" value="B123">.
-Beneficiary Name: A text input field to enter the beneficiary's name. Example: <input type="text" value="My Beneficiary">.
-Beneficiary A/C No: A text input field for the beneficiary's account number. Example: <input type="text" value="A12345">.
-IFSC Code: A text input field for entering the IFSC code. Example: <input type="text" value="CITI00005">.
-E-mail ID: A text input field for entering the beneficiary's email address. Example: <input type="email" value="beneficiary@gmail.com">.
Example Layout:
The "Beneficiary Information For Mapping" section should be structured as a table with five columns: "Beneficiary Code," "Beneficiary Name," "Beneficiary A/C No," "IFSC Code," and "E-mail ID." Each row corresponds to a separate beneficiary's details, and the fields should be organized as follows:

<h3 class="section-header">6. Beneficiary Information For Mapping</h3>
<table class="table">
<tr>
<th>Beneficiary Code</th>
<th>Beneficiary Name</th>
<th>Beneficiary A/C No</th>
<th>IFSC Code</th>
<th>E-mail ID</th>
</tr>
<tr>
<td><input type="text" value="B123" class="input-text"></td>
<td><input type="text" value="My Beneficiary" class="input-text"></td>
<td><input type="text" value="A12345" class="input-text"></td>
<td><input type="text" value="CITI00005" class="input-text"></td>
<td><input type="email" value="beneficiary@gmail.com" class="input-email"></td>
</tr>
</table>
7. Bulk Tax Registration Format For Direct Taxes (CBDT)
Possible Fields:
-PAN / TAN: A text input field for entering the PAN/TAN. Example: <input type="text" value="ABCDE1234X">.
-Full Name: A text input field for entering the full name. Example: <input type="text" value="ABC CORP">.
-Premises / Building: A text input field for entering the premises/building name. Example: <input type="text" value="Silver Metropolis">.
-Flat / Door / Block No: A text input field for entering the flat, door, or block number. Example: <input type="text" value="8th">.
-Road / Street / Lane: A text input field for entering the road, street, or lane. Example: <input type="text" value="West Hwy">.
-Area / Locality: A text input field for entering the area or locality. Example: <input type="text" value="Goregaon">.
-State: A text input field for entering the state. Example: <input type="text" value="MH">.
-Pin Code: A text input field for entering the pin code. Example: <input type="text" value="400063">.

Example Layout:
The "Bulk Tax Registration Format For Direct Taxes (CBDT)" section should be structured as a table with eight columns: "PAN / TAN," "Full Name," "Premises / Building," "Flat / Door / Block No," "Road / Street / Lane," "Area / Locality," "State," and "Pin Code." Each row corresponds to a separate entry, and the fields should be organized as follows:

<h3 class="section-header">7. Bulk Tax Registration Format For Direct Taxes (CBDT)</h3>
<table class="table">
<tr>
<th>PAN / TAN</th>
<th>Full Name</th>
<th>Premises / Building</th>
<th>Flat / Door / Block No</th>
<th>Road / Street / Lane</th>
<th>Area / Locality</th>
<th>State</th>
<th>Pin Code</th>
</tr>
<tr>
<td><input type="text" value="ABCDE1234X" class="input-text"></td>
<td><input type="text" value="ABC CORP" class="input-text"></td>
<td><input type="text" value="Silver Metropolis" class="input-text"></td>
<td><input type="text" value="8th" class="input-text"></td>
<td><input type="text" value="West Hwy" class="input-text"></td>
<td><input type="text" value="Goregaon" class="input-text"></td>
<td><input type="text" value="MH" class="input-text"></td>
<td><input type="text" value="400063" class="input-text"></td>
</tr>
</table>
"""

file_classification_prompt = """
    Follow the Instructions given to you in input context.
    Steps for Generating Response:
                    [
                        "instruction": Analyze the given context and determine which of the following categories it belongs to:
                            1> A Corporate Payments Onboarding file is a comprehensive document used to facilitate the integration of a corporation into a payment processing system. This file includes critical details such as the company’s banking information. Additionally, it encompasses the specifics of the payments transaction file, which outlines the format and structure for various types of payment transactions the corporation will process. The onboarding file ensures that the corporation is set up correctly and securely for handling transactions, maintaining compliance with regulatory requirements, and enabling efficient financial operations.
                                - If the file contains headers, respond with: <type>CPO_WithHeaders</type>
                                - If the file does not contain headers, respond with: <type>CPO_WithoutHeaders</type>
                            2> A Corporate Payments Onboarding Template file is a predefined document that outlines the structure and format required for integrating corporate payments. This template helps ensure that the data is prepared correctly according to predefined standards and requirements for smooth processing.
                                - Respond with: <type>CPO_Template</type>
                            3> A Board Resolution document is an official record of decisions made by a company's board of directors. This document typically includes resolutions for significant corporate actions, such as opening new bank accounts, authorizing certain officers to act on behalf of the company, and approving major financial transactions. The document serves as a legal record that provides formal authorization for these actions and is essential for maintaining corporate governance and compliance. The Board Resolution document ensures that the decisions made are documented and authorized according to the company's bylaws and regulatory requirements.
                                - Respond with: <type>BR</type>
                            4> A Corporate Internet Banking Onboarding Form is a detailed document used to facilitate the setup of corporate internet banking services. This form usually includes sections for client information, accounts mapping, payment module preferences, and user roles. It is a critical document for configuring access to online banking services, setting up roles, and defining payment types.
                                - Respond with: <type>CIB_OnboardingForm</type>
                            5> Out of our domain.
                                - Respond with: <type>outOfDomain</type>

                        "instruction": "For the given context of data, understand what this data is about. Give a summary in 2-3 sentences."
                            "Critical": <summary><p>output of summary</p></summary>, // Replace with the actual summary

                        "instruction": After analyzing if you think that this file contains the following fields or relates to these fields, then please say: "You can perform some actions like below for this file:"
                            "Options": ["generate iso mapping for upload file format", "control file format", "reverse file format"]
                            "CRITICAL INSTRUCTION": Give this instruction output if anything related to the Upload File field is available in the given input context.
                            "output format": Give output inside tags = <options>output of this instruction</options>
                            NOTE: There should be separate <option></option> tags for each option. Do not include '\n' or '<br>' inside the tags. Do not provide the <option></option> tag for the group of options.
                    ]

    Very important: Output should be always in tags following above instructions.
"""

domain_classification_prompt = """
    You are an expert in the corporate transaction banking domain. Analyze the following content to classify the file. Based on the content, identify the domain and the specific type of file. The domains may include but are not limited to: Trade and Finance, Supply Chain Finance, Receivables, Payments, Corporate Lending, Treasury Management, Compliance, and Risk Management. The file types may include templates, onboarding documents, transactional data files, reconciliation reports, and more.
    When identifying the file type, consider the following hints for each domain. Output should be only from one of below classes:
        Payments: Look for fields related to payment instructions, collections processes, file validation rules, and disbursements. Common file types include Collection Files, Transactional Data Files, Disbursement Instructions, and Reconciliation Reports. This can also have onboarding forms, some personal account application, etc.
        Return tags : <type>Payments</type>


        Trade and Finance: Look for fields related to trade transactions, import/export details, and payment terms. Common file types include Trade Finance Documents, Letters of Credit, and Shipping Documents. 
        It can also have mixed documents inside it like:  purchase order, bill of lading, invoices, airways bill, bank guarantees, bill of exchanges, etc
        Return tags : <type>TF</type>


    If the content does not match any of the known domains or file types, provide the closest possible classification and mention that it is unrecognized. Describe any notable characteristics or key fields that might help in identifying the domain and file type in the future.

    Note: If the content is unrecognized, provide the closest possible classification.
"""



json_information_extraction_prompt = '''

You are tasked with generating precise JSON output for the document content provided from the image input.

### Critical Instructions:
- Input Format: The input will be an image of a form or document. Extract all relevant fields and interactive elements.
- Output Format: Provide the extracted data in structured JSON format. The JSON should reflect the document's content, separating each section and grouping related fields together. Include only the data that requires user input or relevant information from the form.
- Sections and Fields: Ensure each section of the form is represented as a key in the JSON, with corresponding fields as nested keys. Fields that include checkboxes, text inputs, radio buttons, and tables should be captured accurately.
  
### Guidelines:

1. Field Extraction: 
   - For each section of the form, identify and extract content that requires user interaction or input, such as text fields, checkboxes, radio buttons, and tables.
   - Ignore static content like labels, headings, or signature fields that do not require user input.

2. Data Structure:
   - Sections: Each section in the form should be represented as a distinct JSON object, with the section name as the key.
   - Fields: Fields within a section should be captured as key-value pairs. For example, text fields will be represented as `"field_name": "field_value"`. Checkboxes or radio buttons should use Boolean values (`true` or `false`) to indicate whether they are checked or selected.
   - Tables: If the form contains tables (for example, user access rights or payment modules), represent each row as a JSON object. Ensure all table data is aligned and categorized under appropriate keys.

3. Completeness:
   - Do not omit any interactive elements like input fields or checkboxes. Every input field that appears in the form must be represented in the JSON output, even if its value is empty or unchecked.
   - Ensure that data is captured exactly as it appears in the image.

4. Special Handling:
   - Date Fields: Convert date fields into a standard ISO date format (`YYYY-MM-DD`).
   - Phone Numbers: For fields containing phone numbers, extract them as strings to preserve any leading zeros.
   - Email Fields: Extract email fields as strings.
   - Checkboxes: Represent checkboxes and radio buttons as Boolean values (`true` if checked, `false` if unchecked).

5. Sections and Example Fields:
   - Client Information: Includes fields like "Company Name," "Address," "Date of Application," "Contact Person Details" (Full Name, Phone Number, Email).
   - Accounts Mapping Information: Fields like "Bank Account Number," "Bank Account Name as per Bank’s Record."
   - Payment Module: Includes "Business Product/Purpose" and corresponding payment products like "RTGS," "NEFT," etc., with each option's status (checked or unchecked).
   - User Information: Fields like "User Full Name," "User Role," "User Email," and "Mobile Number."
   - Other Sections: Identify and extract fields from additional sections as they appear.

### Sample JSON Output:
```json
{
  "client_information": {
    "existing_enet_setup": "yes",
    "enet_setup_test_value": "TEST",
    "date_of_application": "2024-08-09",
    "company_name": "ABC LIMITED.",
    "company_address": "KANJURMARG-EAST, MUMBAI.",
    "full_name": "MR. XYZ",
    "telephone_mobile_no": "9999999999",
    "email_id": "abcd@gmail.com"
  },
  "accounts_mapping_information": {
    "bank_account_details": [
      {
        "bank_account_number": "123456789",
        "bank_account_name": "ABC LIMITED"
      }
    ]
  },
  "payment_module": {
    "options": ["On Screen", "Bulk Upload"],
    "business_product_purpose": [
      {
        "product": "Vendor",
        "payment_products": {
          "RTGS": true,
          "NEFT": true,
          "A2A": true,
          "IMPS": true,
          "Cheque": false,
          "DD": false,
          "ECMS": false
        }
      },
      {
        "product": "Salary",
        "payment_products": {
          "RTGS": true,
          "NEFT": true,
          "A2A": true,
          "IMPS": true,
          "Cheque": false,
          "DD": false,
          "ECMS": false
        }
      }
    ],
    "special_instructions": "",
    "access_required": ["Mobile App", "Trade on Net"],
    "expiry_days": "4 DAYS",
    "beneficiary_validation": {
      "on_screen": false,
      "bulk": false
    }
  },
  "user_information": [
    {
      "user_full_name": "ABC",
      "user_role": "Maker",
      "user_email_id": "abcde@gmail.com",
      "mobile_number": "9999999999"
    },
    {
      "user_full_name": "XYZ",
      "user_role": "Checker",
      "user_email_id": "dddde@gmail.com",
      "mobile_number": "8888888888"
    }
  ]
}
```

### Validation:
Before concluding, ensure the extracted JSON is properly structured and validated for accuracy, without missing any interactive elements or sections. Double-check for alignment and consistency across different sections of the form.

'''