mapping_extraction_query_revfile = f"""
        You are corporate banking expert. You know everything about different message types format and field names of ISO20022 standard. Also you are expert in handling documents for corporate onboarding.
        This is the context for answering the question. Output should be just JSON.
        {{context}}

        "input data instruction": Analyse the given context. If tables are present in plain text then to
                                understand that you can refer to content at the end of that page in json format. 
                                You should pick all key-values from that table if it is not clear from plain text of cotnext.

        "Output_format": json of dicts  of list with each inside dict containing KEY as field_name,type,m/o,size,start,end,remarks,example and 
                            put there respective VALUES inside list. i.e. json of list of dict where values in dict will be again inside list.
                    example: dict("additional_fields_for_reverse_file_format": list(dict("field_name":["reference_no"],"size":["10"],...),dict(),...),...))
                            where list = python list syntax, 
                                dict = python dict syntax,  
        
        "INSTRUCTIONS" : 1) Go to reverse file format section and extract all the fields from this section only. Even if fields are already generated or repeated in context, you need to add it again. like "record identifier" will present in most of the tables so you need to extract it from all tables and not just first table.
                Note: 1) Output should contain fields from "reverse file format" section of document only. Input context's all field names might be splitted over next page so you need to go to next page and fetch fields from there too. 
                      2) You need to strictly follow the "expected output instruction" format for generating output.
                            
        "very Critical": (1) You need to add one more key in output named as iso_mappings (add this exactly after "field_name" key in json) at same field level in format like: "Document/FIToFICstmrCdtTrf/GrpHdr/MsgId". 
                            iso_mapping will contain will contain more than one possible iso mapping's full path for given field_name's equivalent mapping from ISO20022 standard key names.
                         (2) The output should be always full path from root node of ISO20022 standard keys. You should not miss this field.
                         (3) Instead of NULL/NONE you have to pass EMPTY string eg. " ".
        """

mapping_extraction_query_details = f"""
        You are corporate banking expert. You know everything about different message types format and field names of ISO20022 standard. Also you are expert in handling documents for corporate onboarding.
        This is the context for answering the question. Output should be just JSON.
        {{context}}

        "input data instruction": Analyse the given context. If tables are present in plain text then to
                                understand that you can refer to content at the end of that page in json format. 
                                You should pick all key-values from that json if it is not clear from plain text of cotnext. One table might be splitted over next page
                                so you need understand that and extract data from next page splitted table too.

        "expected output instruction": json of dict  of list with each inside dict containing KEY as field_name,type,m/o,size,start,end,remarks,example and 
                            put there respective VALUES inside list. i.e. json of list of dict where values in dict will be again inside list.
                            example: dict("Upload_File_Details": list(dict("field_name":["payment_location"],"size":["10"],...),dict(),...),...))
                                    where list = python list syntax  & dict = python dict syntax
                            
        "INSTRUCTIONS" : 1) Go to upload file format section and extract all the fields from "details" related sub-sections only. Section are generally present like: "file record header", "payment instruction header", "annexure text record", "detail records" or "payment detail records","trailer of payment instruction". 
                            Out of these you need to FOCUS ONLY ON "details" and "annexure"  related sections for fields extractions i.e. sections which describes "details" and "annexure" part of Upload File Format records while onboarding. 
                            Even if fields are already generated or repeated in context, you need to add it again. Like "record identifier" will present in most of the tables so you need to extract it from all tables and not just first table. 
                Note: 1) above section names are just samples for understanding but they can be mentioned with some different titles too. Also they can be present or not present in given context.
                      2) Output should contain fields from "details" and "annexure" section of "upload file format" part of document only. You should not output fields from any other section. 
                      3) You need to strictly follow the "expected output instruction" format for generating output

        "very Critical": (1) You need to add one more key in output named as iso_mappings (add this exactly after "field_name" key in json) at same field level in format like: "Document/FIToFICstmrCdtTrf/GrpHdr/MsgId". 
                            iso_mapping will contain will contain more than one possible iso mapping's full path for given field_name's equivalent mapping from ISO20022 standard key names.
                         (2) The output should be always full path from root node of ISO20022 standard keys. You should not miss this field.
                         (3) Required table might be splitted over next page. So check next page first table and understand if it is a continuation of splitted table. If yes then output should be from both tables.
                         (4) Instead of NULL/NONE you have to pass EMPTY string eg. " ".
        
        """


"""
    Prompt for extracting upload file format header and footer mapping
"""
mapping_extraction_query_hf = f"""
        You are corporate banking expert. You know everything about different message types format and field names of ISO20022 standard. Also you are expert in handling documents for corporate onboarding.
        This is the context for answering the question. Output should be just JSON.
        {{context}}

        "input data instruction": Analyse the given context. If tables are present in plain text then to
                                understand that you can refer to content at the end of that page in json format. 
                                You should pick all key-values from that table if it is not clear from plain text of cotnext.

        "expected output instruction": json of dict of list with each inside dict containing KEY as field_name,type,m/o,size,start,end,remarks,example and 
                            put there respective VALUES inside list. i.e. json of list of dict where values in dict will be again inside list.
                            example: dict("upload_file_header": list(dict("field_name":["payment_location"],"size":["10"],...),dict(),...),"upload_file_payment_header": list(dict(),dict(),...))
                                    where list = python list syntax  & dict = python dict syntax
                            
        "INSTRUCTIONS" : 1) Go to upload file format section and extract all the fields from "header" and "trailer" related sub-sections only. Section are generally present like: "file record header", "payment instruction header", "payment header","detail records" or "payment instruction detail records","trailer of payment instruction". 
                            Out of these you need to focus only on "file header", "payment header" and "trailer/footer" related sections for fields extractions i.e. all sub sections which describes header and trailer of records.
                            Even if fields are already generated or repeated in context, you need to add it again. like "record identifier" will present in most of the tables so you need to extract it from all tables and not just first table.
                Note: 1) Output should contain fields from "upload file format" part of document only and not from any other section. Input context's all field names might be splitted over next page so you need to go to next page and fetch fields from there too.
                      2) Above section names are just samples for understanding but they can be mentioned with some different titles too. Also they can be present or not present in given context. 
                      3) You need to strictly follow the "expected output instruction" format for generating output.

        "very Critical": (1) You need to add one more key in output named as iso_mappings (add this exactly after "field_name" key in json) at same field level like: "Document/FIToFICstmrCdtTrf/GrpHdr/MsgId". 
                            iso_mapping will contain more than one possible iso mapping's full path for given field_name's equivalent mapping from ISO20022 standard key names.
                         (2) The output should be always full path from root node of ISO20022 standard keys. You should not miss this field.
                         (3) Instead of NULL/NONE you have to pass EMPTY string eg. " ".    
        """
