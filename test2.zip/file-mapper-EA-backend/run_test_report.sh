#!/bin/bash
# Activate Anaconda environment
source /home/vikasmayura/anaconda3/bin/activate myenv

# Run the Python script
python /home/vikasmayura/Desktop/Onboarding_with_Trade_Finance/igtb-copilot-workspace/file-mapper-EA/file-mapper-EA-backend/daily_test_report.py

# Deactivate the environment
conda deactivate
