"""
Generate a system prompt that describes the capabilities of the assistant.

Returns:
    str: The system prompt text.
"""


def getSystemPrompt():
    """
    Generate a system prompt that describes the capabilities of the assistant.
    
    Returns:
        str: The system prompt text.
    """
    system_prompt = "You are a helpful assistant.Your name is Lisa.When a user asks questions like 'What can you do for me?', 'Help me', or 'Do something for me', provide a concise yet comprehensive explanation about your capabilities. You specialize in two main categories: Financial Insights and General Assistance. For Financial Insights, you can analyze financial data, identify trends, provide actionable insights, and generate visual reports. For General Assistance, I can answer questions on a wide range of topics, provide explanations, generate creative content, simulate conversation, and more. Explain your capabilities based on these specializations."
    return system_prompt


def getSystemPrompt():
    """
    Generate a system prompt that describes the capabilities of the assistant.

    Returns:
        str: The system prompt text.
    """
    system_prompt = "You are a helpful assistant.Your name is Lisa.When a user asks questions like 'What can you do for me?', 'Help me', or 'Do something for me', provide a concise yet comprehensive explanation about your capabilities. You specialize in two main categories: Financial Insights and General Assistance. For Financial Insights, you can analyze financial data, identify trends, provide actionable insights, and generate visual reports. For General Assistance, I can answer questions on a wide range of topics, provide explanations, generate creative content, simulate conversation, and more. Explain your capabilities based on these specializations."
    return system_prompt


def gettemplate0(Question,chat_history,context):
    """
    Generate a query template for classifying and responding to a question as normal chat, financial insights, or financial analysis.

    Args:
        Question (str): The user's question.
        chat_history (str): The chat history context.
        context (str): Additional context for answering the question.

    Returns:
        str: The formatted query template.
    """

    query = f"""
    ### Question: {Question}
    ### Chat History: 
    {chat_history}
    ### Context for Answering Questions: 
    {context}

    ### Steps for Generating Response: 
        Your task is to classify the Question into one of the following categories and respond within <classification></classification> tags. Additionally, follow the specific instructions for each category:

    a) normalchat:
        - Use this classification for general questions not related to the document.
        - Respond to the question within <normalchat></normalchat> tags.
        - When there is a option selection then please detect the normal chat.
        Important : If you classify the text as normalchat then there should be response in the <normalchat></normalchat> tags.
        e.g "Please proceed with option 2" then it should be <classification>normalchat</classification>

    b) showInGrid:
        - This classification applies to specific scenarios:
            1. ISO mappings for 'upload file format' or 'reverse file format' in corporate payments file.
            2. Instructions to proceed with, or choices of, 'upload file format' or 'reverse file format' in corporate payments file.
            3. Inquiries about authorized signatories from a board resolution document.
            4. Requests for approval matrix information from a board resolution document.
            5. Requests for generating mappings for selected file.
        Important : If the question is about above 4 points then only give the showInGrid classification else it will be chatpdf classfication. 
        - Provide the section code relevant to the question within <sectioncode></sectioncode> tags. Use one of these codes:
            - UFF (Upload File Format). Whenever question is please generate mappings for selected file.
            - CFF (Control File Format)
            - RFF (Reverse File Format)
            - AS (Authorised Signatory)
            - AM (Approval Matrix)
        - Note: These scenarios should always be classified as 'showInGrid', even if they could also fit under 'chatpdf'.
    
    c) chatpdf:
        - Use this classification for questions related to the document, except for the scenarios explicitly listed under 'showInGrid'.
    
    if(<classification>chatpdf</classification>) Then please respond in <chatwithpdf>response to the question</chatwithpdf> tags.
    Important: Ensure each question receives only one classification. Use <br>, <ul>, <li> tags wherever necessary. Consider the chat history in your response.
    IMPORTANT & CRITICAL : Below is the classification priority. You should check the question in below order only.
    A) showInGrid
    B) chatpdf
    C) normalchat
    """
    return query


def gettemplate1(question, sectionname):
    """
    Generate a query template for extracting JSON data from a document section.
    Deprecated.

    Args:
        question (str): The user's question.
        sectionname (str): The name of the section to analyze.

    Returns:
        str: The formatted query template.
    """

    query = f"""
        Question : {question}

        This is the context for answering the question. 
        {{context}}

        Steps for Generating Response :-
            <json>[
                "instruction": "Analyze the entire table from the specified {sectionname} section in the document. 
                This table contains details about various payment fields relevant to {sectionname}, 
                including attributes such as size, start position, and mandatory/optional status. 
                For each {sectionname} field, review all attributes and provide a JSON object representing the entire table. 
                Each field in the JSON should include key:value pairs for all its attributes and the complete ISO mapping XPath for that field. 
                Final output should be list of JSONs . Each JSON will represent the row of table with columns as keys.
                CRITICAL and IMPORTANT: Ensure you include all rows in the table and provide comprehensive ISO mapping XPaths for each. Make sure that if multiple ISO Mappings are possible, do include all the possible ISO mappings in the JSON object as an array.",
                "section": "{sectionname}", 
                "requirements": [
                    "sendResponseIn<json></json>TagsOnly": true,
                    "analyzeEntireTable": true,
                    "provideCompleteISOMapping": true,
                    "createJSONStructure": true,
                ]
            ]</json>
            Important : 
                The values should be in the list. There can be multiple values, please make sure to include all of them in the list.
                Make sure that 'Field' and 'S.N' contains only single element in list.
                The Numbers in the value list should be in the Int format.
                The ISOmapping should be Xpath.
        CRUCIAL NOTE: Please do not generate the '\\' or '\n' characters in json. the json should be plain  space seperated string.
            VERY VERY IMPORTANT: Make sure that the whole response is in one <json></json> tag only.The output should only be of the {sectionname}
        """
    return query


def get_update_mappings_template(question, sectionname):
    """
    Generate the mappings again as per user query.

    Args:
        question (str): The user's question.
        sectionname (str): The name of the section to analyze.

    Returns:
        str: The formatted query template.
    """

    query = f"""
        Question : {question}

        This is the context for answering the question. 
        {{context}}

        Steps for Generating Response :-
            <json>[
                "instruction": "Analyze the entire table from the specified {sectionname} section in the document. 
                This table contains details about various payment fields relevant to {sectionname}, 
                including attributes such as size, start position, and mandatory/optional status. 
                For each {sectionname} field, review all attributes and provide a JSON object representing the entire table. 
                Each field in the JSON should include key:value pairs for all its attributes and the complete ISO mapping XPath for that field. 
                Final output should be list of JSONs . Each JSON will represent the row of table with columns as keys.
                CRITICAL and IMPORTANT: Ensure you include all rows in the table and provide comprehensive ISO mapping XPaths for each. Make sure that if multiple ISO Mappings are possible, do include all the possible ISO mappings in the JSON object as an array.",
                "section": "{sectionname}", 
                "requirements": [
                    "sendResponseIn<json></json>TagsOnly": true,
                    "analyzeEntireTable": true,
                    "provideCompleteISOMapping": true,
                    "createJSONStructure": true,
                ]
            ]</json>
            Important : 
                The values should be in the list. There can be multiple values, please make sure to include all of them in the list.
                Make sure that 'Field' and 'S.N' contains only single element in list.
                The Numbers in the value list should be in the Int format.
                The ISOmapping should be Xpath.
        CRUCIAL NOTE: Please do not generate the '\\' or '\n' characters in json. the json should be plain  space seperated string.
            VERY VERY IMPORTANT: Make sure that the whole response is in one <json></json> tag only.The output should only be of the {sectionname}
        """
    return query


def getsummary():
    """
    Generate a summary template for analyzing document context.

    Returns:
        str: The formatted summary template.
    """
    
    prompt = f"""
                Question: Follow the Instructions given to you in input context.
                This is the context for answering the question.
                {{context}}

                Steps for Generating Response:
                [
                    "instruction": Analyze the given context and determine which of the following categories it belongs to:
                        1> A Corporate Payments Onboarding file is a comprehensive document used to facilitate the integration of a corporation into a payment processing system. This file includes critical details such as the company’s banking information. Additionally, it encompasses the specifics of the payments transaction file, which outlines the format and structure for various types of payment transactions the corporation will process. The onboarding file ensures that the corporation is set up correctly and securely for handling transactions, maintaining compliance with regulatory requirements, and enabling efficient financial operations.
                            - If the file contains headers, respond with: <type>CPO_WithHeaders</type>
                            - If the file does not contain headers, respond with: <type>CPO_WithoutHeaders</type>
                        2> A Corporate Payments Onboarding Template file is a predefined document that outlines the structure and format required for integrating corporate payments. This template helps ensure that the data is prepared correctly according to predefined standards and requirements for smooth processing.
                            - Respond with: <type>CPO_Template</type>
                        3> A Board Resolution document is an official record of decisions made by a company's board of directors. This document typically includes resolutions for significant corporate actions, such as opening new bank accounts, authorizing certain officers to act on behalf of the company, and approving major financial transactions. The document serves as a legal record that provides formal authorization for these actions and is essential for maintaining corporate governance and compliance. The Board Resolution document ensures that the decisions made are documented and authorized according to the company's bylaws and regulatory requirements.
                            - Respond with: <type>BR</type>
                        4> A Corporate Internet Banking Onboarding Form is a detailed document used to facilitate the setup of corporate internet banking services. This form usually includes sections for client information, accounts mapping, payment module preferences, and user roles. It is a critical document for configuring access to online banking services, setting up roles, and defining payment types.
                            - Respond with: <type>CIB_OnboardingForm</type>
                        5> Out of our domain.
                            - Respond with: <type>outOfDomain</type>

                    "instruction": "For the given context of data, understand what this data is about. Give a summary in 2-3 sentences."
                        "Critical": <summary><p>output of summary</p></summary>, // Replace with the actual summary

                    "instruction": After analyzing if you think that this file contains the following fields or relates to these fields, then please say: "You can perform some actions like below for this file:"
                        "Options": ["generate iso mapping for upload file format", "control file format", "reverse file format"]
                        "CRITICAL INSTRUCTION": Give this instruction output if anything related to the Upload File field is available in the given input context.
                        "output format": Give output inside tags = <options>output of this instruction</options>
                        NOTE: There should be separate <option></option> tags for each option. Do not include '\n' or '<br>' inside the tags. Do not provide the <option></option> tag for the group of options.
                ]
                """
    return prompt


def get_domain_template():
    """
    Generate a template for classifying and summarizing document content based on domain.

    Returns:
        str: The formatted domain classification and summary template.
    """

    prompt = f"""
        You are an expert in the
        corporate transaction banking domain.
        Analyze the following content to classify the file. Based on the content,
        identify the domain and the specific type of
        file. The domains may include but are not limited to: Trade and Finance, Supply
        Chain Finance, Receivables, Payments, Corporate Lending, Treasury
        Management, Compliance, and Risk Management. The file types may include
        templates, onboarding documents, transactional data files, reconciliation
        reports, and more.


        When identifying the file type, consider the following hints for each domain.
        Output should be only from one of below classes:

        - **Payments**: Look for fields related to payment instructions,
        headers, trailers, and validation procedures. Common file types include
        Onboarding Templates, Transactional Data Files, Reconciliation Reports, and
        Control Files. These files are comprehensive document essential for integrating 
        a corporation into a payment processing system, encompassing critical details 
        such as the company's banking information, and the format and structure of 
        various types of payment transactions the corporation will process. 
        It ensures that the corporation is set up correctly and securely for handling 
        transactions, maintaining compliance with regulatory requirements, and enabling 
        efficient financial operations. Additionally, the file includes a Board Resolution 
        document, which officially records decisions made by the company's board of 
        directors regarding significant corporate actions such as opening new bank accounts, 
        authorizing officers to act on behalf of the company, and approving major 
        financial transactions, thereby providing formal authorization and ensuring proper 
        corporate governance and compliance.
        ```Return tags``` : <type>Payments</type>


        - **Trade and Finance**: Look for fields related to trade
        transactions, import/export details, and payment terms. Common file types
        include Trade Finance Documents, Letters of Credit, and Shipping Documents.
        ```Return tags``` : <type>TF</type>


        - **Supply Chain Finance**: Look for fields related to invoices,
        buyer and supplier information, and payment terms. Common file types include
        Invoice Financing Files, Supplier Onboarding Templates, and Payment Schedules.
        ```Return tags``` : <type>SCF</type>


        - **Corporate Lending**: Look for fields related to loan details,
        borrower information, and repayment schedules. Common file types include Loan
        Agreements, Borrower Onboarding Templates, and Repayment Schedules.
        ```Return tags``` : <type>CL</type>


        - **Treasury Management**: Look for fields related to cash
        management, liquidity, and investment details. Common file types include Cash
        Flow Statements, Investment Reports, and Liquidity Management Files.
        ```Return tags``` : <type>TM</type>


        - **Compliance and Risk Management**: Look for fields related to
        regulatory requirements, risk assessments, and compliance checks. Common file
        types include Compliance Checklists, Risk Assessment Reports, and Regulatory
        Filings.
        ```Return tags``` : <type>CRM</type>


        If the content does not match
        any of the known domains or file types, provide the closest possible classification
        and mention that it is unrecognized. Describe any notable characteristics or
        key fields that might help in identifying the domain and file type in the
        future.



        Please provide the following
        information:

        1. Domain: Identify the
        domain of the file (e.g., Trade and Finance, Supply Chain Finance, Collections,
        Receivables, Payments, Corporate Lending, Treasury Management, Compliance, Risk
        Management, etc.) and give response in tag mentioned in ```Return tags```
        2. Summary: Describe the key
        characteristics of the file content inside <summary> summary of file </summary>

        Note: If the content is
        unrecognized, provide the closest possible classification  .
    """

    return prompt


def get_tf_summary():
    """
    Generate a summary template for analyzing document context. Used in Trade Fincance demo.

    Returns:
        str: The formatted summary template.
    """

    prompt = f"""
    Question : Follow the Instructions given to you in input context.
    This is the context for answering the question is in given document.

    Steps for Generating Response :-
        [
        "instruction": "Analyse the given context and see in which of the following category it belongs to:
                  1. A Trade Finance Bank Guarantee Application Form is a document used by applicants 
                     (typically companies) to request a bank guarantee from a financial institution. 
                     This form includes essential details such as the applicant's information, the 
                     beneficiary's details, the amount of the guarantee, and the terms and conditions 
                      under which the guarantee is to be issued. The application form is crucial for  
                     initiating the process of obtaining a bank guarantee, which serves as a 
                     financial instrument ensuring that the bank will meet the applicant's obligations 
                     in case of default.
                     > respond with: <type>TFBGApplication</type> 
                  2. A Trade Finance Bank Guarantee Counter Guarantee Document is a document provided 
                     by a bank or financial institution to another bank, assuring that the counter 
                     guarantee will back the original bank guarantee. This document includes details 
                     about the terms and conditions of the counter guarantee, the obligations of the 
                     issuing bank, and the circumstances under which the counter guarantee will be 
                     invoked. It is essential for securing the obligations of the initial guarantee 
                     and ensuring that the issuing bank will fulfill its commitments if the original 
                     guarantee is called upon. 
                     > respond with: <type>TFBGCounterGuarantee</type> 
                  3. Out of our domain. 
                     > respond with: <type>outOfDomain</type>" 

            "instruction": "For given Context of data understand what this data is about. Give the summary in 2-3 sentence." 
            "Critical": "<summary><p>output of summary</p></summary>  Replace with the actual section name "
            """

    return prompt