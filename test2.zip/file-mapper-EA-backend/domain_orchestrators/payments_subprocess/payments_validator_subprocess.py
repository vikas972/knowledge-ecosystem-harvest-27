import sys
import os

# Add the project root directory to the sys.path as this file run as subprocess
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from logger import logger
from db_script.db_operations import get_extracted_fields, store_validation_results_for_bg_form, update_files_status_field,get_document_class,get_extracted_html,update_validated_html,get_extracted_data_by_file_id,update_validated_html_page_wise,get_extracted_fields_for_iso_mappings,store_validation_results,update_validated_json_page_wise
from configs import Asset_for_iso_mapping_fields_validation
from pf_asset_calling.invoke_pf_asset import invoke_asset
import PyPDF2
from utils.utility_functions import extract_json_content, format_json, remove_dots_from_keys, transform_data
from logger import logger
from utils.disable_text_fields_of_html import disable_input_tags


def read_pdf(file_path):
    # Open the PDF file 
    text = ""
    with open(file_path, "rb") as file:
        reader = PyPDF2.PdfReader(file)
        # Iterate through each page
        for page_num in range(len(reader.pages)):
            page = reader.pages[page_num]
            text += page.extract_text()
    return text



def validated_extracted_fields(file_id):
    db_update_result, msg = update_files_status_field(file_id, 
                                                          "validation_status",
                                                         "inprogress")
    if not db_update_result:
        logger.error(f"Validation status update to inprogess failed due to: {msg}")


    # data, message = retrieve_extracted_file_data(file_id,"party_tnc")

    # Get document_type  from file_id
    document_type, _ = get_document_class(file_id)
    if not document_type:
        logger.info(f"Document type not found for file_id: {file_id}")
        

    # Get the previously stored extracted fields for this file.
    json_response = get_extracted_fields(file_id)[0]
    logger.info(json_response)

    input_query = f"""{json_response}"""

    try:
        if document_type == "channel onboarding":
            # For this doc type we are generating HTML for now
            # flag,extracted_html = get_extracted_html(file_id)
            flag,extracted_data  = get_extracted_data_by_file_id(file_id)
            extracted_fields, message = get_extracted_fields_for_iso_mappings(file_id)
            res, message = store_validation_results(file_id,extracted_fields)
            if not res:
                logger.error(f"Failed to update validated JSON for file_id {file_id}: {message}")
            
            if flag:
                # disabled_input_tags_html = disable_input_tags(extracted_html)
                # logger.info(f"Disabled input tags html: {disabled_input_tags_html}")
                
                # #update this html into validation column
                # db_storage_result = update_validated_html(file_id, disabled_input_tags_html)
                # logger.info(f"Updated html in validation column: {msg}")

                for page_data in extracted_data:
                    extracted_html = page_data.get("page_wise_extracted_html")
                    page_number = page_data.get("page_number")

                    # # Disable input tags in the extracted HTML
                    # disabled_input_tags_html = disable_input_tags(extracted_html)
                    # logger.info(f"Disabled input tags html for file_id {file_id}, page_number {page_number}: {disabled_input_tags_html}")

                    # Update this HTML into the validated column
                    # db_storage_result, msg = update_validated_html_page_wise(file_id, page_number, disabled_input_tags_html)

                    db_storage_result, msg = update_validated_json_page_wise(file_id, page_number, extracted_data)
                    
                    # Log the result of updating the validated HTML
                    if db_storage_result:
                        logger.info(f"Updated validated JSON for file_id {file_id}, page_number {page_number}: {msg}")
                    else:
                        logger.error(f"Failed to update validated JSOn for file_id {file_id}, page_number {page_number}: {msg}")

        else:
            # Call LLM calling function with file_id and get its response
            llm_response_1 = invoke_asset(Asset_for_iso_mapping_fields_validation, 
                                                input_query)
            logger.info(f"LLM response for bg fields extraction : {llm_response_1}")  

            validation_results_for_bg_form = extract_json_content(llm_response_1[0]).replace("```","")

            if type(validation_results_for_bg_form)==list:
                logger.info(f"[INFO] Type of reponse is list. Length is:{len(validation_results_for_bg_form)}.")
                updated_results,flag = format_json(validation_results_for_bg_form[0])
            else:
                updated_results,flag = format_json(validation_results_for_bg_form)
            
            # Repeat the loop if it's not in expected output format.
            if not flag:
                transformed_result = {}
            else:
                updated_results = remove_dots_from_keys(updated_results)
                transformed_result = transform_data(updated_results)
                logger.info(f"Validation results after updating json: {transformed_result}")

            
            db_storage_result, msg = store_validation_results_for_bg_form(file_id, 
                                                    "TFBGApplication", 
                                                    "Bank Guarantee Form", 
                                                    transformed_result)
        if not db_storage_result:
            logger.error(f"Storage of extracted fields for BG form failed with msg: {msg}")
        else:
            db_update_result, msg = update_files_status_field(file_id, 
                                                            "validation_status", 
                                                            "done")
            if not db_update_result:
                logger.error(f"Uploaded file with file_id {file_id} failed to\
                            extract  Fields because of error: {msg}")

    except Exception as e:
        db_update_result, msg = update_files_status_field(file_id, 
                                                          "extraction_status",
                                                         "failed")
        logger.error(f"[PF Error] Error while calling pf asset for validation\
                     of extracted fields: {e}")
        
    return


if __name__ == "__main__":
    if len(sys.argv) != 2:
        logger.error("Usage: python background_task.py <file_id> failed")
        sys.exit(1)

    file_id = sys.argv[1]
    validated_extracted_fields(file_id)


# validated_extracted_fields(2)