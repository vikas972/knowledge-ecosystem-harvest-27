# __import__('pysqlite3')
# import sys
# import os
# sys.modules['sqlite3'] = sys.modules.pop('pysqlite3')


import os
import sys
# Add the project root directory to the sys.path as this file run as subprocess
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

import json

# Custom modules

from prompts import *
from configs import *
from utils.utility_functions import *
from pf_asset_calling.invoke_pf_asset import invoke_asset
from db_script.db_operations import *
from rag import get_text

import os
from datetime import datetime
from pf_asset_calling.invoke_pf_automation_asset_with_pdf_staging import invoke_asset as invoke_asset_automation_for_page_classification
from pf_asset_calling.invoke_azure_gpt4o import call_azure_gpt4o
from pf_asset_calling.invoke_azure_gpt4o_with_text import call_azure_gpt4o as call_azure_gpt4o_with_query
from pf_asset_calling.invoke_pf_asset_staging import invoke_asset as invoke_asset_staging
from utils.pdf_to_images import split_pdf_into_images,delete_all_images
from utils.page_wise_json_confidence_html import main_calling_func_for_confidence_score
from logger import logger
from prompts.common_prompts import hdfc_information_extraction_prompt
import asyncio


def update_json_format(input_json):
    """
    Converts the input JSON into a new format where each category's details are represented as a list of field-value pairs.
    
    Args:
        input_json (dict): The input JSON to be converted.
        
    Returns:
        dict: The converted JSON in the new format.
    """
    def flatten_dict(d, parent_key=''):
        """
        Flattens a nested dictionary into a single-level dictionary with compound keys.
        
        Args:
            d (dict): The dictionary to be flattened.
            parent_key (str): The base key for the flattened keys.
            
        Returns:
            dict: The flattened dictionary.
        """
        items = []
        for k, v in d.items():
            new_key = f"{parent_key}{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(flatten_dict(v, f"{new_key}_").items())
            else:
                items.append((new_key, v))
        return dict(items)

    
    # Flatten the input JSON
    flattened = flatten_dict(input_json)

    # Convert the flattened dictionary into the desired format
    converted_json = {}
    for k, v in flattened.items():
        category = k.split('_')[0]
        if category not in converted_json:
            converted_json[category] = []
        converted_json[category].append({"field": k.split('_', 1)[-1].replace('_', ' ').title(), "value": v})

    return converted_json


def continue_text_generation(previous_response, previous_context, previous_prompt, Asset_id_completion):
    """
    This function is used to generate previously broken response due to output
    token limits.
    Input args: 
        previous_response: previously generated response 
        extracted_text: previously extracted context text
        prompt: previously used prompt
        Asset_id_completion: asset_id of completion asset

    Return: 
        consolidated_response: previous + new continues response combined
    """
    
    completion_input = f"""{{### Start of previous prompt ###\n*** "previous_prompt":{previous_prompt}
    \n### End of previous prompt ###
    ### Start of previously generated output ### \n
    *** "previously_generated_output":{previous_response}
    \n### End of previous output ###
    ### Start of context ###\n
    #  *** "context":{previous_context}}}\n 
    ### End of context ###"""

    completion_response = invoke_asset(Asset_id_completion, completion_input)
    logger.info("Received completion response")
    consolidated_response = previous_response + extract_json_content(completion_response[0]).replace("```","")
    return consolidated_response


def extract_fields(extracted_text, Asset_id, prompt=None):
    """
    This function is used to generate the mappings or extract entities as per 
    inputed prompt.
    """
    mappings = {}
    for iterate in range(3): # Loop thrice to get expected output format 
        consolidated_response = ""
        logger.info(f"Trying to generate mappings for the {iterate+1} time.")
        
        mappings_response = invoke_asset_staging(Asset_id, extracted_text)
        mappings_response = extract_json_content(mappings_response[0]).replace("```","")

        tokens_count = count_tokens(mappings_response)
        logger.info(f"Count of tokens:{tokens_count}")
        
        # Continue response generation if output token limit is exhausted in 
        # previous response generation
        if tokens_count >= 4050 and prompt:
            consolidated_response = cut_string_from_last_brace(mappings_response)
            continue_text_generation_response = continue_text_generation(
                                     consolidated_response, 
                                     extracted_text, 
                                     prompt, 
                                     Asset_id_completion)
            mappings_response = continue_text_generation_response

        logger.info("Received response from PF")

        # Check the format of generated response if it is a list
        if type(mappings_response)==list:
            logger.info(f"[INFO] Type of reponse is list. Length is:{len(mappings_response)}.")
            hf,flag = format_json(mappings_response[0])
        else:
            hf,flag = format_json(mappings_response)
        
        # Repeat the loop if it's not in expected output format.
        if not flag:
            continue
        else:
            hf = remove_dots_from_keys(hf)

        # transform results into expected format
        transformed_result = transform_data(hf)

        if transformed_result:
            mappings = transformed_result
            break
        else:
            mappings = {}
    return mappings


def extract_hdfc_data(filepath, asset_id):
    """
    Extracts data from a file using the specified asset ID.
    
    Args:
        filepath (str): The path to the file to be processed.
        asset_id (str): The ID of the asset to be used for the extraction.
    
    Returns:
        dict: The extracted data from the file.
    """
        
    llm_response_1 = invoke_asset_automation_for_page_classification(asset_id, 
                                                "", 
                                                filepath,"document")
    extractions = llm_response_1["response"]["output"][0]["debug_logs"][0]["raw_response"]
    # extractions = json.loads(extractions)
    logger.info(f"Extracted data: {extractions}")
    return extractions

    
def payments_extractor_module(file_id, mapping_id):
    """
    This function works as orchestrator for upload file flow.
    It will check first the class of document then based on that it will call the
    respective assets.

    Args:
        file_id: Id of file
        mapping_id: 
    """

    # Commented temp as we are using vision based models.
    # try:
    #     # Read the contents of the temporary file
    #     with open(temp_file_path, 'r', encoding='utf-8') as temp_file:
    #         extracted_text = temp_file.read()
    #     os.remove(temp_file_path)
    #     logger.info(f"Temporary file {temp_file_path} deleted.")
    # except Exception as e:
    #     logger.info(f"An error occurred while processing the temp file: {e}")
    #     return  

    # Update status in db
    db_update_result, msg = update_files_status_field(file_id, 
                                                          "extraction_status",
                                                         "inprogress")
    if not db_update_result:
        logger.error(f"Classification status update to inprogess failed due to: {msg}")
    
    # Get file path
    filepath = retrieve_file_data(file_id)
    filepath = filepath[0][0]
    logger.info(f"Filepath is: {filepath}\n File ID is: {file_id}")

    # Extract text from vector db for further processing
    extracted_text = get_text(int(file_id), int(file_id), "context").page_content
    logger.info(f"Extracted Text from vectordb: {extracted_text}")
    logger.info("In Payments Extractor...")
    document_type_code, flag = get_document_class(file_id)

    logger.info(f"doc_code: {document_type_code}")

    # Based on document type call respective functions to process text
    try:
        if document_type_code == "Corporate Payments Onboarding":
            logger.info("In onboarding file section...")
            # LLM calls to generate mappings for ISO equivalent
            uff = extract_fields(extracted_text, Asset_for_payments_iso_mapping, Payments_common_prompt)
            # rff = extract_fields(extracted_text, Asset_for_payments_iso_mapping, Payments_common_prompt)
            rff = {}

            ### Add mapping data to database.
            if uff != {}:
                update_mappings_into_db_result, msg = replicate_database_cop(mapping_id, "UFF", "Upload file format", json.loads(json.dumps(uff)))
                if not update_mappings_into_db_result:
                    logger.error(f"Uploaded file  with file_id {file_id} failed to\
                                update mappings into db because of error: {msg}")
            if rff != {}:
                update_mappings_into_db_result, msg = replicate_database_cop(mapping_id, "RFF", "Reverse file format", json.loads(json.dumps(rff)))
                if not update_mappings_into_db_result:
                    logger.error(f"Uploaded file with file_id {file_id} failed to\
                                update mappings into db because of error: {msg}")
            if uff != {} or rff != {}:
                update_is_processed_flag_into_db_result, msg = set_is_processed_true(mapping_id)
                if not update_is_processed_flag_into_db_result:
                    logger.error(f"Uploaded file with file_id {file_id} failed to\
                                update mappings into db because of error: {msg}")
                else:
                    logger.info("Processing Done for onboarding file......")
            

        elif document_type_code == "Board Resolution":
            logger.info("In Board Resolution section...")
            # LLM calls to extract entities
            AM = extract_fields(extracted_text, Asset_id_AM)
            AS = extract_fields(extracted_text, Asset_id_AS)

            # Update data into db
            if AS != {}:
                update_mappings_into_db_result, msg = replicate_database_cop(mapping_id, "AS", "Authorised Signatory", AM)
                if not update_mappings_into_db_result:
                    logger.error(f"Uploaded file with file_id {file_id} failed to\
                                update mappings into db because of error: {msg}")
            if AM != {}:
                update_mappings_into_db_result, msg = replicate_database_cop(mapping_id, "AM", "Approval Matrix", AS)
                if not update_mappings_into_db_result:
                    logger.error(f"Uploaded file with file_id {file_id} failed to\
                                update mappings into db because of error: {msg}")
            if AS != {} or AM != {}:
                update_is_processed_flag_into_db_result, msg = set_is_processed_true(mapping_id)
                if not update_is_processed_flag_into_db_result:
                    logger.error(f"Uploaded file  with file_id {file_id} failed to\
                                update mappings into db because of error: {msg}")
                else:
                    logger.info("Processing Done for BR........")
        
        elif document_type_code == "channel onboarding" or "Unknown Type":
            # logger.info("In channel onboarding Form section...")
            # # image_path = get_thumbnail_paths_for_file_id(file_id)

            # # Split pdf into images to send it to vision model
            # image_path = split_pdf_into_images(filepath)
            # logger.info(f"Image path: {image_path}")

            # # Get HTML generated with extraction data
            # hdfc_fields = call_azure_gpt4o(image_path, hdfc_information_extraction_prompt) # We can send total of approx 140 images at a time with above prompt
            # hdfc_fields = hdfc_fields.replace("```html","").replace("```","")
            # logger.info(f"Response from extractor: {hdfc_fields}")

            # # commented temporarily as PF is giving DNS error
            # completion_response = invoke_asset_staging(Asset_for_html_to_json_converted, 
            #                                     str(hdfc_fields))
            # completion_response = extract_json_content(completion_response[0])
            # completion_response = json.loads(completion_response)

            # # Temporary call to Azure GPT4o with string input.
            # # completion_response = call_azure_gpt4o_with_query(str(hdfc_fields), html_to_json_prompt)
            # # Extract JSON content from string
            # # completion_response = extract_json_content(completion_response)
            # # completion_response = json.loads(completion_response)
            
            # logger.info(f"HTML to JSON converted response: {completion_response}")

            # # Make generated html editable
            # hdfc_fields = make_html_editable(hdfc_fields)
            
            # # Add extracted html into db
            # update_mappings_into_db_result, msg = add_extracted_html(mapping_id, 
            #                                                             "hdfc_fields", 
            #                                                             "HDFC fields", 
            #                                                             hdfc_fields)

            # if not update_mappings_into_db_result:
            #     logger.error(f"Uploaded file {filepath} with file_id {file_id} failed to\
            #                 update mappings into db because of error: {msg}")

            # # Update json of html into db 
            # db_storage_result, msg = update_extracted_results(file_id, 
            #                                                   completion_response)
            
            # if not db_storage_result:
            #     logger.error(f"Uploaded file {filepath} with file_id {file_id} failed to\
            #                 add json data into db because of error: {msg}")
                
            # # delete all the images created previously from file
            # delete_all_images()
            
            
            
            logger.info("In channel onboarding Form section...")

            
            # image_path = get_thumbnail_paths_for_file_id(file_id)

            # Split pdf into images to send it to vision model
            # image_paths = split_pdf_into_images(filepath)
            # logger.info(f"Image paths: {image_paths}")
            

            # # Initialize variable to store concatenated results
            # concatenated_hdfc_fields = ""
            # concatenated_completion_response = []

            # # Process each image (each page) one by one
            # for image_path in image_paths:
            #     logger.info(f"Processing page with image path: {image_path}")
                
            #     # Get HTML generated with extraction data for the current page
            #     hdfc_fields = call_azure_gpt4o([image_path], hdfc_information_extraction_prompt)
            #     hdfc_fields = hdfc_fields.replace("```html", "").replace("```", "")
            #     logger.info(f"Response from extractor for page {image_path}: {hdfc_fields}")
                
            #     # Concatenate the HTML fields for each page
            #     concatenated_hdfc_fields += hdfc_fields
                
            #     # Convert HTML to JSON for the current page
            #     completion_response = invoke_asset_staging(Asset_for_html_to_json_converted, 
            #                                             str(hdfc_fields))
            #     completion_response = extract_json_content(completion_response[0])
            #     completion_response = json.loads(completion_response)
                
            #     # Concatenate JSON results for each page
            #     concatenated_completion_response.append(completion_response)
                
                
            concatenated_hdfc_fields,concatenated_completion_response = asyncio.run(main_calling_func_for_confidence_score(file_id,filepath))

            # Log the concatenated result for all pages
            # logger.info(f"Concatenated HTML from all pages: {concatenated_hdfc_fields}")
            logger.info(f"Concatenated JSON from all pages: {concatenated_completion_response}")

            # Make the generated HTML editable
            concatenated_hdfc_fields = make_html_editable(concatenated_hdfc_fields)

            # Add the concatenated extracted HTML into the database
            update_mappings_into_db_result, msg = add_extracted_html(mapping_id, 
                                                                    "hdfc_fields", 
                                                                    "HDFC fields", 
                                                                    concatenated_hdfc_fields)

            if not update_mappings_into_db_result:
                logger.error(f"Uploaded file {filepath} with file_id {file_id} failed to \
                            update mappings into db because of error: {msg}")

            # Update the concatenated JSON into the database
            db_storage_result, msg = update_extracted_results(file_id, concatenated_completion_response)

            if not db_storage_result:
                logger.error(f"Uploaded file {filepath} with file_id {file_id} failed to \
                            add JSON data into db because of error: {msg}")

            # Delete all the images created previously from the file
            delete_all_images()


        
        elif document_type_code == "outOfDomain":
            logger.info("Uploaded file is out of supported domain.")

    except Exception as e:
        db_update_result, msg = update_files_status_field(file_id, 
                                                          "extraction_status",
                                                         "failed")
        status,msg = update_classification_approval_status(file_id,"FALSE")
        logger.error(f"[PF Error] Error in payments subprocess: {e}")
        return


    db_update_result, msg = update_files_status_field(file_id, 
                                                          "extraction_status", 
                                                          "done")
    if not db_update_result:
        logger.error(f"Uploaded file with file_id {file_id} failed to\
                        extract BG Form Fields because of error: {msg}")
    return



if __name__ == "__main__":
    if len(sys.argv) != 3:
        logger.error("Usage: python domain_orchestrators/tf_subprocesses/payments_extractor_subprocess.py <file_id> <mapping_id> failed")
        sys.exit(1)
    file_id , mapping_id = sys.argv[1], sys.argv[2]
    logger.info(f"file_id : {file_id}")
    logger.info(f"mapping_id : {mapping_id}")
    payments_extractor_module(file_id,mapping_id)
