import sys
import os

# Add the project root directory to the sys.path as this file run as subprocess
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from logger import logger
from db_script.db_operations import get_extracted_fields, store_validation_results_for_bg_form, update_files_status_field,retrieve_extracted_file_data
from pf_asset_calling.invoke_pf_automation_asset_with_query_staging import invoke_asset as invoke_asset_automation
from configs import Asset_for_bg_extracted_fields_validation
import PyPDF2
import json

def read_pdf(file_path):
    # Open the PDF file
    text = ""
    with open(file_path, "rb") as file:
        reader = PyPDF2.PdfReader(file)
        # Iterate through each page
        for page_num in range(len(reader.pages)):
            page = reader.pages[page_num]
            text += page.extract_text()
    return text



def update_json_format(input_json):
    final_output = {"Section":[]}
    for item in input_json:
        tmp_dict = {}
        tmp_dict["field_Name"] = item["source_field"]
        tmp_dict["value_from_document"] = item["source_value"]
        tmp_dict["source_document"] = item["source_file"]
        tmp_dict["vetting_result_for_above_field"] = item["validation_description"]
        tmp_dict["article_source"] = item["field"]
        tmp_dict["validation_flag"] = False
        tmp_dict["disclaimer_on_effectiveness_of_documents"] = item["validation_description"]
        final_output["Section"].append(tmp_dict)
    return final_output


def validate_extracted_bg_fields(file_id):
    db_update_result, msg = update_files_status_field(file_id, 
                                                          "validation_status",
                                                         "inprogress")
    if not db_update_result:
        logger.error(f"Validation status update to inprogess failed due to: {msg}")


    data, _ = retrieve_extracted_file_data(file_id,"party_tnc")

    # Read party terms and condition file and previously generated json response
    
    if data:
        ptnc = read_pdf(data[0])
    else:
        ptnc = ""
    

    # Get the previously stored extracted fields for this file.
    json_response = get_extracted_fields(file_id)[0]
    logger.info(json_response)

    input_query = {"party_terms_and_conditions":f"Terms and conditions for party are as follows\n: ```{ptnc}```",
            "bg_extractor_output":f"The extracted fields are as follows\n:```{json_response}```"}

    try:
        # Call another function with file_id and get its response
        llm_response_1 = invoke_asset_automation(Asset_for_bg_extracted_fields_validation, 
                                             input_query)
        logger.info(f"LLM response for bg fields extraction : {llm_response_1}")  


        ### Changed on Jul 29 2024
        validation_results_for_bg_form = llm_response_1[0]

        # logger.info("---------------------------------heree")
        # validation_results_for_bg_form = json.loads(llm_response_1)


        # validation_results_for_bg_form = llm_response_1[0]
        # validation_results_for_bg_form = update_json_format(validation_results_for_bg_form)




        db_storage_result, msg = store_validation_results_for_bg_form(file_id, 
                                                "TFBGApplication", 
                                                "Bank Guarantee Form", 
                                                validation_results_for_bg_form)
        if not db_storage_result:
            logger.error(f"Storage of extracted fields for BG form failed with msg: {msg}")
        else:
            db_update_result, msg = update_files_status_field(file_id, 
                                                            "validation_status", 
                                                            "done")
            if not db_update_result:
                logger.error(f"Uploaded file with file_id {file_id} failed to\
                            extract BG Form Fields because of error: {msg}")

    except Exception as e:
        db_update_result, msg = update_files_status_field(file_id, 
                                                          "extraction_status",
                                                         "failed")
        logger.error(f"[PF Error] Error while calling pf asset for validation\
                     of extracted BG form fields: {e}")
        
    return


if __name__ == "__main__":
    if len(sys.argv) != 2:
        logger.error("Usage: python background_task.py <file_id> failed")
        sys.exit(1)

    file_id = sys.argv[1]
    validate_extracted_bg_fields(file_id)


# validate_extracted_bg_fields(2)