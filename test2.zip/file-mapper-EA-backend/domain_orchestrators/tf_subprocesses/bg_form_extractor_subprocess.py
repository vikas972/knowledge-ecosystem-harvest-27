import sys
import os

# Add the project root directory to the sys.path as this file run as subprocess
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from logger import logger
from db_script.db_operations import retrieve_file_data, store_extracted_fields, update_files_status_field,retrieve_extracted_file_data
from pf_asset_calling.invoke_pf_automation_asset_with_pdf_staging import invoke_asset as invoke_asset_automation
from configs import Asset_for_bg_fields_extractor
import json


def update_json_format(input_json):
    """
    Converts the input JSON into a new format where each category's details are represented as a list of field-value pairs.
    
    Args:
        input_json (dict): The input JSON to be converted.
        
    Returns:
        dict: The converted JSON in the new format.
    """
    def flatten_dict(d, parent_key=''):
        """
        Flattens a nested dictionary into a single-level dictionary with compound keys.
        
        Args:
            d (dict): The dictionary to be flattened.
            parent_key (str): The base key for the flattened keys.
            
        Returns:
            dict: The flattened dictionary.
        """
        items = []
        for k, v in d.items():
            new_key = f"{parent_key}{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(flatten_dict(v, f"{new_key}_").items())
            else:
                items.append((new_key, v))
        return dict(items)

    def to_field_value_pairs(d):
        """
        Converts a flattened dictionary into a list of field-value pairs.
        
        Args:
            d (dict): The dictionary to be converted.
            
        Returns:
            list: A list of dictionaries each containing 'field' and 'value'.
        """
        result = []
        for k, v in d.items():
            field = k.replace('_', ' ').title()  # Convert key to title case and replace underscores with spaces
            result.append({"field": field, "value": v})
        return result

    # Flatten the input JSON
    flattened = flatten_dict(input_json)

    # Convert the flattened dictionary into the desired format
    converted_json = {}
    for k, v in flattened.items():
        category = k.split('_')[0]
        if category not in converted_json:
            converted_json[category] = []
        converted_json[category].append({"field": k.split('_', 1)[-1].replace('_', ' ').title(), "value": v})

    return converted_json


def extract_bg_fields(file_id,classification):
    # Get data from the database for the given file_id
    # data, message = retrieve_file_data(file_id) #Get path of the file
    data, message = retrieve_extracted_file_data(file_id,classification)


    if data is None or data == ():
        logger.error(f"Error retrieving data for file id:{file_id}")
        return
    
    db_update_result, msg = update_files_status_field(file_id, 
                                                          "extraction_status",
                                                         "inprogress")
    if not db_update_result:
        logger.error(f"Classification status update to inprogess failed due to: {msg}")

    logger.info(f"Data retrieved for file_id >> {file_id}: {data}")

    try:
        # Call another function with file_id and get its response
        llm_response_1 = invoke_asset_automation(Asset_for_bg_fields_extractor, 
                                                 "", 
                                                 data[0],"document")
    except Exception as e:
        db_update_result, msg = update_files_status_field(file_id, 
                                                          "extraction_status",
                                                         "failed")
        logger.error(f"[PF Error] Error while calling pf asset for bg form extractor: {e}")
        return


    ### Changed on Jul 29 2024
    llm_response_1 = llm_response_1["response"]["output"][0]["debug_logs"][0]["raw_response"]
    extracted_fields = json.loads(llm_response_1)
    extracted_fields = extracted_fields["Application_For_Letter_Of_Guarantee"]
    # logger.info("Here",extracted_fields)


    # extracted_fields_response = llm_response_1["response"]["output"][0]["output_parameters"]
    extracted_fields = update_json_format(extracted_fields)
    logger.info(extracted_fields)
    logger.info(f"LLM response for bg fields extraction : {extracted_fields}")
    db_storage_result, msg = store_extracted_fields(file_id, 
                                               "TFBGApplication", 
                                               "Bank Guarantee Form", 
                                               extracted_fields)
    if not db_storage_result:
        logger.error(f"Storage of extracted fields for BG form failed with msg: {msg}")
    else:
        db_update_result, msg = update_files_status_field(file_id, 
                                                          "extraction_status", 
                                                          "done")
        if not db_update_result:
            logger.error(f"Uploaded file with file_id {file_id} failed to\
                        extract BG Form Fields because of error: {msg}")
    return


# if __name__ == "__main__":
#     if len(sys.argv) != 2:
#         logger.error("Usage: python background_task.py <file_id> failed")
#         sys.exit(1)

#     file_id = sys.argv[1]
#     extract_bg_fields(file_id)