# __import__('pysqlite3')
# import sys
# import os
# sys.modules['sqlite3'] = sys.modules.pop('pysqlite3')

# Add the project root directory to the sys.path as this file run as subprocess
# sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import json

# Custom modules
from prompts import *
from configs import *
from utils.utility_functions import *
from pf_asset_calling.invoke_pf_asset import invoke_asset
from db_script.db_operations import *
from rag import get_text
from pf_asset_calling.invoke_pf_automation_asset_with_pdf_staging import invoke_asset as invoke_asset_automation_for_page_classification

import os
from datetime import datetime
from pdf2image import convert_from_path
from logger import logger

from utils.pdf_to_images import split_pdf_into_images,delete_all_images

from utils.utility_functions import extract_json_content
from logger import logger

from pf_asset_calling.invoke_azure_gpt4o import call_azure_gpt4o
from prompts.common_prompts import hdfc_information_extraction_prompt, file_classification_prompt



def continue_text_generation(previous_response, previous_context, previous_prompt, Asset_id_completion):
    """
    This function is used to generate previously broken response due to output
    token limits.
    Input args: 
        previous_response: previously generated response 
        extracted_text: previously extracted context text
        prompt: previously used prompt
        Asset_id_completion: asset_id of completion asset

    Return: 
        consolidated_response: previous + new continues response combined
    """
    
    completion_input = f"""{{### Start of previous prompt ###\n*** "previous_prompt":{previous_prompt}
        \n### End of previous prompt ###
        ### Start of previously generated output ### \n
        *** "previously_generated_output":{previous_response}
        \n### End of previous output ###
        ### Start of context ###\n
        #  *** "context":{previous_context}}}\n 
        ### End of context ###
        # """

    completion_response = invoke_asset(Asset_id_completion, completion_input)
    logger.info("Received completion response")
    consolidated_response = previous_response + extract_json_content(completion_response[0]).replace("```","")
    return consolidated_response


def thumbnail_and_pdf(input_pdf, output_dir, file_id, filename):
    """
    This function is responsible for creating a thumbnail image and saving the complete PDF document for a given input PDF file.
    
    Args:
        input_pdf (str): The path to the input PDF file.
        output_dir (str): The directory where the generated files will be saved.
        file_id (str): The ID of the file.
        filename (str): The name of the file.
    
    Returns:
        dict: A dictionary containing the paths to the generated thumbnail image and the complete PDF document.
    """
        
    file_paths = {
        "images": {},
        "pdfs": {}
    }
    try:
        # Get the current timestamp
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        
        # Create directories if they do not exist
        img_dir = os.path.join(output_dir, 'img')
        pdf_dir = os.path.join(output_dir, 'pdf')
        os.makedirs(img_dir, exist_ok=True)
        os.makedirs(pdf_dir, exist_ok=True)
        server = server_url
        
        # Convert the first page of the PDF to an image (thumbnail)
        pages = convert_from_path(input_pdf, 300, first_page=1, last_page=1)
        img_filename = f'{file_id}_{filename}_thumbnail_{timestamp}.png'
        save_path = os.path.join(server, img_dir, img_filename)
        img_path = os.path.join(img_dir, img_filename)
        pages[0].save(img_path, 'PNG')
        file_paths["images"]["thumbnail"] = save_path

        # Save the complete PDF document path
        complete_pdf_filename = f'{file_id}_{filename}_{timestamp}.pdf'
        complete_pdf_save_path = os.path.join(server, pdf_dir, complete_pdf_filename)
        complete_pdf_path = os.path.join(pdf_dir, complete_pdf_filename)
        with open(input_pdf, "rb") as pdf_file:
            with open(complete_pdf_path, "wb") as output_pdf_file:
                output_pdf_file.write(pdf_file.read())
        file_paths["pdfs"]["complete_pdf"] = complete_pdf_save_path
        
        logger.info("Created Thumbnail and saved complete PDF document path")
        return file_paths

    except FileNotFoundError as e:
        logger.info(f"File not found: {e}")
    except PermissionError as e:
        logger.info(f"Permission denied: {e}")
    except Exception as e:
        logger.info(f"An error occurred: {e}")
        return None


def generate_mappings(extracted_text, Asset_id, prompt=None):
    """
    This function is responsible for generating mappings from the extracted text using an AI asset. 
    It attempts to generate the mappings up to 3 times, handling cases where the output token limit is exceeded. 
    The function formats the response, transforms the data into the expected format, and returns the mappings.
    
    Args:
        extracted_text (str): The text extracted from the document.
        Asset_id (str): The ID of the AI asset to use for generating the mappings.
        prompt (str, optional): An additional prompt to use for continuing the text generation if the output token limit is exceeded.
    
    Returns:
        dict: The generated mappings.
    """
    mappings = {}
    for iterate in range(3): # Loop thrice to get expected output format 
        consolidated_response = ""
        logger.info(f"Trying to generate mappings for the {iterate+1} time.")
        
        mappings_response = invoke_asset(Asset_id, extracted_text)
        mappings_response = extract_json_content(mappings_response[0]).replace("```","")

        tokens_count = count_tokens(mappings_response)
        logger.info(f"Count of tokens:{tokens_count}")
        
        # Continue response generation if output token limit is exhausted in 
        # previous response generation
        if tokens_count >= 4050 and prompt:
            consolidated_response = cut_string_from_last_brace(mappings_response)
            continue_text_generation_response = continue_text_generation(
                                     consolidated_response, 
                                     extracted_text, 
                                     prompt, 
                                     Asset_id_completion)
            mappings_response = continue_text_generation_response

        logger.info("Received response from PF")

        # Check the format of generated response if it is a list
        if type(mappings_response)==list:
            logger.info(f"[INFO] Type of reponse is list. Length is:{len(mappings_response)}.")
            hf,flag = format_json(mappings_response[0])
        else:
            hf,flag = format_json(mappings_response)
        
        # Repeat the loop if it's not in expected output format.
        if not flag:
            continue
        else:
            hf = remove_dots_from_keys(hf)

        # transform results into expected format
        transformed_result = transform_data(hf)

        if transformed_result:
            mappings = transformed_result
            break
        else:
            mappings = {}
    return mappings


def extract_filename(file_path):
    return os.path.basename(file_path)

    
def extract_hdfc_data(filepath, asset_id):
    llm_response_1 = invoke_asset_automation_for_page_classification(asset_id, 
                                                "", 
                                                filepath,"document")
    extractions = llm_response_1["response"]["output"][0]["debug_logs"][0]["raw_response"]
    extractions = json.loads(extractions)
    return extractions


def payments_orchestrator_module(filepath, file_id, corp_id, mapping_id, temp_file_path):
    """
    This function works as orchestrator for upload file flow.
    It will check first the class of document then based on that it will call the
    respective assets.

    Args:
        filename: Name of the file
        file_id: Id of file
        corp_id: Id of organisation
    """

    # Commented for now as we are using vision based model
    # try:
    #     # Read the contents of the temporary file
    #     with open(temp_file_path, 'r', encoding='utf-8') as temp_file:
    #         extracted_text = temp_file.read()
    #     os.remove(temp_file_path)
    #     logger.info(f"Temporary file {temp_file_path} deleted.")
    # except Exception as e:
    #     logger.info(f"An error occurred while processing the temp file: {e}")
    #     return  
    
    extracted_text = get_text(int(file_id), int(file_id), "context").page_content
    logger.info(f"Extracted Text from vectordb: {extracted_text}")
    
    logger.info("In Payments orchestrator...")

    db_status_update_response, msg = update_files_status_field(file_id, 
                                                         "classification_status", 
                                                         "inprogress")
    if not db_status_update_response:
        logger.error(f"Classification status update to inprogess failed due to: {msg}")


    # LLM call to get summary and type of doc from payments. (onboarding or board resolution) 
    # summary_prompt = getsummary() + "Below is context for generating response: " + extracted_text
    # logger.info(f"Summary prompt: {summary_prompt}")

    # Till sonnet3.5 is live on PF we will use azure gpt4o with images as input
    image_path = split_pdf_into_images(filepath)
    logger.info(f"Image path: {image_path}")
    logger.info(f"Image path: {image_path[0]}")
    llm_response_1 = call_azure_gpt4o(image_path, file_classification_prompt)
    delete_all_images()

    # llm_response_1 = invoke_asset(Asset_id_Chat2doc, summary_prompt)
    # llm_response_1 =llm_response_1[0]
    logger.info(f"First LLM response from pf in file upload flow : {llm_response_1}" )

    # Extract data inside tags from llm response.
    tagstoextract = ['type', 'summary', 'options']
    extractedtags = extractValuesFromTag(tagstoextract, llm_response_1)
    
    # Get document type, summary and actions from generated text
    document_type_code = extractedtags['type']
    summary = extractedtags['summary']
    summary_action_buttons = extractedtags['options']
    logger.info(f"[INFO] Document type before preprocessing is: {document_type_code}")

    # Map document type to specific format
    document_type = getDocumentFormat(document_type_code)
    logger.info(f"[INFO] Document type is: {document_type}")

    # Update data into db
    db_update_result, msg = update_database_mapping_details(mapping_id,document_type,summary,summary_action_buttons)
    if not db_update_result:
        logger.error(f"Uploaded file {filename} with file_id {file_id} failed to\
                      complete processing because of error: {msg}")
        return

    logger.info("[INFO] Step 1 Done: Summary Extracted")

    # <<<<<<<<<<<<<<<<<<<Page wise classification part>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    # Create thumbnails from first page of input document
    thumbnail_pdf_path = thumbnail_and_pdf(filepath, "static", mapping_id, extract_filename(filepath))
    doc_path = thumbnail_pdf_path["pdfs"]["complete_pdf"]
    pdf_path = thumbnail_pdf_path["pdfs"]["complete_pdf"]
    thumbnail_path = thumbnail_pdf_path["images"]["thumbnail"]
    filename = extract_filename(pdf_path)

    #current hardcoded domain "payments" needs to change to actual domain name in future.
    update_file_page_details(file_id, 
                             filename, 
                             "Payments",
                             1, 
                             document_type, 
                             thumbnail_path, 
                             pdf_path,doc_path)
    
    logger.info("[INFO] Step 1 Done: Summary Extracted") 

    # Update classification status
    db_update_result, msg = update_database_mapping_details_with_status(mapping_id,
                                                                        document_type,
                                                                        summary,
                                                                        summary_action_buttons,
                                                                        "classification_status",
                                                                        "done")
    if not db_update_result:
        logger.error(f"Uploaded file with file_id {file_id} failed to\
                      update classification to done because of error: {msg}")
        
    return

    # Below block of code is commented as for now we are doing it via human in loop manner
        
    # if document_type_code == "CPO":
    #     logger.info("In onboarding file section...")
    #     # LLM calls to generate mappings for ISO equivalent
    #     uff = generate_mappings(extracted_text, Asset_for_payments_iso_mapping, Payments_common_prompt)
    #     # rff = generate_mappings(extracted_text, Asset_for_payments_iso_mapping, Payments_common_prompt)
    #     rff = {}

    #     ### Add mapping data to database.
    #     if uff != {}:
    #         update_mappings_into_db_result, msg = replicate_database_cop(mapping_id, "UFF", "Upload file format", json.loads(json.dumps(uff)))
    #         if not update_mappings_into_db_result:
    #             logger.error(f"Uploaded file {filename} with file_id {file_id} failed to\
    #                         update mappings into db because of error: {msg}")
    #     if rff != {}:
    #         update_mappings_into_db_result, msg = replicate_database_cop(mapping_id, "RFF", "Reverse file format", json.loads(json.dumps(rff)))
    #         if not update_mappings_into_db_result:
    #             logger.error(f"Uploaded file {filename} with file_id {file_id} failed to\
    #                         update mappings into db because of error: {msg}")
    #     if uff != {} or rff != {}:
    #         update_is_processed_flag_into_db_result, msg = set_is_processed_true(mapping_id)
    #         if not update_is_processed_flag_into_db_result:
    #             logger.error(f"Uploaded file {filename} with file_id {file_id} failed to\
    #                         update mappings into db because of error: {msg}")
    #         else:
    #             logger.info("Processing Done for onboarding file......")
        

    # elif document_type_code == "BR":
    #     logger.info("In Board Resolution section...")
    #     # LLM calls to extract entities
    #     AM = generate_mappings(extracted_text, Asset_id_AM)
    #     AS = generate_mappings(extracted_text, Asset_id_AS)

    #     if AS != {}:
    #         update_mappings_into_db_result, msg = replicate_database_cop(mapping_id, "AS", "Authorised Signatory", AM)
    #         if not update_mappings_into_db_result:
    #             logger.error(f"Uploaded file {filename} with file_id {file_id} failed to\
    #                         update mappings into db because of error: {msg}")
    #     if AM != {}:
    #         update_mappings_into_db_result, msg = replicate_database_cop(mapping_id, "AM", "Approval Matrix", AS)
    #         if not update_mappings_into_db_result:
    #             logger.error(f"Uploaded file {filename} with file_id {file_id} failed to\
    #                         update mappings into db because of error: {msg}")
    #     if AS != {} or AM != {}:
    #         update_is_processed_flag_into_db_result, msg = set_is_processed_true(mapping_id)
    #         if not update_is_processed_flag_into_db_result:
    #             logger.error(f"Uploaded file {filename} with file_id {file_id} failed to\
    #                         update mappings into db because of error: {msg}")
    #         else:
    #             logger.info("Processing Done for BR........")

    # elif document_type_code == "outOfDomain":
    #     logger.info("Uploaded file is out of supported domain.")
    # elif document_type_code == "BR":
    #     logger.info("In Board Resolution section...")
    #     # LLM calls to extract entities
    #     AM = generate_mappings(extracted_text, Asset_id_AM)
    #     AS = generate_mappings(extracted_text, Asset_id_AS)

    #     if AS != {}:
    #         update_mappings_into_db_result, msg = replicate_database_cop(mapping_id, "AS", "Authorised Signatory", AM)
    #         if not update_mappings_into_db_result:
    #             logger.error(f"Uploaded file {filename} with file_id {file_id} failed to\
    #                         update mappings into db because of error: {msg}")
    #     if AM != {}:
    #         update_mappings_into_db_result, msg = replicate_database_cop(mapping_id, "AM", "Approval Matrix", AS)
    #         if not update_mappings_into_db_result:
    #             logger.error(f"Uploaded file {filename} with file_id {file_id} failed to\
    #                         update mappings into db because of error: {msg}")
    #     if AS != {} or AM != {}:
    #         update_is_processed_flag_into_db_result, msg = set_is_processed_true(mapping_id)
    #         if not update_is_processed_flag_into_db_result:
    #             logger.error(f"Uploaded file {filename} with file_id {file_id} failed to\
    #                         update mappings into db because of error: {msg}")
    #         else:
    #             logger.info("Processing Done for BR........")

    # elif document_type_code == "hdfconboarding":
    #     logger.info("In hdfc onboarding file section...")
    #     # LLM calls to generate mappings for ISO equivalent
    #     hdfc_fields = extract_hdfc_data(filepath, Asset_for_hdfc_extraction)
    #     logger.info(hdfc_fields)
    #     update_mappings_into_db_result, msg = replicate_database_cop(mapping_id, "hdfc_fields", "HDFC fields", hdfc_fields)
    #     if not update_mappings_into_db_result:
    #         logger.error(f"Uploaded file {filename} with file_id {file_id} failed to\
    #                     update mappings into db because of error: {msg}")
    #     db_update_result, msg = update_database_mapping_details_with_status(mapping_id,
    #                                                                     document_type,
    #                                                                     summary,
    #                                                                     summary_action_buttons,
    #                                                                     "classification_status",
    #                                                                     "done")
    
    #     if not db_update_result:
    #         logger.error(f"Uploaded file {filename} with file_id {file_id} failed to\
    #                     complete processing because of error: {msg}")
    #         return

    
    # elif document_type_code == "outOfDomain":
    #     logger.info("Uploaded file is out of supported domain.")

    # return


# Uncomment when you want to run it as subprocess or test it individually.
# if __name__ == "__main__":
#     filename, file_id, corp_id , mapping_id, temp_file_path = \
#         sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5]
#     logger.info(f"filename : {filename}")
#     logger.info(f"file_id : {file_id}")
#     logger.info(f"corp_id : {corp_id}")
#     payments_orchestrator(filename, file_id,  corp_id, mapping_id, temp_file_path)
