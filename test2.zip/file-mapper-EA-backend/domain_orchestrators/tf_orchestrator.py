# __import__('pysqlite3')
# import sys
# import os
# sys.modules['sqlite3'] = sys.modules.pop('pysqlite3')

# Add the project root directory to the sys.path as this file run as subprocess
# sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import json

# Custom modules
from prompts import *
from configs import *
from utils.utility_functions import *
from pf_asset_calling.invoke_pf_asset import invoke_asset
from db_script.db_operations import *
# from pf_asset_calling.invoke_pf_automation_asset_with_pdf import invoke_asset as invoke_asset_automation_for_classification
from pf_asset_calling.invoke_pf_automation_asset_with_pdf_staging import invoke_asset as invoke_asset_automation_for_page_classification
from pdf2image import convert_from_path
from PyPDF2 import PdfReader, PdfWriter
from datetime import datetime
import os
import re
from logger import logger
from domain_orchestrators.tf_subprocesses.bg_form_extractor_subprocess import extract_bg_fields

def continue_text_generation(previous_response, previous_context, previous_prompt, Asset_id_completion):
    """
    This function is used to generate previously broken response due to output
    token limits.
    Input args: 
        previous_response: previously generated response 
        extracted_text: previously extracted context text
        prompt: previously used prompt
        Asset_id_completion: asset_id of completion asset

    Return: 
        consolidated_response: previous + new continues response combined
    """
    
    completion_input = f"""{{### Start of previous prompt ###\n*** "previous_prompt":{previous_prompt}
    \n### End of previous prompt ###
    ### Start of previously generated output ### \n
    *** "previously_generated_output":{previous_response}
    \n### End of previous output ###
    ### Start of context ###\n
    #  *** "context":{previous_context}}}\n 
    ### End of context ###"""

    completion_response = invoke_asset(Asset_id_completion, completion_input)
    logger.info(f"Received completion response")
    consolidated_response = previous_response + extract_json_content(completion_response[0]).replace("```","")
    return consolidated_response

def thumbnail_and_pdf(input_pdf, output_dir, file_id, filename):
    file_paths = {
        "images": {},
        "pdfs": {}
    }
    try:
        # Get the current timestamp
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        
        # Create directories if they do not exist
        img_dir = os.path.join(output_dir, 'img')
        pdf_dir = os.path.join(output_dir, 'pdf')
        os.makedirs(img_dir, exist_ok=True)
        os.makedirs(pdf_dir, exist_ok=True)
        server = server_url
        # Convert PDF pages to images (thumbnails)
        pages = convert_from_path(input_pdf, 300)
        for i, page in enumerate(pages):
            img_filename = f'{file_id}_{filename}_page_{i + 1}_{timestamp}.png'
            save_path = os.path.join(server,img_dir, img_filename)
            img_path = os.path.join(img_dir, img_filename)
            page.save(img_path, 'PNG')
            file_paths["images"][f"thumbnail_page_{i}"] = save_path

        # Split PDF into individual pages
        with open(input_pdf, "rb") as pdf_file:
            pdf_reader = PdfReader(pdf_file)
            for page_num, page in enumerate(pdf_reader.pages):
                pdf_writer = PdfWriter()
                pdf_writer.add_page(page)
                
                pdf_filename = f'{file_id}_{filename}_page_{page_num + 1}_{timestamp}.pdf'
                save_path =  os.path.join(server,pdf_dir, pdf_filename)
                pdf_path = os.path.join(pdf_dir, pdf_filename)
                with open(pdf_path, "wb") as output_pdf_file:
                    pdf_writer.write(output_pdf_file)
                file_paths["pdfs"][f"page_{page_num}"] = save_path
        
        logger.info("Created Thumbnail and PDF Pages")
        return file_paths

    except FileNotFoundError as e:
        logger.info(f"File not found: {e}")
    except PermissionError as e:
        logger.info(f"Permission denied: {e}")
    except Exception as e:
        logger.info(f"An error occurred: {e}")
        return None






def split_pdf_and_return_paths(page_mappings, input_pdf, output_dir, file_id):
    """
    Splits a PDF into separate PDFs based on page mappings and returns the paths to the resulting PDFs.

    Args:
        page_mappings (dict): Dictionary containing page mappings (e.g., {'page_1': 'bank_guarantee', 'page_2': 'party_tnc'}).
        input_pdf (str): Path to the input PDF file.
        output_dir (str): Directory where the output PDFs will be saved.
        file_id (str): Identifier to be used in the filenames of the output PDFs.

    Returns:
        dict: Dictionary containing paths to the resulting PDFs based on classification type.
    """
    file_paths = {}
    
    try:
        # Get the current timestamp
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        
        # Create directories if they do not exist
        pdf_dir = os.path.join(output_dir, 'Extracted_pdf')
        os.makedirs(pdf_dir, exist_ok=True)
        
        # Initialize PdfReader
        reader = PdfReader(input_pdf)
        total_pages = len(reader.pages)
        
        # Dictionary to hold PdfWriter objects for each page type
        writers = {}
        
        # Iterate through the page mappings to group pages
        for page_key, page_type in page_mappings.items():
            try:
                page_number = int(page_key.split('_')[1]) # Convert to zero-based index
                
                if page_number>= total_pages:
                    logger.info(f"Warning: Page number {page_number + 1} is out of range for the input PDF.")
                    continue
                
                # Initialize a PdfWriter for the page type if not already done
                if page_type not in writers:
                    writers[page_type] = PdfWriter()
                
                # Add the page to the respective PdfWriter
                writers[page_type].add_page(reader.pages[page_number])
            except Exception as e:
                logger.info(f"An error occurred while processing {page_key}: {e}")
        
        # Save the resulting PDF files
        for page_type, writer in writers.items():
            if len(writer.pages) > 0:
                filename = f'{file_id}_{page_type}_{timestamp}.pdf'
                file_path = os.path.join(pdf_dir, filename)
                with open(file_path, 'wb') as f:
                    writer.write(f)
                file_paths[page_type] = file_path

        logger.info("Created PDF files based on page mappings")
    except Exception as e:
        logger.info(f"An error occurred: {e}")
    
    return file_paths

    
    

def extract_filename(file_path):
    return os.path.basename(file_path)


def extract_number(page_str):
    # Use regular expression to find the number in the string
    match = re.search(r'\d+', page_str)
    if match:
        return int(match.group())
    else:
        return None
    
def tf_orchestrator_module(filepath, file_id, corp_id, mapping_id, temp_file_path):
    """
    This function works as orchestrator for upload file flow.
    It will check first the class of document then store it in database.

    Args:
        filepath: Name of the file
        file_id: Id of file
        corp_id: Id of organisation
    """
    try:
        # Read the contents of the temporary file
        with open(temp_file_path, 'r', encoding='utf-8') as temp_file:
            extracted_text = temp_file.read()
        os.remove(temp_file_path)
        logger.info(f"Temporary file {temp_file_path} deleted.")
    except Exception as e:
        logger.info(f"An error occurred while processing the temp file: {e}")
        return  
    
    logger.info("In TF orchestrator...")

    db_status_update_response, msg = update_files_status_field(file_id, 
                                                         "classification_status", 
                                                         "inprogress")
    if not db_status_update_response:
        logger.error(f"Classification status update to inprogess failed due to: {msg}")

    try:
        # LLM call to get summary and type of doc.
        llm_response_1 = invoke_asset_automation_for_page_classification(Asset_for_bg_classification_with_pdf_input, 
                                                "", 
                                                filepath, "document")
        # LLM call to get classification of each page.
        llm_response_2 = invoke_asset_automation_for_page_classification(Asset_for_mixed_doc_cassification, 
                                                "", 
                                                filepath,"file_input")
        



    except Exception as e:
        db_status_update_response, msg = update_files_status_field(file_id, 
                                                         "classification_status", 
                                                         "failed")
        logger.error("[PF Error] Classification call to pf is failed because of error: {e}")
        return


    # result = llm_response_2
	## Convert into JSON.load
	## Update into DB
    # **************** Write a db function in db_operations and call that to store 
    # page by page data into table 'file_page_details' ******************
    llm_response_2 = llm_response_2["response"]["output"][0]["debug_logs"][0]["raw_response"].strip('```json')
    logger.info(f"Document classification resopnse from PF for TF domain : {llm_response_2}" )
    
    thumbnail_pdf_path = thumbnail_and_pdf(filepath, "static", mapping_id, extract_filename(filepath))
    try:
        # Parse the JSON string into a dictionary
        result = json.loads(llm_response_2)

        extracted_file_paths = split_pdf_and_return_paths(result,filepath,"static",str(file_id))
        # bg_path = extracted_file_paths[str(file_id)]["bank_guarantee"]
        # pt_path = extracted_file_paths[str(file_id)]["party_tnc"]
            
        # Iterate over each key-value pair in the dictionary
        for key, value in result.items():
            doc_path = extracted_file_paths[value]
            pdf_path = thumbnail_pdf_path["pdfs"][key]
            thumbnail_path = thumbnail_pdf_path["images"]["thumbnail_"+key]
            filename = extract_filename(pdf_path)
            update_file_page_details(file_id, filename, "Bank Garanty",extract_number(key), value, thumbnail_path, pdf_path,doc_path)
        
    
    except json.JSONDecodeError as e:
        logger.info(f"Error decoding JSON: {e}")
    except Exception as e:
        logger.info(f"An error occurred: {e}")

        
    logger.info(f"Document classification resopnse from PF for TF domain : {llm_response_1}" )

    document_type_code = llm_response_1["response"]["output"][0]["output_parameters"]["type"][0] #  "BG_form"#extractedtags['type']
    summary = llm_response_1["response"]["output"][0]["output_parameters"]['summary'][0]
    summary_action_buttons = None #extractedtags['options']

    documentType = getDocumentFormat(document_type_code)
    logger.info(f"[INFO] Document type is: {documentType}")
    
    # extract_bg_fields(file_id,"bank_guarantee")  ### Calling Extractor API for seamless Flow

    db_update_result, msg = update_database_mapping_details_with_status(mapping_id,
                                                                        documentType,
                                                                        summary,
                                                                        summary_action_buttons,
                                                                        "classification_status",
                                                                        "done")
    
    if not db_update_result:
        logger.error(f"Uploaded file {filepath} with file_id {file_id} failed to\
                      complete processing because of error: {msg}")
        return

    logger.info("[INFO] Step 1 Done: Summary Extracted and classification of \
                document done")

    return


# if __name__ == "__main__":
#     filepath, file_id, corp_id , mapping_id, temp_file_path = \
#         sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5]
#     logger.info(f"filepath : {filepath}")
#     logger.info(f"file_id : {file_id}")
#     logger.info(f"corp_id : {corp_id}")
#     payments_orchestrator(filepath, file_id,  corp_id, mapping_id, temp_file_path)