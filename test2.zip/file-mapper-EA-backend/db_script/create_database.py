import subprocess
import os
from dotenv import load_dotenv
from db_logger import db_logger


# Load env file to get variables
load_dotenv()

# Database configurations
HOST = os.getenv('POSTGRES_HOST')
PORT = os.getenv('POSTGRES_PORT')
USER = os.getenv('POSTGRES_USER')
PASSWORD = os.getenv('POSTGRES_PASSWORD')
DBNAME = os.getenv('POSTGRES_DB')

# Setting environment variable for the subprocess to use
env = dict(PGPASSWORD=PASSWORD, **dict(os.environ))

def run_command(command, env):
    try:
        result = subprocess.run(command, env=env, check=True, capture_output=True, text=True)
        return True, result.stdout
    except subprocess.CalledProcessError as e:
        return False, e.stderr


# Checking if the database exists
check_db_exists_command = [
    "psql",
    "-h", HOST,
    "-p", PORT,
    "-U", USER,
    "-W", PASSWORD,
    "-d", "postgres",  # Default database
    "-tAc", f"SELECT 1 FROM pg_database WHERE datname='{DBNAME}'"
]

db_logger.info("Enter database password")
success, output = run_command(check_db_exists_command, env)
db_logger.info("Checking if database exist...")

if success and output.strip() == '':
    db_logger.info(f"Database {DBNAME} does not exist. Creating the database...")
    create_db_command = [
        "psql",
        "-h", HOST,
        "-p", PORT,
        "-U", USER,
        "-W", PASSWORD,
        "-d", "postgres",
        "-c", f"CREATE DATABASE {DBNAME}"
    ]
    success, error = run_command(create_db_command, env)
    if success:
        db_logger.info(f"Database {DBNAME} created successfully.")
    else:
        db_logger.error(f"Failed to create database {DBNAME}. Error: {error}")
        exit(1)
else:
    db_logger.info(f"Database {DBNAME} already exists....")
