""""
    Standalone file to create, update, delete tables.
    Also to add initial data into tables.
"""


from sqlite3 import OperationalError
import psycopg2
from db_logger import db_logger
import os
from dotenv import load_dotenv


# Load env file to get variables
load_dotenv()

### Connect to your database
try:
    # Attempt to establish a database connection
    conn = psycopg2.connect(
        dbname=os.getenv('POSTGRES_DB'),
        user=os.getenv('POSTGRES_USER'),
        password=os.getenv('POSTGRES_PASSWORD'),
        host=os.getenv('POSTGRES_HOST'),
        # host='postgres',#'postgresql://postgres:postgres@postgres:5432/filemapperdb',
        port=os.getenv('POSTGRES_PORT')
    )
except OperationalError as e:
    # Handle the case where there is an operational error (e.g., database connection issue)
    db_logger.error(f"Error: {e}")
except psycopg2.Error as e:
    # Handle specific PostgreSQL errors
    db_logger.error(f"PostgreSQL Error: {e}")

### Add table into database and update few corporate names
try:
    cur = conn.cursor()

    # Create table corporate
    cur.execute('''CREATE TABLE IF NOT EXISTS corporates
                (corp_id SERIAL PRIMARY KEY,
                corp_name TEXT NOT NULL)''')

    cur.execute('''
            CREATE SEQUENCE IF NOT EXISTS reference_id_seq;

            CREATE TABLE IF NOT EXISTS document_files (
                file_id SERIAL PRIMARY KEY,
                file_name TEXT NOT NULL,
                cloud_file_path TEXT,
                ocr_needed BOOLEAN DEFAULT FALSE,
                local_file_path TEXT,
                imported_date TIMESTAMPTZ DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata'),
                reference_id INTEGER DEFAULT nextval('reference_id_seq'),
                disabled BOOLEAN DEFAULT FALSE
            );
        ''')

    # Create table corp_file_mapping
    cur.execute('''
            CREATE TABLE IF NOT EXISTS corp_file_mapping (
                corp_file_id SERIAL PRIMARY KEY,
                corp_id INTEGER,
                file_id INTEGER,
                isProcessed BOOLEAN,
                isViewedFile BOOLEAN,
                document_class TEXT,
                document_summary TEXT,
                documentActions TEXT,
                document_domain_name TEXT,
                classification_status TEXT CHECK (classification_status IN ('not_started', 'inprogress', 'done', 'failed')) DEFAULT 'not_started',
                classification_approved BOOLEAN DEFAULT FALSE,
                classification_rejected BOOLEAN DEFAULT FALSE,
                extraction_status TEXT CHECK (extraction_status IN ('not_started', 'inprogress', 'done', 'failed')) DEFAULT 'not_started',
                extraction_approved BOOLEAN DEFAULT FALSE,
                extraction_rejected BOOLEAN DEFAULT FALSE,
                validation_status TEXT CHECK (validation_status IN ('not_started', 'inprogress', 'done', 'failed')) DEFAULT 'not_started',
                validation_approved BOOLEAN DEFAULT FALSE,
                validation_rejected BOOLEAN DEFAULT FALSE,
                final_approval BOOLEAN DEFAULT FALSE,
                FOREIGN KEY(corp_id) REFERENCES corporates(corp_id),
                FOREIGN KEY(file_id) REFERENCES document_files(file_id)
            );
        ''')


    # Create table sections_table_mapping
    cur.execute('''
                CREATE TABLE IF NOT EXISTS sections_table_mapping (
                sec_table_id SERIAL PRIMARY KEY,
                corp_file_id INTEGER,
                sectionCode TEXT,
                section TEXT,
                extracted_results JSON,
                extracted_html TEXT,
                validation_results JSON,
                FOREIGN KEY(corp_file_id) REFERENCES corp_file_mapping(corp_file_id)
            );
            ''')
    
    # Make corp_file_id unique in this table
    cur.execute('''
        ALTER TABLE sections_table_mapping
        ADD CONSTRAINT unique_corp_file_section UNIQUE (corp_file_id);
        ''')
    
    # Create table file_page_details
    cur.execute('''
                CREATE TABLE IF NOT EXISTS file_page_details (
                file_id INTEGER,
                file_name TEXT,
                file_category TEXT,
                page_number INTEGER,
                classification TEXT,
                thumbnail_path TEXT,
                page_path TEXT,
                doc_path TEXT,
                FOREIGN KEY(file_id) REFERENCES document_files(file_id),
                UNIQUE (file_id, page_number)
            );
        ''')
    
    ## Add column validated_html in sections_table_mapping table
    cur.execute('''
            ALTER TABLE sections_table_mapping
            ADD COLUMN validated_html TEXT;
        ''')

    # Create table file_page_content
    cur.execute('''
                CREATE TABLE IF NOT EXISTS file_page_content (
                content_id SERIAL PRIMARY KEY,
                file_id INTEGER,
                page_wise_extracted_html TEXT,
                page_wise_extracted_json JSON,
                page_wise_validated_html TEXT,
                page_wise_validated_json JSON,
                page_number INTEGER,
                FOREIGN KEY(file_id) REFERENCES document_files(file_id),
                UNIQUE (file_id, page_number)
            );
        ''')


    # Create third_party_data table
    cur.execute('''
        CREATE TABLE IF NOT EXISTS third_party_data (
            data_id SERIAL PRIMARY KEY,           -- Auto-incrementing ID
            file_id INTEGER NOT NULL,             -- Foreign key reference to document_files table
            API_url TEXT NOT NULL,                -- Stores the API URL as text
            final_json JSON,                      -- Stores the final JSON response
            FOREIGN KEY (file_id) REFERENCES document_files(file_id),   -- Foreign key constraint
            UNIQUE (file_id, API_url)             -- Add unique constraint for upsert operation
        );
    ''')


    # Insert static data into corporates
    cur.execute("INSERT INTO corporates (corp_name) VALUES (%s)", ('UOB Demo',))
    cur.execute("INSERT INTO corporates (corp_name) VALUES (%s)", ('Reliance',))
    cur.execute("INSERT INTO corporates (corp_name) VALUES (%s)", ('HCL',))
    cur.execute("INSERT INTO corporates (corp_name) VALUES (%s)", ('Tata Power',))
    cur.execute("INSERT INTO corporates (corp_name) VALUES (%s)", ('Tata Motors',))
    cur.execute("INSERT INTO corporates (corp_name) VALUES (%s)", ('Intellect Design Arena',))
    cur.execute("INSERT INTO corporates (corp_name) VALUES (%s)", ('Hindustan Unilever',))
    cur.execute("INSERT INTO corporates (corp_name) VALUES (%s)", ('Bayer',))
    cur.execute("INSERT INTO corporates (corp_name) VALUES (%s)", ('British Airways plc',))

    conn.commit()
    if cur:
        cur.close()
    if conn:
        conn.close()

except OperationalError as e:
    # Handle the case where there is an operational error (e.g., database connection issue)
    db_logger.error(f"OperationalError: {e}")

except psycopg2.Error as e:
    # Handle specific PostgreSQL errors
    db_logger.error(f"PostgreSQL Error: {e}")

