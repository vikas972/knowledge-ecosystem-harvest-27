import psycopg2
from psycopg2 import OperationalError, errorcodes, errors
from psycopg2 import pool

from prompts import *
from prompts_templates import *

import json
import os
from logger import logger
from psycopg2.extras import RealDictCursor
from psycopg2.extras import RealDictCursor
from psycopg2.extras import Json


# def get_db_connection():
#     # Implement the function to get the database connection
#     try:
#         conn = psycopg2.connect(
#             dbname=os.getenv('POSTGRES_DB'),
#             user=os.getenv('POSTGRES_USER'),
#             password=os.getenv('POSTGRES_PASSWORD'),
#             host=os.getenv('POSTGRES_HOST'),
#             # host=os.getenv('postgresql://postgres:postgres@postgres:5432/filemapperdb'),
#             port=os.getenv('POSTGRES_PORT')
#         )
#         return conn
#     except OperationalError as e:
#         logger.error(f"Error connecting to the database: {e}")
#         return None
    
# Initialize the connection pool
db_pool = pool.SimpleConnectionPool(
    1, 20,  # minconn, maxconn
    dbname=os.getenv('POSTGRES_DB'),
    user=os.getenv('POSTGRES_USER'),
    password=os.getenv('POSTGRES_PASSWORD'),
    host=os.getenv('POSTGRES_HOST'),
    port=os.getenv('POSTGRES_PORT')
)

def get_db_connection():
    """Acquire a database connection from the pool."""
    try:
        conn = db_pool.getconn()
        return conn
    except OperationalError as e:
        logger.error(f"Error connecting to the database: {e}")
        return None

def release_db_connection(conn):
    """Release the database connection back to the pool."""
    db_pool.putconn(conn)



def get_json_mapping(corp_file_id, section_code):
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT extracted_results, sec_table_id, extracted_results
                FROM sections_table_mapping 
                WHERE corp_file_id = %s AND sectionCode = %s
                ORDER BY sec_table_id
                LIMIT 1;
                """, (corp_file_id, section_code))
            result = cur.fetchone()
            if result:
                # Safely evaluate the string as a Python dictionary
                # return ast.literal_eval(result[0]), result[1], result[2]
                response = result[0], result[1], result[2]
            else:
                response =  None,None,None
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        response =  None,None,None
    conn.close()
    release_db_connection(conn)
    return response


def update_database_mapping_details(corp_file_id, document_format, document_summary, document_actions):
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # Prepare the SQL query to update the specified fields
        update_query = '''
            UPDATE corp_file_mapping
            SET
                document_class = %s,
                document_summary = %s,
                documentActions = %s
            WHERE
                corp_file_id = %s;
        '''

        # Execute the query with the provided data
        cur.execute(update_query, (document_format, document_summary, document_actions, corp_file_id))
        logger.info("Database Updated: Summary and Document Type")

        # Commit the changes and close the database connection
        conn.commit()
        cur.close()
        conn.close()
        release_db_connection(conn)
        return True, "Update successful"
    except (Exception, errors.DatabaseError) as e:
        logger.error(f"Error updating the database: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Update failed: {e}"


def update_is_viewed_file(corp_file_id):
    conn = None
    try:
        # Get a connection from the pool
        conn = get_db_connection()
        if not conn:
            logger.error("Could not establish a database connection")

        cur = conn.cursor()

        # SQL query to update the isViewedFile field
        update_query = '''
            UPDATE corp_file_mapping
            SET isViewedFile = TRUE
            WHERE corp_file_id = %s;
        '''

        # Execute the query with the provided data
        cur.execute(update_query, (corp_file_id,))

        # Commit the changes
        conn.commit()
        cur.close()
        return True
    except (Exception, psycopg2.DatabaseError, OperationalError) as e:
        # Log the error
        logger.error(f"Error updating isViewedFile for corp_file_id {corp_file_id}: {e}")
        if conn:
            conn.rollback()
        return False
    finally:
        if conn:
            # Ensure the connection is always released back to the pool
            release_db_connection(conn)



def set_is_processed_true(corp_file_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # SQL query to update the isProcessed field
        update_query = '''
            UPDATE corp_file_mapping
            SET isProcessed = TRUE
            WHERE corp_file_id = %s;
        '''

        # Execute the query with the provided data
        cur.execute(update_query, (corp_file_id,))

        # Commit the changes and close the database connection
        conn.commit()
        cur.close()
        conn.close()
        release_db_connection(conn)
        logger.info("isProcessed set to TRUE for corp_file_id: %s", corp_file_id)
        return True, "Update successful"
    except (Exception, errors.DatabaseError) as e:
        logger.error(f"Error updating the database: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Update failed: {e}"

    

def replicate_database_cop(corp_file_id, section_code, section, json_mapping):
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # SQL query to insert new record into sections_table_mapping
        insert_query = '''
            INSERT INTO sections_table_mapping (corp_file_id, sectionCode, section, extracted_results)
            VALUES (%s, %s, %s, %s);
        '''

        # Execute the query with the provided data
        cur.execute(insert_query, (corp_file_id, section_code, section, json.dumps(json_mapping)))

        # Commit the changes and close the database connection
        conn.commit()
        cur.close()
        conn.close()
        release_db_connection(conn)
        logger.info("Record inserted into sections_table_mapping")
        return True, "Insert successful"
    except (Exception, errors.DatabaseError) as e:
        logger.error(f"Error inserting mappings into the database: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Insert failed: {e}"
    

def add_extracted_html(corp_file_id, section_code, section, extracted_html):
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # SQL query to insert new record into sections_table_mapping
        insert_query = '''
            INSERT INTO sections_table_mapping (corp_file_id, sectionCode, section, extracted_html)
            VALUES (%s, %s, %s, %s);
        '''

        # Execute the query with the provided data
        cur.execute(insert_query, (corp_file_id, section_code, section, extracted_html))

        # Commit the changes and close the database connection
        conn.commit()
        cur.close()
        conn.close()
        release_db_connection(conn)
        logger.info("HTML Record inserted into sections_table_mapping")
        return True, "Insert successful"
    except (Exception, errors.DatabaseError) as e:
        logger.error(f"Error inserting mappings into the database: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Insert failed: {e}"


def handle_corporate_addition(new_corp_name):
    """
    Handles the addition of a new corporate entry if provided,
    otherwise uses the selected corporate ID.

    Args:
    - new_corp_name (str): The new corporate name to add.

    Returns:
    - (bool, int or None): Tuple containing a flag indicating success and the corporate ID.
    """
    conn = None
    try:
        # Get database connection
        conn = get_db_connection()
        if not conn:
            raise OperationalError("Could not establish a database connection")
        cur = conn.cursor()
        cur.execute("INSERT INTO corporates (corp_name) VALUES (%s) RETURNING corp_id", (new_corp_name,))
        corp_id = cur.fetchone()[0]
        conn.commit()
        cur.close()
        return True, corp_id
    except (Exception, psycopg2.DatabaseError, OperationalError) as e:
        # Log the error
        logger.error(f"Error during database operation: {e}")
        if conn:
            conn.rollback()
        return False, None
    finally:
        if conn:
            # Ensure the connection is always released back to the pool
            release_db_connection(conn)

def insert_document_file(original_file_name, azure_file_path, local_file_path):
    """
    Inserts a new entry into the document_files table.

    Args:
    - original_file_name (str): The original name of the file.
    - azure_file_path (str): The path to the file in Azure.
    - local_file_path (str): Local file path

    Returns:
    - (bool, int or None): Tuple containing a flag indicating success and the file ID.
    """
    conn = None
    try:
        # Get database connection
        conn = get_db_connection()
        if not conn:
            raise OperationalError("Could not establish a database connection")

        cur = conn.cursor()
        
        # Insert data into document_files table
        cur.execute("INSERT INTO document_files (file_name, cloud_file_path, local_file_path)\
                     VALUES (%s, %s, %s) RETURNING file_id", 
                    (original_file_name, azure_file_path, local_file_path))
        file_id = cur.fetchone()[0]
        
        # Commit the changes
        conn.commit()
        cur.close()
        return True, file_id
    except (Exception, psycopg2.DatabaseError, OperationalError) as e:
        # Log the error
        logger.error(f"An error occurred while doing file entry in db: {e}")
        if conn:
            conn.rollback()
        return False, None
    finally:
        if conn:
            # Ensure the connection is always released back to the pool
            release_db_connection(conn)

def insert_corp_file_mapping(corp_id, file_id):
    """
    Inserts a new entry into the corp_file_mapping table.

    Args:
    - corp_id (int): The corporate ID.
    - file_id (int): The file ID.

    Returns:
    - (bool, int or None): Tuple containing a flag indicating success and the mapping ID.
    """
    conn = None
    try:
        # Get database connection
        conn = get_db_connection()
        if not conn:
            raise OperationalError("Could not establish a database connection")

        cur = conn.cursor()
        
        # Insert data into corp_file_mapping table
        cur.execute(
            "INSERT INTO corp_file_mapping (corp_id, file_id, isProcessed, isViewedFile, document_class, document_summary, documentActions) VALUES (%s, %s, False, False, '', '', '') RETURNING corp_file_id",
            (corp_id, file_id)
        )
        mapping_id = cur.fetchone()[0]
        
        # Commit the changes
        conn.commit()
        cur.close()
        return True, mapping_id
    except (Exception, psycopg2.DatabaseError, OperationalError) as e:
        # Log the error
        logger.error(f"An error occurred while doing corp_file_mapping entry in db: {e}")
        if conn:
            conn.rollback()
        return False, None
    finally:
        if conn:
            # Ensure the connection is always released back to the pool
            release_db_connection(conn)


def fetch_corp_file_mapping_from_db():
    """
    Fetch the corporate file mapping data from the database.

    Returns:
        list: A list of dictionaries containing the corporate file mapping data.
    """
    try:
        conn = get_db_connection()
        if conn is None:
            logger.error("Cannot establish db connection. Please check initial setup")
            return []

        cur = conn.cursor()
        cur.execute('''
            SELECT cm.corp_file_id, 
                    cm.corp_id, 
                    cm.file_id, 
                    cm.isProcessed, 
                    cm.isViewedFile, 
                    cm.document_class, 
                    cm.document_summary, 
                    cm.documentActions, 
                    c.corp_name, 
                    d.file_name, 
                    d.cloud_file_path
            FROM corp_file_mapping cm
            LEFT JOIN corporates c ON cm.corp_id = c.corp_id
            LEFT JOIN document_files d ON cm.file_id = d.file_id
            WHERE cm.isProcessed = TRUE;
        ''')
        data = cur.fetchall()
        cur.close()
        conn.close()

        results = [
            {
                "corp_file_id": row[0],
                "corp_id": row[1],
                "file_id": row[2],
                "isProcessed": row[3],
                "isViewedFile": row[4],
                "document_class": row[5],
                "document_summary": row[6],
                "documentActions": row[7],
                "corp_name": row[8],
                "file_name": row[9],
                "cloud_file_path": row[10]
            }
            for row in data
        ]
        return results
    except (Exception, errors.DatabaseError) as e:
        logger.error(f"Error getting corp names from db: {e}")
        if conn:
            conn.rollback()
        return []
    finally:
        if conn:
            release_db_connection(conn)


def fetch_selected_data_from_db(selected_id):
    """
    Fetch the selected data from the database based on the provided ID.

    Args:
        selected_id (str): The ID of the selected corporate file mapping.

    Returns:
        tuple: A tuple containing the fetched data or None if no data is found.
    """
    try:
        conn = get_db_connection()
        if conn is None:
            logger.error("Cannot establish db connection. Please check initial setup")
            return None

        cur = conn.cursor()
        cur.execute('''
            SELECT cfm.*, c.corp_name, df.file_name, df.cloud_file_path
            FROM corp_file_mapping cfm
            LEFT JOIN corporates c ON cfm.corp_id = c.corp_id
            LEFT JOIN document_files df ON cfm.file_id = df.file_id
            WHERE cfm.corp_file_id = %s;
        ''', (selected_id,))
        data = cur.fetchone()
        cur.close()
        conn.close()
        return data
    except Exception as e:
        logger.error(f"Error while fetching selected data: {e}")
        if conn:
            conn.rollback()
        return None
    finally:
        if conn:
            release_db_connection(conn)

def update_mappings_in_db(mappings_json, sec_table_id):
    """
    Update the modified JSON mappings in the database.

    Args:
        mappings_json (str): The JSON data to be updated in the database.
        sec_table_id (int): The section table ID where the JSON data should be updated.

    Returns:
        str: A message indicating the result of the database update operation.
    """
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        query = "UPDATE sections_table_mapping SET extracted_results=%s WHERE sec_table_id=%s"
        logger.info(query)
        cur.execute(query, (mappings_json, int(sec_table_id)))
        conn.commit()
        return "Updated Successfully"
    except psycopg2.Error as e:
        logger.error("Error while saving updated mappings into database: ", e)
        conn.rollback()
        return "Not able to update into records."
    except Exception as e:
        logger.error("Error while saving updated mappings into database: ", e)
        return "Not able to update into records."
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()
            release_db_connection(conn)



def update_database_mapping_details_with_status(corp_file_id, 
                                                document_format, 
                                                document_summary, 
                                                document_actions,
                                                status_field,
                                                status):
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # Prepare the SQL query to update the specified fields
        update_query = f'''
            UPDATE corp_file_mapping
            SET
                document_class = %s,
                document_summary = %s,
                documentActions = %s,
                {status_field} = %s
            WHERE
                corp_file_id = %s;
        '''

        # Execute the query with the provided data
        cur.execute(update_query, (document_format, document_summary, document_actions, status, corp_file_id))
        logger.info("Database Updated With: Summary, Document Type, and classificatio status")

        # Commit the changes and close the database connection
        conn.commit()
        cur.close()
        conn.close()
        release_db_connection(conn)
        return True, "Update successful"
    except (Exception, errors.DatabaseError) as e:
        logger.error(f"Error updating the database: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Update failed: {e}"
 

def update_files_status_field(file_id, status_field, status_value):
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # Prepare the SQL query to update the specified status field
        update_query = f'''
            UPDATE corp_file_mapping
            SET
                {status_field} = %s
            WHERE
                file_id = %s;
        '''

        # Execute the query with the provided data
        cur.execute(update_query, (status_value, file_id))
        logger.info(f"Database Updated: {status_field} set to {status_value}")

        # Commit the changes and close the database connection
        conn.commit()
        cur.close()
        release_db_connection(conn)
        return True, "Update successful"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error updating the database: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Update failed: {e}"



def update_extraction_approved(file_id, 
                               field_name, 
                               document_format=None,
                               extracted_fields_json=None,
                               validation_json_data=None):
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        if document_format:
            # Prepare the SQL query to update the specified fields
            update_query = f'''
                UPDATE corp_file_mapping
                SET
                    {field_name} = %s,
                    document_class = %s
                WHERE
                    file_id = %s;
            '''

            # Execute the query with the provided data
            cur.execute(update_query, ("TRUE", document_format, file_id))

        elif extracted_fields_json:
            # Prepare the SQL query to update extracted_results in sections_table_mapping
            update_extracted_fields_query = '''
                UPDATE sections_table_mapping
                SET 
                    extracted_results = %s
                WHERE 
                    corp_file_id = %s;
            '''

            # Prepare the SQL query to update extraction_approved in corp_file_mapping
            update_extraction_approved_query = '''
                UPDATE corp_file_mapping
                SET 
                    extraction_approved = TRUE
                WHERE 
                    file_id = %s;
            '''

             # Convert the extracted fields to JSON string
            extracted_fields_json = json.dumps(extracted_fields_json)

            # Execute the queries with the provided data
            cur.execute(update_extracted_fields_query, (extracted_fields_json, file_id))
            cur.execute(update_extraction_approved_query, (file_id,))
            logger.info(f"Database Updated: {field_name} set to TRUE and extracted_results updated")
            # return True, "Update successful"

            # Execute the query with the provided data
            # cur.execute(update_query, ("TRUE", json.dumps(extracted_fields_json), file_id))
            

        elif validation_json_data:
            # Prepare the SQL query to update the specified fields
            update_query = f'''
                UPDATE sections_table_mapping
                SET
                    {field_name} = %s,
                    validation_results = %s
                FROM corp_file_mapping
                WHERE
                    sections_table_mapping.corp_file_id = corp_file_mapping.corp_file_id AND
                    corp_file_mapping.file_id = %s;
            '''

            # Execute the query with the provided data
            cur.execute(update_query, ("TRUE", json.dumps(validation_json_data), file_id))
            logger.info(f"Database Updated: {field_name} set to TRUE and extracted_results updated")
            
        else:
            # Prepare the SQL query to update the specified fields
            update_query = f'''
                UPDATE corp_file_mapping
                SET
                    {field_name} = %s
                WHERE
                    file_id = %s;
            '''

            # Execute the query with the provided data
            cur.execute(update_query, ("TRUE", file_id))
        logger.info(f"Database Updated: {field_name} Status")

        # Commit the changes and close the database connection
        conn.commit()
        cur.close()
        release_db_connection(conn)
        return True, "Update successful"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error updating the database: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Update failed: {e}"



def update_extraction_approved_using_file_id(file_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # Update extraction_approved to TRUE based on file_id
        update_extraction_approved_query = '''
            UPDATE corp_file_mapping
            SET 
                extraction_approved = TRUE
            WHERE 
                file_id = %s;
        '''
        cur.execute(update_extraction_approved_query, (file_id,))

        # Commit changes and close connection
        conn.commit()
        cur.close()
        release_db_connection(conn)
        return True, "Update successful"
    
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error updating the database: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Update failed: {e}"


def retrieve_file_data(file_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cur = conn.cursor()
        select_query = '''
            SELECT local_file_path FROM document_files
            WHERE file_id = %s;
        '''
        cur.execute(select_query, (file_id,))
        result = cur.fetchone()
        cur.close()
        release_db_connection(conn)
        return result, "Data retrieval successful"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching data for file: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return None, f"Data retrieval failed: {e}"
    
def retrieve_extracted_file_data(file_id,classification):
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cur = conn.cursor()
        select_query = '''
            SELECT doc_path FROM file_page_details
            WHERE file_id = %s AND classification = %s;
        '''
        cur.execute(select_query, (file_id,classification))
        result = cur.fetchone()
        cur.close()
        release_db_connection(conn)
        if result:
            return result, "Data retrieval successful"
        else:
            return None, "No data found for the given file_id"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching data for file: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return None, f"Data retrieval failed: {e}"
    
    

def store_extracted_fields(corp_file_id, section_code, section, extracted_fields):
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # Prepare the SQL query to insert or update the extracted fields
        upsert_query = '''
            INSERT INTO sections_table_mapping (
                corp_file_id,
                sectionCode,
                section,
                extracted_results
            ) VALUES (%s, %s, %s, %s)
            ON CONFLICT (corp_file_id)
            DO UPDATE SET
                extracted_results = EXCLUDED.extracted_results;
        '''

        # Execute the query with the provided data
        cur.execute(upsert_query, (corp_file_id, section_code, section, json.dumps(extracted_fields)))
        logger.info("Database Updated: Extracted fields stored")

        # Commit the changes and close the database connection
        conn.commit()
        cur.close()
        release_db_connection(conn)
        return True, "Upsert successful"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error upserting data into the database: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Upsert failed: {e}"


def store_validation_results_for_bg_form(corp_file_id, section_code, section, validation_results):
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # Prepare the SQL query to insert or update the validation results
        upsert_query = '''
            INSERT INTO sections_table_mapping (
                corp_file_id,
                sectionCode,
                section,
                validation_results
            ) VALUES (%s, %s, %s, %s)
            ON CONFLICT (corp_file_id)
            DO UPDATE SET
                validation_results = EXCLUDED.validation_results;
        '''

        # Execute the query with the provided data
        cur.execute(upsert_query, (corp_file_id, section_code, section, json.dumps(validation_results)))
        logger.info("Database Updated: Validation results stored")

        # Commit the changes and close the database connection
        conn.commit()
        cur.close()
        release_db_connection(conn)
        return True, "Upsert successful"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error upserting data into the database: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Upsert failed: {e}"

def get_extracted_fields(file_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cur = conn.cursor()
        select_query = '''
            SELECT extracted_results
            FROM sections_table_mapping
            WHERE corp_file_id = %s;
        '''
        cur.execute(select_query, (file_id,))
        result = cur.fetchone()
        cur.close()
        release_db_connection(conn)
        
        if result:
            return json.dumps(result[0]), "Data retrieval successful"
        else:
            return None, "No data found for the given file_id"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching data: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return None, f"Data retrieval failed: {e}"
    

def get_files_data():
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cur = conn.cursor()
        query = '''
            SELECT 
                df.file_id,
                df.file_name,
                c.corp_name,
                cfm.classification_status,
                cfm.classification_approved,
                cfm.extraction_status,
                cfm.extraction_approved,
                cfm.classification_rejected,
                cfm.extraction_rejected,
                df.imported_date,
                cfm.document_class,
                df.cloud_file_path AS file_path,
                df.reference_id
            FROM 
                document_files df
            JOIN 
                corp_file_mapping cfm ON df.file_id = cfm.file_id
            JOIN 
                corporates c ON cfm.corp_id = c.corp_id
                WHERE df.disabled=False;
        '''
        cur.execute(query)
        results = cur.fetchall()
        cur.close()
        release_db_connection(conn)

        files_data = []
        for row in results:
            file_data = {
                "file_id": row[0],
                "file_name": row[1],
                "corporate": row[2],
                "classification_status": row[3],
                "classification_is_approved": row[4],
                "extraction_status": row[5],
                "extraction_is_approved": row[6],
                "classification_rejected": row[7],
                "extraction_rejected": row[8],
                "imported_date": row[9],
                "file_type": row[10],
                "file_path": row[11],
                "reference_id": row[12]
            }
            files_data.append(file_data)

        return files_data, "Data retrieval successful"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching data: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return None, f"Data retrieval failed: {e}"


def get_document_type(file_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cur = conn.cursor()
        query = '''
            SELECT 
                cfm.document_class,
                df.cloud_file_path AS file_path,
                df.file_id,
                df.file_name,
                df.reference_id
            FROM 
                corp_file_mapping cfm
            JOIN 
                document_files df ON cfm.file_id = df.file_id
            WHERE 
                df.file_id = %s;
        '''
        cur.execute(query, (file_id,))
        result = cur.fetchone()
        cur.close()
        release_db_connection(conn)

        if result:
            file_details = {
                "document_class": result[0],
                "file_path": result[1],
                "file_id": result[2],
                "file_name": result[3],
                "reference_id": result[4]
            }
            return file_details, "Data retrieval successful"
        else:
            return None, "No data found for the given file_id"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching data: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return None, f"Data retrieval failed: {e}"


def get_files_validation_status_data():
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cur = conn.cursor()
        query = '''
            SELECT 
                df.file_id,
                df.file_name,
                c.corp_name,
                cfm.validation_status,
                cfm.validation_approved,
                df.reference_id
            FROM 
                document_files df
            JOIN 
                corp_file_mapping cfm ON df.file_id = cfm.file_id
            JOIN 
                corporates c ON cfm.corp_id = c.corp_id;
        '''
        cur.execute(query)
        results = cur.fetchall()
        cur.close()
        release_db_connection(conn)

        files_data = []
        for row in results:
            file_data = {
                "file_id": row[0],
                "filename": row[1],
                "corporate": row[2],
                "validation_status": row[3],
                "validation_is_approved": row[4],
                "reference_id": row[5]
            }
            files_data.append(file_data)

        return files_data, "Data retrieval successful"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching data: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return None, f"Data retrieval failed: {e}"


def update_ocr_needed(file_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # Prepare the SQL query to update the ocr_needed flag
        update_query = '''
            UPDATE document_files
            SET ocr_needed = TRUE
            WHERE file_id = %s;
        '''

        # Execute the query with the provided data
        cur.execute(update_query, (file_id,))
        conn.commit()
        cur.close()
        release_db_connection(conn)
        return True, "Update successful"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error updating the database: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Update failed: {e}"


def get_extracted_fields_for_bg_form(file_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cur = conn.cursor()
        query = '''
            SELECT 
                stm.extracted_results
            FROM 
                sections_table_mapping stm
            JOIN 
                corp_file_mapping cfm ON stm.corp_file_id = cfm.corp_file_id
            WHERE 
                cfm.file_id = %s AND
                cfm.extraction_status = 'done' AND
                cfm.classification_approved = TRUE;
        '''
        cur.execute(query, (file_id,))
        result = cur.fetchone()
        cur.close()
        release_db_connection(conn)

        if result and result[0]:
            extracted_fields = json.dumps(result[0])
            return extracted_fields, "Data retrieval successful"
        else:
            return None, "No data found for the given file_id or conditions not met"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching data: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return None, f"Data retrieval failed: {e}"
    

def get_validated_fields_for_bg_form(file_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cur = conn.cursor()
        query = '''
            SELECT 
                stm.validation_results
            FROM 
                sections_table_mapping stm
            JOIN 
                corp_file_mapping cfm ON stm.corp_file_id = cfm.corp_file_id
            WHERE 
                cfm.file_id = %s AND
                cfm.validation_status = 'done' AND
                cfm.extraction_approved = TRUE;
        '''
        cur.execute(query, (file_id,))
        result = cur.fetchone()
        cur.close()
        release_db_connection(conn)

        if result and result[0]:
            validation_result = json.dumps(result[0])
            return validation_result, "Data retrieval successful"
        else:
            return None, "No data found for the given file_id or conditions not met"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching data: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return None, f"Data retrieval failed: {e}"


def get_files_validation_data():
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cur = conn.cursor()
        query = '''
            SELECT 
                df.file_id,
                df.file_name,
                c.corp_name,
                cfm.validation_status,
                cfm.validation_approved,
                cfm.validation_rejected,
                df.imported_date,
                cfm.document_class,
                df.reference_id,
                df.cloud_file_path AS file_path  -- Renaming cloud_file_path to file_path
            FROM 
                document_files df
            JOIN 
                corp_file_mapping cfm ON df.file_id = cfm.file_id
            JOIN 
                corporates c ON cfm.corp_id = c.corp_id
            WHERE 
                cfm.extraction_approved = TRUE;
        '''
        cur.execute(query)
        results = cur.fetchall()
        cur.close()
        release_db_connection(conn)

        files_data = []
        for row in results:
            file_data = {
                "file_id": row[0],
                "file_name": row[1],
                "corporate": row[2],
                "validation_status": row[3],
                "validation_approved": row[4],
                "validation_rejected": row[5],
                "imported_date": row[6],
                "file_type": row[7],
                "reference_id": row[8],
                "file_path": row[9]  # Updated key to file_path
            }
            files_data.append(file_data)

        return files_data, "Data retrieval successful"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching data: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return None, f"Data retrieval failed: {e}"

    

def update_file_page_details(file_id, file_name, file_category, page_number, classification, thumbnail_path, page_path,doc_path):
    """
    Insert the file page details in the PostgreSQL database.

    Args:
        file_id (int): The ID of the file.
        file_name (str): The name of the file.
        file_category (str): The category of the file.
        page_number (int): The page number.
        classification (str): The classification of the page.
        thumbnail_path (str): The path to the thumbnail image.
        page_path (str): The path to the page file.

    Returns:
        str: A message indicating the result of the database insert operation.
    """
    
    conn = None
    try:
        # Get database connection
        conn = get_db_connection()
        if not conn:
            raise psycopg2.OperationalError("Could not establish a database connection")

        cur = conn.cursor()
    
        # Prepare the SQL statement
        sql = """
            INSERT INTO file_page_details (
                file_id, 
                file_name, 
                file_category, 
                page_number, 
                classification, 
                thumbnail_path, 
                page_path,
                doc_path
            ) VALUES (
                %(file_id)s, 
                %(file_name)s, 
                %(file_category)s, 
                %(page_number)s, 
                %(classification)s, 
                %(thumbnail_path)s, 
                %(page_path)s,
                %(doc_path)s
            )
        """
        
        logger.info(sql)
        
        # Execute the SQL statement
        cur.execute(sql, {
            "file_id": file_id,
            "file_name": file_name,
            "file_category": file_category,
            "page_number": page_number,
            "classification": classification,
            "thumbnail_path": thumbnail_path,
            "page_path": page_path,
            "doc_path": doc_path
        })
        
        logger.info("file_page_details Table Updated")
        # Commit the changes
        conn.commit()
        cur.close()
        
        return "Updated Successfully"
    
    except (Exception, psycopg2.DatabaseError, psycopg2.OperationalError) as e:
        # Log the error
        logger.error(f"An error occurred while doing file_page_details entry: {e}")
        if conn:
            conn.rollback()
        return "Update Failed"
    finally:
        if conn:
            # Ensure the connection is always released back to the pool
            release_db_connection(conn)

def get_file_page_details(file_id):
    """
    Retrieve the file page details from the PostgreSQL database for a given file_id.

    Args:
        file_id (int): The ID of the file.

    Returns:
        dict: A dictionary containing categories and pages in the specified format.
    """
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cur = conn.cursor()


        sql = '''
            SELECT *
            FROM file_page_details
            WHERE file_id = %s;
        '''
        
        logger.info(sql)
        # Execute the SQL query
        cur.execute(sql, (file_id,))
        # Fetch all results
        rows = cur.fetchall()

        # Column names from cursor description
        column_names = [col[0] for col in cur.description]

        # Convert rows to list of dictionaries
        results = [dict(zip(column_names, row)) for row in rows]

        # Process the results to get the desired format
        categories = set()
        pages = []
        def convert_to_title_case(snake_str):
            # Split the string by underscores
            components = snake_str.split('_')
            # Capitalize the first letter of each component and join them with spaces
            title_case_str = ' '.join(x.capitalize() for x in components)
            return title_case_str
        
        for result in results:
            categories.add(convert_to_title_case(result['classification']))
            page = {
                "id": f"page {result['page_number']}",
                "type": convert_to_title_case(result['classification']),
                "thumbnail": result['thumbnail_path'],
                "pdf": result['page_path'],
                "page_number":result['page_number']
            }
            pages.append(page)

        formatted_data = {
            "categories": list(categories),
            "pages": pages
        }
        cur.close()

        if formatted_data:
            return formatted_data, "Data retrieval successful"
        else:
            return None, "No data found for the given file_id"
    
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching data: {e}")
        if conn:
            conn.rollback()
        return None, f"Data retrieval failed: {e}"
    finally:
        if conn:
            release_db_connection(conn)


def update_classification(file_id, page_number, classification):
    """
    Update the classification in the file_page_details table for the given file_id and page_number.

    Parameters:
    file_id (int): The ID of the file to update.
    page_number (int): The page number of the file to update.
    classification (str): The new classification to set.

    Returns:
    dict: A dictionary containing the result message.
    """

    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE file_page_details
            SET classification = %s
            WHERE file_id = %s AND page_number = %s
        """, (classification, file_id, page_number))
        conn.commit()
        return {'message': 'Classification updated successfully'}
    
    except Exception as e:
        conn.rollback()
        return {'error': str(e)}
    finally:
        cursor.close()
        conn.close()


def get_extraction_status(file_id):
    """
    Retrieve the extraction status from the corp_file_mapping table for the given file_id.

    Parameters:
    file_id (int): The ID of the file to retrieve the extraction status for.

    Returns:
    dict: A dictionary containing the extraction status or an error message.
    """

    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cursor = conn.cursor()

        cursor.execute("""
            SELECT extraction_status
            FROM corp_file_mapping
            WHERE file_id = %s
        """, (file_id,))
        
        result = cursor.fetchone()
        
        if result:
            return True, result[0]
        else:
            return False, "File ID Not Found"
    
    except Exception as e:
        return False,f'error: {str(e)}'
    finally:
        cursor.close()
        conn.close()

def update_validator_files_status_approved(file_id, status_value):
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # Prepare the SQL query to update the specified status field
        update_query = f'''
            UPDATE corp_file_mapping
            SET
               validation_approved = %s
            WHERE
                file_id = %s;
        '''

        # Execute the query with the provided data
        cur.execute(update_query, (status_value, file_id))
        logger.info(f"Database Updated: validation_approved set to {status_value}")

        # Commit the changes and close the database connection
        conn.commit()
        cur.close()
        release_db_connection(conn)
        return True, "Update successful"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error updating the database: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Update failed: {e}"



def get_files_data_for_approval_page():
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cur = conn.cursor()
        query = '''
            SELECT 
                df.file_id,
                df.file_name,
                c.corp_name,
                cfm.classification_status,
                cfm.classification_approved,
                cfm.extraction_status,
                cfm.extraction_approved,
                cfm.classification_rejected,
                cfm.extraction_rejected,
                cfm.validation_approved,
                cfm.validation_rejected,
                cfm.final_approval,
                df.imported_date,
                cfm.document_class,
                df.cloud_file_path AS file_path,
                df.reference_id  
            FROM 
                document_files df
            JOIN 
                corp_file_mapping cfm ON df.file_id = cfm.file_id
            JOIN 
                corporates c ON cfm.corp_id = c.corp_id
            WHERE 
                cfm.classification_approved = TRUE AND
                cfm.extraction_approved = TRUE AND
                cfm.validation_approved = TRUE;
        '''
        cur.execute(query)
        results = cur.fetchall()
        cur.close()
        release_db_connection(conn)

        files_data = []
        for row in results:
            file_data = {
                "file_id": row[0],
                "file_name": row[1],
                "corporate": row[2],
                "classification_status": row[3],
                "classification_is_approved": row[4],
                "extraction_status": row[5],
                "extraction_is_approved": row[6],
                "classification_rejected": row[7],
                "extraction_rejected": row[8],
                "validation_approved":row[9],
                "validation_rejected":row[10],
                "final_approval":row[11],
                "imported_date": row[12],
                "file_type": row[13],
                "file_path": row[14],
                "reference_id": row[15]
            }
            files_data.append(file_data)

        return files_data, "Data retrieval successful"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching data: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return None, f"Data retrieval failed: {e}"



def get_files_data_for_rejected_page():
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cur = conn.cursor()
        query = '''
            SELECT 
                df.file_id,
                df.file_name,
                c.corp_name,
                cfm.classification_status,
                cfm.classification_approved,
                cfm.extraction_status,
                cfm.extraction_approved,
                cfm.classification_rejected,
                cfm.extraction_rejected,
                cfm.validation_approved,
                cfm.validation_rejected,
                cfm.final_approval,
                df.imported_date,
                cfm.document_class,
                df.cloud_file_path AS file_path,
                df.reference_id
            FROM 
                document_files df
            JOIN 
                corp_file_mapping cfm ON df.file_id = cfm.file_id
            JOIN 
                corporates c ON cfm.corp_id = c.corp_id
            WHERE 
                cfm.classification_rejected = TRUE OR
                cfm.validation_rejected = TRUE;
        '''
        cur.execute(query)
        results = cur.fetchall()
        cur.close()
        release_db_connection(conn)

        files_data = []
        for row in results:
            file_data = {
                "file_id": row[0],
                "file_name": row[1],
                "corporate": row[2],
                "classification_status": row[3],
                "classification_is_approved": row[4],
                "extraction_status": row[5],
                "extraction_is_approved": row[6],
                "classification_rejected": row[7],
                "extraction_rejected": row[8],
                "validation_approved":row[9],
                "validation_rejected":row[10],
                "final_approval":row[11],
                "imported_date": row[12],
                "file_type": row[13],
                "file_path": row[14],
                "reference_id": row[15]
            }
            files_data.append(file_data)

        return files_data, "Data retrieval successful"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching data: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return None, f"Data retrieval failed: {e}"
    


### Code change Aug2 2024- Create New File Instance for subclasses

def clone_file_and_create_mapping(file_id, new_local_file_path, document_class, azure_path):
    try:
        conn = get_db_connection()
        if conn is None:
            return "Connection to database failed"
        
        cur = conn.cursor()

        # Retrieve the existing row details from document_files
        select_query = '''
            SELECT file_name, cloud_file_path, ocr_needed, reference_id FROM document_files WHERE file_id = %s
        '''
        cur.execute(select_query, (file_id,))
        file_details = cur.fetchone()
        if not file_details:
            logger.error(f"No file found with file_id: {file_id}")
            release_db_connection(conn)
            return f"No file found with file_id: {file_id}"

        file_name, cloud_file_path, ocr_needed, reference_id = file_details

        # Insert a new row into document_files with the same reference_id
        insert_query = '''
            INSERT INTO document_files (file_name, cloud_file_path, ocr_needed, local_file_path, reference_id)
            VALUES (%s, %s, %s, %s, %s) RETURNING file_id
        '''
        cur.execute(insert_query, (file_name, azure_path, ocr_needed, new_local_file_path, reference_id))
        new_file_id = cur.fetchone()[0]

        # Insert a new row into corp_file_mapping
        insert_mapping_query = '''
            INSERT INTO corp_file_mapping (
                corp_id, file_id, isProcessed, isViewedFile, document_class, 
                document_summary, documentActions, classification_status, classification_approved, 
                classification_rejected, extraction_status, extraction_approved, extraction_rejected, 
                validation_status, validation_approved, validation_rejected, final_approval, document_domain_name)
            VALUES (
                (SELECT corp_id FROM corp_file_mapping WHERE file_id = %s), %s, FALSE, FALSE, %s, 
                NULL, NULL, 'done', TRUE, 
                FALSE, 'inprogress', FALSE, FALSE, 
                'not_started', FALSE, FALSE, FALSE, 'TF')
        '''
        cur.execute(insert_mapping_query, (file_id, new_file_id, document_class))

        conn.commit()
        cur.close()
        release_db_connection(conn)
        logger.info(f"New file and mapping created with new_file_id: {new_file_id}")
        return new_file_id

    except (Exception) as e:
        logger.error(f"Error: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return f"Operation failed: {e}"




def get_file_page_wise_classification_with_path(file_id):
    """
    Retrieve the unique classifications and their paths from the PostgreSQL database for a given file_id.

    Args:
        file_id (int): The ID of the file.

    Returns:
        list: A list of dictionaries containing unique classifications and their paths.
    """
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cur = conn.cursor()

        sql_query = '''
            SELECT DISTINCT classification, doc_path
            FROM file_page_details
            WHERE file_id = %s;
        '''
        
        logger.info(sql_query)
        # Execute the SQL query
        cur.execute(sql_query, (file_id,))
        # Fetch all results
        rows = cur.fetchall()

        # Convert rows to list of dictionaries
        results = [{'classification': row[0], 'path': row[1]} for row in rows]

        cur.close()

        if results:
            return results, "Data retrieval successful"
        else:
            return None, "No data found for the given file_id"
    
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching data: {e}")
        if conn:
            conn.rollback()
        return None, f"Data retrieval failed: {e}"
    finally:
        if conn:
            release_db_connection(conn)


def set_file_disabled(file_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return "Connection to database failed"
        
        cur = conn.cursor()

        # Update the disabled field to TRUE for the given file_id
        update_query = '''
            UPDATE document_files
            SET disabled = TRUE
            WHERE file_id = %s
        '''
        cur.execute(update_query, (file_id,))
        
        # Check if the update was successful
        if cur.rowcount == 0:
            logger.error(f"No file found with file_id: {file_id} to update")
            release_db_connection(conn)
            return f"No file found with file_id: {file_id} to update"

        conn.commit()
        cur.close()
        release_db_connection(conn)
        logger.info(f"File entry with file_id: {file_id} set to disabled successfully")
        return f"File entry with file_id: {file_id} set to disabled successfully"

    except (Exception) as e:
        logger.error(f"Error: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return f"Operation failed: {e}"



def get_file_current_status(file_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return {"error": "Connection to database failed"}
        
        cur = conn.cursor()

        # Check the status of the file in the corp_file_mapping table
        status_query = '''
            SELECT classification_status, extraction_status, validation_status, validation_approved
            FROM corp_file_mapping
            WHERE file_id = %s
        '''
        cur.execute(status_query, (file_id,))
        result = cur.fetchone()

        if result:
            classification_status, extraction_status, validation_status, validation_approved = result
            if validation_approved:
                current_step = "complete"
            elif validation_status == 'done':
                current_step = "verification"
            elif extraction_status == 'done':
                current_step = "extraction"
            elif classification_status == 'done':
                current_step = "classification"
            else:
                current_step = "unknown"
            
            cur.close()
            release_db_connection(conn)
            logger.info(f"Current step for file_id: {file_id} is {current_step}")
            if current_step=="unknown":
                return {"currentStep": "classification"},"Status is unknown"
            else:
                return {"currentStep": current_step},"Status retrieval successful"
        else:
            cur.close()
            release_db_connection(conn)
            return {"error": f"No status found for file_id: {file_id}"}

    except (Exception) as e:
        logger.error(f"Error: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return {"error": f"Operation failed: {e}"}
    









def get_document_class(file_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # Prepare the SQL query to fetch the document class
        query = '''
            SELECT document_class
            FROM corp_file_mapping
            WHERE file_id = %s;
        '''

        # Execute the query with the provided file_id
        cur.execute(query, (file_id,))  # Note the comma to make it a tuple
  
        # Fetch the result
        result = cur.fetchone()

        # Commit and close the database connection
        conn.commit()
        cur.close()
        conn.close()
        release_db_connection(conn)

        if result:
            return True, result[0]  # Return the document class
        else:
            return False, "No document class found for the given file_id"

    except (Exception, errors.DatabaseError) as e:
        logger.error(f"Error retrieving the document class: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Retrieval failed: {e}"
    

def update_document_domain_name(file_id, new_domain_name):
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # Prepare the SQL query to update the document_domain_name
        query = '''
            UPDATE corp_file_mapping
            SET document_domain_name = %s
            WHERE corp_file_id = %s;
        '''

        # Execute the query with the provided data
        cur.execute(query, (new_domain_name, file_id))
  
        # Commit the changes and close the database connection
        conn.commit()
        cur.close()
        conn.close()
        release_db_connection(conn)
        
        return True, "Document domain name updated successfully"
    except (Exception, errors.DatabaseError) as e:
        logger.error(f"Error updating the document domain name: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Update failed: {e}"

def get_document_domain_name(file_id):
    try:
        conn = get_db_connection()
        if conn is None:
            logger.error("Failed to connect to the database.")
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # Prepare the SQL query to retrieve the document_domain_name
        query = '''
            SELECT document_domain_name
            FROM corp_file_mapping
            WHERE file_id = %s;
        '''

        # Execute the query with the provided file_id
        cur.execute(query, (file_id,))
  
        # Fetch the result
        result = cur.fetchone()

        # Close the database connection
        cur.close()
        conn.close()
        release_db_connection(conn)

        if result:
            logger.info(f"Document domain name retrieved successfully for file_id: {file_id}")
            return True, result[0]  # Return the document domain name
        else:
            logger.info(f"No document domain name found for file_id: {file_id}")
            return False, "No document domain name found for the given file_id"
    
    except (Exception, errors.DatabaseError) as e:
        logger.error(f"Error retrieving the document domain name for file_id: {file_id}. Error: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Retrieval failed: {e}"






def get_extracted_fields_for_iso_mappings(file_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cur = conn.cursor(cursor_factory=RealDictCursor)  # Using RealDictCursor to fetch rows as dictionaries
        query = '''
            SELECT 
                stm.extracted_results
            FROM 
                sections_table_mapping stm
            JOIN 
                corp_file_mapping cfm ON stm.corp_file_id = cfm.corp_file_id
            WHERE 
                cfm.file_id = %s AND
                cfm.extraction_status = 'done' AND
                cfm.classification_approved = TRUE;
        '''
        cur.execute(query, (file_id,))
        results = cur.fetchall()
        cur.close()
        release_db_connection(conn)

        if results:
            # Collect each JSON object into a list
            extracted_jsons = [result['extracted_results'] for result in results if result['extracted_results']]
            return json.dumps(extracted_jsons), "Data retrieval successful"
        else:
            return None, "No data found for the given file_id or conditions not met"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching data: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return None, f"Data retrieval failed: {e}"


def get_extracted_html(file_id):
    """
    Fetch the extracted_html from sections_table_mapping for a given file_id.
    """
    try:
        # Establish the database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # SQL query to fetch extracted_html from sections_table_mapping
        query = '''
            SELECT stm.extracted_html
            FROM sections_table_mapping stm
            JOIN corp_file_mapping cfm ON stm.corp_file_id = cfm.corp_file_id
            WHERE cfm.file_id = %s;
        '''

        # Execute the query with the provided file_id
        cur.execute(query, (file_id,))
        result = cur.fetchone()

        # Close the cursor and release the database connection
        cur.close()
        conn.close()
        release_db_connection(conn)

        # Check if a result was found
        if result:
            extracted_html = result[0]
            logger.info("Extracted HTML fetched successfully")
            return True, extracted_html
        else:
            return False, "No extracted HTML found for the given file_id"

    except (Exception, errors.DatabaseError) as e:
        logger.error(f"Error fetching extracted HTML from the database: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Fetch failed: {e}"
    

def get_validation_html(file_id):
    """
    Fetch the validation_html from sections_table_mapping for a given file_id.
    """
    try:
        # Establish the database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # SQL query to fetch validation_html from sections_table_mapping
        query = '''
            SELECT stm.validated_html
            FROM sections_table_mapping stm
            JOIN corp_file_mapping cfm ON stm.corp_file_id = cfm.corp_file_id
            WHERE cfm.file_id = %s;
        '''

        # Execute the query with the provided file_id
        cur.execute(query, (file_id,))
        result = cur.fetchone()

        # Close the cursor and release the database connection
        cur.close()
        conn.close()
        release_db_connection(conn)

        # Check if a result was found
        if result:
            validation_html = result[0]
            logger.info("Extracted HTML fetched successfully")
            return True, validation_html
        else:
            return False, "No extracted HTML found for the given file_id"

    except (Exception, errors.DatabaseError) as e:
        logger.error(f"Error fetching extracted HTML from the database: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Fetch failed: {e}"
    



def get_doc_domain_doc_type(file_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cur = conn.cursor()
        query = '''
            SELECT 
                df.file_id,
                df.file_name,
                cfm.document_domain_name,
                cfm.document_class
            FROM 
                document_files df
            JOIN 
                corp_file_mapping cfm ON df.file_id = cfm.file_id
            WHERE df.disabled = False AND df.file_id = %s;
        '''
        cur.execute(query, (file_id,))
        result = cur.fetchone()
        cur.close()
        release_db_connection(conn)

        if result:
            file_data = {
                "file_id": result[0],
                "file_name": result[1],
                "domain_name": result[2],
                "document_class": result[3]
            }
            return file_data, "Data retrieval successful"
        else:
            return None, "No data found for the given file_id"

    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching data: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return None, f"Data retrieval failed: {e}"
    

def get_validation_fields_for_iso_mappings(file_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cur = conn.cursor(cursor_factory=RealDictCursor)  # Using RealDictCursor to fetch rows as dictionaries
        query = '''
            SELECT 
                stm.validation_results
            FROM 
                sections_table_mapping stm
            JOIN 
                corp_file_mapping cfm ON stm.corp_file_id = cfm.corp_file_id
            WHERE 
                cfm.file_id = %s;
        '''
        cur.execute(query, (file_id,))
        results = cur.fetchall()
        cur.close()
        release_db_connection(conn)

        if results:
            # Collect each JSON object into a list
            validation_json = [result['validation_results'] for result in results if result['validation_results']]
            return json.dumps(validation_json), "Data retrieval successful"
        else:
            return None, "No data found for the given file_id or conditions not met while fetching validation results"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching data while fetching validation results: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return None, f"Data retrieval failed while fetching validation results: {e}"
    

def get_validation_fields_for_iso_mappings(file_id):
    """ This function is used to extract validation fields and return given the file_id """
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"

        cur = conn.cursor(cursor_factory=RealDictCursor)  # Using RealDictCursor to fetch rows as dictionaries
        query = '''
            SELECT 
                stm.validation_results
            FROM 
                sections_table_mapping stm
            JOIN 
                corp_file_mapping cfm ON stm.corp_file_id = cfm.corp_file_id
            WHERE 
                cfm.file_id = %s;
        '''
        cur.execute(query, (file_id,))
        results = cur.fetchall()
        cur.close()
        release_db_connection(conn)

        if results:
            # Collect each JSON object into a list
            validation_json = [result['validation_results'] for result in results if result['validation_results']]
            return json.dumps(validation_json), "Data retrieval successful"
        else:
            return None, "No data found for the given file_id or conditions not met while fetching validation results"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error while fetching validation results: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return None, f"Data retrieval failed while fetching validation results: {e}"



def get_thumbnail_paths_for_file_id(file_id):
    """ This function is used to extract thumbnail paths and return given the file_id """
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"

        cur = conn.cursor(cursor_factory=RealDictCursor)  # Using RealDictCursor to fetch rows as dictionaries
        query = '''
            SELECT 
                fpd.thumbnail_path
            FROM 
                file_page_details fpd
            WHERE 
                fpd.file_id = %s;
        '''
        cur.execute(query, (file_id,))
        results = cur.fetchall()
        cur.close()
        release_db_connection(conn)

        if results:
            # Adjust the thumbnail paths to remove the base URL
            adjusted_thumbnail_paths = [result['thumbnail_path'].replace('http://127.0.0.1:5000/', '') for result in results if result['thumbnail_path']]
            return adjusted_thumbnail_paths, "Data retrieval successful"
        else:
            return None, "No data found for the given file_id or conditions not met while fetching thumbnail paths"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error while fetching thumbnail paths: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return None, f"Data retrieval failed while fetching thumbnail paths: {e}"


def update_extracted_results(file_id, extracted_results):
    try:
        conn = get_db_connection()
        if conn is None:
            return False,"Connection to database failed"
        
        cur = conn.cursor()

        # Convert extracted_results to JSON format
        extracted_results_json = json.dumps(extracted_results)

        # SQL query to update the extracted_results
        query = '''
            UPDATE sections_table_mapping 
            SET extracted_results = %s
            WHERE corp_file_id = %s;
        '''
        logger.info(f">>>>>>>><<<<<<<{extracted_results_json}, {file_id}")
        cur.execute(query, (extracted_results_json, int(file_id)))
        conn.commit()

        # Check if the row was updated
        if cur.rowcount > 0:
            return True,"Update successful"
        else:
            return False,"No rows were updated, please check the file_id"

    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error while updating extracted results: {e}")
        if conn:
            conn.rollback()
        return False,f"Data update failed: {e}"
    finally:
        if cur:
            cur.close()
        release_db_connection(conn)

def update_extracted_html(file_id, extracted_html):
    """
    Update the extracted_html in the sections_table_mapping table for the given file_id.

    Parameters:
    file_id (int): The ID of the file to update.
    extracted_html (str): The new extracted HTML to set.

    Returns:
    dict: A dictionary containing the result message.
    """

    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE sections_table_mapping
            SET extracted_html = %s
            WHERE corp_file_id = (
                SELECT corp_file_id FROM corp_file_mapping WHERE file_id = %s
            )
        """, (extracted_html, file_id))
        conn.commit()
        return {'message': 'Extracted HTML updated successfully'}
    
    except Exception as e:
        conn.rollback()
        return {'error': str(e)}
    finally:
        cursor.close()
        conn.close()


def update_extractor_files_status_approved(file_id, status_value):
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # Prepare the SQL query to update the specified status field
        update_query = f'''
            UPDATE corp_file_mapping
            SET
               extraction_approved = %s
            WHERE
                file_id = %s;
        '''

        # Execute the query with the provided data
        cur.execute(update_query, (status_value, file_id))
        logger.info(f"Database Updated: extraction_approved set to {status_value}")

        # Commit the changes and close the database connection
        conn.commit()
        cur.close()
        release_db_connection(conn)
        return True, "Update successful"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error updating the database: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Update failed: {e}"
    

def get_document_class(file_id):
    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cur = conn.cursor(cursor_factory=RealDictCursor)

        # SQL query to fetch document_class
        query = '''
            SELECT document_class
            FROM corp_file_mapping
            WHERE file_id = %s;
        '''

        cur.execute(query, (file_id,))
        result = cur.fetchone()
        cur.close()
        release_db_connection(conn)

        if result and result.get('document_class'):
            return result['document_class'], "Document class retrieval successful"
        else:
            return None, "No document class found for the given file_id"

    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error while fetching document class: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return None, f"Data retrieval failed: {e}"


def update_validated_html(file_id, validated_html):
    """
    Update the validated_html in the sections_table_mapping table for the given file_id.

    Parameters:
    file_id (int): The ID of the file to update.
    validated_html (str): The new extracted HTML to set.

    Returns:
    dict: A dictionary containing the result message.
    """

    try:
        conn = get_db_connection()
        if conn is None:
            return None, "Connection to database failed"
        
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE sections_table_mapping
            SET validated_html = %s
            WHERE corp_file_id = (
                SELECT corp_file_id FROM corp_file_mapping WHERE file_id = %s
            )
        """, (validated_html, file_id))
        conn.commit()
        return True
    
    except Exception as e:
        logger.error(f"Error while updating validated_html: {e}")
        conn.rollback()
        return False
    finally:
        cursor.close()
        conn.close()
        
        
def update_classification_approval_status(file_id, status_value):
    try:
        # Get the database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # SQL query to update the classification_approved field
        update_query = '''
            UPDATE corp_file_mapping
            SET classification_approved = %s
            WHERE file_id = %s;
        '''

        # Execute the query with the provided status_value and file_id
        cur.execute(update_query, (status_value, file_id))
        logger.info(f"Database Updated: classification_approved set to {status_value} for file_id {file_id}")

        # Commit the changes and close the connection
        conn.commit()
        cur.close()
        release_db_connection(conn)
        return True, "Update successful"
    
    except (Exception, psycopg2.Error) as e:
        # Handle errors, rollback if necessary
        logger.error(f"Error updating the database: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Update failed: {e}"

def insert_page_json_content(file_id, page_number, json_content):
    """
    Inserts HTML and JSON page content into the file_page_content table.

    Args:
        file_id (int): The ID of the file.
        page_number (int): The number of the page.
        json_content (dict): The JSON content for the page.

    Returns:
        tuple: (bool, str) indicating success/failure and a message.
    """
    try:
        # Get a database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # SQL query to insert the page content
        insert_query = '''
            INSERT INTO file_page_content (file_id, page_wise_extracted_json, page_number)
            VALUES (%s, %s, %s)
            ON CONFLICT (file_id, page_number)
            DO UPDATE SET  page_wise_extracted_json = EXCLUDED.page_wise_extracted_json;
        '''

        # Execute the query with the provided data
        cur.execute(insert_query, (file_id, json.dumps(json_content), page_number))

        # Commit the changes
        conn.commit()
        
        # Log success and return
        logger.info(f"Successfully inserted/updated page {page_number} for file_id {file_id}")
        return True, f"Page {page_number} inserted/updated successfully"

    except (Exception, psycopg2.Error) as e:
        # Rollback in case of any error
        logger.error(f"Error while inserting/updating page content for file_id {file_id}, page {page_number}: {e}")
        if conn:
            conn.rollback()
        return False, f"Insert/update failed: {e}"

    finally:
        # Close the cursor and release the connection
        if cur:
            cur.close()
        release_db_connection(conn)


def get_page_wise_extracted_html(file_id, page_number):
    """
    Helper function to fetch extracted HTML for a given file_id and page_number from the database.

    Args:
        file_id (int): The ID of the file for which the extracted HTML is requested.
        page_number (int): The page number of the file for which the HTML is requested.

    Returns:
        tuple:
            - success (bool): Indicates whether the operation was successful.
            - result (str): The extracted HTML content if found or an error message.
    """
    try:
        # Get a database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # SQL query to fetch the extracted HTML for the given file_id and page_number
        query = '''
            SELECT page_wise_extracted_html
            FROM file_page_content
            WHERE file_id = %s AND page_number = %s;
        '''
        cur.execute(query, (file_id, page_number))
        result = cur.fetchone()

        cur.close()
        release_db_connection(conn)

        if result and result[0]:
            return True, result[0]
        else:
            return False, "No extracted HTML found for the given file_id and page_number"
    
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching page-wise extracted HTML from the database: {e}")
        return False, f"Database error: {e}"




def get_extracted_data_by_file_id(file_id):
    """
    Fetches the page_number and page_wise_extracted_html from the file_page_content table for the given file_id.

    Args:
        file_id (int): The ID of the file.

    Returns:
        tuple: (bool, result) where
            - bool indicates success or failure.
            - result contains either the fetched data (list of dicts) on success, or an error message on failure.
    """
    try:
        # Get a database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # SQL query to fetch page_number and page_wise_extracted_html for the given file_id
        fetch_query = '''
            SELECT 
                page_number, 
                page_wise_extracted_html
            FROM file_page_content
            WHERE file_id = %s;
        '''

        # Execute the query
        cur.execute(fetch_query, (file_id,))

        # Fetch all results
        rows = cur.fetchall()

        # If no data found, return an appropriate message
        if not rows:
            return False, f"No extracted data found for file_id {file_id}"

        # Structure the result as a list of dictionaries
        result = [
            {
                "page_number": row[0],
                "page_wise_extracted_html": row[1]
            }
            for row in rows
        ]

        # Return success and the result
        return True, result

    except (Exception, psycopg2.Error) as e:
        # Log the error and return failure
        logger.error(f"Error while fetching extracted data for file_id {file_id}: {e}")
        return False, f"Failed to fetch data: {e}"

    finally:
        # Close the cursor and release the connection
        if cur:
            cur.close()
        release_db_connection(conn)

def update_validated_html_page_wise(file_id, page_number, disabled_input_tags_html):
    """
    Updates the page_wise_validated_html column in the file_page_content table for the given file_id and page_number.

    Args:
        file_id (int): The ID of the file.
        page_number (int): The number of the page to be updated.
        disabled_input_tags_html (str): The HTML content with disabled input tags to be updated in the validated HTML column.

    Returns:
        tuple: (bool, str) indicating success/failure and a message.
    """
    try:
        # Get a database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # SQL query to update the validated HTML content for the given file_id and page_number
        update_query = '''
            UPDATE file_page_content
            SET page_wise_validated_html = %s
            WHERE file_id = %s AND page_number = %s;
        '''

        # Execute the update query with the provided parameters
        cur.execute(update_query, (disabled_input_tags_html, file_id, page_number))

        # Commit the changes
        conn.commit()

        # Log success and return
        return True, f"Successfully updated validated HTML for file_id {file_id}, page_number {page_number}"

    except (Exception, psycopg2.Error) as e:
        # Log the error and return failure
        logger.error(f"Error while updating validated HTML for file_id {file_id}, page_number {page_number}: {e}")
        if conn:
            conn.rollback()
        return False, f"Update failed: {e}"

    finally:
        # Close the cursor and release the connection
        if cur:
            cur.close()
        release_db_connection(conn)


def get_page_wise_validated_html(file_id, page_number):
    """
    Fetches the validated HTML from the file_page_content table for the given file_id and page_number.

    Args:
        file_id (int): The ID of the file.
        page_number (int): The number of the page.

    Returns:
        tuple: (bool, result) where
            - bool indicates success or failure.
            - result contains either the fetched validated HTML on success, or an error message on failure.
    """
    try:
        # Get a database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # SQL query to fetch the validated HTML for the given file_id and page_number
        fetch_query = '''
            SELECT page_wise_validated_html
            FROM file_page_content
            WHERE file_id = %s AND page_number = %s;
        '''

        # Execute the query
        cur.execute(fetch_query, (file_id, page_number))

        # Fetch the result
        row = cur.fetchone()

        # If no data found, return an appropriate message
        if row is None:
            return False, f"No validated HTML found for file_id {file_id} and page_number {page_number}"

        # Return success and the fetched validated HTML
        return True, row[0]

    except (Exception, psycopg2.Error) as e:
        # Log the error and return failure
        logger.error(f"Error while fetching validated HTML for file_id {file_id}, page_number {page_number}: {e}")
        return False, f"Failed to fetch data: {e}"

    finally:
        # Close the cursor and release the connection
        if cur:
            cur.close()
        release_db_connection(conn)



def update_extracted_results_page_wise(file_id, page_number, extracted_results):
    """
    Updates the extracted results (in JSON format) for a specific file and page number
    in the file_page_content table.

    Args:
        file_id (int): The ID of the file.
        page_number (int): The page number for which the extracted results should be updated.
        extracted_results (dict): The extracted results to be updated in the database.

    Returns:
        tuple: (bool, str) indicating success/failure and a message.
    """
    try:
        # Get a database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # Convert extracted_results to JSON format
        extracted_results_json = json.dumps(extracted_results)

        # SQL query to update the extracted results for a specific file_id and page_number
        query = '''
            UPDATE file_page_content 
            SET page_wise_extracted_json = %s
            WHERE file_id = %s AND page_number = %s;
        '''

        # Log the extracted results and file_id for debugging
        logger.info(f"Updating extracted JSON: {extracted_results_json}, file_id: {file_id}, page_number: {page_number}")

        # Execute the query
        cur.execute(query, (extracted_results_json, int(file_id), int(page_number)))
        conn.commit()

        # Check if any row was updated
        if cur.rowcount > 0:
            return True, "Update successful"
        else:
            return False, "No rows were updated, please check the file_id and page_number"

    except (Exception, psycopg2.Error) as e:
        # Handle and log any errors
        logger.error(f"Error while updating extracted results: {e}")
        if conn:
            conn.rollback()
        return False, f"Data update failed: {e}"

    finally:
        # Ensure the cursor is closed and the connection is released
        if cur:
            cur.close()
        release_db_connection(conn)



def extract_and_store_json(file_id):
    """
    Extracts page-wise JSON content from the file_page_content table for a given file_id,
    combines it, and stores the result in the extracted_results column of the
    sections_table_mapping table.

    Args:
        file_id (int): The ID of the file.

    Returns:
        tuple: (bool, str) indicating success/failure and a message.
    """
    try:
        # Get a database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # SQL query to fetch page-wise JSON content for the given file_id
        fetch_query = '''
            SELECT page_number, page_wise_extracted_json
            FROM file_page_content
            WHERE file_id = %s
            ORDER BY page_number;
        '''

        # Execute the query and fetch the page-wise JSON content
        cur.execute(fetch_query, (file_id,))
        rows = cur.fetchall()

        # If no content found, return an appropriate message
        if not rows:
            return False, f"No page-wise JSON found for file_id {file_id}"

        # Aggregate the page-wise JSON into a single list or dictionary (depending on your needs)
        aggregated_json = []
        for row in rows:
            page_number = row[0]
            page_json = row[1]

            # Assuming the JSON from each page is an object or dictionary, add it to the list
            aggregated_json.append({
                "page_number": page_number,
                "content": page_json
            })

        # Convert the aggregated result to a JSON string
        aggregated_json_str = json.dumps(aggregated_json)

        # SQL query to update the extracted_results column in the sections_table_mapping table
        update_query = '''
            UPDATE sections_table_mapping
            SET extracted_results = %s
            WHERE corp_file_id = %s;
        '''

        # Execute the update query
        cur.execute(update_query, (aggregated_json_str, file_id))
        conn.commit()

        # Check if the row was updated
        if cur.rowcount > 0:
            return True, "Aggregated JSON successfully stored in sections_table_mapping"
        else:
            return False, "No rows were updated in sections_table_mapping, please check the corp_file_id"

    except (Exception, psycopg2.Error) as e:
        # Log any errors and roll back the transaction
        logger.error(f"Error while extracting and storing JSON: {e}")
        if conn:
            conn.rollback()
        return False, f"Data extraction and storage failed: {e}"

    finally:
        # Close the cursor and release the connection
        if cur:
            cur.close()
        release_db_connection(conn)


def update_extracted_html_page_wise(file_id, page_number, extracted_html):
    """
    Update the extracted_html in the file_page_content table for the given file_id and page_number.

    Parameters:
    file_id (int): The ID of the file to update.
    page_number (int): The page number to update.
    extracted_html (str): The new extracted HTML to set.

    Returns:
    dict: A dictionary containing the result message or error details.
    """

    try:
        # Get a database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cursor = conn.cursor()

        # SQL query to update the extracted_html in the file_page_content table
        cursor.execute("""
            UPDATE file_page_content
            SET page_wise_extracted_html = %s
            WHERE file_id = %s AND page_number = %s
        """, (extracted_html, file_id, page_number))
        
        # Commit the transaction
        conn.commit()

        # Check if the row was updated
        if cursor.rowcount > 0:
            return True,{'message': 'Extracted HTML updated successfully'}
        else:
            return False,{'error': 'No rows were updated. Please check the file_id and page_number.'}

    except Exception as e:
        # Rollback in case of any error
        conn.rollback()
        return False,{'error': str(e)}
    
    finally:
        # Close the cursor and connection
        if cursor:
            cursor.close()
        if conn:
            conn.close()



def store_validation_results(file_id, validation_results):
    """
    Stores the validation_results into the validation_results column of the sections_table_mapping table
    using file_id as the identifier for the update.

    Args:
        file_id (int): The ID of the file to update.
        validation_results (dict or str): The validation results in JSON format.

    Returns:
        tuple: (bool, str) indicating success/failure and a message.
    """
    try:
        # Get a database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"

        cur = conn.cursor()

        # Convert validation_results to a JSON string if it's a dictionary
        if isinstance(validation_results, dict):
            validation_results_str = json.dumps(validation_results)
        elif isinstance(validation_results, str):
            validation_results_str = validation_results
        else:
            return False, "Invalid data type for validation_results. Must be dict or JSON string."

        # Prepare the SQL query to update the validation_results using file_id
        update_query = '''
            UPDATE sections_table_mapping
            SET validation_results = %s
            WHERE corp_file_id = %s;
        '''

        # Execute the query
        cur.execute(update_query, (validation_results_str, file_id))
        logger.info("Database Updated: Validation results stored")

        # Commit the changes
        conn.commit()

        # Check if any rows were updated
        if cur.rowcount > 0:
            return True, "Validation results successfully updated"
        else:
            return False, "No rows were updated. Please check the file_id."

    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error updating validation results: {e}")
        if conn:
            conn.rollback()
        return False, f"Update failed: {e}"

    finally:
        # Close the cursor and connection
        if cur:
            cur.close()
        release_db_connection(conn)


def extract_validation_results(file_id):
    """
    Extracts the validation_results from the sections_table_mapping table for the given file_id (corp_file_id).

    Args:
        file_id (int): The ID of the file (also equivalent to corp_file_id).

    Returns:
        tuple: (bool, dict or str) indicating success/failure and the validation results or an error message.
    """
    try:
        # Get a database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"

        cur = conn.cursor()

        # SQL query to fetch validation_results using the file_id
        fetch_query = '''
            SELECT validation_results
            FROM sections_table_mapping
            WHERE corp_file_id = %s;
        '''

        # Execute the query
        cur.execute(fetch_query, (file_id,))
        result = cur.fetchone()

        # If no result found, return an appropriate message
        if result is None:
            return False, f"No validation results found for file_id {file_id}"

        validation_results = result[0]

        # Return the validation results
        return True, validation_results

    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching validation results: {e}")
        return False, f"Error fetching validation results: {e}"

    finally:
        # Close the cursor and connection
        if cur:
            cur.close()
        release_db_connection(conn)



def insert_third_party_data(file_id, api_url, final_json):
    """
    Inserts or updates data in the third_party_data table.
    If a record with the same file_id and api_url exists, it will be updated.
    Otherwise, a new record will be inserted.

    Args:
        file_id (int): The ID of the file from the document_files table.
        api_url (str): The API URL used to fetch data.
        final_json (dict or str): The final JSON response from the API.

    Returns:
        tuple: (bool, str) indicating success/failure and a message.
    """
    try:
        # Get a database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to the database failed"
        
        cur = conn.cursor()

        # Convert final_json to a JSON string if it's a dictionary
        if isinstance(final_json, dict):
            final_json_str = json.dumps(final_json)
        elif isinstance(final_json, str):
            final_json_str = final_json
        else:
            return False, "Invalid data type for final_json. Must be dict or JSON string."

        # SQL query to insert or update data in third_party_data table
        upsert_query = '''
            INSERT INTO third_party_data (file_id, API_url, final_json)
            VALUES (%s, %s, %s)
            ON CONFLICT (file_id, API_url) 
            DO UPDATE SET
                final_json = EXCLUDED.final_json;
        '''

        # Execute the upsert query
        cur.execute(upsert_query, (file_id, api_url, final_json_str))
        logger.info("Data successfully upserted into third_party_data")

        # Commit the transaction
        conn.commit()

        return True, "Data successfully upserted into third_party_data"

    except (Exception, psycopg2.Error) as e:
        # Log any errors and roll back the transaction
        logger.error(f"Error upserting data into third_party_data: {e}")
        if conn:
            conn.rollback()
        return False, f"Upsert failed: {e}"

    finally:
        # Close the cursor and connection
        if cur:
            cur.close()
        release_db_connection(conn)



def fetch_third_party_data_by_file_id(file_id):
    """
    Fetches all JSON data associated with a given file_id from the third_party_data table.

    Args:
        file_id (int): The ID of the file to fetch the data for.

    Returns:
        tuple: (bool, list or str) indicating success/failure and the data or an error message.
    """
    try:
        # Get a database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to the database failed"
        
        cur = conn.cursor()

        # SQL query to fetch all JSON data for the given file_id
        fetch_query = '''
            SELECT API_url, final_json
            FROM third_party_data
            WHERE file_id = %s;
        '''

        # Execute the query
        cur.execute(fetch_query, (file_id,))
        rows = cur.fetchall()

        # If no data is found, return a failure message
        if not rows:
            return False, f"No data found for file_id {file_id}"

        # Prepare the response data
        response_data = []
        for row in rows:
            api_url = row[0]
            final_json = row[1]  # Assuming final_json is stored as a JSON object in the database

            response_data.append({
                "API_url": api_url,
                "final_json": final_json
            })

        # Return success with the fetched data
        return True, response_data

    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching data for file_id {file_id}: {e}")
        return False, f"Error fetching data: {e}"

    finally:
        # Close the cursor and connection
        if cur:
            cur.close()
        release_db_connection(conn)


def update_json_by_file_id_and_api_url(file_id, api_url, new_json):
    """
    Updates the final_json field in the third_party_data table based on the file_id and API_url.

    Args:
        file_id (int): The ID of the file.
        api_url (str): The API URL that identifies the record to be updated.
        new_json (dict or str): The new JSON data to be saved.

    Returns:
        tuple: (bool, str) indicating success/failure and a message.
    """
    try:
        # Get a database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to the database failed"
        
        cur = conn.cursor()

        # Convert new_json to a JSON string if it's a dictionary
        if isinstance(new_json, dict):
            new_json_str = json.dumps(new_json)
        elif isinstance(new_json, str):
            new_json_str = new_json
        else:
            return False, "Invalid data type for new_json. Must be dict or JSON string."

        # SQL query to update the final_json based on the file_id and API_url
        update_query = '''
            UPDATE third_party_data
            SET final_json = %s
            WHERE file_id = %s AND API_url = %s;
        '''

        # Execute the update query
        cur.execute(update_query, (new_json_str, file_id, api_url))
        logger.info(f"final_json successfully updated for file_id: {file_id}, API_url: {api_url}")

        # Commit the transaction
        conn.commit()

        # Check if any row was updated
        if cur.rowcount > 0:
            return True, f"final_json updated for file_id: {file_id}, API_url: {api_url}"
        else:
            return False, f"No record found for file_id: {file_id}, API_url: {api_url}"

    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error updating final_json for file_id {file_id} and API_url {api_url}: {e}")
        if conn:
            conn.rollback()
        return False, f"Update failed: {e}"

    finally:
        # Close the cursor and connection
        if cur:
            cur.close()
        release_db_connection(conn)



def insert_page_json_content(file_id, page_number, json_content):
    """
    Inserts HTML and JSON page content into the file_page_content table.

    Args:
        file_id (int): The ID of the file.
        page_number (int): The number of the page.
        json_content (dict): The JSON content for the page.

    Returns:
        tuple: (bool, str) indicating success/failure and a message.
    """
    try:
        # Get a database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # SQL query to insert the page content
        insert_query = '''
            INSERT INTO file_page_content (file_id, page_wise_extracted_json, page_number)
            VALUES (%s, %s, %s)
            ON CONFLICT (file_id, page_number)
            DO UPDATE SET  page_wise_extracted_json = EXCLUDED.page_wise_extracted_json;
        '''

        # Execute the query with the provided data
        cur.execute(insert_query, (file_id, json.dumps(json_content), page_number))

        # Commit the changes
        conn.commit()
        
        # Log success and return
        logger.info(f"Successfully inserted/updated page {page_number} for file_id {file_id}")
        return True, f"Page {page_number} inserted/updated successfully"

    except (Exception, psycopg2.Error) as e:
        # Rollback in case of any error
        logger.error(f"Error while inserting/updating page content for file_id {file_id}, page {page_number}: {e}")
        if conn:
            conn.rollback()
        return False, f"Insert/update failed: {e}"

    finally:
        # Close the cursor and release the connection
        if cur:
            cur.close()
        release_db_connection(conn)




def get_page_wise_extracted_json(file_id, page_number):
    """
    Helper function to fetch extracted JSON for a given file_id and page_number from the database.

    Args:
        file_id (int): The ID of the file for which the extracted JSON is requested.
        page_number (int): The page number of the file for which the JSON is requested.

    Returns:
        tuple:
            - success (bool): Indicates whether the operation was successful.
            - result (dict): The extracted JSON content if found or an error message.
    """
    try:
        # Get a database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # SQL query to fetch the extracted JSON for the given file_id and page_number
        query = '''
            SELECT page_wise_extracted_json
            FROM file_page_content
            WHERE file_id = %s AND page_number = %s;
        '''
        cur.execute(query, (file_id, page_number))
        result = cur.fetchone()

        cur.close()
        release_db_connection(conn)

        if result and result[0]:
            # Ensure the JSON data is returned as a dictionary
            return True, result[0]
        else:
            return False, "No extracted JSON found for the given file_id and page_number"
    
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error fetching page-wise extracted JSON from the database: {e}")
        return False, f"Database error: {e}"




def update_extracted_json_page_wise(file_id, page_number, extracted_json):
    """
    Update the extracted_json in the file_page_content table for the given file_id and page_number.

    Parameters:
    file_id (int): The ID of the file to update.
    page_number (int): The page number to update.
    extracted_json (dict): The new extracted JSON to set.

    Returns:
    tuple: A tuple containing a success flag and a result message or error details.
    """

    try:
        # Get a database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cursor = conn.cursor()

        # Use psycopg2.extras.Json to adapt the dict to JSON
        json_data = Json(extracted_json)

        # SQL query to update the extracted_json in the file_page_content table
        cursor.execute("""
            UPDATE file_page_content
            SET page_wise_extracted_json = %s
            WHERE file_id = %s AND page_number = %s
        """, (json_data, file_id, page_number))
        
        # Commit the transaction
        conn.commit()

        # Check if the row was updated
        if cursor.rowcount > 0:
            return True, {'message': 'Extracted JSON updated successfully'}
        else:
            return False, {'error': 'No rows were updated. Please check the file_id and page_number.'}

    except Exception as e:
        # Rollback in case of any error
        if conn:
            conn.rollback()
        return False, {'error': str(e)}
    
    finally:
        # Close the cursor and connection
        if cursor:
            cursor.close()
        if conn:
            conn.close()



def update_validated_json_page_wise(file_id, page_number, validated_json):
    """
    Updates the page_wise_validated_html column in the file_page_content table for the given file_id and page_number.

    Args:
        file_id (int): The ID of the file.
        page_number (int): The number of the page to be updated.
        validated_json (str): The HTML content with disabled input tags to be updated in the validated HTML column.

    Returns:
        tuple: (bool, str) indicating success/failure and a message.
    """
    try:
        # Get a database connection
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()
        validated_json = json.dumps(validated_json)
        # SQL query to update the validated HTML content for the given file_id and page_number
        update_query = '''
            UPDATE file_page_content
            SET page_wise_validated_json = %s
            WHERE file_id = %s AND page_number = %s;
        '''

        # Execute the update query with the provided parameters
        cur.execute(update_query, (validated_json, file_id, page_number))

        # Commit the changes
        conn.commit()

        # Log success and return
        return True, f"Successfully updated validated HTML for file_id {file_id}, page_number {page_number}"

    except (Exception, psycopg2.Error) as e:
        # Log the error and return failure
        logger.error(f"Error while updating validated HTML for file_id {file_id}, page_number {page_number}: {e}")
        if conn:
            conn.rollback()
        return False, f"Update failed: {e}"

    finally:
        # Close the cursor and release the connection
        if cur:
            cur.close()
        release_db_connection(conn)



def insert_page_html_content(file_id, page_number, html_content):
    """
    Insert HTML content into the file_page_content table for the given file_id and page_number.
    If the record already exists, it will not insert.

    Parameters:
    file_id (int): The ID of the file
    page_number (int): The page number
    html_content (str): The HTML content to insert

    Returns:
    tuple: (bool, str) indicating success/failure and a message
    """
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cursor = conn.cursor()

        # Insert the HTML content
        cursor.execute("""
            INSERT INTO file_page_content (file_id, page_number, page_wise_extracted_html)
            VALUES (%s, %s, %s)
            ON CONFLICT (file_id, page_number) DO NOTHING
        """, (file_id, page_number, html_content))

        conn.commit()
        
        # Check if a row was inserted
        if cursor.rowcount > 0:
            return True, "HTML content inserted successfully"
        else:
            return False, "Record already exists for this file_id and page_number"

    except Exception as e:
        if conn:
            conn.rollback()
        return False, f"Error inserting HTML content: {str(e)}"

    finally:
        if cursor:
            cursor.close()
        release_db_connection(conn)

def update_rejection_reason(file_id, field_name, reason):
    """
    Update the rejection reason for a file in the database.
    
    Args:
        file_id (int): The ID of the file
        field_name (str): The field to update (extraction_rejection_reason or validation_rejection_reason)
        reason (str): The rejection reason
        
    Returns:
        tuple: (success: bool, message: str)
    """
    try:
        conn = get_db_connection()
        if conn is None:
            return False, "Connection to database failed"
        
        cur = conn.cursor()

        # Prepare the SQL query to update the rejection reason
        update_query = f'''
            UPDATE corp_file_mapping
            SET
                {field_name} = %s
            WHERE
                file_id = %s;
        '''

        # Execute the query with the provided data
        cur.execute(update_query, (reason, file_id))
        logger.info(f"Database Updated: {field_name} set to '{reason}'")

        # Commit the changes and close the database connection
        conn.commit()
        cur.close()
        release_db_connection(conn)
        return True, "Update successful"
    except (Exception, psycopg2.Error) as e:
        logger.error(f"Error updating the database: {e}")
        if conn:
            conn.rollback()
        release_db_connection(conn)
        return False, f"Update failed: {e}"