"""
Set up a centralized logger for the entire application.

This function configures a logger that logs messages to both a file and the console.
The log messages include the log level and the message itself.

Returns:
    logging.Logger: The configured logger instance.
"""

import logging

def setup_logger():
    """
    Set up a centralized logger for the entire application.

    This function configures a logger that logs messages to both a file and the console.
    The log messages include the log level and the message itself.

    Returns:
        logging.Logger: The configured logger instance.
    """
    logger = logging.getLogger('logs_files/cops_logs.log')
    logger.setLevel(logging.DEBUG)

    # File Handler
    file_handler = logging.FileHandler('logs_files/cops_logs.log')
    formatter = logging.Formatter('%(message)s')
    file_handler.setFormatter(formatter)

    # Stream Handler (optional, for console output)
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)

    if not logger.handlers:
        logger.addHandler(file_handler)
        logger.addHandler(stream_handler)

    return logger

logger = setup_logger()
