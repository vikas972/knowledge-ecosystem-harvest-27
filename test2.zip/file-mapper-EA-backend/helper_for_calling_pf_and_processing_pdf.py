import os
from PIL import Image
import pymupdf
from pdf2image import convert_from_bytes
import pytesseract
import hashlib
import os
import configs
from glob import glob as glob
import json
import requests
import time
from logger import logger

def read_data_from_pdf(file_bytes: bytes):
    """
    Reads text content from a PDF file provided as `file_bytes`.

    Args:
        file_bytes (bytes): The PDF file content in bytes.

    Returns:
        str: Concatenated text from all pages.
    """

    all_text = {}
    doc = pymupdf.open(stream=file_bytes, filetype="pdf")
    for page in doc:
        all_text["page_" + str(page.number)] = page.get_text()

    doc.close()
    return all_text


def read_data_from_image(image: Image) -> str:
    """
    Extracts text from a Pillow image using pytesseract.

    Args:
        image (Image): Pillow image object.

    Returns:
        str: Extracted text.
    """
    try:
        text = pytesseract.image_to_string(image)
        return text.strip()
    except Exception as e:
        return f"Error extracting text: {str(e)}"


def read_input_file(
    file_cont_bytes: bytes, file_name: str, keep_original_text: bool = False
):
    """
    Reads text from a file (PDF or image).

    Args:
        file_ob (bytes): The PDF file content in bytes.

    Returns:
        dict or str: Extracted text or an error message.
    """
    supported_formats = ["pdf", "jpg", "png", "jpeg"]
    file_extension = file_name.split(".")[-1].lower()

    if file_extension not in supported_formats:
        return (
            f"Unsupported file type (supported formats: {', '.join(supported_formats)})"
        )

    if file_extension == "pdf":
        # Read text from PDF
        pdf_text = read_data_from_pdf(file_cont_bytes)
        # load text after converting to image
        images = convert_from_bytes(file_cont_bytes)

        all_images_text = {}
        for img_num, img_obj in enumerate(images):
            all_images_text["page_" + str(img_num)] = read_data_from_image(img_obj)

        # Decide whether to return PDF text or image text
        if keep_original_text:
            return {
                "text_extracted": pdf_text,
                "meta_data_extraction": "pdf_extraction",
            }
        else:
            # Merge PDF text and image text
            pdf_text_len = len("".join([pdf_text[i] for i in pdf_text]))

            img_text_len = len("".join([all_images_text[i] for i in all_images_text]))

            index_max_text_len = [pdf_text_len, img_text_len].index(
                max([pdf_text_len, img_text_len])
            )

            # Return the text with the maximum length
            if index_max_text_len == 0:
                return {
                    "text_extracted": pdf_text,
                    "meta_data_extraction": "pdf_extraction",
                }
            else:
                return {
                    "text_extracted": all_images_text,
                    "meta_data_extraction": "image_extraction",
                }


def dedup_file_level(extracted_text, org_doc_bytes):
    """
    Deduplicates the pages in a PDF document by removing any duplicate pages based on their content hash.
    
    Args:
        extracted_text (dict): A dictionary containing the extracted text for each page of the PDF document.
        org_doc_bytes (bytes): The original PDF document as bytes.
    
    Returns:
        tuple: A tuple containing the updated PDF document and a list of the page numbers that were deleted (if any).
    """
    
    org_doc = pymupdf.open(stream=org_doc_bytes, filetype="pdf")

    unique_pages_hashes = set()
    unique_pages = {}
    for curr_page_no, curr_page_content in extracted_text["text_extracted"].items():
        # Create a hash of the page content
        page_hash = hashlib.sha256(curr_page_content.encode("utf-8")).hexdigest()
        # If the hash is unique, add the page to the list of unique pages
        if page_hash not in unique_pages_hashes:
            unique_pages_hashes.add(page_hash)
            unique_pages[curr_page_no] = curr_page_content

    pages_2_del = set(extracted_text["text_extracted"].keys()) - set(
        unique_pages.keys()
    )
    # sort pages_2_delete
    # https://github.com/pymupdf/PyMuPDF/discussions/2591
    pages_2_del = [int(i.split("_")[-1].strip()) for i in pages_2_del]
    if pages_2_del:
        pages_2_del = sorted(pages_2_del, reverse=True)
        logger.info(f"following pages will be deletd {pages_2_del}")
        for p_no in pages_2_del:
            org_doc.delete_page(p_no)  # format is page_0
        return org_doc, pages_2_del
    else:
        return org_doc, "no duplicate pages found"


def split_save_doc_by_page(src, op_dir, file_extension):
    """
    Splits a PDF document into individual pages and saves them as separate files.
    Args:
        src (pymupdf.Document): The PDF document to split.
        op_dir (str): The directory to save the individual pages.
        file_extension (str): The file extension to use for the saved pages.
    Returns:
        None
    """
    # create output directory if it doesn't exist
    os.makedirs(op_dir, exist_ok=True)
    # src = pymupdf.open(test_file) # open a document
    logger.info(f"saving document page by page")
    for page in src:
        dest = pymupdf.open()  # empty output PDF
        dest.insert_pdf(src, from_page=page.number, to_page=page.number)
        dest.save(
            os.path.join(op_dir, "page_" + str(page.number) + "." + file_extension)
        )  # save the document
        dest.close()
    src.close()
    logger.info("saving complited")


####################### Purple Fabric API code #######################


def get_access_token(end_point, api_key, username, password):
    """
    Retrieves an access token from the Purple Fabric API using the provided endpoint, API key, username, and password.
    
    Args:
        end_point (str): The endpoint URL for the Purple Fabric API.
        api_key (str): The API key for the Purple Fabric API.
        username (str): The username for the Purple Fabric API.
        password (str): The password for the Purple Fabric API.
    
    Returns:
        str: The access token retrieved from the Purple Fabric API.
    """
    url = f"https://{end_point}/accesstoken/{configs.PURPLE_FABRIC_TENANT}"
    payload = {}
    headers = {"apikey": api_key, "username": username, "password": password}

    response = requests.request("GET", url, headers=headers, data=payload)

    return response.json().get("access_token")


def get_trace_id(
    access_token, asset_version_id, end_point, api_key, file_name, file_content
):
    """
    Retrieves a trace ID from the Purple Fabric API by invoking an asset with the provided asset version ID, file name, and file content.
    
    Args:
        access_token (str): The access token for the Purple Fabric API.
        asset_version_id (str): The ID of the asset version to invoke.
        end_point (str): The endpoint URL for the Purple Fabric API.
        api_key (str): The API key for the Purple Fabric API.
        file_name (str): The name of the file to upload.
        file_content (bytes): The content of the file to upload.
    
    Returns:
        str: The trace ID returned by the Purple Fabric API.
    """
    url = f"https://{end_point}/magicplatform/v1/invokeasset/{asset_version_id}/genai"

    payload = {}
    files = [("document", (file_name, file_content, "application/pdf"))]
    headers = {
        "apikey": api_key,
        "Accept": "application/json",
        "Authorization": f"Bearer {access_token}",
    }

    response = requests.request("POST", url, headers=headers, data=payload, files=files)

    response = response.json()
    return response.get("trace_id")


def get_response(trace_id, access_token, asset_id, end_point, api_key):
    """
    Retrieves the response from the Purple Fabric API for the given asset ID and trace ID.
    
    Args:
        trace_id (str): The trace ID to use for the API request.
        access_token (str): The access token to use for authentication.
        asset_id (str): The asset ID to use for the API request.
        end_point (str): The endpoint URL for the Purple Fabric API.
        api_key (str): The API key to use for the API request.
    
    Returns:
        dict: The JSON response from the Purple Fabric API.
    """
    url = f"https://{end_point}/magicplatform/v1/invokeasset/{asset_id}/{trace_id}"

    payload = {}
    headers = {
        "apikey": api_key,
        "Accept": "application/json",
        "Authorization": f"Bearer {access_token}",
    }

    response = requests.request("GET", url, headers=headers, data=payload)
    return response.json()


def get_result(asset_headers, asset_id, trace_id):
    
    """
    Retrieves the response from the Purple Fabric API for the given asset ID and trace ID.
    
    Args:
        trace_id (str): The trace ID to use for the API request.
        asset_id (str): The asset ID to use for the API request.
        asset_headers (dict): The headers to use for the API request, including the access token.
    
    Returns:
        dict: The JSON response from the Purple Fabric API.
    """
    status = ""
    # duration = 120
    # start_time = time.time()
    while status != "COMPLETED":
        if configs.PURPLE_FABRIC_ENV == "qa":
            chunk_get = requests.get(
                "https://api.intellectqacloud.com/magicplatform/v1/invokeasset/"
                + asset_id
                + "/"
                + trace_id,
                headers=asset_headers,
            )
        elif configs.PURPLE_FABRIC_ENV == "stg":
            chunk_get = requests.get(
                "https://api.intellectseecstag.com/magicplatform/v1/invokeasset/"
                + asset_id
                + "/"
                + trace_id,
                headers=asset_headers,
            )
        else:
            pass
        data = chunk_get.json()
        status = data["status"]
        # status = status
        if status == "COMPLETED":
            return data
        else:
            logger.info(f"coming from get_result {data}")
        # elapsed_time = time.time() - start_time
        # if elapsed_time >= duration:
        #     return 'api response error'
        time.sleep(2)


def get_all_trace_ids_classifier(page_paths):
    """
    Retrieves the trace IDs for all files in the given page paths, and returns a dictionary mapping the trace IDs to the file names.
    
    Args:
        page_paths (str): The path to the directory containing the files.
    
    Returns:
        dict: A dictionary mapping trace IDs to file names.
        str: The access token used to retrieve the trace IDs.
    """
    trace_id_file = dict()
    access_token = get_access_token(
        configs.PURPLE_FABRIC_ENDPOINT,
        configs.PURPLE_FABRIC_API_KEY,
        configs.PURPLE_FABRIC_USERNAME,
        configs.PURPLE_FABRIC_PASSWORD,
    )
    try:
        all_files = glob(page_paths + "*")
        all_files = sorted(all_files, key=lambda x: x.split("/")[-1])
        for each_page_path in all_files:
            each_page_name = each_page_path.split("/")[-1]
            each_page_content = open(each_page_path, "rb")
            trace_id = get_trace_id(
                access_token,
                configs.PURPLE_FABRIC_CLASSIFIER_ID,
                configs.PURPLE_FABRIC_ENDPOINT,
                configs.PURPLE_FABRIC_API_KEY,
                each_page_name,
                each_page_content,
            )
            trace_id_file[trace_id] = each_page_name
        return trace_id_file, access_token
    except Exception as e:
        trace_id = "NO_TRACE_ID"
        return trace_id_file, access_token


def get_all_trace_ids_extractor(page_paths, page_2_class):
    """
    Retrieves the trace IDs for all files in the given page paths, and returns a dictionary mapping the trace IDs to the file names.
    
    Args:
        page_paths (str): The path to the directory containing the files.
        page_2_class (dict): A dictionary mapping file names to their corresponding class names.
    
    Returns:
        dict: A dictionary mapping trace IDs to file names.
        str: The access token used to retrieve the trace IDs.
    """
    trace_id_file = dict()
    access_token = get_access_token(
        configs.PURPLE_FABRIC_ENDPOINT,
        configs.PURPLE_FABRIC_API_KEY,
        configs.PURPLE_FABRIC_USERNAME,
        configs.PURPLE_FABRIC_PASSWORD,
    )
    all_files = glob(page_paths + "*")
    all_files = sorted(all_files, key=lambda x: x.split("/")[-1])
    # loop through all the files in the page_paths
    for each_page_path in all_files:
        each_page_name = each_page_path.split("/")[-1]
        each_page_content = open(each_page_path, "rb")
        class_name = page_2_class[each_page_name]
        # get the asset id for the class name
        extractor_asset_id, _ = get_extractor_asset_id(class_name)
        if extractor_asset_id != None:
            trace_id = get_trace_id(
                access_token,
                extractor_asset_id,
                configs.PURPLE_FABRIC_ENDPOINT,
                configs.PURPLE_FABRIC_API_KEY,
                each_page_name,
                each_page_content,
            )
        else:
            trace_id = "NO_TRACE_ID"
        trace_id_file[trace_id] = each_page_name
    return trace_id_file, access_token


def get_classifier_raw_response(trace_id_file, access_token):
    """
    Retrieves the raw response from the classifier for the given trace IDs and file names.
    
    Args:
        trace_id_file (dict): A dictionary mapping trace IDs to file names.
        access_token (str): The access token used to authenticate with the Purple Fabric API.
    
    Returns:
        dict: A dictionary mapping file names to their corresponding classifier responses.
    """
    asset_headers = {
        "apikey": configs.PURPLE_FABRIC_API_KEY,
        "Accept": "application/json",
        "Authorization": f"Bearer {access_token}",
    }
    all_responses = dict()
    for trace_id, file in trace_id_file.items():
        try:
            if trace_id != "NO_TRACE_ID":
                # get the classifier response
                response = get_result(
                    asset_headers, configs.PURPLE_FABRIC_CLASSIFIER_ID, trace_id
                )
                response = response.get("response").get("output")[0]
                if get_doc_class(response["output"]) == "NO_CLASS":
                    response["output"] = get_parsed_clf_op(
                        response["raw_model_response"]
                    )
                logger.info(f"Classifier response : The file {file} response is {response}")
                all_responses[file] = response
            else:
                all_responses[file] = {
                    "classifier_response": "classifier response failed",
                    "trace_id": trace_id,
                }
        except Exception as e:
            all_responses[file] = {
                "classifier_response": "classifier response failed",
                "trace_id": trace_id,
            }
    return all_responses


def get_extractor_raw_response(trace_id_file, access_token, page_2_class):
    """
    Retrieves the raw response from the extractor for the given trace IDs, file names, and classifier output classes.
    
    Args:
        trace_id_file (dict): A dictionary mapping trace IDs to file names.
        access_token (str): The access token used to authenticate with the Purple Fabric API.
        page_2_class (dict): A dictionary mapping file names to their corresponding classifier output classes.
    
    Returns:
        dict: A dictionary mapping file names to their corresponding extractor responses.
    """
    asset_headers = {
        "apikey": configs.PURPLE_FABRIC_API_KEY,
        "Accept": "application/json",
        "Authorization": f"Bearer {access_token}",
    }
    all_responses = dict()

    for trace_id, file in trace_id_file.items():
        try:
            class_name = page_2_class[file]
            extractor_asset_id, asset_id_type_str = get_extractor_asset_id(class_name)
            if trace_id != "NO_TRACE_ID" or class_name.lower() == "NO_CLASS":
                count = 0
                while count < 5:
                    try:
                        response = get_result(
                            asset_headers, extractor_asset_id, trace_id
                        )
                        break
                    except requests.exceptions.ConnectionError:
                        count += 1
                logger.info(f"Extractor response : The file {file} response is {response}")
                response = response.get("response").get("output")[0]
                response["classifier_output"] = class_name
                response["asset_id_type_str"] = asset_id_type_str
                all_responses[file] = response
            else:
                all_responses[file] = {
                    "classifier_output": class_name,
                    "extractor_response": "extractor response failed",
                    "asset_id_type_str": asset_id_type_str,
                    "trace_id": trace_id,
                }
        except Exception as e:
            all_responses[file] = {
                "classifier_output": class_name,
                "extractor_response": "extractor response failed",
                "asset_id_type_str": asset_id_type_str,
                "trace_id": trace_id,
            }
    return all_responses


def process_classifier_response(classifier_raw_response):
    """
    Processes the raw response from the classifier and returns a list of dictionaries, where each dictionary contains the file name, the raw classifier response, and the processed classifier response.
    
    Args:
        classifier_raw_response (dict): A dictionary mapping file names to their corresponding classifier responses.
    
    Returns:
        list: A list of dictionaries, where each dictionary contains the file name, the raw classifier response, and the processed classifier response.
    """
    classifier_full_response = []
    for file, response in classifier_raw_response.items():
        temp_data_var = dict()
        temp_data_var["file_page_name"] = file
        temp_data_var["classifier_raw_response"] = response
        if "output" in response:
            temp_data_var["classifier_processed_response"] = response.get("output")
        else:
            temp_data_var["classifier_processed_response"] = response
        classifier_full_response.append(temp_data_var)

    return classifier_full_response


def get_address_keys(data):
    """
    Retrieves a list of keys from the provided data dictionary that contain the words "address" or "adress" (case-insensitive).
    
    Args:
        data (dict): The dictionary to search for address-related keys.
    
    Returns:
        list: A list of keys from the data dictionary that contain the words "address" or "adress".
    """
    keys = []
    for key in data.keys():
        if "address" in key.lower() or "adress" in key.lower():
            keys.append(key)
    return keys


def process_extractor_response(extractor_raw_response):
    """
    Processes the raw response from the extractor and returns a list of dictionaries, where each dictionary contains the file name, the raw extractor response, and the processed extractor response.
    
    Args:
        extractor_raw_response (dict): A dictionary mapping file names to their corresponding extractor responses.
    
    Returns:
        list: A list of dictionaries, where each dictionary contains the file name, the raw extractor response, and the processed extractor response.
    """
    extractor_full_response = []
    for file, response in extractor_raw_response.items():
        temp_data_var = dict()
        temp_data_var["file_page_name"] = file
        temp_data_var["extractor_raw_response"] = response
        if "output" in response:
            temp_data_var["extractor_processed_response"] = response.get("output")
            clean_string = (
                temp_data_var["extractor_raw_response"]["raw_model_response"]
                .replace("```json\n", "")
                .replace("\n```", "")
                .replace("\n", "")
            ).lower()
            json_clean_string = json.loads(clean_string)
            if (
                "commodity_details"
                in temp_data_var["extractor_raw_response"]["raw_model_response"]
            ):
                if response["classifier_output"] == "invoice":
                    temp_data_var["extractor_processed_response"][
                        "invoice_commodity_details"
                    ] = json_clean_string["invoice_commodity_details"]
                elif response["classifier_output"] == "purchase_order":
                    temp_data_var["extractor_processed_response"][
                        "po_commodity_details"
                    ] = json_clean_string["po_commodity_details"]
            if "address" in clean_string or "adress" in clean_string:
                for ent_name in get_address_keys(json_clean_string):
                    temp_data_var["extractor_processed_response"][ent_name] = ", ".join(
                        json_clean_string[ent_name]
                    )
        else:
            temp_data_var["extractor_processed_response"] = response
        extractor_full_response.append(temp_data_var)

    return extractor_full_response


def get_doc_class(item_dict):
    """
    Determines the document class based on the values in the provided `item_dict`.
    
    If any of the values in `item_dict` are `True`, the function returns the corresponding key converted to lowercase and with spaces replaced by underscores. If none of the values are `True`, the function returns `"NO_CLASS"`.
    
    Args:
        item_dict (dict): A dictionary mapping document class names to boolean values.
    
    Returns:
        str: The determined document class, or `"NO_CLASS"` if no class is found.
    """
    for key, value in item_dict.items():
        if value == True:
            return "_".join(key.lower().strip().split(" "))
    return "NO_CLASS"


def get_extractor_asset_id(class_name):
    """
    Determines the extractor asset ID and asset ID type string based on the provided document class name.
    
    Args:
        class_name (str): The name of the document class.
    
    Returns:
        tuple: A tuple containing the extractor asset ID and the asset ID type string.
    """
    try:
        if class_name == "purchase_order":
            extractor_asset_id = configs.PURPLE_FABRIC_EXTRACTOR_PO_ASSET_ID
            asset_id_type_str = "PURPLE_FABRIC_EXTRACTOR_PO_ASSET_ID"
        elif class_name == "bill_of_lading":
            extractor_asset_id = configs.PURPLE_FABRIC_EXTRACTOR_BOL_ASSET_ID
            asset_id_type_str = "PURPLE_FABRIC_EXTRACTOR_BOL_ASSET_ID"
        elif class_name == "airway_bill":
            extractor_asset_id = configs.PURPLE_FABRIC_EXTRACTOR_AWB_ASSET_ID
            asset_id_type_str = "PURPLE_FABRIC_EXTRACTOR_AWB_ASSET_ID"
        elif class_name == "bill_of_exchange":
            extractor_asset_id = configs.PURPLE_FABRIC_EXTRACTOR_BOE_ASSET_ID
            asset_id_type_str = "PURPLE_FABRIC_EXTRACTOR_BOE_ASSET_ID"
        elif class_name == "invoice":
            extractor_asset_id = configs.PURPLE_FABRIC_EXTRACTOR_INV_ASSET_ID
            asset_id_type_str = "PURPLE_FABRIC_EXTRACTOR_INV_ASSET_ID"
        else:
            extractor_asset_id = None
            asset_id_type_str = "No Extractor Asset"
    except Exception as e:
        extractor_asset_id = None
        asset_id_type_str = "No Extractor Asset"

    return extractor_asset_id, asset_id_type_str


def get_parsed_clf_op(response):
    """
    x_1 = '''```json\n{\n  "properties": {\n    "Invoice": true,\n    "Bill of Exchange": true,\n    "Airway Bill": false,\n    "Purchase Order": false,\n    "Bill of Lading": false\n  }\n}\n```'''
    x_2 = '''```json\n{\n  "Invoice": [true],\n  "Bill of Exchange": [true],\n  "Airway Bill": [],\n  "Purchase Order": [],\n  "Bill of Lading": []\n}\n```'''
    """
    parsed_output = response.replace("```json", "")
    parsed_output = parsed_output.replace("```", "")
    parsed_output = json.loads(parsed_output)
    if len(parsed_output) == 1:
        parsed_output = parsed_output["properties"]
    for key, value in parsed_output.items():
        if isinstance(value, list):
            if len(value) > 0:
                parsed_output[key] = True
            else:
                parsed_output[key] = False
        elif isinstance(value, str):
            if value == True:
                parsed_output[key] = True
            else:
                parsed_output[key] = False
    return parsed_output
