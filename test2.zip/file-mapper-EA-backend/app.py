#This code is a workaround to use the `pysqlite3` library instead of the default `sqlite3` library in Python. 
#This is likely done to address a specific issue or compatibility problem with the `sqlite3` library. 
#The code imports the `pysqlite3` library, then swaps it into the `sys.modules` dictionary to replace the default `sqlite3` module. This ensures that any code that tries to import `sqlite3` will actually get the `pysqlite3` library instead.
__import__('pysqlite3')
import sys
sys.modules['sqlite3'] = sys.modules.pop('pysqlite3')


import os
import logging
from datetime import datetime
from functools import wraps
from tempfile import mkdtemp
from urllib.parse import urlencode
import secrets
import subprocess
import requests

from flask import Flask, jsonify, render_template, request
from flask import url_for, redirect, session
from flask_session import Session
from flask_oauthlib.client import OAuth
from flask_cors import CORS
from dotenv import load_dotenv

from configs import *
from prompts import *
from prompts_templates import *
from rag import *
from utils.utility_functions import *
from logger import logger
from pf_asset_calling.invoke_pf_asset import invoke_asset
from utils.utility_functions import run_subprocess
from db_script.db_operations import *
from pf_asset_calling.invoke_pf_asset_staging import invoke_asset as invoke_asset_staging
from pf_asset_calling.invoke_pf_automation_asset_with_image_staging import invoke_asset as invoke_asset_with_image

from PIL import Image
import base64
import io

from pf_asset_calling.invoke_azure_gpt4o import call_azure_gpt4o
# from transformers import TrOCRProcessor, VisionEncoderDecoderModel
# import torch


# import numpy as np
# import easyocr
# import cv2

# Load env file to get variables
load_dotenv()

"""
Stores a dictionary of active sessions, where the keys are session IDs and the values are the session data.
The `SECRET` variable is a randomly generated 32-character hexadecimal string used as a secret key for session management.
"""
active_sessions = {}
SECRET = secrets.token_hex(16)



app = Flask(__name__)
CORS(app, origins="*")
app.json.sort_keys=False

### Load all env variables
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY')
app.secret_key = os.getenv('SECRET_KEY')
app.config['SESSION_TYPE'] = os.getenv('SESSION_TYPE') # Use filesystem session
app.config['AUTH0_CLIENT_ID'] = os.getenv('AUTH0_CLIENT_ID')
app.config['SESSION_USE_SIGNER'] = True
app.config['SESSION_KEY_PREFIX'] = os.getenv('SESSION_KEY_PREFIX')
# create a temp directory to store session data
app.config['SESSION_FILE_DIR'] = mkdtemp()
app.config['SESSION_COOKIE_SAMESITE'] = os.getenv('SESSION_COOKIE_SAMESITE')
### Set an explicit session cookie name for flask to make sure that it doesn't 
	#conflict with Auth0 session cookie name
app.config['SESSION_COOKIE_NAME'] = os.getenv('SESSION_COOKIE_NAME')
app.config['UPLOAD_FOLDER'] = "static/uploads"
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)


Session(app)

def requires_auth(f):
	@wraps(f)
	def decorated(*args, **kwargs):
		# Add this line to logger.info the entire session
		logger.info(f"logger.infoing session inside decorated:{session}")
		# Check if profile exists in session
		if 'profile' not in session:
			# Check what's inside the session
			logger.info(f"Session content:{session}")
			# Redirecting to home if profile not found in session
			return redirect('/')
		return f(*args, **kwargs)
	return decorated

# Auth0 setup
oauth = OAuth(app)
auth0 = oauth.remote_app(
	'auth0',
	consumer_key=os.getenv('AUTH0_CLIENT_ID'),
	consumer_secret=os.getenv('AUTH0_CLIENT_SECRET'),
	request_token_params={
		'scope': 'openid profile email',
	},
	base_url=f'https://{os.getenv("AUTH0_DOMAIN")}/',
	access_token_method='POST',
	access_token_url=f'https://{os.getenv("AUTH0_DOMAIN")}/oauth/token',
	authorize_url=f'https://{os.getenv("AUTH0_DOMAIN")}/authorize',
)

@auth0.tokengetter
def get_auth0_oauth_token():
	return session.get('token')


@app.route('/')
def default():
	return redirect('/login')


# Supporting both GET and POST methods
@app.route('/login', methods=['POST', 'GET'])
def login():
	"""
	Handle user login via GET and POST methods.

	For GET requests, this endpoint initiates the Auth0 authorization process.
	For POST requests, it logs in the user by saving the session details and
	updates the active sessions list.

	GET method:
		Initiates the Auth0 authorization process by redirecting to the Auth0
		login page with the specified callback URL.

	POST method:
		Receives JSON data containing the userId, saves the session, and updates
		the active sessions list.

	Returns:
		Response: A JSON response with a login message for POST requests.
		Redirect: A redirect response to the Auth0 login page for GET requests.

	GET Redirect Example:
		Redirects to the Auth0 login page with the specified callback URL.
	"""
	if request.method == 'POST':
		try: 
			user_id = request.json.get('userId')

			logger.info(f"Active sessions before duplicate check: \
						{active_sessions}")
			logger.info(f"Incoming user ID: {user_id}")

			# Save the session
			session_id = session.sid
			session['userId'] = user_id
			session.permanent = True
			active_sessions[session_id] = {
				'userId': user_id, 'timestamp': datetime.now()}
			message = 'Logged in successfully.'
		except Exception as e:
			# logger.error("Logging error:", e)
			message = "Some technical issue"
		return jsonify(message=message)

	elif request.method == 'GET':
		callback_url = os.getenv('AUTH0_CALLBACK_URL')
		return auth0.authorize(callback=callback_url)

	

@app.route('/callback')
def callback_handling():
	try:
		code = request.args.get('code')
		
		if not code:
			logging.error("No code parameter in callback. Redirecting to login.")
			# Redirecting to login page as the code is not present
			return redirect(url_for('login'))
		
		response = auth0.authorized_response()
		if response is None:
			logging.error("Invalid response from Auth0. Response: None")
			# Redirecting to login page as the response is None
			return redirect(url_for('login'))
		
		access_token = response.get('access_token')
		if access_token is None:
			error_reason = request.args.get('error_reason', 'Unknown')
			error_description = request.args.get('error_description', 'Unknown')
			logging.error(f"Access denied: reason={error_reason} \
						  error={error_description}")
			# Redirecting to login page as access_token is None
			return redirect(url_for('login'))
		
		# Store the token in the session
		session['token'] = (response['access_token'], '')
		user_info = auth0.get('userinfo')
		
		logger.info(f"Complete user_info object: {user_info}")

		user_id = user_info.data.get('email')
		user_id_for_role = user_info.data.get('sub')  # Fetching Auth0 user_id from user_info

		
		# As of now facing issue in the Auth0 management API. 
		# if 'CopilotUsers' not in roles:  # Checking for 'CopilotUsers' role
		if False:
			session.clear()  # clear the session
			return '''
				You do not have permission to access the application.
				Please <a href="javascript:void(0);" onclick="window.location.href='/logout'">login</a> with valid credentials.
				Please contact the admin for valid credentials.
				''', 403
		
		user_id = user_info.data.get('email')

		logger.info(f"User ID : {user_id}")
		logger.info(f"Session  : {session}")

		
		session['userId'] = user_id
		session['profile'] = user_info.data
		session.modified = True

		session_id = session.sid
		active_sessions[session_id] = {
			'userId': user_id, 'timestamp': datetime.now()}

		return redirect('/mapper')
	
	except Exception as e:
		logging.error(f"An unexpected error occurred: {str(e)}. ")
		# Redirecting to login page as an unexpected error occurred
		return redirect(url_for('login'))


@app.route('/clear-session', methods=['POST'])
def clear_session():
	session.clear()
	return '', 204  # Return 204 No Content response

@app.route('/logout')
def logout():
	"""
	Log the user out by clearing the session and redirecting to Auth0 logout.

	This endpoint clears the user's session and constructs a logout URL for Auth0 using
	the `AUTH0_DOMAIN` environment variable and `AUTH0_CLIENT_ID` configuration. The user is then
	redirected to the Auth0 logout page.

	Returns:
		Response: A redirect response to the Auth0 logout URL.

	Example:
		GET /logout

		The response will redirect the user to the Auth0 logout page.
	"""
	session.clear()  # clear the session
	params = {'returnTo': url_for(
		'login', _external=True), 'client_id': app.config['AUTH0_CLIENT_ID']}
	
	logger.info("PARAMS")
	logger.info(params)
	# Get AUTH0_DOMAIN from environment variables
	auth0_domain = os.getenv('AUTH0_DOMAIN')

	# Construct logout URL
	logout_url = f'https://{auth0_domain}/v2/logout?' + urlencode(params)
	return redirect(logout_url)


@app.route('/classification', methods=['POST'])
def document_classification():
	classify_data = request.get_json()
	logger.info(f"Received classify_data:{classify_data}")
	# Return HTML page and pass the classify_data to the template
	return render_template('classification.html', classify_data=classify_data)

@app.route('/extraction', methods=['POST'])
def document_extraction():
	classify_data = request.get_json()
	logger.info(f"Received classify_data:{classify_data}")
	file_id = classify_data["item"]["file_id"]
	file_type = classify_data["item"]["file_type"]
	success,domain_name = get_document_domain_name(file_id)
	# Return HTML page and pass the classify_data to the template
	if domain_name == "Payments":
		if file_type == "channel onboarding":
			return render_template('html_json_Extraction.html', classify_data=classify_data)
		else:
			return render_template('iso_extractor.html', classify_data=classify_data)
	else:
		return render_template('extractor.html', classify_data=classify_data)

	# return render_template('extractor_render.html', classify_data=classify_data)

@app.route('/validation', methods=['POST'])
def document_validation():
	data = request.get_json()
	logger.info(f"Received data:{data}")
	
	file_id = data["item"]["file_id"]
	file_type = data["item"]["file_type"]
	success,domain_name = get_document_domain_name(file_id)

	if not success:
		return jsonify({"success": False, "message": "Failed to get domain name"})
	
	# Return HTML page and pass the classify_data to the template
	if domain_name == "Payments":
		if file_type == "channel onboarding":
			return render_template('html_json_validation.html', data=data)
		else:
			return render_template('iso_validator.html', data=data)
	else:
		return render_template('validator.html', data=data)
	
	# Return HTML page and pass the data to the template
	# return render_template('hdfc_render_validator.html', data=data)
	# return render_template('iso_validator.html', data=data)

@app.route('/json_payload')
def json_payload_page():
    return render_template('json_payload.html')

@app.route('/upload_file')
def upload_page():
	"""
	Render the upload file page with a list of corporates.

	This endpoint fetches the list of corporates from the database and renders
	the upload file page. If there is an error during database access, an error message
	is logged, and a message indicating the failure is returned.

	Returns:
		Response: An HTML response rendering the upload file page with a list of corporates.

	Example:
		GET /upload_file

		The response will render 'upload.html' with a context containing a list of corporates.
	"""
	try:
		conn = get_db_connection()
		cur = conn.cursor()
		cur.execute("SELECT corp_id, corp_name FROM corporates")
		corporates = cur.fetchall()
		message = "Loaded"
	except psycopg2.Error as e:
		logger.error(f"Error while loading upload file page:{e} ")
		conn.rollback()
		message = "Not able to load the page."
	except Exception as e:
		logger.error(f"Error while loading upload file page: {e}")
		message = "Not able to load the page."
		if cur:
			cur.close()
		if conn:
			conn.close()
	finally:
		if conn:
			release_db_connection(conn)
	return render_template('upload.html', 
						   corporates=corporates)



@app.route('/get_corporates', methods=['GET'])
def get_corporates():
	"""
	Retrieve a list of corporate entities based on a search term.

	This endpoint accepts a GET request with an optional search term to filter
	corporate entities by their names. It queries the database and returns a JSON
	response with the matching corporate entities.

	Returns:
		Response: A JSON response containing a list of corporate entities or an error message.

	Examples:
		curl -X GET "http://localhost:5000/get_corporates?search=term"

	Request Args:
		search (str, optional): The search term to filter corporate names. Defaults to an empty string.

	Response:
		corp_id (int): The ID of the corporate entity.
		corp_name (str): The name of the corporate entity.
		error (str, optional): An error message if an exception occurs.
	"""
	try:
		search_term = request.args.get('search', '')
		conn = get_db_connection()
		cur = conn.cursor()
		query = "SELECT corp_id, corp_name FROM corporates WHERE corp_name ILIKE %s"
		cur.execute(query, ('%' + search_term + '%',))
		corporates = [{'corp_id': row[0], 'corp_name': row[1]} 
					  for row in cur.fetchall()]
		cur.close()
		conn.close()
		return jsonify(corporates)
	except Exception as e:
		# Handle the error and return an appropriate response
		error_message = f"Error occurred: {str(e)}"
		return jsonify({'error': error_message})
	finally:
		if conn:
			release_db_connection(conn)



@app.route('/upload_file', methods=['POST'])
def upload_file():
	"""
	Handle the uploading of a file and process it.

	This endpoint accepts a file upload via a POST request, saves it to a specified
	location, and performs additional processing tasks. If a new corporate name is
	provided, it handles the corporate addition. It also inserts data into the
	`document_files` and `corp_file_mapping` tables and starts a subprocess task
	asynchronously.

	Request Args:
		file : File uploaded by user
		newCorpName : New corporate name
		corporateSelect : Corporate id

	Raises:
		ValueError: If the 'fileUpload' key is not present in the request files or if no file is selected.

	Examples:
		curl -X POST -F "fileUpload=@path_to_file" -F "corporateSelect=corp_id" http://localhost:5000/upload_file

	Request Forms:
		fileUpload (file): The file to be uploaded.
		newCorpName (str, optional): The name of a new corporate entity to be added.
		corporateSelect (str, optional): The ID of an existing corporate entity.

	Response Example:
		message (str): A message indicating the result of the operation.
	"""
	# Check if the 'fileUpload' key is in the request files
	if 'fileUpload' not in request.files:
		return jsonify({'message': 'No file part'}), 400

	file = request.files['fileUpload']
	logger.info(f"Input File: {file.filename}")
	# Check if the file has a filename and is not empty
	if file.filename == '' or not file:
		return jsonify({'message': 'No selected file'}), 400

	# Generate a new filename with a timestamp
	original_file_name, file_extension = os.path.splitext(file.filename)
	original_file_name = original_file_name.replace(' ', '_')
	timestamp = datetime.now().strftime("-%Y%m%d%H%M%S")
	new_file_name = original_file_name + timestamp + file_extension
	filepath = os.path.join(app.config['UPLOAD_FOLDER'], new_file_name)
	# Save the file to the specified filepath
	file.save(filepath)
	azure_file_path = bucket_url + new_file_name

	# Handle new corporate addition if 'newCorpName' is provided
	if request.form.get('newCorpName'):
		flag, corp_id = handle_corporate_addition(request.form['newCorpName'])
		if not flag:
			return jsonify({'message': f'Selected corp not found in records. Please select other corp'}), 200
	else:
		corp_id = request.form.get('corporateSelect')

	# Insert data into document_files table
	flag, file_id = insert_document_file(original_file_name, azure_file_path, filepath)
	if not flag:
		return jsonify({'message': f'File {original_file_name} failed to upload. Please try again after some time'}), 200

	# Insert data into corp_file_mapping table
	flag, mapping_id = insert_corp_file_mapping(corp_id, file_id)
	if not flag:
		return jsonify({'message': f'File {original_file_name} failed to upload. Please try again after some time'}), 200

	# Asynchronously run the subprocess task
	flag, msg = run_subprocess(filepath, file_id, corp_id, mapping_id, new_file_name)

	logger.info(filepath)
	logger.info({"status": "processing"})
	if flag:
		logger.info({"status": "Processing started", "message": msg})
		return jsonify({'message': f'File {original_file_name} successfully \
					uploaded and processing started.'}), 200
	else: 
		logger.info({"status": "error", "message": msg})
		return jsonify({'message': f'File {original_file_name} failed to \
					upload. Please try after some time.'}), 200



@app.route('/mapper')
@requires_auth
def index():
	"""
	Render the index page with user profile information.

	This endpoint renders the index page and displays the logged-in user's profile
	information, including their name, picture, and email. Authentication is required
	to access this endpoint.

	Returns:
		Response: An HTML response rendering the index page with user profile information.

	Examples:
		Access this endpoint in a web browser after logging in:
		http://localhost:5000/mapper

	HTML Template:
		Renders the 'index.html' template with the following context variables:
		- user_name (str): The name of the logged-in user.
		- user_picture (str): The URL of the logged-in user's profile picture.
		- email (str): The email of the logged-in user.

	Raises:
		KeyError: If the session does not contain the necessary profile information.
	"""
	user_name = session['profile']['name']
	user_picture = session['profile']['picture']
	email = session['profile']['email']
	# logger.info("user_name :", user_name)
	# logger.info("user_picture :", user_picture)
	
	return render_template('index.html',
						   user_name=user_name, 
						   user_picture=user_picture,
						   email=email)


@app.route('/fetch_corp_file_mapping', methods=['GET'])
def fetch_corp_file_mapping_data():
	"""
	Fetch the corporate file mapping data and return it as a JSON response.

	This endpoint retrieves the processed corporate file mapping data from the database
	and returns it as a JSON response. The data includes information such as corporate
	file IDs, corporate IDs, file IDs, processing status, view status, document format,
	document summary, document actions, corporate names, file names, and modified file names.

	Response Example:
		[
			{
				"corp_file_id": int,
				"corp_id": int,
				"file_id": int,
				"isProcessed": bool,
				"isViewedFile": bool,
				"document_class": str,
				"document_summary": str,
				"documentActions": str,
				"corp_name": str,
				"file_name": str,
				"cloud_file_path": str
			}
		]
	"""
	data = fetch_corp_file_mapping_from_db()
	return jsonify(data)


@app.route('/submit_selection', methods=['POST'])
def submit_selection():
	"""
	Handle the selection submission and return the corresponding data as a JSON response.

	This endpoint retrieves data based on the selected ID from the form, processes it,
	and returns it as a JSON response. It includes additional logic to generate specific
	buttons based on the document format and updates the viewed status of the file.

	Request params: 
		selectedId : selected Id from options

	Response Example:
		{
			"status": "success",
			"message": "Data retrieved successfully",
			"data": {
				"corp_file_id": int,
				"corp_id": int,
				"file_id": int,
				"isProcessed": bool,
				"isViewedFile": bool,
				"document_class": str,
				"document_summary": str,
				"sec_table_id": int,
				"documentActions": list,
				"corp_name": str,
				"file_name": str,
				"cloud_file_path": str
			}
		}
		or
		{
			"status": "error",
			"message": "No data found for the provided ID"
		}
		or
		{
			"status": "error",
			"message": "No ID received"
		}
	"""

	logger.info("Selection API Fetched")
	selected_id = request.form.get('selectedId')
	if selected_id:
		data = fetch_selected_data_from_db(selected_id)
		if data:
			buttons = []
			if data[5] == "Corporate Payments Onboarding":
				buttons = [{
						'label': 'Generate Mappings', 
						'action': 'Please generate mappings for selected file.'}]
					# },
					# {
					#     'label': 'Reverse file format', 
					#     'action': 'Please generate iso mappings for Reverse file format'
					# }]
			elif data[5] == "Board Resolution":
				buttons = [{
						'label': 'Approval Matrix', 
						'action': 'Please generate approval matrix'
					},
					{
						'label': 'Authorised Signatory', 
						'action': 'Please generate authorised signatory'
					}]
			
			# Construct your object with the necessary information
			mapping_object = {
				"corp_file_id": data[0],
				"corp_id": data[1],
				"file_id": data[2],
				"isProcessed": data[3],
				"isViewedFile": data[4],
				"document_class": data[5],
				"document_summary": data[6],
				"sec_table_id": data[7],
				"documentActions": buttons,
				"corp_name": data[8],
				"file_name": data[9],
				"cloud_file_path": data[10]
			}
			update_is_viewed_file(selected_id)
			return jsonify({"status": "success", 
							"message": "Data retrieved successfully", 
							"data": mapping_object})
		else:
			return jsonify({"status": "error", 
							"message": "No data found for the provided ID"})
	else:
		return jsonify({"status": "error", "message": "No ID received"})



@app.route('/getNLresponse',  methods=['POST'])
def getResponse(): 
	"""
	Handle the Natural Language response generation based on user input.

	This endpoint processes a user's question and selected file ID to generate a natural language response.
	It uses various functions to fetch chat history, document text, and templates, and invokes an external 
	language model to classify and respond to the question. The response can include text, table data, or buttons 
	based on the classification of the question.

	Response:
		{
			"text_response": str,
			"tablejson": list,
			"buttons": list,
			"sec_table_id": int (optional)
		}
	"""

	data = {}
	question = request.form['message']
	file_id = request.form['selectedId'] #corp_file_id
	data['text_response'] = "Looks like no mappings were generated for this file."
	data['tablejson'] = []
	data['buttons'] = []

	if file_id == "undefined":
		data['text_response'] = "Please select any file first."
		return jsonify(data)
	if question  == "undefined":
		data['text_response'] = "Please add some question."
		return jsonify(data)

	try:
		chat_history = get_chat_history_from_session(question, 
													 session, 
													 global_initial_message)
		chat_history = parse_chat_history(chat_history)
		
		document_text = get_text(int(file_id), int(file_id), question)
		input_prompt = gettemplate0(question, chat_history, document_text)

		# Calling PF assets to get LLM response
		llm1Response = invoke_asset(Asset_id_Chat2doc, input_prompt)[0]
		logger.info(f"First LLM call response: {llm1Response}")
		
		tagstoextract = ['classification', 'normalchat', 'chatwithpdf']
		extractedtags = extractValuesFromTag(tagstoextract, llm1Response)
		logger.info(f"[INFO] Extracted Tags from LLM response: {extractedtags}")

		if(extractedtags['classification'] == 'normalchat'):
			normal_chat = extractedtags['normalchat']
			if file_id == "undefined":
				default_msg = """<p>Please select the file by clicking on the \
					<i class="fa fa-plus" aria-hidden="true"></i> icon below</p>"""
				# data['text_response'] = "Please upload the file you want me to analyze."
				data['text_response'] = default_msg
			else:
				data['text_response'] = normal_chat

		if(extractedtags['classification'] == 'showInGrid'):
			#IF condition for no file select
			# data['text_response'] = "JSON Mapping generated successfully !!!"
			JSONsection = extractValuesFromTag(["sectioncode"], llm1Response)
			logger.info(f"JSON Section Code: {JSONsection}")
			
			finalJSON, sec_table_id, modified_mappings = get_json_mapping(
												file_id, 
												JSONsection['sectioncode'])
			if modified_mappings:
				data['tablejson'] = modified_mappings
			else:
				data['tablejson'] = finalJSON
			data['sec_table_id'] = sec_table_id

			data['text_response'] = get_response_text_sectionwise(JSONsection['sectioncode'])

		elif(extractedtags['classification'] == 'chatpdf'):
			data['text_response'] = extractedtags['chatwithpdf']

		elif(extractedtags['classification'] == 'isomap'):
			section = extractedtags['section']
			llm2Response = ChatWithPdf(gettemplate1(question, section), file_id)
			tagstoextract = ['json']
			extractedtags = extractValuesFromTag(tagstoextract, llm2Response)
			data['text_response'] = 'The JSON response is generated Successfully.'
			raw = eval(extractedtags['json'])
			data['tablejson'] = raw
	except Exception as e:
		logger.error(f"Error in getNL response api: {e}")
		return jsonify(data)

	session['global_messages'].append(
		{"role": "user", "content": question}
	)
	session['global_messages'].append(
		{"role": "assistant", "content": data['text_response']}
	)
	return jsonify(data)


@app.route('/save_mappings_json', methods=['POST'])
def save_mappings_json():
	"""
	Handle the saving of JSON mappings into the database.

	This endpoint accepts JSON data and a section table ID via a POST request,
	and updates the corresponding entry in the database.

	Request Params: 
		jsonData : Json data 
		sec_table_id : id of section table

	Returns:
		Response: A JSON response containing the status and message of the operation.

	Examples:
		curl -X POST -F "jsonData=your_json_data" -F "sec_table_id=1" http://localhost:5000/save_mappings_json

	Response Example:
		{
			"status": "Done",
			"message": str
		}
	"""
	logger.info("Inserting mapping json into database")
	mappings_json = request.form.get('jsonData')
	sec_table_id = request.form.get('sec_table_id')
	if mappings_json:
		message = update_mappings_in_db(mappings_json, sec_table_id)
	else:
		message = "No mappings received."

	return jsonify({"status": "Done", "message": message})


@app.route('/update_classification_approval_status', methods=['POST'])
def update_classification_approval_status():
	"""
	Update the approval status of a document in the database.

	This endpoint accepts a JSON payload containing the file ID, document format,
	and an approval flag. It updates the 'classification_approved' status of the
	corresponding entry in the 'corp_file_mapping' table to the update approval status.

	URL: http://localhost:5000/update_classification_approval_status

	Request JSON Payload:
	{
		"file_id": int,
		"document_class": str, # this can serve the purpose if format is changed by user.
		"is_approved": bool
	}

	Responses:
	- 200 OK: If the request is processed successfully or if there are missing fields.
		- Success: {"Status": "Done", "message": "Update successful"}
		- Failure: {"Status": "Failed", "message": "Error message"}
		- Missing Fields: {"Status": "Failed", "message": "Missing required fields"}

	Returns:
		Response object with a status code and a JSON message indicating the result of the operation.
	"""
	data = request.json
	file_id = data.get('file_id')
	document_format = data.get('document_class')
	is_approved = data.get('is_approved')

	if file_id is None or document_format is None or is_approved is None or not is_approved :
		return jsonify({"Status": "Failed", "message": "Missing required fields"}), 200

	success, message = update_extraction_approved(file_id, "classification_approved", document_format)
	
	
	success,domain_name = get_document_domain_name(file_id)
	logger.info(message)

	if domain_name=="TF":
		# Asynchronously run the subprocess task
		# command = f"python domain_orchestrators/tf_subprocesses/bg_form_extractor_subprocess.py \
		#     {file_id}"
		# try:
		#     if message!="done":
		#         process = subprocess.Popen(command, shell=True)

		def convert_to_title_case(snake_str):
			# Split the string by underscores
			components = snake_str.split('_')
			# Capitalize the first letter of each component and join them with spaces
			title_case_str = ' '.join(x.capitalize() for x in components)
			return title_case_str
		

		def extract_pdf_name(file_path):
			"""
			Extract the name of the PDF file from the given file path.

			Parameters:
			file_path (str): The full path to the PDF file.

			Returns:
			str: The name of the PDF file without the extension.
			"""
			# Get the base name of the file (with extension)
			pdf_name = os.path.basename(file_path)
			
			return pdf_name
		
		file_type_with_path = get_file_page_wise_classification_with_path(file_id)
		asset_id = Asset_for_bg_fields_extractor
		for file_path in file_type_with_path[0]:
			classification = file_path["classification"]
			path = file_path["path"]
			logger.info("New File ID created")
			if classification=="party_tnc" or classification=="no_class":
				continue
			azure_file_name = extract_pdf_name(path)
			flag, msg = upload_file_to_blob(path,azure_file_name)
			if not flag:
				logger.debug(f"An error occurred while storing file to file storage: {msg}")
				return False, "File is not uploaded properly. Please try after some time."
			

			azure_file_path = bucket_url + azure_file_name

			new_file_id = clone_file_and_create_mapping(file_id,path,convert_to_title_case(classification),azure_file_path)
			# Determine the asset ID based on the classification
			if classification == "purchase_order":
				asset_id = Asset_for_purchase_order
			elif classification == "invoice":
				asset_id = Asset_for_invoice
			elif classification == "airway_bills":
				asset_id = Asset_for_airway_bill
			elif classification == "bill_of_lading":
				asset_id = Asset_for_bill_of_lading
			elif classification == "bill_of_exchange":
				asset_id = Asset_for_bill_of_exchange
			elif classification == "bank_guarantee":
				asset_id = Asset_for_bg_fields_extractor
			# extract_mixed_doc_fields(file_id,classification,asset_id)

			command = f"python domain_orchestrators/tf_subprocesses/mixed_classes_extractor_subprocess.py \
			{new_file_id} {classification} {asset_id} {file_id}"
			process = subprocess.Popen(command, shell=True)

		set_file_disabled(file_id)

		return jsonify({"Status": "Done", 
							"message": "Extractor triggered"}), 200  
		# except Exception as e:
		#     logger.debug(f"An error occurred while starting the subprocess: {e}")
		#     return jsonify({"Status": "Failed", 
		#                     "message": "Extractor not triggered"}), 200
	elif domain_name=="Payments":
		command = f"python domain_orchestrators/payments_subprocess/payments_extractor_subprocess.py \
			{file_id} {file_id}"
		_ = subprocess.Popen(command, shell=True)
		# generate_iso_mappings(file_id,file_id)
		return jsonify({"Status": "Done", 
							"message": "Extractor triggered"}), 200  
	else:

		logger.info(f"Failed to update classification status : {message}")
		return jsonify({"Status": "Failed", "message": "Failed to update status."}), 200


@app.route('/update_extractor_approval_status', methods=['POST'])
def update_extractor_approval_status():
	"""
	Update the approval status of a document in the database.

	This endpoint accepts a JSON payload containing the file ID, document format,
	and an approval flag. It updates the 'classification_approved' status of the
	corresponding entry in the 'corp_file_mapping' table to the update approval status.

	URL: http://localhost:5000/update_extractor_approval_status
	
	Request JSON Payload:
	{
		"file_id": int,
		"extracted_data": JSON updated, # this can serve the purpose if format is changed by user.
		"is_approved": bool
	}

	Responses:
	- 200 OK: If the request is processed successfully or if there are missing fields.
		- Success: {"Status": "Done", "message": "Update successful"}
		- Failure: {"Status": "Failed", "message": "Error message"}
		- Missing Fields: {"Status": "Failed", "message": "Missing required fields"}

	Returns:
		Response object with a status code and a JSON message indicating the result of the operation.
	"""
	data = request.json
	file_id = data.get('file_id')
	# extracted_data = data.get('extracted_data')
	# is_approved = data.get('is_approved')

	if file_id is None:
		return jsonify({"Status": "Failed", "message": "Missing required fields"}), 200

	success, message = update_extraction_approved_using_file_id(file_id)
	if not success:
		logger.info(f"Failed to update Extraction approval status : {message}")
		
	success,domain_name = get_document_domain_name(file_id)

	# Get document file type
	document_type, _ = get_document_class(file_id)
	command = None
	
	if success:
		# Asynchronously run the subprocess task
		if domain_name=="Payments":
			if not document_type:
				pass
			elif document_type == "Board Resolution":
				# Change validation status to Done
				db_update_result, msg = update_files_status_field(file_id, 
															"validation_status", 
															"done")
				if not db_update_result:
					logger.error(f"Uploaded file with file_id {file_id} failed to\
								update Validation Status because of error: {msg}")
					
				# Change validation status to Done
				success, message = update_extraction_approved(file_id, "validation_approved")
				if not success:
					logger.error(f"Uploaded file with file_id {file_id} failed to\
								update Validation Approved Status because of error: {msg}")
					return jsonify({"Status": "Failed", 
								"message": "Failed to start validation"}), 200
				else:
					return jsonify({"Status": "Done", 
								"message": "Extractor triggered"}), 200 
	
			else:
				command = f"python domain_orchestrators/payments_subprocess/payments_validator_subprocess.py \
					{file_id}"
				
		elif domain_name=="TF":
			command = f"python domain_orchestrators/tf_subprocesses/bg_form_validator_subprocess.py \
				{file_id}"
		
		if command:
			try:
				_ = subprocess.Popen(command, shell=True)
				return jsonify({"Status": "Done", 
								"message": "Extractor triggered"}), 200  
			except Exception as e:
				logger.debug(f"An error occurred while starting the subprocess: {e}")
				return jsonify({"Status": "Failed", 
								"message": "Extractor not triggered"}), 200
	else:
		logger.info(f"Failed to update extraction status : {message}")
		return jsonify({"Status": "Failed", "message": "Failed to update status."}), 200


@app.route('/update_validation_approval_status', methods=['POST'])
def update_validation_approval_status():

	"""
	Update the approval status of a document in the database.

	This endpoint accepts a JSON payload containing the file ID, document format,
	and an approval flag. It updates the 'validation_approved' status of the
	corresponding entry in the 'corp_file_mapping' table to the update approval status
	and also add the updated validation_json_data.

	Request JSON Payload:
	{
		"file_id": int,
		"validation_json_data": updated validation data JSON, # this can serve the purpose if format is changed by user.
		"is_approved": bool
	}

	Responses:
	- 200 OK: If the request is processed successfully or if there are missing fields.
		- Success: {"Status": "Done", "message": "Update successful"}
		- Failure: {"Status": "Failed", "message": "Error message"}
		- Missing Fields: {"Status": "Failed", "message": "Missing required fields"}

	Returns:
		Response object with a status code and a JSON message indicating the result of the operation.
	"""
	data = request.json
	file_id = data.get('file_id')
	validation_json_data = data.get('validation_json_data')
	is_approved = data.get('is_approved')

	if file_id is None or validation_json_data is None or is_approved is None:
		return jsonify({"Status": "Failed", "message": "Missing required fields"}), 200

	success, message = update_extraction_approved(file_id = file_id, 
												  field_name = "validation_approved",
												  validation_json_data = validation_json_data)
	if success:
		return jsonify({"Status": "Done", 
							"message": "Extractor triggered"}), 200  
	else:
		logger.error(f"Failed to update Validation status : {message}")
		return jsonify({"Status": "Failed", "message": "Failed to approve."}), 200



@app.route('/files_data', methods=['GET'])
def files_data_endpoint():
	"""
	GET endpoint to retrieve files data for dashboard visualisation.
	URL: http://localhost:5000/files_data
	Request Type: GET

	Returns:
		JSON response containing the files data or an error message.
		e.g.:
		{
			"Status": "Success",
			"Data": [
				{
					"file_id": 7,
					"filename": "Sample_4_DBZ",
					"corporate": "Reliance",
					"classification_status": "Done",
					"classification_is_approved": true,
					"extraction_status": "Done",
					"extraction_is_approved": true,
					"classification_rejected": true,
					"extraction_rejected": true,
					"imported_date": "Wed, 24 Jul 2024 07:56:45 GMT",
					"document_format": "Bank Guarantee Form"
				},
				.../
			]
		}
	"""
	files_data, message = get_files_data()
	# Manipulate the status of file for ui
	for item in files_data:
		item["classification_status"] = manipulate_file_status(item["classification_status"])
		item["extraction_status"] = manipulate_file_status(item["extraction_status"])
		item["current_status"] = get_current_file_status(item["classification_status"],
							item["classification_is_approved"],
							item["classification_rejected"],
							item["extraction_status"],
							item["extraction_is_approved"],
							item["extraction_rejected"])
	# Sort the data by file_id in descending order
	files_data = sorted(files_data, key=lambda x: x['file_id'], reverse=True)

	if files_data:
		return jsonify({"Status": "Success", "Data": files_data}), 200
	else:
		return jsonify({"Status": "Failed", "Message": message}), 500


@app.route('/document_classification', methods=['POST'])
def document_classification_endpoint():
	"""
	POST endpoint to retrieve type of file with file_path.
	URL: http://localhost:5000/document_classification
	Request type: POST

	Request JSON Payload:
	{
		"file_id": int
	}

	Returns:
		JSON response containing the file details or an error message.
		e.g.:
		{
			"Status": "Success",
			"Data": {
				"document_class": "Bank Guarantee Form",
				"file_path": "https://onboardingdocstorage.blob.core.windows.net/onboardingdocstorage/Sample_4_DBZ-20240721221402.pdf",
				"file_id": 7
			}
		}
	"""
	data = request.json
	file_id = data.get('file_id')
	logger.info(file_id)

	if file_id is None:
		return jsonify({"Status": "Failed", "Message": "Missing file_id"}), 200
	
	classification_data_thumbnail_pdf, message = get_file_page_details(file_id)
	logger.info(classification_data_thumbnail_pdf)

	if classification_data_thumbnail_pdf:
		return jsonify({"Status": "Success", "Data": classification_data_thumbnail_pdf}), 200
	else:
		return jsonify({"Status": "Failed", "Message": message}), 200

	# document_type_data, message = get_document_type(file_id)
	# if document_type_data:
	#     return jsonify({"Status": "Success", "Data": document_type_data}), 200
	# else:
	#     return jsonify({"Status": "Failed", "Message": message}), 200


@app.route('/documents_fields_validation_status', methods=['GET'])
def documents_fields_validation_status_endpoint():
	"""
	GET endpoint to retrieve file's field validation status.
	URL: http://localhost:5000/documents_fields_validation_status

	Returns:
		JSON response containing the files data or an error message.
		e.g.:
		{
			"Status": "Success",
			"Data": [
				{
					"file_id": 1,
					"filename": "Sample_4_DBZ",
					"corporate": "Intellect Design Arena",
					"validation_status": null,
					"validation_is_approved": false
				},
				{
					"file_id": 2,
					"filename": "Sample2",
					"corporate": "Intellect Design Arena",
					"validation_status": null,
					"validation_is_approved": false
				}
			]
		}
	"""
	documents_fields_validation_status, message = get_files_validation_status_data()
	if documents_fields_validation_status:
		return jsonify({"Status": "Success", "Data": documents_fields_validation_status}), 200
	else:
		return jsonify({"Status": "Failed", "Message": message}), 500



@app.route('/get_extracted_fields_for_bg_form', methods=['POST'])
def get_extracted_fields_endpoint():
	"""
	POST endpoint to retrieve extracted fields.

	URL: http://localhost:5000/get_extracted_fields_for_bg_form

	Request JSON Payload:
	{
		"file_id": int
	}

	Returns:
		JSON response containing the extracted fields or an error message.
		e.g.: {
					"Status": "Success",
					"Data": "{\"Governing_Law_Jurisdiction\": \"\", \"Advising_Bank_Name\": \"\", \"Undertaking_Amount\": \"670,000\", \"Claim_Period\": \"\", \"Document_and_Presentation_Instructions\": \"\", \"Undertaking_Terms_and_Conditions\": \"\", \"Form_of_Undertaking\": \"\", \"Issuer_BIC\": \"\", \"Supplementary_Information_About_Amount\": \"\", \"Date_Of_Issue\": \"Date of Issue\", \"Beneficiary_Name\": \"BIOMARIN PHARMACEUTICAL INC.\", \"Issue_Type\": \"\", \"Beneficiary_Address_2\": \"38 GLOUCESTER RD Van Cliln\", \"Beneficiary_Telephone_No\": \"+1 (415) 455-7558\", \"Delivery_of_Original_Undertaking\": \"\", \"Obligor_Instructing Party_Address\": \"\", \"Issuer_Name\": \"DBS Bank Ltd., Australia Branch\", \"Effective_Date\": \"As per format attached\", \"Applicant_Contact_Person\": \"MASARO UESHIMA\", \"Beneficiary_Contact_Person\": \"ELIZABETH MC KEE ANDERSON\", \"Debit_Account_No\": \"\", \"Beneficiary_Address_1\": \"105 DIGITAL DRIVE\", \"Expiry_Type\": \"Specific Date\", \"Applicant_Fax_No\": \"+61-0801 321267\", \"Applicant_Name\": \"ICC PHARMA AUSTRALIA LIMITED\", \"Application_Type\": \"ISSUE as per FORMAT ENCLOSED initialed on each page by the authorised signatories of the Company with such amendments satisfactory to you (which is deemed to be our authorised format, hereinafter called the \\\"Format\\\")\", \"Applicant_Telephone_No\": \"+61-0800 423267\", \"Advising_Bank_Address\": \"\", \"Claim_Date\": \"01-10-2020\", \"Applicant_Address_1\": \"UNIT 1, 1 SLOUGH BUSINESS PARK\", \"Requested_Local_Undertaking_Terms_and_Conditions\": \"\", \"Expiry_Condition\": \"As per format attached\", \"Available_With\": \"\", \"Applicant_Address_2\": \"\", \"Applicable_Rules\": \"\", \"Demand_Indicator\": \"\", \"Obligor_Instructing Party_Name\": \"\", \"Applicant_Address_3\": \"NEW SOUTH WALES, 2137\", \"Underlying_Transaction_Details\": \"\", \"Confirmation_Instruction\": \"\", \"Beneficiary_Address_3\": \"Hong Kong\", \"Delivery_To_Collection_By\": \"Please courier back to Applicant at Address for attention of Contact Person as indicated above. We are aware of the additional transit time of 3-5 working days.\", \"Application_Sub_Type\": \"\", \"Beneficiary_Fax_No\": \"+1 (415) 532-1457\", \"Advising_Bank_BIC\": \"\", \"Date_of_Expiry\": \"28-08-2020\", \"Charges\": \"\", \"Undertaking_Amount_CCY\": \"USD United States Dollar\"}"
				}
	"""
	data = request.json
	file_id = data.get('file_id')

	if file_id is None:
		return jsonify({"Status": "Failed", "Message": "Missing file_id"}), 400

	extracted_fields, message = get_extracted_fields_for_bg_form(file_id)
	if extracted_fields:
		return jsonify({"Status": "Success", "Data": extracted_fields}), 200
	else:
		return jsonify({"Status": "Failed", "Message": message}), 500




@app.route('/get_validation_of_fields_for_bg_form', methods=['POST'])
def get_validation_of_fields_for_bg_form():
	"""
	POST endpoint to retrieve validation results for BG form fields.

	URL: http://localhost:5000/get_validation_of_fields_for_bg_form

	Request JSON Payload:
	{
		"file_id": int
	}

	Returns:
		JSON response containing the extracted fields or an error message.
		e.g.: {
					"Status": "Success",
					"Data": [{...}]
				}
	"""


	def group_and_rename(json_data):
		grouped_data = {}
		for entry in json_data:
			source_file = entry['source_file']
			if source_file == 'bg_form':
				source_file = 'Bank Guarantee Form Validation'
			elif source_file == 'party_tnc':
				source_file = 'Party Terms and Conditions Validation'
			
			if source_file not in grouped_data:
				grouped_data[source_file] = []
			
			# Numbering the source fields
			entry['source_field'] = f"{len(grouped_data[source_file]) + 1}. {entry['source_field']}"
			grouped_data[source_file].append(entry)
		
		return grouped_data
	data = request.json
	file_id = data.get('file_id')

	if file_id is None:
		return jsonify({"Status": "Failed", "Message": "Missing file_id"}), 200

	validation_result, message = get_validated_fields_for_bg_form(file_id)

	if validation_result:
		grouped_result = group_and_rename(json.loads(validation_result))
		return jsonify({"Status": "Success", "Data": json.dumps(grouped_result)}), 200
	else:
		return jsonify({"Status": "Failed", "Message": message}), 200


@app.route('/update_status_to_rejected', methods=['POST'])
def update_status_to_rejected():
	"""
		POST endpoint to update field status to 'Rejected = True' 
		URL: http://localhost:5000/update_status_to_rejected

		Request JSON Payload:
			{
				"file_id": int
				"field" : classification_rejected or extraction_rejected or validation_rejected
			}
		e.g.: {"file_id":7,"field":"validation_rejected"}

		Returns:
			JSON response indicating the success or failure of the update operation.
			e.g.: {
					"Status": "Success",
					"Message": "Update successful"
				}
	"""
	data = request.json
	file_id = data.get('file_id')
	field_name = data.get('field')

	if file_id is None:
		return jsonify({"Status": "Failed", "Message": "Missing file_id"}), 400

	db_status_update_response, msg = update_files_status_field(file_id, field_name, True)
	if db_status_update_response:
		return jsonify({"Status": "Success", "Message": msg}), 200
	else:
		return jsonify({"Status": "Failed", "Message": msg}), 500

@app.route('/save_draft', methods=['POST'])
def save_draft():
	"""
	API endpoint to update the classification in the file_page_details table.
	Expects a JSON body with 'file_id' and 'pages'.

	Returns:
	Response: JSON response with a success message or error details.
	"""
	data = request.json

	file_id = data.get('file_id')
	pages = data.get('pages')

	if not file_id or not pages:
		return jsonify({'error': 'file_id and pages are required'}), 400

	for page in pages:
		page_number = page.get('page_number')
		classification = page.get('type')

		if not page_number or not classification:
			return jsonify({'error': 'Each page must have a page_number and type'}), 400

		result = update_classification(file_id, page_number, classification)

		if 'error' in result:
			return jsonify(result), 500

	return jsonify({'message': 'All classifications updated successfully'}), 200




@app.route('/files_validation_data', methods=['GET'])
def files_validation_data_endpoint():
	"""
	GET endpoint to retrieve files data for dashboard visualisation.
	URL: http://localhost:5000/files_validation_data
	Request Type: GET

	Returns:
		JSON response containing the files data or an error message.
		e.g.:
		{
			"Status": "Success",
			"Data": [
			   {
					"file_id": 7,
					"file_name": "Sample_4_DBZ",
					"corporate": "Reliance",
					"validation_status": "done",
					"validation_approved": true,
					"validation_rejected": true,
					"imported_date": "Wed, 24 Jul 2024 07:56:45 GMT",
					"document_type": "Bank Guarantee Form"
				},
				.../
			]
		}
	"""

	def determine_current_status(validation_status, validation_approved, validation_rejected):
		"""
		Determine the current status based on validation status, approved, and rejected fields.

		Args:
			validation_status (str): The validation status.
			validation_approved (bool): Whether the validation is approved.
			validation_rejected (bool): Whether the validation is rejected.

		Returns:
			str: The current status.
		"""
		if validation_status != "done":
			return "validation pending"
		if validation_approved:
			return "validation approved"
		if validation_rejected:
			return "validation rejected"
		return "validation done"

	files_data, message = get_files_validation_data()
	# Manipulate the status of file for ui
	for item in files_data:
		item["validation_status"] = manipulate_file_status(item["validation_status"])
		item["validation_approved"] = manipulate_file_status(item["validation_approved"])

		item["current_status"] = determine_current_status(
			item["validation_status"],
			item["validation_approved"],
			item["validation_rejected"]
		)
	# Sort the data by file_id in descending order
	files_data = sorted(files_data, key=lambda x: x['file_id'], reverse=True)
	if files_data:
		return jsonify({"Status": "Success", "Data": files_data}), 200
	else:
		return jsonify({"Status": "Failed", "Message": message}), 500
	


@app.route('/update_validator_status_to_approved', methods=['POST'])
def update_validator_status_to_approved():
	data = request.json
	file_id = data.get('file_id')

	if file_id is None:
		return jsonify({"Status": "Failed", "Message": "Missing file_id"}), 400

	db_status_update_response, msg = update_validator_files_status_approved(file_id, True)
	success, domain_name = get_document_domain_name(file_id)
	# Get document file type
	document_type, _ = get_document_class(file_id)
	if domain_name == "Payments" and document_type == "channel onboarding":
		extracted_fields, message = get_extracted_fields_for_iso_mappings(file_id)
		
		if message:

			# Generate unique customer ID
			unique_customer_id = generate_unique_customer_id()
			
			# Add customer ID to extracted fields as a processing instruction
			extracted_fields_data = json.loads(extracted_fields)
			customer_id_instruction = {
				"uniqueCustomerId": unique_customer_id,
				"instruction": "Please use this unique customer ID when generating results: " + unique_customer_id
			}
			
			# Combine the data and convert back to string
			if isinstance(extracted_fields_data, list):
				extracted_fields_data.append(customer_id_instruction)
			else:
				extracted_fields_data = [extracted_fields_data, customer_id_instruction]
			
			extracted_fields = json.dumps(extracted_fields_data)
			logger.info(f"Newly generated customer and account json: {extracted_fields}")
			# Use the parallel processing utility for faster API calls and DB updates
			from utils.parallel_validator_processing import run_parallel_validator_processing
			success, message = run_parallel_validator_processing(file_id, extracted_fields)
			
			if not success:
				logger.error(f"Parallel processing failed: {message}")
				return jsonify({"Status": "Failed", "Message": "Failed to process APIs"}), 500

	if db_status_update_response:
		return jsonify({"Status": "Success", "Message": msg}), 200
	else:
		return jsonify({"Status": "Failed", "Message": msg}), 500


@app.route('/get_rejected_files', methods=['GET'])
def get_rejected_files():
	"""
	GET endpoint to retrieve files data for dashboard visualisation.
	URL: http://localhost:5000/get_rejected_files
	Request Type: GET

	Returns:
		JSON response containing the files data or an error message.
		e.g.:
		{
			"Status": "Success",
			"Data": [
						{
								"file_id": 58,
								"file_name": "Sample_2_Mizuho",
								"corporate": "Reliance",
								"classification_status": "done",
								"classification_is_approved": false,
								"extraction_status": "done",
								"extraction_is_approved": false,
								"classification_rejected": true,
								"extraction_rejected": false,
								"validation_approved": false,
								"validation_rejected": false,
								"final_approval": false,
								"imported_date": "Tue, 30 Jul 2024 11:00:16 GMT",
								"file_type": "Bank Guarantee Form",
								"file_path": "https://onboardingdocstorage.blob.core.windows.net/onboardingdocstorage/Sample_2_Mizuho-20240730163016.pdf",
								"current_status": "Classification Rejected"
							},
				.../
			]
		}
	"""
	files_data, message = get_files_data_for_rejected_page()
	# Manipulate the status of file for ui
	for item in files_data:
		item["classification_status"] = manipulate_file_status(item["classification_status"])
		item["extraction_status"] = manipulate_file_status(item["extraction_status"])
		item["current_status"] = get_current_file_status_for_validator(item["classification_rejected"],item["validation_rejected"])
	# Sort the data by file_id in descending order
	files_data = sorted(files_data, key=lambda x: x['file_id'], reverse=True)

	if files_data:
		return jsonify({"Status": "Success", "Data": files_data}), 200
	else:
		return jsonify({"Status": "Failed", "Message": message}), 500
	
@app.route('/get_file_current_status_for_flow', methods=['POST'])
def get_file_current_status_for_flow_endpoint():
	"""
	POST endpoint to retrieve type of file with file_path.
	URL: http://localhost:5000/get_file_current_status_for_flow
	Request type: POST

	Request JSON Payload:
	{
		"file_id": int
	}

	Returns:
		JSON response containing the file details or an error message.
		e.g.:
		{
			"Status": "Success",
			"Data": {"currentStep": "classification"}
		}
	"""
	data = request.json
	file_id = data.get('file_id')
	logger.info(file_id)

	if file_id is None:
		return jsonify({"Status": "Failed", "Message": "Missing file_id"}), 200
	file_status, message = get_file_current_status(file_id)
	if file_status:
		return jsonify({"Status": "Success", "Data": file_status}), 200
	else:
		return jsonify({"Status": "Failed", "Message": message}), 500
	
@app.route('/get_extracted_fields_for_iso_mappings', methods=['POST'])
def get_extracted_fields_for_iso_mappings_endpoint():
	"""
	POST endpoint to retrieve extracted fields.

	URL: http://localhost:5000/get_extracted_fields_for_iso_mappings

	Request JSON Payload:
	{
		"file_id": int
	}

	Returns:
		JSON response containing the extracted fields or an error message.
		e.g.: {
					"Status": "Success",
					"Data": "{\"Governing_Law_Jurisdiction\": \"\", \"Advising_Bank_Name\": \"\", \"Undertaking_Amount\": \"670,000\", \"Claim_Period\": \"\", \"Document_and_Presentation_Instructions\": \"\", \"Undertaking_Terms_and_Conditions\": \"\", \"Form_of_Undertaking\": \"\", \"Issuer_BIC\": \"\", \"Supplementary_Information_About_Amount\": \"\", \"Date_Of_Issue\": \"Date of Issue\", \"Beneficiary_Name\": \"BIOMARIN PHARMACEUTICAL INC.\", \"Issue_Type\": \"\", \"Beneficiary_Address_2\": \"38 GLOUCESTER RD Van Cliln\", \"Beneficiary_Telephone_No\": \"+1 (415) 455-7558\", \"Delivery_of_Original_Undertaking\": \"\", \"Obligor_Instructing Party_Address\": \"\", \"Issuer_Name\": \"DBS Bank Ltd., Australia Branch\", \"Effective_Date\": \"As per format attached\", \"Applicant_Contact_Person\": \"MASARO UESHIMA\", \"Beneficiary_Contact_Person\": \"ELIZABETH MC KEE ANDERSON\", \"Debit_Account_No\": \"\", \"Beneficiary_Address_1\": \"105 DIGITAL DRIVE\", \"Expiry_Type\": \"Specific Date\", \"Applicant_Fax_No\": \"+61-0801 321267\", \"Applicant_Name\": \"ICC PHARMA AUSTRALIA LIMITED\", \"Application_Type\": \"ISSUE as per FORMAT ENCLOSED initialed on each page by the authorised signatories of the Company with such amendments satisfactory to you (which is deemed to be our authorised format, hereinafter called the \\\"Format\\\")\", \"Applicant_Telephone_No\": \"+61-0800 423267\", \"Advising_Bank_Address\": \"\", \"Claim_Date\": \"01-10-2020\", \"Applicant_Address_1\": \"UNIT 1, 1 SLOUGH BUSINESS PARK\", \"Requested_Local_Undertaking_Terms_and_Conditions\": \"\", \"Expiry_Condition\": \"As per format attached\", \"Available_With\": \"\", \"Applicant_Address_2\": \"\", \"Applicable_Rules\": \"\", \"Demand_Indicator\": \"\", \"Obligor_Instructing Party_Name\": \"\", \"Applicant_Address_3\": \"NEW SOUTH WALES, 2137\", \"Underlying_Transaction_Details\": \"\", \"Confirmation_Instruction\": \"\", \"Beneficiary_Address_3\": \"Hong Kong\", \"Delivery_To_Collection_By\": \"Please courier back to Applicant at Address for attention of Contact Person as indicated above. We are aware of the additional transit time of 3-5 working days.\", \"Application_Sub_Type\": \"\", \"Beneficiary_Fax_No\": \"+1 (415) 532-1457\", \"Advising_Bank_BIC\": \"\", \"Date_of_Expiry\": \"28-08-2020\", \"Charges\": \"\", \"Undertaking_Amount_CCY\": \"USD United States Dollar\"}"
				}
	"""
	data = request.json
	file_id = data.get('file_id')
	if file_id is None:
		return jsonify({"Status": "Failed", "Message": "Missing file_id"}), 400
	
	extracted_fields, message = get_extracted_fields_for_iso_mappings(file_id)
	if extracted_fields:
		return jsonify({"Status": "Success", "Data": extracted_fields}), 200
	else:
		return jsonify({"Status": "Failed", "Message": message}), 500
	


@app.route('/get_approved_files', methods=['GET'])
def get_approved_files():
	"""
	GET endpoint to retrieve files data for dashboard visualisation.
	URL: http://localhost:5000/get_approved_files
	Request Type: GET

	Returns:
		JSON response containing the files data or an error message.
		e.g.:
		{
			"Status": "Success",
			"Data": [
						{
								"file_id": 50,
								"file_name": "Sample_2_Mizuho",
								"corporate": "Reliance",
								"classification_status": "done",
								"classification_is_approved": true,
								"extraction_status": "done",
								"extraction_is_approved": true,
								"classification_rejected": false,
								"extraction_rejected": false,
								"validation_approved": true,
								"validation_rejected": false,
								"final_approval": false,
								"imported_date": "Tue, 30 Jul 2024 06:42:34 GMT",
								"file_type": "Bank Guarantee Form",
								"file_path": "https://onboardingdocstorage.blob.core.windows.net/onboardingdocstorage/Sample_2_Mizuho-20240730121234.pdf",
								"current_status": "validation approved"
							},
				.../
			]
		}
	"""

  
	files_data, message = get_files_data_for_approval_page()
	# Manipulate the status of file for ui
	for item in files_data:
		item["classification_status"] = manipulate_file_status(item["classification_status"])
		item["extraction_status"] = manipulate_file_status(item["extraction_status"])
		item["current_status"] = "validation approved"
		

	# Sort the data by file_id in descending order
	files_data = sorted(files_data, key=lambda x: x['file_id'], reverse=True)

	if files_data:
		return jsonify({"Status": "Success", "Data": files_data}), 200
	else:
		return jsonify({"Status": "Failed", "Message": message}), 500


@app.route('/get-extracted-html', methods=['POST'])
def fetch_extracted_html():
	"""
	Fetch the extracted HTML for a given file_id.

	This endpoint calls the get_extracted_html function, which retrieves
	the extracted_html from the database for the specified file_id.

	Args:
		file_id (int): The ID of the file for which the extracted HTML is requested.

	Returns:
		JSON response with the following structure:
			- success (bool): Indicates whether the operation was successful.
			- extracted_html (str): The extracted HTML content if found (present only if success is True).
			- error (str): Error message if the operation failed (present only if success is False).
		
		HTTP Status Codes:
			- 200 OK: If the extracted_html was found and returned successfully.
			- 400 Bad Request: If there was an error in fetching the extracted_html.
	"""
	data = request.json
	file_id = data.get('file_id')
	success, result = get_extracted_html(file_id)
	logger.info(f"In extracting html api \n Success: {success}, Result: {result}")
	if success:
		return jsonify({"success": True, "extracted_html": result}), 200
	else:
		return jsonify({"success": False, "error": result}), 400



@app.route('/get-validation-html', methods=['POST'])
def fetch_validation_html():
	"""
	Fetch the extracted HTML for a given file_id.

	This endpoint calls the get_validation_html function, which retrieves
	the validation_html from the database for the specified file_id.

	Args:
		file_id (int): The ID of the file for which the extracted HTML is requested.

	Returns:
		JSON response with the following structure:
			- success (bool): Indicates whether the operation was successful.
			- validation_html (str): The extracted HTML content if found (present only if success is True).
			- error (str): Error message if the operation failed (present only if success is False).
		
		HTTP Status Codes:
			- 200 OK: If the validation_html was found and returned successfully.
			- 400 Bad Request: If there was an error in fetching the validation_html.
	"""
	data = request.json
	file_id = data.get('file_id')
	success, result = get_validation_html(file_id)
	logger.info(f"In extracting html api \n Success: {success}, Result: {result}")
	if success:
		return jsonify({"success": True, "validation_html": result}), 200
	else:
		return jsonify({"success": False, "error": result}), 400



@app.route('/get_validation_fields_for_onboarding_doc', methods=['POST'])
def get_validation_fields_for_onboarding_doc():
	"""
	POST endpoint to retrieve extracted fields.

	URL: http://localhost:5000/get_validation_fields_for_onboarding_doc

	Request JSON Payload:
	{
		"file_id": int
	}

	Returns:
		JSON response containing the extracted fields or an error message.
		e.g.: {
					"Status": "Success",
					"Data": "JSON RESPONSE"                
			}
	"""
	data = request.json
	file_id = data.get('file_id')

	if file_id is None:
		return jsonify({"Status": "Failed", "Message": "Missing file_id"}), 400

	extracted_fields, message = get_validation_fields_for_iso_mappings(file_id)
	if extracted_fields:
		return jsonify({"Status": "Success", "Data": extracted_fields}), 200
	else:
		return jsonify({"Status": "Failed", "Message": message}), 500


@app.route('/share_validated_json_with_iTurmeric_api', methods=['POST'])
def share_validated_json_with_iTurmeric_api():
	data = request.json
	file_id = data.get('file_id')

	if not file_id:
		return jsonify({"error": "file_id is required"}), 400
	
	validation_json, message = get_validation_fields_for_iso_mappings(file_id)
	
	if validation_json is None:
		return jsonify({"error": message}), 500
	
	try:
		payload = {
			"shared_json": validation_json
		}
		# External API URL
		url = "https://turmericpoc.intellectdesign.com/OFRuntime/publisher/EA_docu_check"
		
		# Send POST request to the external API
		headers = {'Content-Type': 'application/json'}
		response = requests.post(url, data=json.dumps(payload), headers=headers)
		
		# Check if the request was successful
		if response.status_code == 200:
			return jsonify({"message": "Data successfully sent to the external API", "response": response.json()["msg"]}), 200
		else:
			logger.error(f"Error sending data to external API: {response.text}")
			return jsonify({"message": "Failed to send data to the external API", "response": response.text}), response.status_code
	except requests.exceptions.RequestException as e:
		logger.error(f"Request exception: {e}")
		return jsonify({"message": "Error occurred while sending data to external API", "exception": str(e)}), 500



@app.route('/share_extracted_json_with_iTurmeric_api', methods=['POST'])
def share_extracted_json_with_iTurmeric_api():
	data = request.json
	file_id = data.get('file_id')

	if not file_id:
		return jsonify({"error": "file_id is required"}), 400
	
	validation_json, message = get_extracted_fields_for_iso_mappings(file_id)
	
	if validation_json is None:
		return jsonify({"error": message}), 500
	
	try:
		payload = {
			"shared_json": validation_json
		}
		# External API URL
		url = "https://turmericpoc.intellectdesign.com/OFRuntime/publisher/EA_docu_check"
		
		# Send POST request to the external API
		headers = {'Content-Type': 'application/json'}
		response = requests.post(url, data=json.dumps(payload), headers=headers)
		
		# Check if the request was successful
		if response.status_code == 200:
			return jsonify({"message": "Data successfully sent to the external API", "response": response.json()["msg"]}), 200
		else:
			logger.error(f"Error sending data to external API: {response.text}")
			return jsonify({"message": "Failed to send data to the external API", "response": response.text}), response.status_code
	except requests.exceptions.RequestException as e:
		logger.error(f"Request exception: {e}")
		return jsonify({"message": "Error occurred while sending data to external API", "exception": str(e)}), 500


@app.route('/save_draft_for_extracted_html', methods=['POST'])
def save_draft_for_extracted_html():
	"""
	API endpoint to update the extracted_html in the sections_table_mapping table.
	Expects a JSON body with 'file_id' and 'html_content'.

	Returns:
	Response: JSON response with a success message or error details.
	"""
	data = request.json

	file_id = data.get('file_id')
	html_content = data.get('html_content')

	if not file_id or not html_content:
		return jsonify({'error': 'file_id and html_content are required'}), 400

	result = update_extracted_html(file_id, html_content)

	completion_response = invoke_asset_staging(Asset_for_html_to_json_converted, 
												str(html_content))
	logger.info(f"HTML to JSON converted response: {completion_response}")
	completion_response = extract_json_content(completion_response[0])
	completion_response = json.loads(completion_response)
	
	logger.info(f"Loading of JSON : {completion_response},{type(completion_response)}")
	db_storage_result, msg = update_extracted_results(file_id, completion_response)
			
	if not db_storage_result:
		logger.error(f"Failed to add json data into db because of error: {msg}")

	if 'error' in result:
		return jsonify(result), 500

	return jsonify({'message': 'Draft saved successfully'}), 200


@app.route('/update_extractor_status_to_approved_with_file_id', methods=['POST'])
def update_extractor_status_to_approved_with_file_id():
	"""
		POST endpoint to update field status to 'Rejected = True' 
		URL: http://localhost:5000/update_extractor_status_to_approved_with_file_id

		Request JSON Payload:
			{
				"file_id": int
			}
		e.g.: {"file_id":7}

		Returns:
			JSON response indicating the success or failure of the update operation.
			e.g.: {
					"Status": "Success",
					"Message": "Update successful"
				}
	"""
	data = request.json
	file_id = data.get('file_id')

	if file_id is None:
		return jsonify({"Status": "Failed", "Message": "Missing file_id"}), 400

	db_status_update_response, msg = update_extractor_files_status_approved(file_id, True)
	if db_status_update_response:
		return jsonify({"Status": "Success", "Message": msg}), 200
	else:
		return jsonify({"Status": "Failed", "Message": msg}), 500
	
@app.route('/get_user_info', methods=['GET'])
def get_user_info():
	"""
	Retrieves the user's information from the session, including their username and profile picture URL.
	
	Returns:
		A JSON response containing the user's information, or an error message if the user is not logged in.
	"""
 	
	# Check if the session has user data
	if 'profile' in session:
		user_profile = session['profile']
		user_info = {
			'username': user_profile.get('name'),
			'profile_picture': user_profile.get('picture')
		}
		return jsonify(user_info), 200
	else:
		return jsonify({'error': 'User not logged in'}), 401




@app.route('/get_page_wise_extracted_html', methods=['POST'])
def fetch_page_wise_extracted_html():
    """
    Fetch the extracted HTML for a given file_id and page_number.

    This endpoint retrieves the extracted HTML from the database for the specified
    file_id and page_number using the get_page_wise_extracted_html function.

    Args:
        file_id (int): The ID of the file for which the extracted HTML is requested.
        page_number (int): The page number of the file for which the HTML is requested.

    Returns:
        JSON response with the following structure:
            - success (bool): Indicates whether the operation was successful.
            - extracted_html (str): The extracted HTML content if found (present only if success is True).
            - error (str): Error message if the operation failed (present only if success is False).
        
        HTTP Status Codes:
            - 200 OK: If the extracted_html was found and returned successfully.
            - 400 Bad Request: If there was an error in fetching the extracted_html.
    """
    try:
        data = request.json
        file_id = data.get('file_id')
        page_number = data.get('page_number')
        
        if not file_id or not page_number:
            return jsonify({"success": False, "error": "file_id and page_number are required"}), 400
        
        # Fetch the extracted HTML using the helper function
        success, result = get_page_wise_extracted_html(file_id, page_number)
        if success:
            return jsonify({"success": True, "extracted_html": result}), 200
        else:
            return jsonify({"success": False, "error": result}), 400
    
    except Exception as e:
        logger.error(f"Error in fetch_page_wise_extracted_html API: {e}")
        return jsonify({"success": False, "error": "Internal Server Error"}), 500

@app.route('/get_page_wise_validated_html', methods=['POST'])
def fetch_page_wise_validated_html():
    """
    Fetch the validated HTML for a given file_id and page_number.

    This endpoint retrieves the validated HTML from the database for the specified
    file_id and page_number using the get_page_wise_validated_html function.

    Args:
        file_id (int): The ID of the file for which the validated HTML is requested.
        page_number (int): The page number of the file for which the HTML is requested.

    Returns:
        JSON response with the following structure:
            - success (bool): Indicates whether the operation was successful.
            - validated_html (str): The validated HTML content if found (present only if success is True).
            - error (str): Error message if the operation failed (present only if success is False).
        
        HTTP Status Codes:
            - 200 OK: If the validated_html was found and returned successfully.
            - 400 Bad Request: If there was an error in fetching the validated_html.
    """
    try:
        data = request.json
        file_id = data.get('file_id')
        page_number = data.get('page_number')
        
        if not file_id or not page_number:
            return jsonify({"success": False, "error": "file_id and page_number are required"}), 400
        
        # Fetch the validated HTML using the helper function
        success, result = get_page_wise_validated_html(file_id, page_number)
        if success:
            return jsonify({"success": True, "validated_html": result}), 200
        else:
            return jsonify({"success": False, "error": result}), 400
    
    except Exception as e:
        logger.error(f"Error in fetch_page_wise_validated_html API: {e}")
        return jsonify({"success": False, "error": "Internal Server Error"}), 500

@app.route('/save_draft_for_page_wise_extracted_html', methods=['POST'])
def save_draft_for_page_wise_extracted_html():
    """
    API endpoint to update the extracted_html in the file_page_content table for a specific page.
    Expects a JSON body with 'file_id', 'page_number', and 'html_content'.

    Returns:
    Response: JSON response with a success message or error details.
    """
    try:
        # Parse the JSON data from the request
        data = request.json

        # Extract the necessary parameters
        file_id = data.get('file_id')
        page_number = data.get('page_number')
        html_content = data.get('html_content')

        # Validate that all required parameters are present
        if not file_id or not page_number or not html_content:
            return jsonify({'error': 'file_id, page_number, and html_content are required'}), 400

        # Update the extracted HTML for the specified page
        result = update_extracted_html_page_wise(file_id, page_number, html_content)

        # Invoke any additional processing (if needed)
        completion_response = invoke_asset_staging(Asset_for_html_to_json_converted, str(html_content))
        logger.info(f"HTML to JSON converted response: {completion_response}")
        completion_response = extract_json_content(completion_response[0])
        completion_response = json.loads(completion_response)
        
        logger.info(f"Loading of JSON : {completion_response},{type(completion_response)}")

        # Store the extracted results into the database
        db_storage_result, msg = update_extracted_results_page_wise(file_id, page_number, completion_response)
        
        if not db_storage_result:
            logger.error(f"Failed to add JSON data into db because of error: {msg}")
            return jsonify({'error': 'Failed to store JSON data', 'details': msg}), 500

        # Check for errors in updating the HTML
        if 'error' in result:
            return jsonify(result), 500

        db_save_json,db_msg = extract_and_store_json(file_id)
        if not db_save_json:
            logger.error(f"Failed to add consolidated JSON data into db because of error: {db_msg}")
        
		# Return a success message
        return jsonify({'message': 'Draft saved successfully for page ' + str(page_number)}), 200
    
    except Exception as e:
        logger.error(f"Error in save_draft_for_page_wise_extracted_html API: {e}")
        return jsonify({'error': 'Internal Server Error'}), 500





@app.route('/submit_jsons', methods=['POST'])
def submit_jsons():
    data = request.get_json()
    submissions = data.get('submissions')

    if not submissions:
        return jsonify({'Status': 'Error', 'Message': 'No submissions provided'}), 400

    responses = []

    for submission in submissions:
        api_url = submission.get('apiUrl')
        content = submission.get('content')

        parsed_json = json.loads(content)  # Validate JSON
        logger.info(parsed_json)

		# Define the headers
        headers = {
			'Content-Type': 'application/json'
		}
        # Send the POST request to the external system

        try:
            response = requests.post(api_url, json=parsed_json, headers=headers)

            # Raise an error if the status code indicates a problem
            # response.raise_for_status()
            if response.status_code >= 200 and response.status_code < 300:
				# Check if the response content is not empty
            	if response.content:
					# Parse and return the response as JSON
            		customer_creation_response = response.text
            	else:
					# Handle empty response (e.g., HTTP 202 with no content)
            		customer_creation_response = {'message': 'No response body. The request was accepted and is being processed.'}

				# Return the successful response with details
            	responses.append({
						'apiUrl': api_url,
						'data': customer_creation_response
					})
            else:
                responses.append({
                    'apiUrl': api_url,
                    'error': f'Status Code: {response.status_code}, Message: {response.text}'
                })

        except json.JSONDecodeError:
            responses.append({
                'apiUrl': api_url,
                'error': 'Invalid JSON format'
            })
        except Exception as e:
            responses.append({
                'apiUrl': api_url,
                'error': str(e)
            })

    return jsonify({'Status': 'Success', 'Responses': responses}), 200




@app.route('/customer_create', methods=['POST'])
def create_customer():
    """
    API endpoint to create a customer by sending the provided payload to an external system.
    Expects a JSON body with the customer creation payload.

    Returns:
    Response: JSON response with a success message or error details.
    """
    try:
        # Parse the JSON data from the request (payload from UI)
        data = request.json
        
        # Validate that the payload is present
        if not data:
            return jsonify({'error': 'Payload is required'}), 400

        # Convert the payload to JSON string
        payload_json = json.dumps(data)
        logger.info(payload_json)
        # Define the headers
        headers = {
            'Content-Type': 'application/json'
        }

        # Send the POST request to the external system
        try:
            response = requests.post(customer_creation_url, data=payload_json, headers=headers)

            # Raise an error if the status code indicates a problem
            response.raise_for_status()

            # Check if the response content is not empty
            if response.content:
                # Parse and return the response as JSON
                customer_creation_response = response.text
            else:
                # Handle empty response (e.g., HTTP 202 with no content)
                customer_creation_response = {'message': 'No response body. The request was accepted and is being processed.'}

            # Return the successful response with details
            return jsonify({
                'message': 'Customer created successfully',
                'customer_creation_response': customer_creation_response
            }), 200

        except requests.exceptions.HTTPError as http_err:
            return jsonify({'error': f"HTTP error occurred: {http_err}", 'details': response.text}), 500
        except Exception as err:
            return jsonify({'error': f"Other error occurred: {err}"}), 500

    except Exception as e:
        return jsonify({'error': f'Internal Server Error: {e}'}), 500


@app.route('/get_third_party_data_by_file_id', methods=['POST'])
def get_third_party_data_by_file_id():
    """
    POST endpoint to fetch all JSON data associated with a given file_id from the third_party_data table.
    
    URL: http://localhost:5000/get_third_party_data_by_file_id

    Request JSON Payload:
        {
            "file_id": int
        }
    e.g.: {"file_id": 7}

    Returns:
        JSON response containing all the final_json entries for the given file_id.
    """
    data = request.json
    file_id = data.get('file_id')

    # Validate file_id
    if file_id is None:
        return jsonify({"Status": "Failed", "Message": "Missing file_id"}), 400

    # Call the database operation to fetch the third-party data by file_id
    success, result = fetch_third_party_data_by_file_id(file_id)

    if success:
        return jsonify({"Status": "Success", "Data": result}), 200
    else:
        return jsonify({"Status": "Failed", "Message": result}), 404 if "No data found" in result else 500



@app.route('/update_json_and_save_draft', methods=['POST'])
def update_json_and_save_draft():
    """
    POST endpoint to update final_json based on file_id and API_url and invoke the save draft operation.
    
    URL: http://localhost:5000/update_json_and_save_draft

    Request JSON Payload:
        {
            "file_id": int,
            "api_url": str,
            "draft_data": dict or str
        }
    e.g.: 
    {
        "file_id": 7,
        "api_url": "https://api.example.com/data",
        "new_json": {...},
        "draft_data": {...}
    }

    Returns:
        JSON response indicating the success or failure of the update and save draft operations.
    """
    data = request.json
    file_id = data.get('file_id')
    api_url = data.get('api_url')
    draft_data = data.get('draft_data')

    # Validate input
    if not file_id or not api_url or not draft_data:
        return jsonify({"Status": "Failed", "Message": "Missing required parameters"}), 400

    # Step 1: Update the final_json based on the file_id and API_url
    update_success, update_message = update_json_by_file_id_and_api_url(file_id, api_url, draft_data)
    if not update_success:
        return jsonify({"Status": "Failed", "Message": update_message}), 500

    # If both operations succeed
    return jsonify({"Status": "Success", "Message": "Update and save draft operations completed successfully"}), 200




@app.route('/perform_ocr', methods=['POST'])
def perform_ocr():
    try:
        # Get data from request
        data = request.get_json()
        image_data = data['image']

        # Decode the base64 image
        image_bytes = base64.b64decode(image_data.split(',')[1])
        image = Image.open(io.BytesIO(image_bytes)).convert('RGB')

        # Save image temporarily
        temp_image_path = 'static/output_images/'+'temp_image.jpg'
        image.save(temp_image_path)

        # Call the GPT4O model with the image
        prompt = "Please extract the text from the provided image and return only the extracted text."
        extracted_text = call_azure_gpt4o([temp_image_path], prompt)
        print("here",extracted_text)

        # result = invoke_asset_with_image("b5a8bbf0-e0c1-4b46-a387-074c2b3cc016",#"96d0c9ba-9df5-4b00-a707-469587be3dfd", 
		# 			"", 
		# 			temp_image_path,
		# 			'document')

        # extracted_text = result["response"]["output"][0]["debug_logs"][0]["raw_response"]
        # logger.info(extracted_text)

        # Optionally remove the temp image
        if os.path.exists(temp_image_path):
            os.remove(temp_image_path)

        return jsonify({'success': True, 'text': extracted_text.strip()})
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'error': 'An error occurred during OCR processing.'}), 500

@app.route('/get_page_wise_extracted_json', methods=['POST'])
def fetch_page_wise_extracted_json():
    """
    Fetch the extracted JSON for a given file_id and page_number.

    This endpoint retrieves the extracted JSON from the database for the specified
    file_id and page_number using the get_page_wise_extracted_json function.

    Args:
        file_id (int): The ID of the file for which the extracted JSON is requested.
        page_number (int): The page number of the file for which the JSON is requested.

    Returns:
        JSON response with the following structure:
            - success (bool): Indicates whether the operation was successful.
            - extracted_json (dict): The extracted JSON content if found (present only if success is True).
            - error (str): Error message if the operation failed (present only if success is False).
        
        HTTP Status Codes:
            - 200 OK: If the extracted_json was found and returned successfully.
            - 400 Bad Request: If there was an error in fetching the extracted_json.
    """
    try:
        data = request.json
        file_id = data.get('file_id')
        page_number = data.get('page_number')
        
        if not file_id or not page_number:
            return jsonify({"success": False, "error": "file_id and page_number are required"}), 400
        
        # Fetch the extracted JSON using the helper function
        success, result = get_page_wise_extracted_json(file_id, page_number)
        if success:
            return jsonify({"success": True, "extracted_json": result}), 200
        else:
            return jsonify({"success": False, "error": result}), 400
    
    except Exception as e:
        logger.error(f"Error in fetch_page_wise_extracted_json API: {e}")
        return jsonify({"success": False, "error": "Internal Server Error"}), 500

@app.route('/save_draft_for_page_wise_extracted_json', methods=['POST'])
def save_draft_for_page_wise_extracted_json():
    """
    Save the extracted JSON draft for a given file_id and page_number.
    
    This endpoint saves or updates the extracted JSON in the database for the specified
    file_id and page_number.
    
    Args:
        file_id (int): The ID of the file for which the extracted JSON is being saved.
        page_number (int): The page number of the file for which the JSON is being saved.
        extracted_json (dict): The extracted JSON content to be saved.
    
    Returns:
        JSON response with the following structure:
            - success (bool): Indicates whether the operation was successful.
            - message (str): Success or error message.
        
        HTTP Status Codes:
            - 200 OK: If the extracted_json was saved successfully.
            - 400 Bad Request: If there was an error in saving the extracted_json.
    """
    try:
        data = request.json
        file_id = data.get('file_id')
        page_number = data.get('page_number')
        extracted_json = data.get('extracted_json')
        
        if not file_id or not page_number or extracted_json is None:
            return jsonify({"success": False, "error": "file_id, page_number, and extracted_json are required"}), 400
        logger.info(data)
        # Save the extracted JSON using the helper function
        success, result = update_extracted_json_page_wise(file_id, page_number, extracted_json)
        if success:
            return jsonify({"success": True, "message": result}), 200
        else:
            return jsonify({"success": False, "error": result}), 400
        
    except Exception as e:
        logger.error(f"Error in save_draft_for_page_wise_extracted_json API: {e}")
        return jsonify({"success": False, "error": "Internal Server Error"}), 500

# def get_page_wise_extracted_json(file_id, page_number):
#     """
#     Helper function to fetch extracted JSON for a given file_id and page_number from the database.

#     Args:
#         file_id (int): The ID of the file for which the extracted JSON is requested.
#         page_number (int): The page number of the file for which the JSON is requested.

#     Returns:
#         tuple:
#             - success (bool): Indicates whether the operation was successful.
#             - result (dict): The extracted JSON content if found or an error message.
#     """
#     try:
#         # Get a database connection
#         conn = get_db_connection()
#         if conn is None:
#             return False, "Connection to database failed"
        
#         cur = conn.cursor()

#         # SQL query to fetch the extracted JSON for the given file_id and page_number
#         query = '''
#             SELECT page_wise_extracted_json
#             FROM file_page_content
#             WHERE file_id = %s AND page_number = %s;
#         '''
#         cur.execute(query, (file_id, page_number))
#         result = cur.fetchone()

#         cur.close()
#         release_db_connection(conn)

#         if result and result[0]:
#             # Ensure the JSON data is returned as a dictionary
#             return True, result[0]
#         else:
#             return False, "No extracted JSON found for the given file_id and page_number"
    
#     except (Exception, psycopg2.Error) as e:
#         logger.error(f"Error fetching page-wise extracted JSON from the database: {e}")
#         return False, f"Database error: {e}"


# Load TrOCR model and processor at the start
# device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# processor = TrOCRProcessor.from_pretrained('microsoft/trocr-large-handwritten')  # Use 'microsoft/trocr-base-printed' for printed text
# model = VisionEncoderDecoderModel.from_pretrained('microsoft/trocr-large-handwritten').to(device)

# processor = TrOCRProcessor.from_pretrained('microsoft/trocr-base-printed')  # Use 'microsoft/trocr-base-printed' for printed text
# model = VisionEncoderDecoderModel.from_pretrained('microsoft/trocr-base-printed').to(device)

# Initialize EasyOCR Reader
# reader = easyocr.Reader(['en'], gpu=False)  # Set gpu=True if you have a GPU

# @app.route('/perform_ocr', methods=['POST'])
# def perform_ocr():
#     try:
#         # Get data from request
#         data = request.get_json()
#         image_data = data['image']

#         # Decode the base64 image
#         image_bytes = base64.b64decode(image_data.split(',')[1])
#         image = Image.open(io.BytesIO(image_bytes)).convert('RGB')

#         # Convert PIL image to OpenCV format
#         image_np = np.array(image)
#         image_cv = cv2.cvtColor(image_np, cv2.COLOR_RGB2BGR)

#         # Perform OCR using EasyOCR
#         result = reader.readtext(image_cv)

#         # Concatenate text from result
#         extracted_text = ' '.join([res[1] for res in result])
#         print("hello",extracted_text)

#         return jsonify({'success': True, 'text': extracted_text.strip()})
#     except Exception as e:
#         print(f"Error: {e}")
#         return jsonify({'error': 'An error occurred during OCR processing.'}), 500

# def perform_ocr():
#     try:
#         data = request.get_json()
#         image_data = data['image']

#         # Decode the base64 image
#         header, encoded = image_data.split(",", 1)
#         image_bytes = base64.b64decode(encoded)
#         image = Image.open(io.BytesIO(image_bytes)).convert("RGB")

#         # Perform OCR using TrOCR
#         pixel_values = processor(images=image, return_tensors="pt").pixel_values
#         pixel_values = pixel_values.to(device)

#         generated_ids = model.generate(pixel_values)
#         generated_text = processor.batch_decode(generated_ids, skip_special_tokens=True)[0]

#         return jsonify({'success': True, 'text': generated_text})
#     except Exception as e:
#         print(f'Error during OCR: {e}')
#         return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/update_extractor_rejection_status', methods=['POST'])
def update_extractor_rejection_status():
    """
    Update the rejection status of a document in the extraction phase.

    Request JSON Payload:
    {
        "file_id": int,
        "rejection_reason": str
    }

    Returns:
        JSON response indicating success or failure of the rejection operation.
    """
    data = request.json
    file_id = data.get('file_id')
    rejection_reason = data.get('rejection_reason')

    if file_id is None or rejection_reason is None:
        return jsonify({"Status": "Failed", "message": "Missing required fields"}), 200

    # Update the rejection status
    db_status_update_response, msg = update_files_status_field(file_id, "extraction_rejected", True)
    
    if not db_status_update_response:
        return jsonify({"Status": "Failed", "message": f"Failed to update rejection status: {msg}"}), 200

    # Store the rejection reason
    db_reason_update_response, msg = update_rejection_reason(file_id, "extraction_rejection_reason", rejection_reason)
    
    if not db_reason_update_response:
        return jsonify({"Status": "Failed", "message": f"Failed to store rejection reason: {msg}"}), 200

    return jsonify({"Status": "Success", "message": "Document rejected successfully"}), 200


@app.route('/update_validator_rejection_status', methods=['POST'])
def update_validator_rejection_status():
    """
    Update the rejection status of a document in the validation phase.

    Request JSON Payload:
    {
        "file_id": int,
        "rejection_reason": str
    }

    Returns:
        JSON response indicating success or failure of the rejection operation.
    """
    data = request.json
    file_id = data.get('file_id')
    rejection_reason = data.get('rejection_reason')

    if file_id is None or rejection_reason is None:
        return jsonify({"Status": "Failed", "message": "Missing required fields"}), 200

    # Update the rejection status
    db_status_update_response, msg = update_files_status_field(file_id, "validation_rejected", True)
    
    if not db_status_update_response:
        return jsonify({"Status": "Failed", "message": f"Failed to update rejection status: {msg}"}), 200

    # Store the rejection reason
    db_reason_update_response, msg = update_rejection_reason(file_id, "validation_rejection_reason", rejection_reason)
    
    if not db_reason_update_response:
        return jsonify({"Status": "Failed", "message": f"Failed to store rejection reason: {msg}"}), 200

    return jsonify({"Status": "Success", "message": "Document rejected successfully"}), 200


if __name__ == '__main__':
	app.run(debug=True,host="0.0.0.0", port=5000)


