"""
Retrieves relevant documents based on the provided file ID or mapping ID, and generates a chat response using the retrieved documents and a provided chat prompt template.

The `getRetriever` function retrieves documents from a vector database based on the provided file ID or mapping ID. 
The `ChatWithPdf` function generates a chat response using the retrieved documents and a provided chat prompt template. 
The `get_text` function retrieves the relevant text from the vector database based on the provided question and document identifiers. 
The `store_text_in_vecdb` function stores extracted text data into the vector database.
"""


"""
Imports the pysqlite3 module and replaces the sqlite3 module with it.

This code is used to work around an issue where the sqlite3 module is not available, and the pysqlite3 module needs to be used instead. 
It imports the pysqlite3 module and then replaces the sqlite3 module with it, so that any code that expects to use sqlite3 will actually use pysqlite3 instead.
"""
__import__('pysqlite3')
import sys
sys.modules['sqlite3'] = sys.modules.pop('pysqlite3')

from langchain.prompts import ChatPromptTemplate
from langchain.schema.output_parser import StrOutputParser
from langchain.schema.runnable import RunnablePassthrough
from langchain_core.documents.base import Document

from configs import model, embeddings, vectordb
from logger import logger


def getRetriever(fileId=None, mapping_id=None):
    """
    Retrieve documents based on the provided file ID or mapping ID.

    Args:
        fileId (str, optional): The ID of the file.
        mapping_id (str, optional): The ID of the mapping.

    Returns:
        retriever: The retriever object configured with the search criteria.
    """
    logger.info(f"Getting Retrieval for file: {mapping_id}")
    retriever = vectordb.as_retriever(search_kwargs={'k': 1,
                                                     'filter': {"document_id": mapping_id}})
    return retriever


def ChatWithPdf(template, fileId=None, mapping_id=None, question=None):
    """
    Generate a chat response based on the provided template and document.

    Args:
        template (str): The chat prompt template.
        fileId (str, optional): The ID of the file.
        mapping_id (str, optional): The ID of the mapping.
        question (str, optional): The user's question.

    Returns:
        str: The generated chat response.
    """
    prompt = ChatPromptTemplate.from_template(template)
    retriever = getRetriever(fileId, mapping_id)
    chain = (
        {"context": retriever, "question": RunnablePassthrough()}
        | prompt
        | model
        | StrOutputParser()
    )

    res = chain.invoke(template)
    return res


def get_text(fileId=None, mapping_id=None, question=None):
    """
    Retrieve relevant text based on the provided question and document identifiers.

    Args:
        fileId (str, optional): The ID of the file.
        mapping_id (str, optional): The ID of the mapping.
        question (str, optional): The user's question.

    Returns:
        Document: The relevant document.
    """
    retriever = vectordb.as_retriever(search_kwargs={'k': 1,
                                                     'filter': {"document_id": mapping_id}})
    return retriever.get_relevant_documents(question)[0]


def store_text_in_vecdb(mapping_id, extracted_text):
    """
    Store extracted text data into the vector database.

    Args:
        mapping_id (str): The ID of the mapping.
        extracted_text (str): The text to be stored.

    Returns:
        tuple: A tuple containing a boolean indicating success and a message.
    """
    try:
        # Create a new document
        new_doc = Document(page_content=extracted_text, metadata={"document_id": mapping_id})
        logger.debug(f"Created new document: {new_doc}")

        # Add the new document to the database
        vectordb.add_documents([new_doc], collection_name='cops')
        logger.debug("Added document to collection")

        # Persist the changes
        vectordb.persist()
        logger.debug("Persisted changes to ChromaDB")

        return True, "Done"
    except Exception as e:
        logger.error(f"An error occurred: {e}")
        return False, f"{e}"
